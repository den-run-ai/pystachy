#!/usr/bin/env python3
"""Materialize authorized artifact URLs, validating provider hashes and ZIP CRCs.

The transfer file is temporary and contains credentials. Output manifests never
contain download URLs. This script performs no GitHub writes or executable loads.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import urllib.request
import zipfile


def fetch_one(item, output):
    name = item['name']
    if not name or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for c in name):
        raise ValueError('unsafe artifact name')
    archive = output / 'archives' / f"{item['id']}-{name}.zip"
    archive.parent.mkdir(parents=True, exist_ok=True)
    if not archive.exists():
        partial = archive.with_suffix('.part')
        request = urllib.request.Request(item['url'], headers={'User-Agent': 'Pystachy-CI-review'})
        try:
            with urllib.request.urlopen(request, timeout=60) as response, partial.open('wb') as target:
                shutil.copyfileobj(response, target)
            partial.replace(archive)
        except Exception as error:
            # Some urllib exception representations include the signed URL.
            raise RuntimeError(f"artifact {item['id']} download failed ({type(error).__name__})") from None
    data = archive.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if len(data) != item['expected_size']:
        raise ValueError(f"artifact {item['id']} size mismatch")
    if item.get('expected_digest') and 'sha256:' + digest != item['expected_digest']:
        raise ValueError(f"artifact {item['id']} SHA-256 mismatch")
    area = 'original-reports' if name.startswith('verification-') else 'artifacts'
    destination = output / area / name
    members = []
    with zipfile.ZipFile(archive) as bundle:
        if bundle.testzip() is not None:
            raise ValueError(f"artifact {item['id']} ZIP CRC failure")
        for info in bundle.infolist():
            relative = PurePosixPath(info.filename)
            if relative.is_absolute() or '..' in relative.parts or '\\' in info.filename:
                raise ValueError(f"artifact {item['id']} unsafe ZIP path")
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError(f"artifact {item['id']} unexpected ZIP symlink")
            path = destination.joinpath(*relative.parts)
            if info.is_dir():
                path.mkdir(parents=True, exist_ok=True)
                continue
            content = bundle.read(info)
            path.parent.mkdir(parents=True, exist_ok=True)
            if path.exists() and path.read_bytes() != content:
                raise ValueError(f"artifact {item['id']} would replace different existing evidence")
            path.write_bytes(content)
            members.append({'path': info.filename, 'bytes': len(content), 'crc32': f'{info.CRC:08x}',
                            'sha256': hashlib.sha256(content).hexdigest()})
    return {'id': item['id'], 'name': name, 'run_id': item['run_id'],
            'archive': str(archive.relative_to(output)), 'bytes': len(data), 'sha256': digest,
            'provider_size_verified': True, 'provider_digest_verified': bool(item.get('expected_digest')),
            'zip_crc_verified': True, 'members': members}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('transfer', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--workers', type=int, default=4)
    args = parser.parse_args()
    items = json.loads(args.transfer.read_text())['artifacts']
    args.output.mkdir(parents=True, exist_ok=True)
    manifest = args.output / 'artifact-manifest.json'
    previous = json.loads(manifest.read_text()) if manifest.exists() else {'schema': 1, 'artifacts': []}
    by_id = {entry['id']: entry for entry in previous['artifacts']}
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(lambda item: fetch_one(item, args.output), items):
            if result['id'] in by_id and by_id[result['id']] != result:
                raise ValueError(f"artifact {result['id']} identity changed")
            by_id[result['id']] = result
            previous.update(checked_at=datetime.now(timezone.utc).isoformat(),
                            artifacts=sorted(by_id.values(), key=lambda entry: entry['name']))
            manifest.write_text(json.dumps(previous, indent=2, sort_keys=True) + '\n')
            print(f"{result['name']}: {result['bytes']} bytes; SHA-256 and ZIP CRC verified", flush=True)
    args.transfer.unlink()


if __name__ == '__main__':
    main()
