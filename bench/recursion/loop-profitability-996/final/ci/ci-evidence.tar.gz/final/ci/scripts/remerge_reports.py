#!/usr/bin/env python3
"""Run the reviewed repository's report gate, preserving inputs and its raw result."""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def comparable(report):
    result = copy.deepcopy(report)
    result.pop('timestamp_utc', None)
    for step in result['steps']:
        if isinstance(step.get('log'), str):
            marker = 'verification-' + step['ci_group'] + '/'
            assert marker in step['log'], step['log']
            step['log'] = marker + step['log'].split(marker, 1)[1]
    for group in result['ci']['groups']:
        marker = 'verification-' + group['group'] + '/'
        assert marker in group['report'], group['report']
        group['report'] = marker + group['report'].split(marker, 1)[1]
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--ci', type=Path, required=True)
    parser.add_argument('--review', type=Path, required=True)
    args = parser.parse_args()
    ci, review = args.ci.resolve(), args.review.resolve()
    binding = json.loads((ci / 'source-binding.json').read_text())
    git = lambda *argv: subprocess.check_output(['git', *argv], cwd=review, text=True).strip()
    assert git('rev-parse', 'HEAD') == binding['synthetic_merge']
    assert git('rev-parse', 'HEAD^{tree}') == binding['tree']
    assert not git('status', '--porcelain')
    plan = subprocess.check_output(['sh', 'tests/verify.sh', '--list'], cwd=review, text=True)
    groups = {row[0]: row[1:] for row in (line.split() for line in plan.splitlines())}
    directory = ci / 'original-reports'
    reports = sorted(directory.glob('verification-*/verification.json'))
    actual = {json.loads(path.read_text())['group']: path for path in reports}
    assert len(actual) == len(reports) == 31
    assert set(actual) == set(groups) - {'all'}
    before = {str(path.relative_to(ci)): digest(path) for path in reports}
    output = ci / 'remerged-verification.json'
    command = [sys.executable, str(review / 'tools/merge_verification.py'), str(directory), '-o', str(output)]
    run = subprocess.run(command, cwd=review, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'},
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
    (ci / 'verification-merge.log').write_bytes(run.stdout)
    after = {str(path.relative_to(ci)): digest(path) for path in reports}
    assert before == after, 'original reports changed'
    merged = json.loads(output.read_text())
    assessment = {'schema': 1, 'checked_at': datetime.now(timezone.utc).isoformat(),
                  'command': command, 'cwd': str(review), 'exit_code': run.returncode,
                  'controller_sha256': digest(review / 'tools/merge_verification.py'),
                  'head': binding['head'], 'synthetic_merge': binding['synthetic_merge'],
                  'result': merged['result'], 'original_reports': len(reports),
                  'original_report_sha256': before, 'original_reports_unchanged': True,
                  'logical_stages_expected': len(groups['all']),
                  'group_stage_records_expected': sum(len(rows) for name, rows in groups.items() if name != 'all'),
                  'merged_report_sha256': digest(output),
                  'log_sha256': digest(ci / 'verification-merge.log')}
    if run.returncode == 0 and merged['result'] == 'pass':
        assert merged['summary']['steps'] == merged['summary']['passed'] == 54
        assert merged['summary']['failed'] == 0 and len(merged['ci']['groups']) == 31
        assert sum(row['steps'] for row in merged['ci']['groups']) == 84
        assert merged['git']['commit'] == binding['synthetic_merge']
        published = ci / 'artifacts/verification/verification.json'
        other = json.loads(published.read_text())
        assert comparable(merged) == comparable(other), 'published and independently merged reports differ'
        assessment.update(logical_stages=54, group_stage_records=84,
                          published_report_sha256=digest(published),
                          published_report_matches=True,
                          comparison_ignores=['top-level timestamp_utc', 'local root prefix of steps[].log',
                                              'local root prefix of ci.groups[].report'])
    else:
        assessment['error'] = merged.get('error', 'report gate did not pass')
    (ci / 'verification-assessment.json').write_text(json.dumps(assessment, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: assessment.get(key) for key in ('result', 'exit_code', 'original_reports',
                                                          'logical_stages', 'group_stage_records',
                                                          'published_report_matches', 'error')}, sort_keys=True))
    return run.returncode


if __name__ == '__main__':
    sys.exit(main())
