#!/usr/bin/env python3
"""Review exact PR workflow and job membership; incomplete is never green."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess


HEAD = '44b638bbf8df1835b67bebda0468d65374569c71'
BASE = '07b26e02425d023288ed95a9d2a5077be5aeb45e'
MERGE = 'b20d3720ed557a6934e6ac10a6287a5610d2fc1f'
TREE = 'a1eddfe2c43d368b5c48ac79798501d8d7add552'
RUNS = {'Installation': 41269133843, 'Coverage': 41269133823, 'Lint': 41269133830, 'Packages': 41269133836, 'Performance smoke': 41269133825, 'CI': 41269133835, 'DCO': 41269131959}


def expected_jobs(review):
    plan = subprocess.check_output(['sh', 'tests/verify.sh', '--list'], cwd=review, text=True)
    rows = [line.split() for line in plan.splitlines()]
    groups = [row[0] for row in rows[1:]]
    assert len(groups) == 31 and len(rows[0]) - 1 == 54
    assert sum(len(row) - 1 for row in rows[1:]) == 84
    names = {
        'CI': [f'verify ({group})' for group in groups] + [
            'upstream port preservation (CPython)',
            'upstream large regex (JIT and AOT, normal GC)',
            'make verify (Linux x86-64, LLVM 18, Python 3.13)'],
        'Lint': ['make lint (ruff, shellcheck, clang -Wall -Wextra)'],
        'Coverage': [f'hosted compiler coverage (corpus {n} of 8)' for n in range(8)] + [
            'hosted compiler coverage (ffi, ir)', 'hosted compiler coverage (cache, unit)',
            'hosted compiler coverage (report)'] + [
            f'native runtime coverage (corpus {n} of 6)' for n in range(6)] + [
            'native runtime coverage (ffi)', 'native runtime coverage (report)',
            "publish main's coverage to the badges branch"],
        'Installation': [f'Install ({os})' for os in ('ubuntu-24.04', 'macos-15', 'macos-15-intel')],
        'Packages': ['source wheels (CPython, JIT and AOT)'],
        'Performance smoke': ['smoke'],
        'DCO': ['DCO certified (fork pull requests)'],
    }
    expected = {workflow: {name: 'success' for name in jobs} for workflow, jobs in names.items()}
    expected['DCO']['DCO certified (fork pull requests)'] = 'skipped'
    expected['Coverage']["publish main's coverage to the badges branch"] = 'skipped'
    assert sum(map(len, expected.values())) == 61
    return expected


def evaluate(snapshot, review):
    expected = expected_jobs(review)
    failures, pending, records = [], [], []
    counts = Counter()
    git = lambda *args: subprocess.check_output(['git', *args], cwd=review, text=True).strip()
    assert git('rev-parse', 'HEAD') == MERGE
    assert git('rev-parse', 'HEAD^{tree}') == TREE
    assert git('rev-parse', HEAD + '^{tree}') == TREE
    assert git('rev-list', '--parents', '-n', '1', MERGE).split() == [MERGE, BASE, HEAD]
    assert not git('status', '--porcelain'), 'review checkout changed'
    for workflow, members in expected.items():
        run = snapshot['runs'].get(workflow)
        if not run:
            pending.append(f'{workflow}: missing run metadata')
            continue
        if run['id'] != RUNS[workflow] or run['head_sha'] != HEAD:
            failures.append(f'{workflow}: wrong run/head identity')
        expected_event = 'pull_request_target' if workflow == 'DCO' else 'pull_request'
        if run['event'] != expected_event:
            failures.append(f'{workflow}: unexpected trigger')
        prs = [p for p in run['pull_requests'] if p['number'] == 996]
        if len(prs) != 1 or prs[0]['head']['sha'] != HEAD or prs[0]['base']['sha'] != BASE:
            failures.append(f'{workflow}: PR head/base association differs')
        conclusion = 'skipped' if workflow == 'DCO' else 'success'
        if run['status'] != 'completed':
            pending.append(f'{workflow}: workflow {run["status"]}')
        elif run['conclusion'] != conclusion:
            failures.append(f'{workflow}: workflow conclusion {run["conclusion"]}')
        page = snapshot['jobs'].get(workflow, {})
        jobs = page.get('jobs', [])
        if page.get('total_count') != len(jobs):
            pending.append(f'{workflow}: incomplete jobs pagination')
        observed = Counter(job['name'] for job in jobs)
        for name in sorted(set(members) - observed.keys()):
            pending.append(f'{workflow}: missing job {name}')
        if observed - Counter(members.keys()):
            failures.append(f'{workflow}: unexpected or duplicate jobs {dict(observed - Counter(members.keys()))}')
        for job in jobs:
            name = job['name']
            counts[job['conclusion'] or job['status']] += 1
            if job['head_sha'] != HEAD or job['run_id'] != run['id']:
                failures.append(f'{workflow}/{name}: job source/run identity differs')
            if job['status'] != 'completed':
                pending.append(f'{workflow}/{name}: {job["status"]}')
            elif name in members and job['conclusion'] != members[name]:
                failures.append(f'{workflow}/{name}: {job["conclusion"]}')
            for step in job.get('steps', []):
                if step['conclusion'] in ('failure', 'cancelled', 'timed_out', 'action_required'):
                    failures.append(f'{workflow}/{name}/{step["name"]}: {step["conclusion"]}')
            records.append({'workflow': workflow, 'name': name, 'id': job['id'],
                            'run_id': job['run_id'], 'run_attempt': job['run_attempt'],
                            'status': job['status'], 'conclusion': job['conclusion'],
                            'url': job['html_url'], 'started_at': job['started_at'],
                            'completed_at': job['completed_at']})
    failures.extend(str(item) for item in snapshot.get('errors', []))
    return {'schema': 1, 'checked_at': datetime.now(timezone.utc).isoformat(),
            'snapshot_at': snapshot['captured_at'], 'head': HEAD, 'base': BASE,
            'synthetic_merge': MERGE, 'tree': TREE, 'head_merge_tree_equal': True,
            'review_checkout_clean': True, 'result': 'fail' if failures else 'incomplete' if pending else 'pass',
            'expected_jobs': 61, 'expected_success': 59, 'expected_skipped': 2,
            'observed': dict(counts), 'failures': failures, 'pending': pending, 'jobs': records}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('snapshot', type=Path)
    parser.add_argument('--review', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = evaluate(json.loads(args.snapshot.read_text()), args.review)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: result[key] for key in ('result', 'observed', 'failures')}, sort_keys=True))


if __name__ == '__main__':
    main()
