"""Package only the final 44b638bb evidence; initial uploaded files stay frozen."""
import argparse
from collections import Counter, defaultdict
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

import pack_loop_profitability as p

p.SOURCE = p.ROOT / "prototype-996-final"
p.DEST = p.ROOT / "pystachy-evidence/bench/recursion/loop-profitability-996/final"
CONTROLLERS = {"measure.py", "kernels.py", "jit_measure.py", "corpus_compare.py", "jit_time.py", "focused_native.py"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def gzip_bytes(data):
    out = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=out, mtime=0, compresslevel=6) as target:
        target.write(data)
    result = out.getvalue()
    if gzip.decompress(result) != data:
        raise ValueError("gzip metadata roundtrip differs")
    return result


def write_bytes(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_bytes(data)
    temporary.chmod(0o644)
    temporary.replace(path)


def classify(relative, source):
    parts = relative.parts
    first = parts[0]
    if source.is_symlink():
        return {"disposition": "excluded", "reason": "LLVM/tool symlink", "link_target": os.readlink(source)}
    if "__pycache__" in parts or source.suffix == ".pyc":
        return {"disposition": "excluded", "reason": "generated Python bytecode"}
    if source.name == "pr-body.md" or source.name.endswith(".tmp") or source.suffix == ".url":
        return {"disposition": "excluded", "reason": "temporary publication/transport draft"}
    cache = any(part == "cache" or part.startswith("cache-") for part in parts[:-1])
    if ((cache and source.suffix in (".bc", ".o", ".so"))
            or ("tmp" in parts and source.suffix == ".bc" and not source.name.endswith(".optimized.bc"))):
        return {"disposition": "excluded", "reason": "generated runtime/cache binary; hash retained"}
    if p.native_binary(source):
        return {"disposition": "excluded", "reason": "generated native executable/object; hash retained"}
    if len(parts) == 1 and first in CONTROLLERS:
        return {"disposition": "direct", "destination": "scripts/" + first}
    if len(parts) == 1 and source.suffix in (".json", ".patch"):
        return {"disposition": "direct", "destination": "local/" + str(relative)}
    if first == "corpus-final" and len(parts) == 2 and source.name == "comparison.json":
        return {"disposition": "compressed-record", "destination": "local/" + str(relative) + ".gz"}
    if first == "corpus-final" and len(parts) == 2 and source.name in ("diagnostic-assessment.json", "independent-audit.json"):
        return {"disposition": "direct", "destination": "local/" + str(relative)}
    if first == "policy_final" and len(parts) == 2 and source.suffix == ".json":
        return {"disposition": "direct", "destination": "local/" + str(relative)}
    if str(relative) == "policy_final/focused-native/report.json":
        return {"disposition": "direct", "destination": "local/" + str(relative)}
    if first.startswith("jit-") and len(parts) == 2 and source.suffix == ".json":
        return {"disposition": "direct", "destination": "local/" + str(relative)}
    if first == "corpus-final":
        bundle = "corpus-final"
    elif first == "jit-policy-final":
        bundle = "jit-policy_final"
    elif first == "jit-native-time":
        bundle = "jit-native-time-incomplete"
    elif first == "jit-native-time-repeat":
        bundle = "jit-native-time-repeat"
    elif first == "policy_final" and ("focused-native" in parts or source.suffix == ".log"):
        bundle = "native-validation"
    elif first == "policy_final":
        bundle = "aot-policy_final"
    else:
        bundle = "run-records"
    return {"disposition": "archive", "bundle": bundle, "member": "local/" + str(relative)}


def inventory():
    entries = []
    for directory, dirs, files in os.walk(p.SOURCE):
        here = Path(directory)
        if here == p.SOURCE:
            dirs[:] = [name for name in dirs if name != "ci"]
        for name in sorted(files):
            source = here / name
            relative = source.relative_to(p.SOURCE)
            entries.append({"source": str(relative), "source_path": str(source), **p.state(source),
                            **classify(relative, source)})
    for name in ("pack_final_evidence.py", "pack_loop_profitability.py"):
        source = p.ROOT / name
        entries.append({"source": "@packaging/" + name, "source_path": str(source), **p.state(source),
                        "disposition": "archive", "bundle": "run-records", "member": "local/packaging/" + name})
    return sorted(entries, key=lambda entry: entry["source"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pack", action="store_true", help="owner explicitly authorized the heavy packaging window")
    args = parser.parse_args()
    if not args.pack:
        print("No packing performed. Pass --pack only in the authorized serial window.")
        return
    # These reviews may be written after measurements finish. Do not seal a
    # partial snapshot or infer a successful timing result from warmup output.
    for name in ("corpus-final/comparison.json", "corpus-final/independent-audit.json",
                 "jit-native-time/cleanup-assessment.json", "jit-native-time-repeat/report.json"):
        if not (p.SOURCE / name).is_file():
            raise ValueError("await final owner record: " + name)
    strict = json.loads((p.SOURCE / "corpus-final/comparison.json").read_text())
    if not strict.get("complete") or strict.get("recorded_cases") != 3924:
        raise ValueError("final corpus recorder is incomplete")
    entries = inventory()
    before = {entry["source"]: entry for entry in entries}
    grouped, mappings, archives = defaultdict(list), [], []
    for entry in entries:
        kind = entry["disposition"]
        if kind == "direct":
            mappings.append(p.copy_direct(entry, False))
        elif kind == "archive":
            grouped[entry["bundle"]].append(entry)
        elif kind == "compressed-record":
            source = Path(entry["source_path"])
            raw = source.read_bytes()
            compressed = gzip_bytes(raw)
            write_bytes(p.DEST / entry["destination"], compressed)
            mapping = p.public_entry(entry, digest(raw))
            mapping.update(encoding="gzip", compressed_sha256=digest(compressed), compressed_size=len(compressed))
            mappings.append(mapping)
            summary = {key: value for key, value in json.loads(raw).items() if key != "rows"}
            summary.update(summary_schema=1, omitted_rows=len(strict["rows"]), raw_comparison={
                "path": entry["destination"], "raw_sha256": mapping["sha256"], "raw_bytes": len(raw),
                "gzip_sha256": mapping["compressed_sha256"], "gzip_bytes": len(compressed)},
                summary_note="All original top-level fields except rows are retained. Full exact rows remain in the gzip addendum; strict failure is unchanged.")
            p.write_json(p.DEST / "local/corpus-final/comparison-summary.json", summary)
        else:
            sha = None if entry["symlink"] else p.sha256(Path(entry["source_path"]))
            p.stable(entry)
            mappings.append(p.public_entry(entry, sha))
    for name in sorted(grouped):
        if name == "corpus-final":
            for entry in grouped[name]:
                sha = p.sha256(Path(entry["source_path"]))
                p.stable(entry)
                mappings.append(p.public_entry(entry, sha))
        else:
            partial = p.ROOT / "final-pack-parts" / (name + ".json")
            if partial.exists():
                saved = json.loads(partial.read_text())
                if saved["source_snapshot"] != grouped[name]:
                    raise ValueError("independently packed sources changed: " + name)
                record, members = saved["record"], saved["members"]
                if (p.DEST / record["path"]).stat().st_size != record["compressed_bytes"]:
                    raise ValueError("independently packed archive changed: " + name)
            else:
                record, members = p.pack_archive(name, grouped[name], False)
            archives.append(record)
            mappings.extend(members)
    manifest = {"schema": 2, "source_root": str(p.SOURCE), "destination_root": str(p.DEST),
                "scope": "Final 44b638bb source, tree a1eddfe2c43d368b5c48ac79798501d8d7add552. Initial checkpoint and CI are separate.",
                "artifacts": sorted(mappings, key=lambda item: item["source"]), "archives": archives,
                "ci_deferred_to_separate_owner": True}
    staging = p.DEST / p.MANIFEST_NAME
    p.write_json(staging, manifest)
    trial = p.ROOT / "final-corpus-solid-trial"
    subprocess.run([sys.executable, p.ROOT / "solid_final_corpus.py", "--output", trial, "--dict-mib", "8"], check=True)
    solid = json.loads((trial / "archive-record.json").read_text())
    solid_mappings = json.loads((trial / "artifact-mappings.json").read_text())
    for entry in solid_mappings:
        if entry.get("transform") == "identity":
            for key in ("transform", "payload_size", "payload_mode", "payload_sha256", "shared_payload"):
                entry.pop(key, None)
    manifest["artifacts"] = sorted([entry for entry in mappings if entry.get("bundle") != "corpus-final"] + solid_mappings,
                                    key=lambda entry: entry["source"])
    manifest["archives"].append(solid)
    target = p.DEST / solid["path"]
    shutil.copyfile(trial / "corpus-final.tar.xz", target)
    target.chmod(0o644)
    if p.sha256(target) != solid["sha256"]:
        raise ValueError("solid archive copy differs")
    manifest["source_counts"] = dict(Counter(entry["disposition"] for entry in manifest["artifacts"]))
    manifest["mapping_semantics"] = "Source sha256/size/mode identify original bytes. gzip-decompress entries additionally identify exact IR payload bytes, checked against compiler records; identical raw aliases may share a member. Compressed-record entries recover exact source bytes after gzip decoding."
    manifest["preservation_note"] = "Raw stdout/stderr, commands, status, errors and completeness fields are unchanged. Both native-JIT attempts remain incomplete with zero timed samples; no elapsed result is derived from warmup."
    after = {entry["source"]: entry for entry in inventory()}
    if before != after:
        raise ValueError("final source evidence changed while packaging")
    manifest_raw = p.json_bytes(manifest)
    compressed = gzip_bytes(manifest_raw)
    manifest_relative = "local/artifact-manifest.json.gz"
    write_bytes(p.DEST / manifest_relative, compressed)
    shutil.move(staging, trial / "artifact-manifest.before-solid.json")
    manifest_record = {"path": manifest_relative, "sha256": digest(compressed), "bytes": len(compressed),
                       "raw_sha256": digest(manifest_raw), "raw_bytes": len(manifest_raw), "encoding": "gzip"}
    paths = {entry["destination"] for entry in manifest["artifacts"] if entry["disposition"] in ("direct", "compressed-record")}
    paths.update(record["path"] for record in manifest["archives"])
    paths.update((manifest_relative, "local/corpus-final/comparison-summary.json", "local/archive-sizes.json", "local/evidence-index.json"))
    sizes = {"schema": 1, "complete": True, "archives": manifest["archives"],
             "total_archive_bytes": sum(record["compressed_bytes"] for record in manifest["archives"]),
             "owned_publication_file_count": len(paths), "artifact_manifest": manifest_record,
             "source_counts": manifest["source_counts"], "note": "CI owner files and root README/report are separate. All archive members were read back and verified."}
    p.write_json(p.DEST / "local/archive-sizes.json", sizes)
    index = {"schema": 1, "scope": manifest["scope"], "full_manifest": manifest_record,
             "corpus_comparison_summary": "local/corpus-final/comparison-summary.json",
             "corpus_diagnostic_assessment": "local/corpus-final/diagnostic-assessment.json",
             "corpus_independent_audit": "local/corpus-final/independent-audit.json",
             "initial_native_jit_attempt": {"path": "local/jit-native-time/report.json", "complete": False, "timed_observations": 0},
             "repeat_native_jit_attempt": {"path": "local/jit-native-time-repeat/report.json", "complete": False, "timed_observations": 0},
             "archive_sizes": "local/archive-sizes.json", "archives": manifest["archives"], "intended_paths": sorted(paths)}
    p.write_json(p.DEST / "local/evidence-index.json", index)
    archive_by_path = {record["path"]: record for record in manifest["archives"]}
    files = []
    for relative in sorted(paths):
        path = p.DEST / relative
        sha = archive_by_path[relative]["sha256"] if relative in archive_by_path else p.sha256(path)
        files.append({"path": "final/" + relative, "repo_path": "bench/recursion/loop-profitability-996/final/" + relative,
                      "local_path": str(path), "size": path.stat().st_size, "sha256": sha})
    p.write_json(p.ROOT / "final-evidence-publication-files.json", {"schema": 1, "files": files, "file_count": len(files),
                                                                 "scope": "Final local evidence only; initial 39 files, initial CI, final CI and root report/README are separate."})
    (p.ROOT / "final-evidence-publication-files.txt").write_text("".join(entry["repo_path"] + "\n" for entry in files))
    print(json.dumps({"final_files": len(files), "total_archive_bytes": sizes["total_archive_bytes"],
                      "allowlist": str(p.ROOT / "final-evidence-publication-files.json")}, indent=2), flush=True)


if __name__ == "__main__":
    main()
