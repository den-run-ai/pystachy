"""Package PR 996 measurements; inventory is read-only and never compresses.

Run `pack --corpus-complete` only after the owner confirms the serial corpus
job has ended. CI is owned separately and is deliberately left out. This script
owns only local/, scripts/, and archives/ under the evidence destination.
"""
import argparse
from collections import Counter, defaultdict
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import shutil
import stat
import tarfile
import zlib


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "prototype-996"
DEST = ROOT / "pystachy-evidence/bench/recursion/loop-profitability-996"
CONTROLLERS = {"measure.py", "kernels.py", "jit_measure.py", "corpus_compare.py"}
ROLES = {"main", "baseline", "value", "policy"}
MANIFEST_NAME = "local/artifact-manifest.json"
REPORT_NAME = "local/archive-sizes.json"


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_bytes(json_bytes(value))
    temporary.chmod(0o644)
    temporary.replace(path)


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for data in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(data)
    return digest.hexdigest()


def state(path):
    value = path.lstat()
    return {"size": value.st_size, "mode": format(stat.S_IMODE(value.st_mode), "04o"),
            "mtime_ns": value.st_mtime_ns, "symlink": path.is_symlink()}


def native_binary(path):
    # User bitcode captures are deliberately retained. Only native executable
    # formats and runtime-cache object/bitcode payloads are omitted.
    if path.suffix in (".json", ".ll", ".log", ".stdout", ".stderr", ".msg", ".diff",
                       ".py", ".txt", ".patch", ".hashes", ".target", ".callgrind", ".bc"):
        return False
    with path.open("rb") as source:
        magic = source.read(4)
    return magic == b"\x7fELF" or magic[:2] == b"MZ" or magic in (
        b"\xfe\xed\xfa\xce", b"\xce\xfa\xed\xfe", b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe")


def classification(relative, path, include_corpus):
    parts = relative.parts
    first = parts[0]
    if first == "ci":
        return {"disposition": "deferred", "reason": "CI evidence is owned and integrated separately"}
    if (first == "corpus-policy" or first == "corpus-policy.log") and not include_corpus:
        return {"disposition": "deferred", "reason": "corpus owner has not authorized the completed snapshot"}
    if str(relative) == "pr-body.md":
        return {"disposition": "excluded", "reason": "temporary PR draft with publication placeholders; final report is owned separately"}
    if path.is_symlink():
        return {"disposition": "excluded", "reason": "tool symlink, not an evidence payload",
                "link_target": os.readlink(path)}
    if "__pycache__" in parts or path.suffix == ".pyc":
        return {"disposition": "excluded", "reason": "generated Python bytecode"}
    cache = any(part == "cache" or part.startswith("cache-") for part in parts[:-1])
    if cache and path.suffix in (".bc", ".o", ".so"):
        return {"disposition": "excluded", "reason": "generated runtime-cache binary; SHA-256 retained"}
    if native_binary(path):
        return {"disposition": "excluded", "reason": "generated native executable or object; SHA-256 retained"}
    if len(parts) == 1 and first in CONTROLLERS:
        return {"disposition": "direct", "destination": "scripts/" + first}
    if len(parts) == 1 and path.suffix in (".json", ".patch"):
        return {"disposition": "direct", "destination": "local/" + str(relative)}
    if first in ROLES and len(parts) == 2 and path.suffix == ".json":
        return {"disposition": "direct", "destination": "local/" + str(relative)}
    if first.startswith("jit-") and len(parts) == 2 and parts[1] == "report.json":
        return {"disposition": "direct", "destination": "local/" + str(relative)}
    if first == "corpus-policy" and len(parts) == 2 and parts[1] in (
            "comparison.json", "diagnostic-assessment.json"):
        return {"disposition": "direct", "destination": "local/" + str(relative)}
    if first in ROLES:
        bundle = "aot-" + first
    elif first.startswith("jit-"):
        bundle = "jit-" + parts[1] if len(parts) > 2 and parts[1] in ROLES else "jit-common"
    elif first == "analysis":
        bundle = "analysis"
    elif first == "corpus-policy" or first == "corpus-policy.log":
        bundle = "corpus-policy"
    else:
        bundle = "run-records"
    return {"disposition": "archive", "bundle": bundle, "member": "local/" + str(relative)}


def inventory(include_corpus=False):
    entries = []
    deferred_trees = {"ci": "Entire CI tree is owned and integrated separately"}
    if not include_corpus:
        deferred_trees["corpus-policy"] = "Entire corpus tree awaits owner confirmation that the job ended"
    for path in sorted(SOURCE.rglob("*")):
        relative = path.relative_to(SOURCE)
        if relative.parts[0] in deferred_trees:
            continue
        if not path.is_file() and not path.is_symlink():
            continue
        entries.append({"source": str(relative), "source_path": str(path), **state(path),
                        **classification(relative, path, include_corpus)})
    for name, reason in deferred_trees.items():
        if (SOURCE / name).exists():
            entries.append({"source": name + "/", "source_path": str(SOURCE / name),
                            "size": 0, "mode": "0755", "mtime_ns": 0, "symlink": False,
                            "disposition": "deferred", "reason": reason})
    # Keep the packaging utility inside an archive, leaving exactly four
    # measurement controllers directly readable under scripts/.
    path = Path(__file__).resolve()
    entries.append({"source": "@packaging/" + path.name, "source_path": str(path), **state(path),
                    "disposition": "archive", "bundle": "run-records",
                    "member": "local/packaging/" + path.name})
    return sorted(entries, key=lambda item: item["source"])


def plan(entries):
    groups = defaultdict(lambda: {"files": 0, "bytes": 0})
    for entry in entries:
        key = entry.get("bundle", entry["disposition"])
        groups[key]["files"] += 1
        groups[key]["bytes"] += entry["size"]
    bundles = sorted({entry["bundle"] for entry in entries if entry["disposition"] == "archive"})
    direct = [entry["destination"] for entry in entries if entry["disposition"] == "direct"]
    return {"source": str(SOURCE), "destination": str(DEST), "groups": dict(sorted(groups.items())),
            "direct_files": direct, "archives": ["archives/" + name + ".tar.gz" for name in bundles],
            "estimated_owned_publication_files": len(direct) + len(bundles) + 2,
            "notes": ["Inventory uses only metadata and short native-file magic reads; no compression or full-file hashing.",
                      "README, decision report, and separately owned CI evidence are untouched.",
                      "The completed corpus must be explicitly authorized before packaging."]}


def stable(entry):
    if state(Path(entry["source_path"])) != {key: entry[key] for key in ("size", "mode", "mtime_ns", "symlink")}:
        raise RuntimeError("source changed while packaging: " + entry["source"])


def public_entry(entry, digest):
    result = {key: entry[key] for key in ("source", "size", "mode", "disposition")}
    for key in ("destination", "bundle", "member", "reason", "link_target"):
        if key in entry:
            result[key] = entry[key]
    if digest is not None:
        result["sha256"] = digest
    return result


def copy_direct(entry, overwrite):
    source = Path(entry["source_path"])
    target = DEST / entry["destination"]
    stable(entry)
    digest = sha256(source)
    if target.exists() and not overwrite and sha256(target) != digest:
        raise FileExistsError("refusing to replace an existing different file: " + str(target))
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + ".tmp")
    shutil.copyfile(source, temporary)
    temporary.chmod(int(entry["mode"], 8))
    if sha256(temporary) != digest:
        raise RuntimeError("direct copy differs: " + entry["source"])
    stable(entry)
    temporary.replace(target)
    return public_entry(entry, digest)


class HashReader:
    def __init__(self, source):
        self.source = source
        self.hash = hashlib.sha256()
        self.size = 0

    def read(self, size):
        data = self.source.read(size)
        self.hash.update(data)
        self.size += len(data)
        return data


def tar_info(name, size, mode):
    info = tarfile.TarInfo(name)
    info.size = size
    info.mode = mode
    info.mtime = 0
    info.uid = info.gid = 0
    info.uname = info.gname = ""
    return info


def verify_archive(path, manifest_member, expected_manifest):
    expected = {item["path"]: item for item in expected_manifest["members"]}
    seen = set()
    manifest_seen = False
    with tarfile.open(path, "r:gz") as archive:
        for member in archive:
            if not member.isfile() or member.uid or member.gid or member.mtime:
                raise ValueError("noncanonical tar header: " + member.name)
            data = archive.extractfile(member)
            if member.name == manifest_member:
                if (manifest_seen or member.mode != 0o644
                        or member.size != len(json_bytes(expected_manifest))
                        or data.read() != json_bytes(expected_manifest)):
                    raise ValueError("internal manifest differs")
                manifest_seen = True
                continue
            if member.name not in expected or member.name in seen:
                raise ValueError("unexpected/duplicate tar member: " + member.name)
            digest = hashlib.sha256()
            size = 0
            for chunk in iter(lambda: data.read(1024 * 1024), b""):
                digest.update(chunk)
                size += len(chunk)
            item = expected[member.name]
            if (digest.hexdigest(), size, format(member.mode, "04o")) != (item["sha256"], item["size"], item["mode"]):
                raise ValueError("archive member verification failed: " + member.name)
            seen.add(member.name)
    if not manifest_seen or seen != set(expected):
        raise ValueError("archive has missing members")
    with path.open("rb") as raw:
        header = raw.read(10)
    if header[:3] != b"\x1f\x8b\x08" or header[3] != 0 or header[4:8] != b"\0\0\0\0":
        raise ValueError("gzip header is not deterministic")


def pack_archive(name, entries, overwrite):
    target = DEST / "archives" / (name + ".tar.gz")
    if target.exists() and not overwrite:
        raise FileExistsError("archive already exists: " + str(target))
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + ".tmp")
    members, mappings = [], []
    manifest_member = "local/_archive-manifests/" + name + ".json"
    with temporary.open("wb") as raw, gzip.GzipFile(filename="", mode="wb", fileobj=raw,
                                                   compresslevel=6, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w|", format=tarfile.PAX_FORMAT) as archive:
            for entry in sorted(entries, key=lambda item: item["member"]):
                stable(entry)
                with Path(entry["source_path"]).open("rb") as source:
                    reader = HashReader(source)
                    archive.addfile(tar_info(entry["member"], entry["size"], int(entry["mode"], 8)), reader)
                    if reader.size != entry["size"] or source.read(1):
                        raise RuntimeError("source size changed: " + entry["source"])
                stable(entry)
                digest = reader.hash.hexdigest()
                members.append({"path": entry["member"], "source": entry["source"],
                                "size": entry["size"], "mode": entry["mode"], "sha256": digest})
                mappings.append(public_entry(entry, digest))
            internal = {"schema": 1, "bundle": name, "members": members,
                        "note": "This manifest lists every payload member. It excludes itself; its SHA-256 and the complete archive SHA-256 are recorded externally."}
            data = json_bytes(internal)
            archive.addfile(tar_info(manifest_member, len(data), 0o644), io.BytesIO(data))
    temporary.chmod(0o644)
    verify_archive(temporary, manifest_member, internal)
    temporary.replace(target)
    result = {"path": str(target.relative_to(DEST)), "sha256": sha256(target), "mode": "0644",
              "compressed_bytes": target.stat().st_size,
              "payload_bytes": sum(item["size"] for item in members),
              "payload_members": len(members), "internal_manifest_member": manifest_member,
              "internal_manifest_sha256": hashlib.sha256(data).hexdigest(),
              "internal_manifest_bytes": len(data), "internal_manifest_mode": "0644",
              "verified_all_member_hashes_modes_sizes": True}
    print(name, len(members), "members,", result["compressed_bytes"], "compressed bytes", flush=True)
    return result, mappings


def pack(args):
    if args.corpus_complete:
        result = json.loads((SOURCE / "corpus-policy/comparison.json").read_text())
        if not result.get("complete") or result.get("recorded_cases") != result.get("case_count"):
            raise ValueError("corpus summary does not establish a complete retained run")
    entries = inventory(args.corpus_complete)
    before = {item["source"]: item for item in entries if item["disposition"] != "deferred"}
    grouped, mappings, archives = defaultdict(list), [], []
    direct = sorted(item["source"] for item in entries if item["disposition"] == "direct" and item["destination"].startswith("scripts/"))
    if direct != sorted(CONTROLLERS):
        raise ValueError("expected exactly four unchanged measurement controllers")
    for entry in entries:
        if entry["disposition"] == "direct":
            mappings.append(copy_direct(entry, args.overwrite))
        elif entry["disposition"] == "archive":
            grouped[entry["bundle"]].append(entry)
        elif entry["disposition"] == "excluded":
            digest = None if entry["symlink"] else sha256(Path(entry["source_path"]))
            stable(entry)
            mappings.append(public_entry(entry, digest))
        else:
            mappings.append(public_entry(entry, None))
    for name in sorted(grouped):
        record, members = pack_archive(name, grouped[name], args.overwrite)
        archives.append(record)
        mappings.extend(members)
    after = {item["source"]: item for item in inventory(args.corpus_complete)
             if item["disposition"] != "deferred"}
    if before != after:
        raise RuntimeError("measurement inventory changed during packaging")
    source_counts = Counter(item["disposition"] for item in mappings)
    manifest = {"schema": 1, "source_root": str(SOURCE), "destination_root": str(DEST),
                "corpus_included_after_owner_confirmation": args.corpus_complete,
                "ci_deferred_to_separate_owner": True, "source_counts": dict(source_counts),
                "artifacts": sorted(mappings, key=lambda item: item["source"]), "archives": archives,
                "determinism": {"gzip_mtime": 0, "gzip_filename": "", "gzip_level": 6,
                                "tar_format": "PAX", "tar_mtime": 0, "uid": 0, "gid": 0,
                                "member_order": "lexical payload path followed by archive-specific internal manifest",
                                "modes": "original permission modes preserved", "python": platform.python_version(),
                                "zlib": zlib.ZLIB_VERSION},
                "preservation_note": "Direct files and archived payloads preserve exact bytes. Original absolute paths inside raw records are retained. Excluded native/cache binaries have SHA-256 identities; LLVM symlinks are listed with their targets. Raw comparisons retain their original verdicts."}
    write_json(DEST / MANIFEST_NAME, manifest)
    report = {"schema": 1, "complete": True, "source_counts": dict(source_counts),
              "archives": archives, "total_archive_bytes": sum(item["compressed_bytes"] for item in archives),
              "total_archived_payload_bytes": sum(item["payload_bytes"] for item in archives),
              "owned_publication_file_count": source_counts["direct"] + len(archives) + 2,
              "artifact_manifest": {"path": MANIFEST_NAME, "sha256": sha256(DEST / MANIFEST_NAME)},
              "notes": ["README, report and separately integrated CI files are not included in the owned file count.",
                        "Every tar.gz was reopened and every member's SHA-256, size and mode was verified."]}
    write_json(DEST / REPORT_NAME, report)
    print(json.dumps({key: value for key, value in report.items() if key != "archives"}, indent=2), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("inventory", "pack"))
    parser.add_argument("--corpus-complete", action="store_true",
                        help="owner confirmed corpus job ended; require its complete summary and include it")
    parser.add_argument("--overwrite", action="store_true", help="replace this utility's owned outputs")
    parser.add_argument("--plan-output", type=Path, default=ROOT / "loop-profitability-pack-plan.json")
    args = parser.parse_args()
    if args.action == "inventory":
        value = plan(inventory(args.corpus_complete))
        write_json(args.plan_output, value)
        print(json.dumps(value, indent=2), flush=True)
    else:
        pack(args)


if __name__ == "__main__":
    main()
