"""Compare exclusive Ir costs; skip edge-inclusive rows following calls=."""
import argparse
import collections
import hashlib
import json
from pathlib import Path


def parse(path):
    functions = collections.Counter()
    edges = collections.Counter()
    obj, fn, callee = "", "", ""
    skip_edge = False
    position_count = 0
    event_index = 0
    summary = None
    for line in path.read_text().splitlines():
        if line.startswith("positions:"):
            position_count = len(line.split()) - 1
        elif line.startswith("events:"):
            event_index = line.split()[1:].index("Ir")
        elif line.startswith("summary:"):
            summary = int(line.split()[1 + event_index])
        elif line.startswith("ob="):
            obj = line[3:]
            if obj.endswith("/text"):
                obj = "program"
        elif line.startswith("fn="):
            fn = line[3:]
        elif line.startswith("cfn="):
            callee = line[4:]
        elif line.startswith("calls="):
            skip_edge = True
        elif line and line[0] in "0123456789+-*":
            parts = line.split()
            value = int(parts[position_count + event_index])
            if skip_edge:
                edges[(obj, fn, callee)] += value
                skip_edge = False
            else:
                functions[(obj, fn)] += value
    assert summary == sum(functions.values()), (path, summary, sum(functions.values()))
    return summary, functions, edges


def rows(first, second, total):
    result = []
    for key in first.keys() | second.keys():
        delta = second[key] - first[key]
        result.append({"object": key[0], "function": key[1], "main_Ir": first[key],
                       "baseline_Ir": second[key], "delta_Ir": delta,
                       "pct_of_main_total": 100 * delta / total})
    return sorted(result, key=lambda row: row["delta_Ir"], reverse=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("main", type=Path)
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    first_total, first, first_edges = parse(args.main)
    second_total, second, second_edges = parse(args.baseline)
    comparisons = rows(first, second, first_total)
    output = {"note": "Exclusive function Ir only. Edge-inclusive rows are excluded. Each role sums exactly to callgrind summary. Inlining and cloning can move cost between symbols, so per-symbol deltas are not causal attribution.",
              "inputs": {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [args.main, args.baseline]},
              "main_total_Ir": first_total, "baseline_total_Ir": second_total,
              "delta_Ir": second_total-first_total,
              "delta_pct": 100*(second_total/first_total-1), "functions": comparisons}
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({k:v for k,v in output.items() if k != "functions"}, indent=2))
    print("Largest exclusive increases:")
    for row in comparisons[:25]:
        print(row)
    print("Largest exclusive decreases:")
    for row in comparisons[-12:]:
        print(row)


if __name__ == "__main__":
    main()
