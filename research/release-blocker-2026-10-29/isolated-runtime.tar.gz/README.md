# Pystachy release-blocker performance evidence

These are raw, text-only evidence for the compatible scalar dictionary runtime change and its release integration. Keep this directory on a research branch; the curated report belongs in docs/reports.

## Recorded runtime-only runs

- `runs/outlined-runtime`: measured local/published source `12d99dea2093bd4a4569a7274ab7b645394b8e8d`.
- `runs/inline-runtime`: measured local source `5665d8e916acdcdc4e86180e22510d7a35e6619c`, tree `491c61ef5894822fbbb5b1cbd52c5a6bfe63565c`. Published source `86cedeec314390005e5a5e21dad01373233d2f6b` has that exact tree.
- Both use alpha.3 `f5a09d4223139d7255e31051be97fc509e1ca1fe` and main `5b49dcfaf639d943a12cbc00ce9117ba3e7b5fcc` as separate baselines.

`metadata.json` records each actual source/library/runtime input hash, commit/tree, host/toolchain/settings and harness hash. `build.json` binds the metadata to exact executable/raw-IR hashes and sizes. `profile.json` retains Callgrind totals and original profile-file hashes; the inclusive/self annotated function summaries are in `logs`. `timings-raw.json` retains every pair/order/value, while `timings-summary.json` gives full ranges, medians and paired ratios. Each log JSON retains the exact command, start time, exit status, process elapsed time and stdout/stderr hashes; its adjacent text outputs preserve stdout parity and diagnostics.

Binaries, runtime caches, raw LLVM and raw Callgrind files are deliberately excluded. Their hashes remain recorded; regenerate from the exact sources/input with the commands below. No sample was dropped from either reported timing series. The initial build-only attempt before the libc metadata serialization correction did not reach profiling or paired timings and is not a result series.

## Reproduce

Obtain clean checkouts of each exact source. Use CPython 3.13.16, matching LLVM 18.1.3 tools and Valgrind 3.22.0. The recorded source-specific paths will differ on another machine; use fresh output directories so new source/path/toolchain metadata and hashes are retained honestly. Each checkout must retain its own compiler, library and runtime. Do not share PYSTACHY_HOME between different sources.

Run the unmodified `json_acceptance.py` with explicit `--variant NAME=/path/to/source`, `--candidate runtime`, `--python /path/to/python3.13`, `--llvm /path/to/llvm18/bin`, `--input /path/to/json_loads.py`, `--out /path/to/fresh/results`, and `--cpu` naming an allowed CPU. Run its `build`, `profile` and `timing` stages in that order with identical arguments; profiling additionally takes `--valgrind`, `--valgrind-lib` when needed, and `--annotate` for callgrind_annotate. Defaults are 300 profile iterations, 2000 timed iterations, seven alternating pairs and two warmups per variant in each series. The runner enforces pinned Python, checks exact CPython stdout, and verifies source/binary provenance before/after measurement.

For the final Counter/TOML check use `--workload counter --input counter_acceptance.py --pairs 9`; it measures native AOT process time, including startup, because the exact historical source has no internal timer. Its fixed workload has 30,000,000 iterations. Run no other owned heavy workload during profiling/timing, and report shared-host uncertainty.

## Final combined acceptance

Pending the final #973/identity/runtime integration. Add its fresh evidence under a separate runs/ directory, preserving the earlier source-specific results above.
