# Correctness verification evidence

This is a text-only record of the final promoting-integer identity and module-scoping
checks for Pystachy. See `correctness-integration-report.md` for the curated conclusions
and `provenance/source-mapping.json` for exact local/published source identities. This
bundle does not assert complete CI, runtime-fast-path acceptance or release approval.

## Contents and results

| Evidence | Exact result |
|---|---|
| `oracle-identity-fixture-final/` | 3,861 inputs; 3,851 byte-identical; seven IR-only changes and three new acceptances; no rejection, signal or timeout introduced |
| `oracle-scope-fixture-final/` | 3,865 inputs; 3,861 byte-identical; four IR-only changes; no status/diagnostic/acceptance change |
| `identity-promoted-real-gc/` | 17 cases in native JIT and AOT; 34/34 passed with per-allocation program GC |
| `scope-promoted-real-gc/` | The same 17 cases and modes; 34/34 passed with per-allocation program GC |
| `focused-checks/` | Selected bootstrap, IR/runtime contract, arithmetic/TOML and import/list gate logs; historical GC naming is corrected below |
| `scripts/` | The exact native comparison and true-GC scripts, classification helper, and the relevant repository harnesses from `26cae9ed` |
| `provenance/` | Source/tree mappings, reused-binary hashes, production-source equivalence and command notes |

Each oracle directory includes its complete `results.json`, `manifest.json`, case inventory,
summary, classification and old/new home-input hashes. `changed-cases/` contains all 14
classified text diffs, their diagnostic bytes and individual result records. The original
classifications refer to numbered raw-output directories and prior classifications; archived
changed-case files are under `changed-cases/NUMBER` instead. Prior-output equivalence was
recorded during classification; the prior full-corpus outputs are not in this bundle.

The final fixture inventories are `26cae9ed` and `be12e700`; the reused native compilers
were built from `0ad6467c` and `28093c5a`. Their production files are unchanged. Production
path checks are retained in `provenance/verified-production-equivalence.json`, and complete
input hashes are in each oracle manifest. Native binary SHA-256 values remain in the
manifests and GC reports. The published core, runtime/identity and combined commits have
exactly matching trees to their recorded local counterparts.

## GC evidence correction

The opt-in gate sanitizes its environment and sets `PYSTACHY_GC_STRESS_PROGRAM=0`. Therefore
`focused-checks/identity-arithmetic-promoted-*-gc.*` files are additional NORMAL checks,
despite their historical filenames. They are not evidence of promoted GC stress. The
ordinary `identity-arithmetic-*-gc.log` direct-harness runs did use stress.

The two `*-promoted-real-gc/` directories supply the missing evidence. Their script prepares
a fresh promoting overlay, records expectations with pinned CPython, sanitizes the environment,
then explicitly sets `PYSTACHY_GC_STRESS_PROGRAM=1` before calling `tests/run.sh` directly.
The repository harness propagates that value to JIT and AOT program execution. Both reports
record 34 checks, 34 passes and exit code zero. The script asserts a clean, unchanged checkout.

The report distinguishes older-source executions from final production checks. Unit-suite
counts came from the compiler author's exact command results; no unit stdout is included.
See `provenance/validation-command-notes.json` for commands and evidence limits. Other
selected text logs are preserved without rewriting their contents.

## Reproduction

Use CPython 3.13.16 and LLVM/Clang 18.1.3 on Linux x86-64. Oracle manifest Python strings
also show the compiler used to build the CPython interpreter; that is not the LLVM toolchain
used for generated Pystachy programs. Recorded absolute paths describe the original workspace
and need relocation on a new machine. Source snapshots are available through the repository
commits in `provenance/source-mapping.json`; the repository itself is not duplicated here.

Build the baseline compiler at `5b49dcfa`, the core compiler at `0ad6467c` and the scoped
compiler at `28093c5a` using the repository bootstrap instructions. Keep those executables,
then check out final fixture heads `26cae9ed` and `be12e700` for their comparison inventories.
Verify the production-path equivalence before reusing an executable. The existing hashes
identify these historical executables; a fresh bootstrap is not claimed to reproduce their
binary bytes on every host.

With BASELINE, CORE and SCOPE set to those separate checkout roots, replay the comparisons
with fresh output directories:

```sh
python scripts/retained_irsame.py --baseline "$BASELINE" --candidate "$CORE" \
  --old "$BASELINE/pystachy" --new "$CORE/pystachy" \
  --old-build-sha 5b49dcfaf639d943a12cbc00ce9117ba3e7b5fcc \
  --new-build-sha 0ad6467caf83ef0485daaf565710ca766e5ab599 --out identity-rerun --jobs 2
python scripts/retained_irsame.py --baseline "$CORE" --candidate "$SCOPE" \
  --old "$CORE/pystachy" --new "$SCOPE/pystachy" \
  --old-build-sha 0ad6467caf83ef0485daaf565710ca766e5ab599 \
  --new-build-sha 28093c5a3238224b5d3c366fed996f0e92224778 --out scope-rerun --jobs 2
python scripts/run_promoted_gc.py --root "$CORE" --compiler "$CORE/pystachy" \
  --report-dir identity-gc-rerun
python scripts/run_promoted_gc.py --root "$SCOPE" --compiler "$SCOPE/pystachy" \
  --report-dir scope-gc-rerun
```

The comparison script returns status 1 for any difference, including the expected classified
changes. Interpret its structured summary and inspect the differences; status 1 alone is not
an unexpected regression. The compiler comparison checks generated IR, diagnostic bytes and
exit status. It does not execute every compiled program. No textual or path normalization
was applied to the original comparisons. Old/new library and runtime inputs were byte-compared
before permitting a shared PYSTACHY_HOME, and source/command hashes were checked after each run.

## Intentional omissions and integrity

Thousands of per-case raw LLVM files, most unchanged diagnostic files, native compiler
executables, runtime caches, temporary overlays and unrelated performance outputs are omitted.
Every generated IR and diagnostic hash used by the comparisons is retained in `results.json`
(with null for absent IR); every source input and compiler executable hash is retained in the
manifests. Full diffs and diagnostic bytes for every classified change are included. Re-running
the retained script is necessary to recover omitted bytes; a hash alone cannot recover them.

`SHA256SUMS` covers every other file in this directory. Verify it with `sha256sum -c SHA256SUMS`.
All included files are UTF-8 text. `bundle-validation.json` records the independent metadata
consistency checks performed while packaging; packaging did not re-run compilation or programs.
