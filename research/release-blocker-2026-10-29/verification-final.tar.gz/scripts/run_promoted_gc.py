"""Run a fresh pinned-CPython promoting overlay through the actual program-GC harness.

Unlike the opt-in gate, this local probe deliberately enables program GC stress after
the gate's normal environment sanitization. It changes no repository/harness file.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile


parser = argparse.ArgumentParser()
parser.add_argument("--root", type=Path, required=True)
parser.add_argument("--compiler", type=Path, required=True)
parser.add_argument("--report-dir", type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve()
compiler = args.compiler.resolve()
report_dir = args.report_dir.resolve()
report_dir.mkdir(parents=True, exist_ok=True)
version = ".".join(map(str, sys.version_info[:3]))
assert version == (root / ".python-version").read_text().strip(), version
spec = importlib.util.spec_from_file_location("optin", root / "tools/dynany_optin.py")
optin = importlib.util.module_from_spec(spec)
spec.loader.exec_module(optin)
cases = sorted(str(path.relative_to(root)) for pattern in (
    "tests/programs/inference/dynany_identity_promote_*.py",
    "tests/programs/inference/dynany_promote_arithmetic*.py",
) for path in root.glob(pattern))
cases += ["tests/programs/library/lib_tomllib.py",
          "tests/programs/numbers/python_int_import.py",
          "tests/programs/numbers/python_int_lists.py"]
assert len(cases) == len(set(cases)) == 17, cases
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
tree = subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=root, text=True).strip()
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=root), "dirty input tree"
with tempfile.TemporaryDirectory(prefix="pystachy-promoted-real-gc-") as tmp:
    temp = Path(tmp)
    overlay = temp / "tree"
    optin.prepare_tree(root, overlay, cases, b"# pystachy: python-int\n")
    work = temp / "work"
    work.mkdir()
    env = optin.environment(root, work)
    env["PYSTACHY_GC_STRESS_PROGRAM"] = "1"
    assert env["PYSTACHY_GC_STRESS_PROGRAM"] == "1"
    with (report_dir / "record.log").open("w") as log:
        recorded = subprocess.run(["sh", "tests/record.sh", *cases], cwd=overlay, env=env,
                                  stdout=log, stderr=subprocess.STDOUT, timeout=300)
    assert recorded.returncode == 0, "pinned oracle failed"
    command = ["sh", "tests/run.sh", str(compiler), "jit aot", *cases]
    with (report_dir / "checks.log").open("w") as log:
        checked = subprocess.run(command, cwd=overlay, env=env, stdout=log,
                                 stderr=subprocess.STDOUT, timeout=900)
    output = (report_dir / "checks.log").read_text()
    passed = checked.returncode == 0 and "34 passed, 0 failed" in output
    report = {"schema": 1, "python": version, "root": str(root), "head": head, "tree": tree,
              "compiler": str(compiler), "compiler_sha256": hashlib.sha256(compiler.read_bytes()).hexdigest(),
              "pragma": "# pystachy: python-int", "PYSTACHY_GC_STRESS_PROGRAM": "1",
              "cases": cases, "modes": ["jit", "aot"], "checks": 34,
              "passed_checks": 34 if passed else None, "exit_code": checked.returncode,
              "command": command}
    (report_dir / "report.json").write_text(json.dumps(report, indent=2) + "\n")
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip() == head
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=root), "input tree mutated"
print(output, end="")
sys.exit(0 if passed else 1)
