import collections
import difflib
import json
from pathlib import Path
import sys

prior = Path(sys.argv[1])
current = Path(sys.argv[2])
previous_rows = {row["case"]: row for row in json.loads((prior / "results.json").read_text())}
previous_classifications = {row["case"]: row for row in json.loads((prior / "classification.json").read_text())["classified"]}
rows = json.loads((current / "results.json").read_text())
summary = json.loads((current / "summary.json").read_text())
manifest = json.loads((current / "manifest.json").read_text())
classified = []
for row in rows:
    if not row.get("differences"):
        continue
    case = row["case"]
    directory = current / f"{row['index']:04d}"
    chunks = []
    for suffix in ["msg", "ll"]:
        old_path, new_path = directory / ("old." + suffix), directory / ("new." + suffix)
        old_text = old_path.read_text() if old_path.exists() else ""
        new_text = new_path.read_text() if new_path.exists() else ""
        chunks += difflib.unified_diff(old_text.splitlines(True), new_text.splitlines(True), fromfile="old." + suffix, tofile="new." + suffix)
    (directory / "full.diff").write_text("".join(chunks))
    reused = False
    if case in previous_classifications:
        before = previous_rows[case]
        reused = all(row["results"][side][key] == before["results"][side][key] for side in ["old", "new"] for key in ["exit_status", "messages_sha256", "ir_sha256"])
    if reused:
        entry = dict(previous_classifications[case])
        entry.update(evidence_directory=directory.name, exact_prior_outputs=True, prior_evidence=str(prior))
    else:
        entry = {"case": case, "evidence_directory": directory.name, "differences": row["differences"], "explanation": "REVIEW REQUIRED", "exact_prior_outputs": False}
    classified.append(entry)
report = {"baseline_source": manifest["baseline_head"], "candidate_source": manifest["candidate_head"], "old_build_source_sha": manifest["old_build_source_sha"], "new_build_source_sha": manifest["new_build_source_sha"], "baseline_accepts": sum(row["results"]["old"]["exit_status"] == 0 for row in rows), "candidate_accepts": sum(row["results"]["new"]["exit_status"] == 0 for row in rows), "classified": classified, "source_identical_before_after": not summary["source_inputs_changed_during_run"], "binaries_identical_before_after": not summary["command_inputs_changed_during_run"], "normalization": "none; identical home inputs and candidate paths", "scope": "native compiler IR/status/messages, not program execution; raw and full diffs retained", "fixture_only_binary_reuse_provenance": "/workspace/scratch/d7d6ff7f2910/fixture-rerun-provenance.json"}
(current / "classification.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"summary": summary, "baseline_accepts": report["baseline_accepts"], "candidate_accepts": report["candidate_accepts"], "prior_output_matches": sum(row["exact_prior_outputs"] for row in classified), "review_required": [row["case"] for row in classified if not row["exact_prior_outputs"]]}, indent=2))
