import tomllib

class Counter:
    def __init__(self) -> None:
        self.pos = 0
        self.n = 0

    def step(self, k: int) -> None:
        for i in range(k):
            self.pos = self.pos + i
            self.n += 1

c = Counter()
c.step(30000000)
print(c.pos, c.n)
print(len(tomllib.loads("a = 1")))
