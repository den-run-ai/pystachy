# Pystachy release-blocker performance evidence

These are raw, text-only evidence for the compatible scalar dictionary runtime change and its release integration. Keep this directory on a research branch; the curated report belongs in docs/reports.

## Recorded runtime-only runs

- `runs/outlined-runtime`: measured local/published source `12d99dea2093bd4a4569a7274ab7b645394b8e8d`.
- `runs/inline-runtime`: measured local source `5665d8e916acdcdc4e86180e22510d7a35e6619c`, tree `491c61ef5894822fbbb5b1cbd52c5a6bfe63565c`. Published source `86cedeec314390005e5a5e21dad01373233d2f6b` has that exact tree.
- Both use alpha.3 `f5a09d4223139d7255e31051be97fc509e1ca1fe` and main `5b49dcfaf639d943a12cbc00ce9117ba3e7b5fcc` as separate baselines.

`metadata.json` records each actual source/library/runtime input hash, commit/tree, host/toolchain/settings and harness hash. `build.json` binds the metadata to exact executable/raw-IR hashes and sizes. `profile.json` retains Callgrind totals and original profile-file hashes; the inclusive/self annotated function summaries are in `logs`. `timings-raw.json` retains every pair/order/value, while `timings-summary.json` gives full ranges, medians and paired ratios. Each log JSON retains the exact command, start time, exit status, process elapsed time and stdout/stderr hashes; its adjacent text outputs preserve stdout parity and diagnostics.

Binaries, runtime caches, raw LLVM and raw Callgrind files are deliberately excluded. Their hashes remain recorded; regenerate from the exact sources/input with the commands below. No sample was dropped from either reported timing series. The initial build-only attempt before the libc metadata serialization correction did not reach profiling or paired timings and is not a result series.

## Reproduce

Obtain clean checkouts of each exact source. Use CPython 3.13.16, matching LLVM 18.1.3 tools and Valgrind 3.22.0. The recorded source-specific paths will differ on another machine; use fresh output directories so new source/path/toolchain metadata and hashes are retained honestly. Each checkout must retain its own compiler, library and runtime. Do not share PYSTACHY_HOME between different sources.

Run the unmodified `json_acceptance.py` with explicit `--variant NAME=/path/to/source`, `--candidate runtime`, `--python /path/to/python3.13`, `--llvm /path/to/llvm18/bin`, `--input /path/to/json_loads.py`, `--out /path/to/fresh/results`, and `--cpu` naming an allowed CPU. Run its `build`, `profile` and `timing` stages in that order with identical arguments; profiling additionally takes `--valgrind`, `--valgrind-lib` when needed, and `--annotate` for callgrind_annotate. Defaults are 300 profile iterations, 2000 timed iterations, seven alternating pairs and two warmups per variant in each series. The runner enforces pinned Python, checks exact CPython stdout, and verifies source/binary provenance before/after measurement.

For the final Counter/TOML check use `--workload counter --input counter_acceptance.py --pairs 9`; it measures native AOT process time, including startup, because the exact historical source has no internal timer. Its fixed workload has 30,000,000 iterations. Run no other owned heavy workload during profiling/timing, and report shared-host uncertainty.

## Combined acceptance and bounded rejected trial

- `runs/combined-json` and `runs/combined-counter`: local source `aa051bf85554ab7c87884a9b1e1920216f006591`, tree `bba7daabb1d51ed2ac30d32f4169bcad781e2817`, exactly matching published #973 head `d315ace58c7122245670215f12f28bc9cc497833`. JSON has profiles plus seven-pair AOT/warm-JIT series; Counter has nine-pair AOT process-time series. Source/runtime bytes remained frozen throughout.
- `runs/reconstructed-int32`: the same combined source, a newly reconstructed 343-byte 32-key JSON payload (`k0`…`k31`, values 1000…1031), and 3,000 discarded typed loads in a dynamic-Any program. The complete reconstructed source is `json_int32_reconstructed.py`, SHA-256 `d02a1bacd6be31de87de758758ee3a3ee18f581894e80f924000cd6357c37510`. This is not a replay of the unavailable historical 124-million-instruction input. Build/output checks and profiles are retained; no paired timing series was run for this control.
- `runs/rejected-scalar-trial`: local unmerged trial `29acda6949ab904e3cf55ff1ee3142e7a01d2906`, tree `d56a52215c7a5a29ad7412924e8111282b5d24c6`, based on the combined source above. `rejected-scalar-trial.diff` reconstructs its complete source change. It specializes marked scalar lookup loops while preserving exact hashes/probes and avoiding generic equality dispatch. Correctness/probe/GC checks passed, but total instructions worsened from 1,351,366,723 to 1,361,638,491 (+0.76%). It was rejected without a paired timing series; do not merge it into production.

The accepted runtime remains the forced-inlining version. All series are separate, with their actual source hashes and raw results retained. Later fixture-only or release-documentation updates require explicit production-source equivalence; these records do not automatically certify an unrelated new tree.

## Final fixture-only publication

`final-source-equivalence.json` maps measured local `aa051bf8` / published `d315ace5` to final local `eb11dab661be2fc04147761edb95c3376493bb43` / published `9fd73f34a36cfae6196f165628b2ed19fa16538b`, tree `c996c5698c3b201d959cde9e3fc9fff3313cc549`. All 129 recorded production source inputs and both original benchmarks are byte-identical. Exactly 11 regression fixture, test documentation and opt-in exception-manifest files differ; the full path list is recorded. Performance evidence carries through that verified production equivalence; final test/CI acceptance belongs to the published head.
