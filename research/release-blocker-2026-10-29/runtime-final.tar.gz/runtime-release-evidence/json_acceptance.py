#!/usr/bin/env python3
"""Same-input native JSON decoder acceptance; raw evidence stays outside the repo.

Run build first, then profile and timing with no other owned heavy job running.
Every source uses its own library/runtime and private cache. All frontends are
hosted by the same pinned CPython; only native program loop time is compared.
"""

import argparse
import hashlib
import json
import math
import os
import platform
import re
import statistics
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def output(cmd, cwd=None):
    return subprocess.check_output(cmd, cwd=cwd, text=True).strip()


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def source_identity(path):
    changed = output(["git", "status", "--porcelain", "--untracked-files=normal"], path)
    if changed:
        raise RuntimeError(f"source must be clean: {path}\n{changed}")
    # Record actual readable source bytes, including any ignored source overlays.
    files = [path / x for x in ("pystachy.py", "runtime.c", "runtime.py", "VERSION")]
    for directory in ("src", "lib", "ryu", "mpz"):
        files.extend(p for p in (path / directory).rglob("*")
                     if p.is_file() and p.suffix in (".py", ".c", ".h", ".txt"))
    hashes = {str(p.relative_to(path)): sha256(p) for p in sorted(set(files))}
    return {"path": str(path), "commit": output(["git", "rev-parse", "HEAD"], path),
            "tree": output(["git", "rev-parse", "HEAD^{tree}"], path),
            "source_hashes": hashes}


class Experiment:
    def __init__(self, args):
        self.args = args
        self.out = (args.out or ROOT / (args.workload + "-acceptance")).resolve()
        self.out.mkdir(parents=True, exist_ok=True)
        self.logs = self.out / "logs"
        self.logs.mkdir(exist_ok=True)
        self.variants = {}
        for spec in args.variant:
            name, sep, path = spec.partition("=")
            if not sep or not re.fullmatch(r"[a-zA-Z0-9_-]+", name):
                raise ValueError(f"invalid variant: {spec}")
            self.variants[name] = Path(path).resolve()
        self.cpu = args.cpu if args.cpu is not None else min(os.sched_getaffinity(0))
        if self.cpu not in os.sched_getaffinity(0):
            raise ValueError(f"CPU {self.cpu} is outside the allowed affinity")
        self.python = str(args.python.resolve())
        self.llvm = str(args.llvm.resolve())
        if output([self.python, "--version"]) != "Python 3.13.16":
            raise RuntimeError("recording and measurement require CPython 3.13.16")
        self.env = {k: v for k, v in os.environ.items()
                    if not k.startswith("PYSTACHY_") and k not in ("PYTHONPATH", "PYTHONHOME")}
        self.env["PYSTACHY_LLVM"] = self.llvm
        self.env["PYTHONHASHSEED"] = "0"
        self.env["LC_ALL"] = "C.UTF-8"
        self.input = self.out / ("json_loads.py" if args.workload == "json" else "counter.py")
        original = (args.input or (ROOT / "runtime/bench/pyperformance/json_loads.py"
                    if args.workload == "json" else ROOT / "counter_acceptance.py")).resolve()
        if self.input.exists() and sha256(self.input) != sha256(original):
            raise RuntimeError("benchmark input changed since an earlier stage")
        self.input.write_bytes(original.read_bytes())
        identities = {name: source_identity(path) for name, path in self.variants.items()}
        self.identities = identities
        metadata = {"input": str(self.input), "input_sha256": sha256(self.input),
                    "harness_sha256": sha256(Path(__file__)),
                    "python": self.python, "python_version": output([self.python, "--version"]),
                    "llvm": self.llvm, "llvm_version": output([self.llvm + "/clang", "--version"]),
                    "platform": platform.platform(), "libc": list(platform.libc_ver()), "cpu": self.cpu,
                    "cpu_model": next((line.split(":", 1)[1].strip()
                                       for line in Path("/proc/cpuinfo").read_text().splitlines()
                                       if line.startswith("model name")), "unknown"),
                    "variants": identities, "frontend": "CPython-hosted for every source",
                    "workload": args.workload,
                    "measurement": ("native program internal loop timer; shared host" if args.workload == "json"
                                    else "native AOT process elapsed time including startup; shared host"),
                    "inherited_settings_cleared": "PYSTACHY_*, PYTHONPATH, PYTHONHOME",
                    "controlled_settings": {"PYSTACHY_LLVM": self.llvm, "PYTHONHASHSEED": "0",
                                            "LC_ALL": "C.UTF-8", "PYSTACHY_CACHE": "private per source"}}
        metadata_file = self.out / "metadata.json"
        if metadata_file.exists() and json.loads(metadata_file.read_text()) != metadata:
            raise RuntimeError("source/toolchain/host metadata changed since an earlier stage")
        write_json(metadata_file, metadata)
        self.metadata_file = metadata_file
        self.references = {}

    def verify_sources(self):
        if {name: source_identity(path) for name, path in self.variants.items()} != self.identities:
            raise RuntimeError("source changed during this stage")

    def verify_builds(self):
        self.verify_sources()
        manifest = json.loads((self.out / "build.json").read_text())
        if manifest["metadata_sha256"] != sha256(self.metadata_file):
            raise RuntimeError("build manifest belongs to different source/toolchain metadata")
        for name in self.variants:
            saved = manifest["variants"][name]
            target = self.out / name
            if (sha256(target / "json_loads") != saved["binary_sha256"] or
                    sha256(target / "program.ll") != saved["ir_sha256"]):
                raise RuntimeError(f"{name}: binary or IR changed after the recorded build")

    def run(self, label, command, *, variant=None, timeout=600, profile=False):
        env = self.env.copy()
        if variant:
            cache = self.out / "cache" / variant
            cache.mkdir(parents=True, exist_ok=True)
            env["PYSTACHY_CACHE"] = str(cache)
        if profile and self.args.valgrind_lib:
            env["VALGRIND_LIB"] = str(self.args.valgrind_lib.resolve())
        started = time.time()
        timer = time.perf_counter()
        result = subprocess.run(command, cwd=self.variants.get(variant, self.out), env=env, check=False,
                                capture_output=True, timeout=timeout,
                                preexec_fn=lambda: os.sched_setaffinity(0, {self.cpu}))
        result.elapsed_seconds = time.perf_counter() - timer
        (self.logs / (label + ".stdout")).write_bytes(result.stdout)
        (self.logs / (label + ".stderr")).write_bytes(result.stderr)
        write_json(self.logs / (label + ".json"), {"command": command, "variant": variant,
                   "started_epoch": started, "process_elapsed_seconds": result.elapsed_seconds,
                   "status": result.returncode, "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
                   "stderr_sha256": hashlib.sha256(result.stderr).hexdigest()})
        if result.returncode:
            raise RuntimeError(f"{label} exited {result.returncode}: {result.stderr.decode(errors='replace')[-2000:]}")
        return result

    def reference(self, loops):
        if loops not in self.references:
            extra = [str(loops)] if self.args.workload == "json" else []
            result = self.run(f"cpython-{loops}", [self.python, str(self.input)] + extra)
            self.references[loops] = result.stdout
        return self.references[loops]

    def native(self, label, variant, mode, loops, *, profile=False):
        extra = [str(loops)] if self.args.workload == "json" else []
        if mode == "aot":
            command = [str(self.out / variant / "json_loads")] + extra
        else:
            command = [self.python, str(self.variants[variant] / "pystachy.py"),
                       "run", str(self.input)] + extra
        if profile:
            destination = self.out / variant / "callgrind.out"
            command = [str(self.args.valgrind.resolve()), "--tool=callgrind", "--error-exitcode=99",
                       "--callgrind-out-file=" + str(destination)] + command
        result = self.run(label, command, variant=variant, profile=profile)
        if result.stdout != self.reference(loops):
            raise RuntimeError(f"{label}: native stdout differs from CPython")
        if self.args.workload == "counter":
            if result.stderr and not profile:
                raise RuntimeError(f"{label}: unexpected stderr; inspect log")
            return result.elapsed_seconds
        timing = re.findall(rb"^seconds ([0-9.eE+-]+)$", result.stderr, re.MULTILINE)
        if len(timing) != 1:
            raise RuntimeError(f"{label}: expected exactly one internal timer")
        value = float(timing[0])
        if not math.isfinite(value) or value <= 0:
            raise RuntimeError(f"{label}: invalid timer {value}")
        if not profile and result.stderr.strip() != b"seconds " + timing[0]:
            raise RuntimeError(f"{label}: unexpected stderr; inspect log")
        return value

    def build(self):
        rows = {}
        for name, path in self.variants.items():
            target = self.out / name
            target.mkdir(exist_ok=True)
            compiler = [self.python, str(path / "pystachy.py")]
            self.run(f"{name}-ir", compiler + ["ir", str(self.input), "-o", str(target / "program.ll")], variant=name)
            self.run(f"{name}-build", compiler + ["build", str(self.input), "-o", str(target / "json_loads")], variant=name)
            for mode in (("aot", "jit") if self.args.workload == "json" else ("aot",)):
                self.native(f"{name}-{mode}-check", name, mode, self.args.loops)
            rows[name] = {"binary_sha256": sha256(target / "json_loads"),
                          "binary_bytes": (target / "json_loads").stat().st_size,
                          "ir_sha256": sha256(target / "program.ll")}
            self.verify_sources()
            write_json(self.out / "build.json", {"metadata_sha256": sha256(self.metadata_file), "variants": rows})
            print(f"built and checked {name}", flush=True)

    def profile(self):
        self.verify_builds()
        if not self.args.valgrind:
            raise ValueError("--valgrind is required for the profile stage")
        rows = {}
        for name in self.variants:
            self.native(f"{name}-callgrind", name, "aot", self.args.profile_loops, profile=True)
            profile_path = self.out / name / "callgrind.out"
            profile = profile_path.read_text()
            events = re.search(r"^events: (.+)$", profile, re.MULTILINE).group(1).split()
            totals = list(map(int, re.search(r"^summary: (.+)$", profile, re.MULTILINE).group(1).split()))
            rows[name] = {"loops": self.args.profile_loops, "counts": dict(zip(events, totals, strict=True)),
                          "callgrind_sha256": sha256(profile_path)}
            if self.args.annotate:
                self.run(f"{name}-callgrind-inclusive", [str(self.args.annotate.resolve()),
                         "--inclusive=yes", "--threshold=100", str(profile_path)])
                self.run(f"{name}-callgrind-self", [str(self.args.annotate.resolve()),
                         "--inclusive=no", "--threshold=100", str(profile_path)])
            write_json(self.out / "profile.json", rows)
            print(f"profiled {name}: {rows[name]['counts']}", flush=True)
        self.verify_builds()

    def timing(self):
        self.verify_builds()
        candidate = self.args.candidate
        baselines = self.args.baseline or [n for n in self.variants if n != candidate]
        if candidate not in self.variants or any(n not in self.variants for n in baselines):
            raise ValueError("candidate and baselines must be named variants")
        rows = []
        summary = []
        for baseline in baselines:
            for mode in (("aot", "jit") if self.args.workload == "json" else ("aot",)):
                for warmup in range(2):
                    for name in (baseline, candidate):
                        self.native(f"{baseline}-{mode}-warmup{warmup}-{name}", name, mode, self.args.loops)
                pairs = []
                for pair in range(self.args.pairs):
                    order = (baseline, candidate) if pair % 2 == 0 else (candidate, baseline)
                    values = {}
                    for name in order:
                        values[name] = self.native(f"{baseline}-{mode}-pair{pair + 1}-{name}", name, mode, self.args.loops)
                    ratio = values[candidate] / values[baseline]
                    pairs.append({"pair": pair + 1, "order": order, "seconds": values, "ratio": ratio})
                    rows.append({"baseline": baseline, "candidate": candidate, "mode": mode, **pairs[-1]})
                    write_json(self.out / "timings-raw.json", rows)
                    print(f"{baseline} {mode} pair {pair + 1}: candidate/base={ratio:.5f}", flush=True)
                a = [p["seconds"][baseline] for p in pairs]
                b = [p["seconds"][candidate] for p in pairs]
                summary.append({"baseline": baseline, "candidate": candidate, "mode": mode,
                    "loops": self.args.loops, "pairs": self.args.pairs,
                    "baseline_seconds": {"median": statistics.median(a), "min": min(a), "max": max(a)},
                    "candidate_seconds": {"median": statistics.median(b), "min": min(b), "max": max(b)},
                    "ratio_of_medians": statistics.median(b) / statistics.median(a),
                    "median_paired_ratio": statistics.median(p["ratio"] for p in pairs),
                    "candidate_faster_pairs": sum(p["ratio"] < 1 for p in pairs)})
                write_json(self.out / "timings-summary.json", summary)
        self.verify_builds()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("build", "profile", "timing", "all"))
    parser.add_argument("--workload", choices=("json", "counter"), default="json")
    parser.add_argument("--variant", action="append", default=[])
    parser.add_argument("--candidate", default="runtime")
    parser.add_argument("--baseline", action="append")
    parser.add_argument("--out", type=Path)
    parser.add_argument("--input", type=Path)
    parser.add_argument("--python", type=Path, default=Path(sys.executable))
    parser.add_argument("--llvm", type=Path, required=True)
    parser.add_argument("--valgrind", type=Path)
    parser.add_argument("--valgrind-lib", type=Path)
    parser.add_argument("--annotate", type=Path)
    parser.add_argument("--cpu", type=int)
    parser.add_argument("--loops", type=int)
    parser.add_argument("--profile-loops", type=int, default=300)
    parser.add_argument("--pairs", type=int, default=7)
    args = parser.parse_args()
    if args.loops is None:
        args.loops = 2000 if args.workload == "json" else 30000000
    if args.workload == "counter" and args.loops != 30000000:
        parser.error("the historical Counter source uses exactly 30000000 iterations")
    if not args.variant:
        args.variant = [f"alpha3={ROOT / 'alpha3'}", f"main={ROOT / 'baseline5b49'}", f"runtime={ROOT / 'runtime'}"]
    experiment = Experiment(args)
    for stage in ("build", "profile", "timing") if args.stage == "all" else (args.stage,):
        getattr(experiment, stage)()


if __name__ == "__main__":
    main()
