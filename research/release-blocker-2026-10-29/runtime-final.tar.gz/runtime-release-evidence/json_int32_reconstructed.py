# pystachy: dynamic-any
# Reconstructed control: 32 integer-valued keys, not a historical source replay.
import json
import sys
import time
from typing import Any

TEXT = '{"k0":1000,"k1":1001,"k2":1002,"k3":1003,"k4":1004,"k5":1005,"k6":1006,"k7":1007,"k8":1008,"k9":1009,"k10":1010,"k11":1011,"k12":1012,"k13":1013,"k14":1014,"k15":1015,"k16":1016,"k17":1017,"k18":1018,"k19":1019,"k20":1020,"k21":1021,"k22":1022,"k23":1023,"k24":1024,"k25":1025,"k26":1026,"k27":1027,"k28":1028,"k29":1029,"k30":1030,"k31":1031}'
loops = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
started = time.perf_counter()
for _ in range(loops):
    json.loads(TEXT)
print("seconds", time.perf_counter() - started, file=sys.stderr)
print("json_int32", loops)
value: Any = json.loads(TEXT)
print(value)
