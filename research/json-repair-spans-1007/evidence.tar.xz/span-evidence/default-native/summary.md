# Default JSON-repair API control

Campaign complete: True; elapsed 54.8 seconds.

Unchanged `bench/json_repair/bench.py`: ten synthetic records per round,
2,000 rounds (20,000 repairs) per batch, three warmups and five measured
batches per process. This uses the default decoder dispatch and returned
objects; serialization is outside timing. Exact full output witnesses match
both adapted-CPython zero-round oracles and every native execution.

| Engine | Pairs | Base ms | Candidate ms | Change | Paired change | Speedup |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| aot | 3 | 205.704 | 177.204 | -13.85% | -13.85% | 1.161× |
| jit | 3 | 240.712 | 294.143 | +22.20% | +0.89% | 0.818× |

Times are medians of the per-process medians. Paired changes summarize
the candidate/base ratio in each interleaved pair. Processes were pinned to
CPU 0 and run sequentially on a shared host. Negative change means faster.

AOT build commands, times, source/binary hashes and raw records are retained.
AOT RSS excludes compilation. JIT RSS covers the compiler/JIT invocation and
waited-for children; ru_maxrss is a maximum, not aggregate concurrent memory.
The runtime cache may be warmed by the preceding campaign. Process wall time
is retained separately from loop timing; no cold-start claim is made.

CPython ran only zero-round output checks, not a peer-runtime performance
campaign. These controls do not establish a general runtime ranking.
