"""Independent bounded CPython semantic comparison of span processing."""
from __future__ import annotations

import hashlib
import importlib
import importlib.util
import itertools
import json
from pathlib import Path
import random
import signal
import sys
import time

BASE = Path('/tmp/pystachy-span-test-baseline-wz1qlqzi/repo')
CAND = Path('/workspace/scratch/a9cec5b79fe1/pystachy-spans')
OUT = Path(__file__).resolve().parent


class ProbeTimeout(Exception):
    pass


def alarm(_signal, _frame):
    raise ProbeTimeout('per-call 0.35 s watchdog expired')


signal.signal(signal.SIGALRM, alarm)


def load(name, root):
    path = root / 'ports/json_repair/__init__.py'
    spec = importlib.util.spec_from_file_location(name, path, submodule_search_locations=[str(path.parent)])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return (module, importlib.import_module(name + '.json_parser'),
            importlib.import_module(name + '.parse_string'))


def freeze(value):
    if value is None:
        return ['none']
    if isinstance(value, bool):
        return ['bool', value]
    if isinstance(value, int):
        return ['int', str(value)]
    if isinstance(value, float):
        return ['float', value.hex()]
    if isinstance(value, str):
        return ['str', [ord(c) for c in value]]
    if isinstance(value, list):
        return ['list', [freeze(v) for v in value]]
    if isinstance(value, tuple):
        return ['tuple', [freeze(v) for v in value]]
    if isinstance(value, dict):
        return ['dict', [[freeze(k), freeze(v)] for k, v in value.items()]]
    raise AssertionError(type(value))


def guarded(fn):
    signal.setitimer(signal.ITIMER_REAL, 0.35)
    try:
        return ['value', freeze(fn())]
    except Exception as exc:
        return ['exception', type(exc).__name__, str(exc)]
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)


baseline = load('review_baseline_json_repair', BASE)
candidate = load('review_candidate_json_repair', CAND)
checks = {'public_calls': 0, 'parser_calls': 0, 'scan_calls': 0, 'accumulator_steps': 0}
mismatches = []
timeouts = []
started = time.monotonic()
hashes = {str(root): hashlib.sha256((root / 'ports/json_repair/parse_string.py').read_bytes()).hexdigest()
          for root in (BASE, CAND)}


def compare(category, descriptor, before, after):
    checks[category] += 1
    if 'ProbeTimeout' in repr(before) or 'ProbeTimeout' in repr(after):
        timeouts.append({'kind': category, 'case': descriptor, 'baseline': before, 'candidate': after})
    if before != after:
        mismatches.append({'kind': category, 'case': descriptor, 'baseline': before, 'candidate': after})
        (OUT / 'mismatches.json').write_text(json.dumps(mismatches, ensure_ascii=True, indent=2))
        if len(mismatches) >= 20:
            raise RuntimeError('20 mismatches; stop')


def parser_outcome(package, text, flags):
    p = package[1].JSONParser(text, True, stream_stable=flags['stream_stable'], strict=flags['strict'])
    result = guarded(p.parse)
    return [result, p.index, freeze(p.logger), freeze(p.context.context), p.context.current, p.context.empty]


fragments = [
    'abc', 'ordinary text', 'é🌲', '\ud800', '\udfff', '\u0301', '\x00', '\x1c', '\x85', '\u2003', '\u3000',
    '\\n', '\\t', '\\r', '\\b', '\\u005b', '\\u005d', '\\u007b', '\\u007d', '\\u0020', '\\u2003',
    '\\ud800', '\\udfff', '\\x20', '\\q', '\\', '\\\\', '\\\\\\', '"', "'", '“', '”', '„',
    '{', '}', '[', ']', '(', ')', ',', ':', '`', '#', '/', '*', ' ', '\t', '\r', '\n',
]
wrappers = [('{"a":"', '",}'), ('{"a":', ',}'), ('{"', ':1,}'), ('{', ':1,}'),
            ('["', '",]'), ("['", "',]"), ('[“', '”,]'), ('[', ',]')]
texts = []
for n in (0, 1, 2, 62, 63, 64, 65, 126, 127, 128, 129, 255):
    for separator in fragments:
        body = 'é' * n + separator + '🌲' * (n % 17) + '\\nend'
        for prefix, suffix in wrappers:
            texts.append(prefix + body + suffix)

rng = random.Random(20261101)
for _ in range(1500):
    prefix, suffix = rng.choice(wrappers)
    body = ''.join(rng.choices(fragments, k=rng.randint(0, 16)))
    if rng.randrange(4) == 0:
        body = 'long ordinary prose ' * rng.randrange(1, 9) + body
    texts.append(prefix + body + (suffix if rng.randrange(3) else ''))

for i, text in enumerate(texts):
    flags = {'stream_stable': bool(i & 1), 'strict': bool(i & 2)}
    compare('parser_calls', {'text': text, 'flags': flags},
            parser_outcome(baseline, text, flags), parser_outcome(candidate, text, flags))
    if i % 4 == 0:
        api_flags = dict(flags, skip_json_loads=True, logging=bool(i & 4), return_objects=bool(i & 8))
        before = guarded(lambda: baseline[0].repair_json(text, **api_flags))
        after = guarded(lambda: candidate[0].repair_json(text, **api_flags))
        compare('public_calls', {'text': text, 'flags': api_flags}, before, after)


def scan_outcome(package, descriptor):
    p = package[1].JSONParser(descriptor['source'], True,
                             stream_stable=descriptor['stream_stable'], strict=descriptor['strict'])
    p.index = descriptor['start']
    for context in descriptor['contexts']:
        p.context.set(context)
    state = package[2].StringParseState()
    package[2]._append_string_content(state, descriptor['accumulated'])
    for key, value in descriptor['state'].items():
        setattr(state, key, value.copy() if isinstance(value, list) else value)
    result = guarded(lambda: package[2]._scan_string_body(p, state))
    return [result, p.index, freeze(p.logger), freeze(vars(state)), freeze(p.context.context)]

for i in range(3000):
    before = rng.choice(['', 'é🌲prefix', 'prefix[abc', 'prefix[\u2003', 'prefix{', 'prefix\\', 'x' * 63, 'x' * 64])
    source_prefix = rng.choice(['', 'é🌲', 'xyz'])
    text = source_prefix + ''.join(rng.choices(fragments, k=rng.randint(0, 20)))
    delimiter = rng.choice(['"', "'", '”'])
    descriptor = {
        'source': text, 'start': len(source_prefix), 'accumulated': before,
        'contexts': rng.choice([[], [1], [2], [3], [3, 2]]),
        'stream_stable': bool(i & 1), 'strict': bool(i & 2),
        'state': {'missing_quotes': bool(i & 4), 'doubled_quotes': bool(i & 8),
                  'lstring_delimiter': '“' if delimiter == '”' else delimiter,
                  'rstring_delimiter': delimiter + ('\0' if i & 16 else ''),
                  'unmatched_delimiter': bool(i & 32), 'pending_inline_container': bool(i & 64),
                  'inline_container_stack': rng.choice([[], ['['], ['{'], ['[', '{']]),
                  'object_value_has_no_future_delimiter': bool(i & 128)}}
    compare('scan_calls', descriptor, scan_outcome(baseline, descriptor), scan_outcome(candidate, descriptor))


for sequence in range(100):
    states = [package[2].StringParseState() for package in (baseline, candidate)]
    history = []
    for step in range(40):
        content = ''.join(rng.choices(fragments, k=rng.randint(0, 45)))
        history.append(content)
        for package, state in zip((baseline, candidate), states):
            package[2]._append_string_content(state, content)
        compare('accumulator_steps', {'sequence': sequence, 'step': step, 'history': history.copy()},
                freeze(vars(states[0])), freeze(vars(states[1])))
        if rng.randrange(3) == 0:
            for package, state in zip((baseline, candidate), states):
                package[2]._append_string_content(state, '\\')
                package[2]._replace_last_escape(state, content)
            compare('accumulator_steps', {'sequence': sequence, 'step': step, 'operation': 'replace'},
                    freeze(vars(states[0])), freeze(vars(states[1])))

report = {'python': sys.version, 'source_sha256': hashes, 'checks': checks,
          'mismatches': mismatches, 'timeouts': timeouts,
          'seconds': time.monotonic() - started,
          'final_source_sha256': {str(root): hashlib.sha256((root / 'ports/json_repair/parse_string.py').read_bytes()).hexdigest()
                                  for root in (BASE, CAND)}}
(OUT / 'differential-report.json').write_text(json.dumps(report, ensure_ascii=True, indent=2))
print(json.dumps({k: v for k, v in report.items() if k not in ('mismatches', 'timeouts')}, indent=2))
print('Mismatches:', len(mismatches), 'Watchdog outcomes:', len(timeouts))
sys.exit(bool(mismatches or timeouts))
