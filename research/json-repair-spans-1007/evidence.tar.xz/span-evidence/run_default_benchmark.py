#!/usr/bin/env python3
"""Default json_repair API control. Requires --run; prepare while other work runs.

Execute only after the 208-process span campaign and all builds have stopped.
This script then obtains two adapted-CPython zero-round oracles, builds two AOT
executables, and runs three interleaved AOT/JIT pairs with the unchanged maintained
ten-record consumer. No repository files are edited.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import signal
import statistics
import subprocess
import time

from run_benchmarks import (
    CPU, EVIDENCE, LLVM, SOURCES, atomic_json, command_output, environment,
    sha256, source_identity,
)


PYTHON = Path('/root/.local/bin/python3.13')
BENCH_RELATIVE = Path('bench/json_repair/bench.py')
ROUNDS = 2000
SAMPLES = 5
WARMUPS = 3
PAIRS = 3
WATCHDOG_SECONDS = 120


def execute(args: list[str], env: dict[str, str], cwd: Path, prefix: Path) -> dict:
    stdout_path = prefix.with_suffix('.stdout')
    stderr_path = prefix.with_suffix('.stderr')
    record = {
        'argv': args, 'environment': env, 'cwd': str(cwd),
        'started_at': datetime.now(timezone.utc).isoformat(), 'load_before': os.getloadavg(),
        'stdout_file': str(stdout_path), 'stderr_file': str(stderr_path),
    }
    start = time.monotonic()
    with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
        process = subprocess.Popen(args, cwd=cwd, env=env, stdout=stdout,
                                   stderr=stderr, start_new_session=True)
        timed_out = False
        try:
            while True:
                pid, status, usage = os.wait4(process.pid, os.WNOHANG)
                if pid:
                    break
                if time.monotonic() - start > WATCHDOG_SECONDS:
                    timed_out = True
                    os.killpg(process.pid, signal.SIGKILL)
                    pid, status, usage = os.wait4(process.pid, 0)
                    break
                time.sleep(0.05)
        except BaseException:
            os.killpg(process.pid, signal.SIGKILL)
            _, status, _ = os.wait4(process.pid, 0)
            process.returncode = os.waitstatus_to_exitcode(status)
            raise
        process.returncode = os.waitstatus_to_exitcode(status)
    record.update(
        returncode=process.returncode, timed_out=timed_out,
        wall_seconds=time.monotonic() - start, load_after=os.getloadavg(),
        stdout=stdout_path.read_text(), stderr=stderr_path.read_text(),
        rusage={name: getattr(usage, name) for name in (
            'ru_utime', 'ru_stime', 'ru_maxrss', 'ru_minflt', 'ru_majflt', 'ru_nvcsw', 'ru_nivcsw')},
    )
    return record


def parse_output(stdout: str, rounds: int, samples: int, warmups: int) -> dict:
    lines = stdout.splitlines()
    assert len(lines) == 2 + warmups + 3 * samples, lines
    assert lines[0].startswith('outputs '), lines[:2]
    outputs_json = lines[0][len('outputs '):]
    outputs = json.loads(outputs_json)
    assert isinstance(outputs, list) and len(outputs) == 10, outputs
    assert lines[1] == 'per_round 616', lines[1]
    for line in lines[2:2 + warmups]:
        parts = line.split()
        assert len(parts) == 2 and parts[0] == 'warmup_seconds', line
        value = float(parts[1])
        assert math.isfinite(value) and value >= 0, line
    measured = []
    for index in range(2 + warmups, len(lines), 3):
        assert lines[index] == f'records {rounds * 10}', lines[index]
        assert lines[index + 1] == f'checksum {rounds * 616}', lines[index + 1]
        parts = lines[index + 2].split()
        assert len(parts) == 2 and parts[0] == 'seconds', lines[index + 2]
        seconds = float(parts[1])
        assert math.isfinite(seconds) and seconds >= 0, seconds
        if rounds:
            assert seconds > 0
        measured.append(seconds)
    assert len(measured) == samples
    return {
        'witness': {'outputs_json': outputs_json, 'per_round': 616, 'records_per_round': 10},
        'rounds': rounds, 'samples_seconds': measured,
        'median_seconds': statistics.median(measured),
        'records_per_batch': rounds * 10, 'checksum_per_batch': rounds * 616,
    }


def plan() -> list[dict]:
    rows = []
    for pair in range(PAIRS):
        engines = ('aot', 'jit') if pair % 2 == 0 else ('jit', 'aot')
        variants = ('base', 'candidate') if pair % 2 == 0 else ('candidate', 'base')
        for engine in engines:
            for variant in variants:
                rows.append({'phase': 'measure', 'pair': pair, 'engine': engine, 'variant': variant})
    return rows


def summarize(records: list[dict]) -> list[dict]:
    results = []
    for engine in ('aot', 'jit'):
        rows = [row for row in records if row['phase'] == 'measure' and row['engine'] == engine and 'result' in row]
        base = {row['pair']: row for row in rows if row['variant'] == 'base'}
        candidate = {row['pair']: row for row in rows if row['variant'] == 'candidate'}
        pairs = sorted(base.keys() & candidate.keys())
        if not pairs:
            continue
        for pair in pairs:
            assert base[pair]['result']['witness'] == candidate[pair]['result']['witness']
        base_medians = [base[pair]['result']['median_seconds'] for pair in pairs]
        candidate_medians = [candidate[pair]['result']['median_seconds'] for pair in pairs]
        base_median = statistics.median(base_medians)
        candidate_median = statistics.median(candidate_medians)
        ratios = [candidate_medians[i] / base_medians[i] for i in range(len(pairs))]
        results.append({
            'engine': engine, 'pairs': len(pairs),
            'base_process_medians_seconds': base_medians,
            'candidate_process_medians_seconds': candidate_medians,
            'base_median_seconds': base_median, 'candidate_median_seconds': candidate_median,
            'ratio_of_medians': candidate_median / base_median,
            'percent_change_of_medians': (candidate_median / base_median - 1) * 100,
            'speedup_of_medians': base_median / candidate_median,
            'paired_ratios': ratios, 'median_paired_ratio': statistics.median(ratios),
            'median_paired_percent_change': (statistics.median(ratios) - 1) * 100,
            'base_peak_rss_kib': [base[pair]['rusage']['ru_maxrss'] for pair in pairs],
            'candidate_peak_rss_kib': [candidate[pair]['rusage']['ru_maxrss'] for pair in pairs],
            'witness': base[pairs[0]]['result']['witness'],
        })
    return results


def markdown(summary: list[dict], complete: bool, elapsed: float) -> str:
    lines = [
        '# Default JSON-repair API control', '',
        f'Campaign complete: {complete}; elapsed {elapsed:.1f} seconds.', '',
        'Unchanged `bench/json_repair/bench.py`: ten synthetic records per round,',
        '2,000 rounds (20,000 repairs) per batch, three warmups and five measured',
        'batches per process. This uses the default decoder dispatch and returned',
        'objects; serialization is outside timing. Exact full output witnesses match',
        'both adapted-CPython zero-round oracles and every native execution.', '',
        '| Engine | Pairs | Base ms | Candidate ms | Change | Paired change | Speedup |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: |',
    ]
    for row in summary:
        lines.append(f"| {row['engine']} | {row['pairs']} | {row['base_median_seconds'] * 1000:.3f} | "
                     f"{row['candidate_median_seconds'] * 1000:.3f} | {row['percent_change_of_medians']:+.2f}% | "
                     f"{row['median_paired_percent_change']:+.2f}% | {row['speedup_of_medians']:.3f}× |")
    lines.extend([
        '', 'Times are medians of the per-process medians. Paired changes summarize',
        'the candidate/base ratio in each interleaved pair. Processes were pinned to',
        'CPU 0 and run sequentially on a shared host. Negative change means faster.', '',
        'AOT build commands, times, source/binary hashes and raw records are retained.',
        'AOT RSS excludes compilation. JIT RSS covers the compiler/JIT invocation and',
        'waited-for children; ru_maxrss is a maximum, not aggregate concurrent memory.',
        'The runtime cache may be warmed by the preceding campaign. Process wall time',
        'is retained separately from loop timing; no cold-start claim is made.', '',
        'CPython ran only zero-round output checks, not a peer-runtime performance',
        'campaign. These controls do not establish a general runtime ranking.', '',
    ])
    return '\n'.join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--output', type=Path, default=EVIDENCE / 'default-native')
    args = parser.parse_args()
    measurements = plan()
    if not args.run:
        print(json.dumps({'oracle_processes': 2, 'aot_builds': 2, 'measurements': measurements,
                          'rounds': ROUNDS, 'warmups': WARMUPS, 'samples': SAMPLES,
                          'cpu': CPU, 'output': str(args.output)}, indent=2))
        return
    if CPU not in os.sched_getaffinity(0):
        raise SystemExit('CPU 0 is unavailable')
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    binaries = {variant: output / ('bench-' + variant + '-default') for variant in SOURCES}
    identities = {variant: source_identity(source) for variant, source in SOURCES.items()}
    bench_hashes = {variant: sha256(source / BENCH_RELATIVE) for variant, source in SOURCES.items()}
    assert bench_hashes['base'] == bench_hashes['candidate'], 'maintained benchmark differs between sources'
    parser_hashes = {variant: sha256(source / 'ports/json_repair/parse_string.py') for variant, source in SOURCES.items()}
    metadata = {
        'started_at': datetime.now(timezone.utc).isoformat(), 'sources': identities,
        'benchmark': {'relative_path': str(BENCH_RELATIVE), 'sha256': bench_hashes['base']},
        'cpu': CPU, 'allowed_cpus': sorted(os.sched_getaffinity(0)), 'load': os.getloadavg(),
        'cpuinfo': Path('/proc/cpuinfo').read_text().split('\n\n')[0],
        'python': command_output([str(PYTHON), '--version']),
        'llvm': {tool: command_output([str(LLVM / tool), '--version']) for tool in ('clang', 'lli')},
        'rounds': ROUNDS, 'samples': SAMPLES, 'warmups': WARMUPS, 'plan': measurements,
    }
    atomic_json(output / 'metadata.json', metadata)
    records = []
    oracle = None
    complete = False
    started = time.monotonic()

    def retain(record: dict) -> None:
        records.append(record)
        atomic_json(output / 'runs.json', records)
        if record['returncode']:
            raise RuntimeError(f"{record['phase']} {record['variant']} failed with exit {record['returncode']}")

    try:
        for variant, source in SOURCES.items():
            env = {key: value for key, value in environment(variant).items() if not key.startswith('PYSTACHY_')}
            env['PYTHONPATH'] = str(source / 'ports')
            record = execute([str(PYTHON), str(source / BENCH_RELATIVE), '0', '1', '0'], env, source,
                             output / ('oracle-' + variant))
            record.update(phase='oracle', variant=variant)
            retain(record)
            record['result'] = parse_output(record['stdout'], 0, 1, 0)
            if oracle is None:
                oracle = record['result']['witness']
            assert record['result']['witness'] == oracle, 'adapted CPython oracles disagree'
            atomic_json(output / 'runs.json', records)
        atomic_json(output / 'oracle.json', oracle)
        for variant, source in SOURCES.items():
            env = environment(variant)
            Path(env['PYSTACHY_CACHE']).mkdir(parents=True, exist_ok=True)
            record = execute([str(source / 'pystachy'), 'build', str(source / BENCH_RELATIVE), '-o', str(binaries[variant])],
                             env, source, output / ('build-' + variant))
            record.update(phase='build', variant=variant)
            retain(record)
            record['binary'] = {'path': str(binaries[variant]), 'sha256': sha256(binaries[variant]),
                                'bytes': binaries[variant].stat().st_size}
            atomic_json(output / 'runs.json', records)
            print(f"built {variant}: {record['wall_seconds']:.2f}s", flush=True)
        binary_hashes = {variant: sha256(binary) for variant, binary in binaries.items()}
        metadata['binaries'] = {variant: {'path': str(binary), 'sha256': binary_hashes[variant]}
                                for variant, binary in binaries.items()}
        atomic_json(output / 'metadata.json', metadata)
        for number, row in enumerate(measurements, 1):
            for variant, source in SOURCES.items():
                assert sha256(source / BENCH_RELATIVE) == bench_hashes[variant], 'benchmark changed'
                assert sha256(source / 'ports/json_repair/parse_string.py') == parser_hashes[variant], 'parser changed'
            variant = row['variant']
            source = SOURCES[variant]
            command = ([str(binaries[variant])] if row['engine'] == 'aot' else
                       [str(source / 'pystachy'), 'run', str(source / BENCH_RELATIVE)])
            record = execute(['/usr/bin/taskset', '-c', str(CPU), *command, str(ROUNDS), str(SAMPLES), str(WARMUPS)],
                             environment(variant), source,
                             output / f"{number:02d}-{variant}-{row['engine']}-pair{row['pair']}")
            record.update(row)
            record['rss_scope'] = ('AOT program peak RSS, KiB' if row['engine'] == 'aot' else
                                   'Whole compiler/JIT and waited-for children; ru_maxrss maximum, not concurrent aggregate')
            retain(record)
            record['result'] = parse_output(record['stdout'], ROUNDS, SAMPLES, WARMUPS)
            assert record['result']['witness'] == oracle, 'native output differs from CPython oracle'
            atomic_json(output / 'runs.json', records)
            atomic_json(output / 'summary.json', summarize(records))
            print(f"{number}/{len(measurements)} {variant} {row['engine']} "
                  f"median={record['result']['median_seconds'] * 1000:.3f}ms wall={record['wall_seconds']:.2f}s", flush=True)
        final_identities = {variant: source_identity(source) for variant, source in SOURCES.items()}
        atomic_json(output / 'final-identities.json', final_identities)
        for variant in SOURCES:
            assert final_identities[variant]['files'] == identities[variant]['files'], 'source changed during campaign'
            assert final_identities[variant]['compiler_sha256'] == identities[variant]['compiler_sha256'], 'compiler changed'
            assert sha256(binaries[variant]) == binary_hashes[variant], 'AOT executable changed'
        complete = True
    finally:
        elapsed = time.monotonic() - started
        summary_error = None
        try:
            summary = summarize(records)
        except (AssertionError, KeyError, ValueError) as exc:
            summary = []
            summary_error = repr(exc)
        atomic_json(output / 'summary.json', summary)
        atomic_json(output / 'completion.json', {
            'complete': complete, 'processes_recorded': len(records), 'planned_processes': 16,
            'elapsed_seconds': elapsed, 'summary_error': summary_error,
        })
        (output / 'summary.md').write_text(markdown(summary, complete, elapsed))


if __name__ == '__main__':
    main()
