# Paired ordinary-span measurements

Campaign complete: True. Elapsed wall time: 459.9 seconds.

All values are batch times. Lower is better. Each process median uses seven
measured batches after a separate first batch and three warmups. Reported
times are medians across processes; paired percentages are medians of each
candidate/base process pair. Negative changes mean a faster candidate.

| Engine | Mode | Case | Size | Rounds | Pairs | Base ms | Candidate ms | Change | Paired change | Speedup |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| aot | objects | short | 4096 | 20000 | 5 | 60.995 | 60.631 | -0.60% | -0.62% | 1.006× |
| aot | objects | mixed | 4096 | 5000 | 5 | 106.734 | 83.275 | -21.98% | -22.66% | 1.282× |
| aot | objects | long | 4096 | 200 | 5 | 232.994 | 35.939 | -84.58% | -84.54% | 6.483× |
| aot | objects | sparse | 4096 | 200 | 5 | 221.816 | 34.130 | -84.61% | -84.61% | 6.499× |
| aot | objects | dense | 4096 | 100 | 5 | 169.170 | 171.517 | +1.39% | -0.79% | 0.986× |
| aot | objects | unicode | 4096 | 100 | 5 | 125.943 | 29.769 | -76.36% | -76.69% | 4.231× |
| aot | objects | punctuation | 4096 | 100 | 5 | 114.676 | 75.634 | -34.05% | -34.05% | 1.516× |
| aot | objects | regex | 4096 | 100 | 5 | 106.216 | 85.312 | -19.68% | -19.02% | 1.245× |
| jit | objects | short | 4096 | 20000 | 5 | 73.333 | 73.538 | +0.28% | +0.17% | 0.997× |
| jit | objects | mixed | 4096 | 5000 | 5 | 119.343 | 100.778 | -15.56% | -18.97% | 1.184× |
| jit | objects | long | 4096 | 200 | 5 | 267.944 | 34.205 | -87.23% | -86.65% | 7.833× |
| jit | objects | sparse | 4096 | 200 | 5 | 255.361 | 35.144 | -86.24% | -86.20% | 7.266× |
| jit | objects | dense | 4096 | 100 | 5 | 193.086 | 198.598 | +2.85% | -0.47% | 0.972× |
| jit | objects | unicode | 4096 | 100 | 5 | 142.481 | 29.653 | -79.19% | -79.39% | 4.805× |
| jit | objects | punctuation | 4096 | 100 | 5 | 131.724 | 85.163 | -35.35% | -36.75% | 1.547× |
| jit | objects | regex | 4096 | 100 | 5 | 119.134 | 98.627 | -17.21% | -20.53% | 1.208× |
| aot | serialize | long | 4096 | 200 | 3 | 223.879 | 36.980 | -83.48% | -83.43% | 6.054× |
| aot | serialize | sparse | 4096 | 200 | 3 | 226.926 | 41.773 | -81.59% | -81.59% | 5.432× |
| aot | serialize | dense | 4096 | 100 | 3 | 170.852 | 175.959 | +2.99% | +2.99% | 0.971× |
| aot | serialize | unicode | 4096 | 100 | 3 | 143.774 | 48.499 | -66.27% | -66.12% | 2.964× |
| aot | objects | long | 8192 | 100 | 3 | 222.376 | 35.631 | -83.98% | -83.84% | 6.241× |
| aot | objects | long | 16384 | 100 | 3 | 450.818 | 65.697 | -85.43% | -85.48% | 6.862× |
| aot | objects | sparse | 8192 | 100 | 3 | 225.998 | 32.785 | -85.49% | -85.68% | 6.893× |
| aot | objects | sparse | 16384 | 100 | 3 | 447.901 | 66.895 | -85.06% | -85.06% | 6.696× |

## Scope

These are repeated synthetic controls on a shared host, pinned to CPU 0.
Every native process performs exact full-value, code-point and serialization
checks outside timing. Baseline/candidate witnesses must also match.
All repairs force skip_json_loads=True, isolating the repair parser.
The baseline includes #1003 and #1004; the candidate adds ordinary spans
and the one-code-point storage fast path. See metadata.json for every source
hash, binary hash, command environment, toolchain and CPU identity.

Native AOT peak RSS excludes compilation. JIT RSS covers the entire compiler/JIT
launch and waited-for children, and ru_maxrss reports a maximum rather than
the sum of simultaneously resident processes. Treat startup and RSS separately
from steady batch times. No CPython, PyPy or GraalPy ranking is established.
