"""Longer confirmation of the retained, noisy short default-API campaign."""
import json
import statistics
from pathlib import Path

import run_default_benchmark as bench


def main():
    output = bench.EVIDENCE / "default-confirmation"
    output.mkdir(exist_ok=False)
    original = bench.EVIDENCE / "default-native"
    oracle = json.loads((original / "oracle.json").read_text())
    binaries = {variant: original / ("bench-" + variant + "-default")
                for variant in bench.SOURCES}
    bench.ROUNDS = 10000
    bench.PAIRS = 5
    identities = {variant: bench.source_identity(source)
                  for variant, source in bench.SOURCES.items()}
    binary_hashes = {variant: bench.sha256(binary) for variant, binary in binaries.items()}
    metadata = {"reason": "Short default JIT medians and paired ratios disagreed; retain that campaign and confirm with five longer pairs.",
                "rounds": bench.ROUNDS, "pairs": bench.PAIRS, "samples": bench.SAMPLES,
                "warmups": bench.WARMUPS, "sources": identities,
                "binary_hashes": binary_hashes, "oracle": oracle,
                "original_campaign": str(original), "plan": bench.plan()}
    bench.atomic_json(output / "metadata.json", metadata)
    records = []
    complete = False
    try:
        for number, row in enumerate(bench.plan(), 1):
            variant = row["variant"]
            source = bench.SOURCES[variant]
            command = ([str(binaries[variant])] if row["engine"] == "aot" else
                       [str(source / "pystachy"), "run", str(source / bench.BENCH_RELATIVE)])
            record = bench.execute(["/usr/bin/taskset", "-c", str(bench.CPU), *command,
                                    str(bench.ROUNDS), str(bench.SAMPLES), str(bench.WARMUPS)],
                                   bench.environment(variant), source,
                                   output / f"{number:02d}-{variant}-{row['engine']}-pair{row['pair']}")
            record.update(row)
            records.append(record)
            bench.atomic_json(output / "runs.json", records)
            assert record["returncode"] == 0, record
            record["result"] = bench.parse_output(record["stdout"], bench.ROUNDS, bench.SAMPLES, bench.WARMUPS)
            assert record["result"]["witness"] == oracle, "native output differs from CPython"
            bench.atomic_json(output / "runs.json", records)
            bench.atomic_json(output / "summary.json", bench.summarize(records))
            print(number, len(bench.plan()), variant, row["engine"],
                  round(record["result"]["median_seconds"] * 1000, 3), "ms", flush=True)
        for variant, source in bench.SOURCES.items():
            current = bench.source_identity(source)
            assert current["files"] == identities[variant]["files"]
            assert current["compiler_sha256"] == identities[variant]["compiler_sha256"]
            assert bench.sha256(binaries[variant]) == binary_hashes[variant]
        complete = True
    finally:
        bench.atomic_json(output / "summary.json", bench.summarize(records))
        bench.atomic_json(output / "completion.json", {"complete": complete,
                          "completed_processes": len(records), "planned_processes": len(bench.plan())})


if __name__ == "__main__":
    main()
