#!/usr/bin/env python3
"""Write the publication report only after every retained campaign completes."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import statistics


EVIDENCE = Path(__file__).resolve().parent
REPOSITORY = 'https://github.com/den-run-ai/pystachy'
IMPLEMENTATION = '946bb203c1835af708b5779c388b85482cf7514b'
MAIN = '07b26e02425d023288ed95a9d2a5077be5aeb45e'
INTEGER_FIX = 'dceda23e8b71311c43e5c843698ed4443292004b'
BYTE_SCAN = 'd056aafe2f0c09d72ca23bf14b18123d1e439170'
BASE_TREE = '276e01519733a14303e9d7d29bed2b44df92e37a'
CASE_ORDER = ('short', 'mixed', 'long', 'sparse', 'dense', 'unicode', 'punctuation', 'regex')


def read_json(path: Path):
    return json.loads(path.read_text())


def artifact_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_link(path: str, label: str) -> str:
    return f'[{label}]({REPOSITORY}/blob/{IMPLEMENTATION}/{path})'


def pct(value: float) -> str:
    return f'{value:+.2f}%'


def milliseconds(row: dict, variant: str) -> float:
    if variant + '_median_ns' in row:
        return row[variant + '_median_ns'] / 1e6
    return row[variant + '_median_seconds'] * 1000


def compact_row(row: dict) -> dict:
    keys = ('group', 'engine', 'mode', 'case', 'size', 'rounds', 'pairs',
            'percent_change_of_medians', 'median_paired_percent_change', 'speedup_of_medians',
            'paired_ratios', 'base_peak_rss_kib', 'candidate_peak_rss_kib')
    result = {key: row[key] for key in keys if key in row}
    for variant in ('base', 'candidate'):
        result[variant + '_median_ms'] = milliseconds(row, variant)
        key = variant + '_process_medians_ns'
        if key in row:
            result[variant + '_process_medians_ms'] = [value / 1e6 for value in row[key]]
        else:
            key = variant + '_process_medians_seconds'
            result[variant + '_process_medians_ms'] = [value * 1000 for value in row[key]]
        result[variant + '_median_peak_rss_kib'] = statistics.median(row[variant + '_peak_rss_kib'])
    return result


def span_table(rows: list[dict]) -> str:
    lines = [
        '| Case | AOT base → candidate ms | AOT change / paired | JIT base → candidate ms | JIT change / paired |',
        '| --- | ---: | ---: | ---: | ---: |',
    ]
    by_case = {(row['engine'], row['case']): row for row in rows if row['group'] == 'objects'}
    for case in CASE_ORDER:
        aot, jit = by_case['aot', case], by_case['jit', case]
        lines.append(f"| {case} | {milliseconds(aot, 'base'):.3f} → {milliseconds(aot, 'candidate'):.3f} | "
                     f"{pct(aot['percent_change_of_medians'])} / {pct(aot['median_paired_percent_change'])} | "
                     f"{milliseconds(jit, 'base'):.3f} → {milliseconds(jit, 'candidate'):.3f} | "
                     f"{pct(jit['percent_change_of_medians'])} / {pct(jit['median_paired_percent_change'])} |")
    return '\n'.join(lines)


def other_table(rows: list[dict]) -> str:
    lines = [
        '| AOT control | Size | Rounds | Base → candidate ms | Change / paired |',
        '| --- | ---: | ---: | ---: | ---: |',
    ]
    for row in rows:
        if row['group'] == 'objects':
            continue
        label = ('serialize ' if row['group'] == 'serialization' else 'objects ') + row['case']
        lines.append(f"| {label} | {row['size']} | {row['rounds']} | "
                     f"{milliseconds(row, 'base'):.3f} → {milliseconds(row, 'candidate'):.3f} | "
                     f"{pct(row['percent_change_of_medians'])} / {pct(row['median_paired_percent_change'])} |")
    return '\n'.join(lines)


def default_table(short: list[dict], confirmation: list[dict]) -> str:
    lines = [
        '| Campaign | Engine | Repairs/batch | Pairs | Base → candidate ms | Change / paired |',
        '| --- | --- | ---: | ---: | ---: | ---: |',
    ]
    for label, repairs, rows in [('Initial', 20000, short), ('Confirmation', 100000, confirmation)]:
        for row in rows:
            lines.append(f"| {label} | {row['engine'].upper()} | {repairs} | {row['pairs']} | "
                         f"{milliseconds(row, 'base'):.3f} → {milliseconds(row, 'candidate'):.3f} | "
                         f"{pct(row['percent_change_of_medians'])} / {pct(row['median_paired_percent_change'])} |")
    return '\n'.join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=EVIDENCE / 'publication')
    args = parser.parse_args()
    completions = {}
    for campaign, expected in [('paired-native', 208), ('default-native', 16), ('default-confirmation', 20)]:
        path = EVIDENCE / campaign / 'completion.json'
        if not path.exists():
            raise SystemExit(f'{campaign} has no completion record; report generation is deferred')
        completion = read_json(path)
        if not completion.get('complete'):
            raise SystemExit(f'{campaign} is incomplete; report generation is deferred')
        actual = completion.get('completed_processes', completion.get('processes_recorded'))
        assert actual == expected and completion['planned_processes'] == expected, completion
        assert completion.get('summary_error') is None, completion
        completions[campaign] = completion

    span_rows = read_json(EVIDENCE / 'paired-native/summary.json')
    short_rows = read_json(EVIDENCE / 'default-native/summary.json')
    confirmation_rows = read_json(EVIDENCE / 'default-confirmation/summary.json')
    assert len(span_rows) == 24 and len(short_rows) == len(confirmation_rows) == 2
    assert all(row['pairs'] == (5 if row['group'] == 'objects' else 3) for row in span_rows)
    assert all(row['pairs'] == 3 for row in short_rows)
    assert all(row['pairs'] == 5 for row in confirmation_rows)
    metadata = read_json(EVIDENCE / 'paired-native/metadata.json')
    short_metadata = read_json(EVIDENCE / 'default-native/metadata.json')
    confirmation_metadata = read_json(EVIDENCE / 'default-confirmation/metadata.json')
    assert confirmation_metadata['rounds'] == 10000 and confirmation_metadata['samples'] == 5
    assert confirmation_metadata['warmups'] == 3
    for variant in ('base', 'candidate'):
        assert metadata['sources'][variant]['files'] == short_metadata['sources'][variant]['files']
        assert metadata['sources'][variant]['files'] == confirmation_metadata['sources'][variant]['files']
        assert short_metadata['binaries'][variant]['sha256'] == confirmation_metadata['binary_hashes'][variant]
    differential = read_json(EVIDENCE / 'review/differential-report.json')
    assert sum(differential['checks'].values()) == 16132
    assert not differential['mismatches'] and not differential['timeouts']
    for mode in ('cpython', 'aot', 'aot-gc', 'jit', 'jit-gc'):
        report = read_json(EVIDENCE / (mode + '-corpus.json'))
        assert report == {'cases': 645, 'matched': 645, 'problems': []}, (mode, report)

    memory_row = next(row for row in span_rows if row['group'] == 'scaling' and
                      row['case'] == 'long' and row['size'] == 8192)
    memory_base = statistics.median(memory_row['base_peak_rss_kib'])
    memory_candidate = statistics.median(memory_row['candidate_peak_rss_kib'])
    memory_delta_mib = (memory_candidate - memory_base) / 1024
    first_aot = next(row for row in short_rows if row['engine'] == 'aot')['paired_ratios'][0]
    compact = {
        'implementation_commit': IMPLEMENTATION, 'standalone_base_commit': MAIN,
        'benchmark_base': {'parents': [INTEGER_FIX, BYTE_SCAN], 'tree': BASE_TREE,
                           'local_merge_commit': metadata['sources']['base']['commit']},
        'comparison': 'same adapted port; benchmark candidate adds only the span parse_string.py diff to the combined baseline',
        'host': {'cpu': metadata['cpu'], 'platform': metadata['platform'],
                 'model': next(line.split(':', 1)[1].strip() for line in metadata['cpuinfo'].splitlines()
                               if line.startswith('model name')), 'clang': metadata['llvm']['clang'].splitlines()[0]},
        'source_identities': {variant: {
            'compiler_sha256': metadata['sources'][variant]['compiler_sha256'],
            'files_digest': metadata['sources'][variant]['files_digest'],
            'parser_sha256': metadata['sources'][variant]['files']['ports/json_repair/parse_string.py'],
        } for variant in ('base', 'candidate')},
        'probe_sha256': metadata['probe']['sha256'],
        'forced_repair': {'completion': completions['paired-native'], 'warmups': 3, 'samples': 7,
                          'measurements': [compact_row(row) for row in span_rows]},
        'default_initial': {'completion': completions['default-native'], 'rounds': 2000, 'repairs_per_batch': 20000,
                            'warmups': 3, 'samples': 5, 'measurements': [compact_row(row) for row in short_rows]},
        'default_confirmation': {'completion': completions['default-confirmation'], 'rounds': 10000,
                                 'repairs_per_batch': 100000, 'warmups': 3, 'samples': 5,
                                 'measurements': [compact_row(row) for row in confirmation_rows]},
        'validation': {
            'corpus': {mode: read_json(EVIDENCE / (mode + '-corpus.json'))
                       for mode in ('cpython', 'aot', 'aot-gc', 'jit', 'jit-gc')},
            'hosted_differential': differential['checks'], 'hosted_differential_mismatches': 0,
            'new_native_executions': 8, 'combined_native_executions': 16,
            'accumulator_unit_tests': 9, 'repository_hygiene_unit_tests': 11,
            'ci': 'See ci-ledger.json; no counts inferred from local runs',
        },
        'retained_inputs': {str(path.relative_to(EVIDENCE)): artifact_sha256(path)
                            for path in [EVIDENCE / campaign / name
                                         for campaign in ('paired-native', 'default-native', 'default-confirmation')
                                         for name in ('metadata.json', 'runs.json', 'summary.json', 'completion.json')]},
    }

    text = f'''# Ordinary-text spans in JSON repair: implementation and measurements

The native controls show substantial improvements when malformed strings contain
ordinary runs: about **6.5× AOT and 7.3–7.8× JIT** for long/sparse-escape inputs,
and **4.2–4.8×** for raw Unicode text. Dense escapes gain little, and larger-string
peak memory can increase. The default API's maintained mixed workload is measured
separately below, including its noisy initial campaign and longer confirmation.

## Change and comparison identity

[{IMPLEMENTATION[:8]}]({REPOSITORY}/commit/{IMPLEMENTATION}) is the standalone
span implementation on main `{MAIN[:8]}` in [PR #1007]({REPOSITORY}/pull/1007).
It changes the maintained adaptation of json_repair 0.64.1. The
{source_link('ports/json_repair/parse_string.py', 'parser')} advances across
ordinary code points with a small local scan, then appends the source range once.
It stops at escapes, quotes, structural punctuation and context-sensitive
whitespace, retaining the existing post-append quote/colon heuristics and logs.

The shared accumulator fills its tail and adds complete **64-code-point chunks**
without materializing the entire substring or copying a growing prefix. Arbitrary
appends still update brace/regex metadata; proven ordinary spans omit that work.
A one-code-point path avoids extra slicing on short runs and decoded escapes.
This storage improvement also serves existing inline-container and escape callers.
It is reusable within the parser, with no new compiler transformation, ownership
assumption, byte-index conversion or restriction on accepted programs.

To measure after the correctness fix and account for the existing scanner work,
both benchmark variants use a local merge of
[#1003 `{INTEGER_FIX[:8]}`]({REPOSITORY}/commit/{INTEGER_FIX}) and
[#1004 `{BYTE_SCAN[:8]}`]({REPOSITORY}/commit/{BYTE_SCAN}). Its exact tree is
`{BASE_TREE}`. The candidate adds **only the span parser diff** to that tree;
the compiler and the other ports/libraries are identical. This is not a claim that
these separate PRs are merged. Full identities and all measurements are retained in
[measurements.json](measurements.json) and the [raw archive](evidence.tar.xz).

## Method

LLVM/Clang **18.1.3**, Linux x86-64, Intel Xeon Platinum 8573C, CPU 0 on a shared
host. Processes run sequentially, with baseline/candidate order alternating and
case order rotated. Complete values, Unicode code points and serialized text are
validated outside timers; each timed result contributes to a checked checksum.
All **208** primary-campaign processes completed with matching witnesses.

Tables show batch-time medians across process medians. “Change” is the percentage
change between those medians; “paired” is the median change within process pairs.
Negative percentages mean faster. These are descriptive comparisons, not confidence
intervals; raw process samples are retained.

## Forced-repair controls

The {source_link('bench/extended/json_repair_spans.py', 'standalone probe')}
uses the same adapted port in both variants and forces `skip_json_loads=True`.
Large strings include escapes or raw newlines so the simple-quoted-string shortcut
cannot conceal repair work. These controls isolate repair from valid-JSON decoding.
Each configuration has **five pairs**, three warmups and seven measured batches.
Size is 4,096 target code points except fixed small short/mixed inputs. Rounds per
batch: short 20,000; mixed 5,000 with five repairs each; long/sparse 200; others 100.

{span_table(span_rows)}

Short results are close to unchanged. Dense object-return aggregates are slightly
slower while paired medians are slightly faster; this establishes no dependable
dense-escape gain. The historical repeated `x\\n` workload has almost no ordinary
span to batch. This change does **not** establish that its reported PyPy gap closes.

## Serialization and scaling

These AOT controls use three pairs, three warmups and seven measured batches.
Serialization includes repair plus `repair_json()`'s output encoding. Scaling
uses 100 repairs per batch, whereas the 4,096-size long/sparse rows above use 200;
normalize by calls before comparing sizes.

{other_table(span_rows)}

Long/sparse wins persist at 8,192 and 16,384 code points. Dense serialization costs
about **3.0%** in this campaign and is retained as a tradeoff. No threshold was
relaxed and no slower control was removed.

Peak RSS is also not uniformly better. The 8,192-code-point long control's median
AOT peak rises **{memory_base:.0f} → {memory_candidate:.0f} KiB
(+{memory_delta_mib:.2f} MiB)**. All per-process RSS values are in the compact ledger.
These are process peaks, not allocation counts or evidence of a leak. AOT excludes
compilation; JIT RSS covers the compiler/JIT invocation and waited-for children,
with `ru_maxrss` reporting a maximum rather than total concurrent residency.

## Default API: maintained mixed consumer

The unchanged {source_link('bench/json_repair/bench.py', 'ten-record benchmark')}
uses normal decoder dispatch and returns objects; serialization is outside timing.
Both adapted-CPython zero-round oracles and every native run have identical full
outputs, `per_round=616`, and checked records/checksums. Each process has three
warmups and five measured batches. Both campaigns are retained:

{default_table(short_rows, confirmation_rows)}

The initial JIT summary was **+22.20%** slower by aggregate medians but **+0.89%**
by paired medians; its first AOT pair was **{(first_aot - 1) * 100:+.1f}%** slower.
That disagreement prompted one longer confirmation using unchanged sources and
executables, five pairs and 100,000 repairs per batch. The additional evidence does
not erase the initial variation. This is one repeated synthetic consumer, not a
production workload distribution or a promise of improvement for every document.

## Correctness and verification

The existing **645-case** replay passes in adapted CPython, native JIT/AOT, and
both native modes with collection at every program allocation. This corpus is
not the complete upstream test suite. Independent hosted differential review
compares **16,132** public/parser/scan/accumulator observations against the original
port, including values, errors, logs, positions and metadata, with zero mismatches.

Two new regression programs pass eight normal/stressed native executions; the
combined correctness/scanning/span selection passes 16 native executions.
Nine accumulator unit tests include independent metadata and deterministic work
checks plus negative controls; 11 repository-hygiene tests and local lint pass.
These checks cover code-point/chunk boundaries, Unicode/surrogates, escapes,
quoted keys, regex whitespace, smart quotes, inline containers and streaming EOF.
Compiler/runtime sources are unchanged by the span PR. Local checks and
[CI evidence](ci-ledger.json) are separate; consult that ledger for the reviewed
GitHub revision, workflow outcomes and any pending/skipped work.

## Reproduction and limits

The [portable recipe](reproduction/README.md) reconstructs the pinned baseline,
applies only the parser delta, verifies source hashes, and builds fresh compilers.
Timing requires explicit opt-in after other builds/tests stop. The raw archive
preserves all campaigns, rejected/intermediate pilots, build logs, commands,
environments and source identities; [measurements.json](measurements.json) keeps
the complete compact comparison, including slower cases and memory peaks.

Startup/compilation and process wall time are separate from warmed batch timings.
Runtime caches may already be warm; **no cold-start claim** is made. CPython's
default-API runs are output checks, not a performance comparison; no fresh PyPy,
GraalPy or pristine-upstream ranking was measured. These results support the
ordinary-span optimization within its measured scope, not universal JSON-repair
superiority, full compatibility or release readiness.
'''
    output = args.output.resolve()
    assert 1000 <= len(text.split()) <= 1500, 'report exceeds its reviewed word budget'
    output.mkdir(parents=True, exist_ok=True)
    (output / 'README.md').write_text(text)
    (output / 'measurements.json').write_text(json.dumps(compact, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'report': str(output / 'README.md'), 'measurements': str(output / 'measurements.json'),
                      'word_count': len(text.split()), 'measurement_rows': len(span_rows) + len(short_rows) + len(confirmation_rows)}))


if __name__ == '__main__':
    main()
