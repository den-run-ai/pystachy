import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path('/workspace/scratch/c66a10c5a7b1')
name = sys.argv[1]
assert name in ('alpha1', 'alpha2')
repo = ROOT / ('lean-' + name)
sys.path.insert(0, str(repo / 'tools'))
import lean_report as r

records_path = ROOT / (name + '-lean-records.jsonl')
report_path = ROOT / (name + '-lean-report.md')
lines = [json.loads(line) for line in records_path.read_text().splitlines()]
assert set(lines[0]) == {'header'}
header, records = lines[0]['header'], lines[1:]
programs = r.corpus.corpus()
expected_count = {'alpha1': 2529, 'alpha2': 2550}[name]
actual_names = [row['program'] for row in records]
assert len(programs) == expected_count
assert len(actual_names) == len(set(actual_names)) == expected_count
assert set(actual_names) == set(programs)
assert header['inventory'] == r.inventory(programs) == r.inventory(actual_names)
promoting = set(r.storage_corpus.select(programs))
assert len(header['promoting']) == len(set(header['promoting']))
assert set(header['promoting']) == promoting
assert header['inputs']['corpus']['programs'] == []
conditional = {'int', 'int_inline', 'storage'}
required = {key for key, *_ in r.CHECKS} - conditional
for row in records:
    assert not row.get('error') and not row.get('failed'), row['program']
    expected = required | (conditional if row['program'] in promoting else set())
    assert set(row['checks']) == expected, row['program']
    for check in row['checks'].values():
        assert all(type(check[key]) is int and check[key] >= 0 for key in ('functions', 'obligations', 'proved'))
        assert check['proved'] <= check['obligations']
        assert isinstance(check['unproved'], list)
        assert all(item['status'] in ('rejected', 'unsupported') for item in check['unproved']), row['program']
current_inputs = r.inputs()
assert r.clean_inputs(header['inputs']) and r.clean_inputs(current_inputs)
assert header['inputs'] == current_inputs == r.recorded(report_path)
executables = r.checker_executables(r.boundary.DEFAULT_CHECKER, r.access.DEFAULT_CHECKER)
assert executables == header['checker_executables']
assert header['commit'] == subprocess.check_output(['git', 'rev-parse', '--short=12', 'HEAD'], cwd=repo, text=True).strip()
assert header['python'] == platform.python_version()
assert header['platform'] == sys.platform
completion = r.recorded_completion(report_path)
assert completion == r.meta(header, records)['completion']
assert not r.completion_problem(completion, r.inventory(programs), r.inventory(promoting))
assert not r.summarize(records)['failed']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
result = {'name': name, 'commit': header['commit'], 'full_census_count': expected_count,
          'unique_names_exactly_match_current_corpus': True, 'promoting_programs': len(promoting),
          'required_checks_present_in_every_record': True, 'no_error_or_failed_checks': True,
          'clean_inputs_match_current_source': True, 'checker_executables_match': True,
          'full_completion_metadata_matches': True, 'report_sha256': hashlib.sha256(report_path.read_bytes()).hexdigest(),
          'records_sha256': hashlib.sha256(records_path.read_bytes()).hexdigest()}
(ROOT / (name + '-lean-full-acceptance.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
