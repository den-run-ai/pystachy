import collections
import json
from pathlib import Path
import re
import sys

ROOT = Path('/workspace/scratch/c66a10c5a7b1')
BASELINE = Path(sys.argv[2]) if len(sys.argv) > 2 else Path('/workspace/scratch/c2b093657c17/pystachy/build/lean-report.jsonl')
name = sys.argv[1]
LABEL = sys.argv[3] if len(sys.argv) > 3 else 'history'
sys.path.insert(0, str(ROOT / ('lean-' + name) / 'tools'))
import lean_report

def read(path):
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    return rows[0]['header'], {row['program']: row for row in rows[1:]}

def normalized_reason(text):
    text = re.sub(r'%t\d+', '%tN', text)
    text = re.sub(r'\bL\d+\b', 'LN', text)
    return text

def identity(item):
    return lean_report.base(item['function']), item['status'], normalized_reason(item['reason'])

old_header, old = read(BASELINE)
header, current = read(ROOT / (name + '-lean-records.jsonl'))
summary = lean_report.summarize(list(current.values()))
old_summary = lean_report.summarize(list(old.values()))
added = sorted(current.keys() - old.keys())
missing = sorted(old.keys() - current.keys())
changes = []
new_unproved = []
for program in sorted(old.keys() & current.keys()):
    before, after = old[program], current[program]
    for check in sorted(before.get('checks', {}).keys() | after.get('checks', {}).keys()):
        b, a = before.get('checks', {}).get(check, {}), after.get('checks', {}).get(check, {})
        if a != b:
            changes.append({'program': program, 'check': check, 'before': b, 'after': a})
        previous = collections.Counter(identity(item) for item in b.get('unproved', []))
        for item in a.get('unproved', []):
            key = identity(item)
            if previous[key]:
                previous[key] -= 1
            else:
                new_unproved.append({'program': program, 'check': check, **item})
result = {
    'baseline_commit': old_header['commit'],
    'baseline_note': ('Completed alpha1 final report with clean-input/inventory evidence; comparison only, no records reused.'
                      if LABEL == 'alpha1' else 'Historical completed report predates clean-input/inventory metadata hardening; comparison only, no records reused.'),
    'current_commit': header['commit'],
    'baseline_programs': len(old), 'current_programs': len(current),
    'baseline_summary': old_summary, 'current_summary': summary,
    'added_programs': {name: current[name] for name in added},
    'missing_baseline_programs': missing,
    'shared_program_changes': changes,
    'new_unproved_shared_programs': new_unproved,
}
target = ROOT / (name + '-lean-' + LABEL + '-comparison.json')
target.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'current_programs': len(current), 'added_programs': len(added),
                  'missing_baseline_programs': len(missing), 'shared_changes': len(changes),
                  'new_unproved_shared': new_unproved, 'failed': summary['failed']}, indent=2))
