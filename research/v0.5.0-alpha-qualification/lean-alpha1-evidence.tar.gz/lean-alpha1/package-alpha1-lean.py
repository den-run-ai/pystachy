"""Package accepted Lean evidence, preserving original record/report bytes."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import tarfile

ROOT = Path('/workspace/scratch/c66a10c5a7b1')
DEST = ROOT / 'research-evidence/lean-alpha1'
ARCHIVE = ROOT / 'lean-alpha1-qualification-evidence.tar.gz'
COMMIT = '41cc2dde4705efcf03d9d910455ac72fd5da2312'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    os.nice(15)
    assert not DEST.exists() and not ARCHIVE.exists()
    DEST.mkdir(parents=True)
    acceptance = json.loads((ROOT / 'alpha1-lean-full-acceptance.json').read_text())
    assert acceptance['full_census_count'] == 2529 and acceptance['promoting_programs'] == 175
    assert acceptance['report_sha256'] == sha(ROOT / 'alpha1-lean-report.md')
    assert acceptance['records_sha256'] == sha(ROOT / 'alpha1-lean-records.jsonl')
    assert all(v for k, v in acceptance.items() if isinstance(v, bool))
    state = json.loads((ROOT / 'alpha1-lean-status.json').read_text())
    assert state['commit'] == COMMIT and state['resume'] and state['existing_record_lines'] == 1674
    assert state['report_exit'] == state['status_exit'] == 0
    final_lines = (ROOT / 'alpha1-lean-records.jsonl').read_bytes().splitlines()
    prior_lines = (ROOT / 'lean-alpha1-failed-isolated4/alpha1-lean-records.jsonl').read_bytes().splitlines()
    assert len(final_lines) == 2530 and len(prior_lines) == 1675
    final_records = {json.loads(line)['program']: line for line in final_lines[1:]}
    assert len(final_records) == 2529
    assert final_lines[0] == prior_lines[0]
    assert all(final_records[json.loads(line)['program']] == line for line in prior_lines[1:])
    assert not any(json.loads(line).get('error') or json.loads(line).get('failed') for line in prior_lines[1:])
    comparison = json.loads((ROOT / 'alpha1-lean-history-comparison.json').read_text())
    assert comparison['current_programs'] == 2529 and comparison['baseline_programs'] == 2505
    assert not comparison['missing_baseline_programs'] and not comparison['new_unproved_shared_programs']
    assert json.loads((ROOT / 'alpha1-premerge-github.json').read_text())['head'] == COMMIT
    names = ['alpha1-lean-report.md', 'alpha1-lean-records.jsonl', 'alpha1-lean-status.json',
        'alpha1-lean-full-acceptance.json', 'alpha1-lean-full-acceptance.log', 'alpha1-lean-history-comparison.json',
        'alpha1-lean-qualification.md', 'alpha1-lean.log', 'lean-prepared.json', 'alpha1-premerge-github.json',
        'run-lean-qualification.py', 'verify-lean-full.py', 'compare-lean-history.py', 'package-alpha1-lean.py']
    for dirname in ['lean-alpha1-failed-concurrent', 'lean-alpha1-failed-isolated4']:
        names.extend(str(p.relative_to(ROOT)) for p in sorted((ROOT / dirname).iterdir()) if p.is_file())
    provenance = []
    for name in names:
        source, target = ROOT / name, DEST / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        assert sha(source) == sha(target)
        provenance.append({'path': name, 'original_path': str(source), 'bytes': source.stat().st_size, 'sha256': sha(source)})
    (DEST / 'README.md').write_text('''# Alpha.1 Lean qualification evidence

The accepted full census covers source `41cc2dde4705efcf03d9d910455ac72fd5da2312`, tree `d41286e801afd97f1fb45553d96ca76ccc336583`. Start with `alpha1-lean-qualification.md` for the independent conclusion, affected-program tables and model limits. The report and current-input status both exited 0; independent acceptance checks all 2,529 unique current-corpus records, exact 175-program promoting-int selection, required checks, clean inputs, actual checker hashes and full completion metadata. Zero inspection/check execution failures remain.

## Resume provenance and unsuccessful attempts

1. The initial concurrent four-worker attempt stopped with exit 130 after two SIGKILL inspection errors, leaving 468 records. Its complete preserved files are in `lean-alpha1-failed-concurrent/`. None of those records were reused.
2. A fresh isolated four-worker attempt ended with a broken process pool after 1,674 successful records. Its preserved files are in `lean-alpha1-failed-isolated4/`; it contains no failed program result. Memory pressure was suspected, not proven.
3. The documented resume path validated identical clean source/checker/corpus inputs, actual checker executable hashes, Python/platform and full inventory before accepting exactly those 1,674 same-source successful records. Two workers completed the remaining 855 cases. The package additionally verifies that the isolated header and every resumed record remain byte-identical in the accepted final JSONL. Failed and successful histories remain separately labeled; the final report is a complete census.

The generated report, records, acceptance and status are copied byte-for-byte. `PACKAGE.json` records their original paths/hashes and packaging assertions; `SHA256SUMS` covers every bundled file except itself. The outer gzip archive is deterministic and contains these files, including both unsuccessful-attempt directories. The absolute paths in runner/audit scripts identify the actual execution environment.

## Proof scope and coverage limits

Successful census execution is not a proof of the entire compiler or all runtime behavior. Existing rejected/unsupported model verdicts remain visible in the full report. Against the historical 2,505-case report at `8350a073aab7`, all baseline programs remain, 24 cases are added, and no newly unproved verdict appears on shared programs. Historical rows were used only for comparison and were never resumed.

Coverage is explicitly bounded: eight shared context-manager consumers lose 100 modeled field-initialization obligations when backing/bookkeeping fields become compiler-hidden and excluded by the model. Nullable JSON decoder specialization adds 11 proved obligations, yielding a shared net field change of -89. Removed-null-check obligations change by a shared net +20, all changed obligations proved. The new context-manager Python-int case proves seven modeled storage obligations but has two unsupported FUNCTIONS with unknown obligation counts; these are not two failed obligations. The standalone summary provides the complete affected-program tables.

## Canonical source model documentation

The generated report's original relative links are intentionally unchanged. In this evidence directory, its `README.md` link would refer to this evidence overview, so use these canonical links pinned to the qualified source instead:

- [Dynamic payload model](https://github.com/den-run-ai/pystachy/blob/41cc2dde4705efcf03d9d910455ac72fd5da2312/tools/lean_boundary/README.md)
- [Unchecked access model](https://github.com/den-run-ai/pystachy/blob/41cc2dde4705efcf03d9d910455ac72fd5da2312/tools/lean_boundary/ACCESS.md)
- [Null, closed-union, payload and field models](https://github.com/den-run-ai/pystachy/blob/41cc2dde4705efcf03d9d910455ac72fd5da2312/tools/lean_boundary/GUARDS.md)
- [Collector scanning model](https://github.com/den-run-ai/pystachy/blob/41cc2dde4705efcf03d9d910455ac72fd5da2312/tools/lean_boundary/GC.md)
- [Promoting-int model](https://github.com/den-run-ai/pystachy/blob/41cc2dde4705efcf03d9d910455ac72fd5da2312/tools/lean_boundary/INT.md)
- [Promoting-int storage model](https://github.com/den-run-ai/pystachy/blob/41cc2dde4705efcf03d9d910455ac72fd5da2312/tools/lean_boundary/STORAGE.md)

`alpha1-premerge-github.json` is a preserved premerge PR/check/review snapshot, not evidence for subsequent exact-main release gates. Merge, all four exact-main workflows, native/PyPI publication and public artifact verification remain separate steps. This archive changes no release source and does not itself publish alpha.1.
''')
    package = {'source_commit': COMMIT, 'source_tree': 'd41286e801afd97f1fb45553d96ca76ccc336583',
        'acceptance': acceptance, 'final_report_exit': 0, 'current_input_status_exit': 0,
        'resume': {'original_successful_records': 1674, 'new_records': 855,
            'original_header_byte_identical': True, 'every_resumed_record_byte_identical': True,
            'concurrent_failed_attempt_reused': False},
        'history': {'baseline_commit': comparison['baseline_commit'], 'baseline_programs': 2505,
            'current_programs': 2529, 'added_programs': 24, 'missing_baseline_programs': 0,
            'new_unproved_shared_programs': 0, 'historical_records_reused': False},
        'files_copied_byte_identically': provenance}
    (DEST / 'PACKAGE.json').write_text(json.dumps(package, indent=2) + '\n')
    paths = sorted(p for p in DEST.rglob('*') if p.is_file())
    (DEST / 'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(DEST)}\n' for p in paths))
    paths = sorted(p for p in DEST.rglob('*') if p.is_file())
    with ARCHIVE.open('xb') as raw, gzip.GzipFile(fileobj=raw, filename='', mode='wb', compresslevel=6, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for path in paths:
                data = path.read_bytes()
                info = tarfile.TarInfo('lean-alpha1/' + str(path.relative_to(DEST)))
                info.size = len(data)
                info.mode = 0o644
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(data))
    with tarfile.open(ARCHIVE, 'r:gz') as tar:
        members = tar.getmembers()
        assert len(members) == len(paths)
        for item, path in zip(members, paths):
            assert item.name == 'lean-alpha1/' + str(path.relative_to(DEST))
            assert hashlib.sha256(tar.extractfile(item).read()).hexdigest() == sha(path)
    data = ARCHIVE.read_bytes()
    result = {'archive': str(ARCHIVE), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
        'git_blob_sha': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
        'files': len(paths), 'uncompressed_bytes': sum(p.stat().st_size for p in paths),
        'directory': str(DEST), 'standalone_summary': str(DEST / 'alpha1-lean-qualification.md'),
        'manifest': str(DEST / 'PACKAGE.json'), 'archive_roundtrip_hashes_verified': True}
    (ROOT / 'lean-alpha1-qualification-evidence.manifest.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
