# Alpha.1 Lean qualification evidence

The accepted full census covers source `41cc2dde4705efcf03d9d910455ac72fd5da2312`, tree `d41286e801afd97f1fb45553d96ca76ccc336583`. Start with `alpha1-lean-qualification.md` for the independent conclusion, affected-program tables and model limits. The report and current-input status both exited 0; independent acceptance checks all 2,529 unique current-corpus records, exact 175-program promoting-int selection, required checks, clean inputs, actual checker hashes and full completion metadata. Zero inspection/check execution failures remain.

## Resume provenance and unsuccessful attempts

1. The initial concurrent four-worker attempt stopped with exit 130 after two SIGKILL inspection errors, leaving 468 records. Its complete preserved files are in `lean-alpha1-failed-concurrent/`. None of those records were reused.
2. A fresh isolated four-worker attempt ended with a broken process pool after 1,674 successful records. Its preserved files are in `lean-alpha1-failed-isolated4/`; it contains no failed program result. Memory pressure was suspected, not proven.
3. The documented resume path validated identical clean source/checker/corpus inputs, actual checker executable hashes, Python/platform and full inventory before accepting exactly those 1,674 same-source successful records. Two workers completed the remaining 855 cases. The package additionally verifies that the isolated header and every resumed record remain byte-identical in the accepted final JSONL. Failed and successful histories remain separately labeled; the final report is a complete census.

The generated report, records, acceptance and status are copied byte-for-byte. `PACKAGE.json` records their original paths/hashes and packaging assertions; `SHA256SUMS` covers every bundled file except itself. The outer gzip archive is deterministic and contains these files, including both unsuccessful-attempt directories. The absolute paths in runner/audit scripts identify the actual execution environment.

## Proof scope and coverage limits

Successful census execution is not a proof of the entire compiler or all runtime behavior. Existing rejected/unsupported model verdicts remain visible in the full report. Against the historical 2,505-case report at `8350a073aab7`, all baseline programs remain, 24 cases are added, and no newly unproved verdict appears on shared programs. Historical rows were used only for comparison and were never resumed.

Coverage is explicitly bounded: eight shared context-manager consumers lose 100 modeled field-initialization obligations when backing/bookkeeping fields become compiler-hidden and excluded by the model. Nullable JSON decoder specialization adds 11 proved obligations, yielding a shared net field change of -89. Removed-null-check obligations change by a shared net +20, all changed obligations proved. The new context-manager Python-int case proves seven modeled storage obligations but has two unsupported FUNCTIONS with unknown obligation counts; these are not two failed obligations. The standalone summary provides the complete affected-program tables.

## Canonical source model documentation

The generated report's original relative links are intentionally unchanged. In this evidence directory, its `README.md` link would refer to this evidence overview, so use these canonical links pinned to the qualified source instead:

- [Dynamic payload model](https://github.com/den-run-ai/pystachy/blob/41cc2dde4705efcf03d9d910455ac72fd5da2312/tools/lean_boundary/README.md)
- [Unchecked access model](https://github.com/den-run-ai/pystachy/blob/41cc2dde4705efcf03d9d910455ac72fd5da2312/tools/lean_boundary/ACCESS.md)
- [Null, closed-union, payload and field models](https://github.com/den-run-ai/pystachy/blob/41cc2dde4705efcf03d9d910455ac72fd5da2312/tools/lean_boundary/GUARDS.md)
- [Collector scanning model](https://github.com/den-run-ai/pystachy/blob/41cc2dde4705efcf03d9d910455ac72fd5da2312/tools/lean_boundary/GC.md)
- [Promoting-int model](https://github.com/den-run-ai/pystachy/blob/41cc2dde4705efcf03d9d910455ac72fd5da2312/tools/lean_boundary/INT.md)
- [Promoting-int storage model](https://github.com/den-run-ai/pystachy/blob/41cc2dde4705efcf03d9d910455ac72fd5da2312/tools/lean_boundary/STORAGE.md)

`alpha1-premerge-github.json` is a preserved premerge PR/check/review snapshot, not evidence for subsequent exact-main release gates. Merge, all four exact-main workflows, native/PyPI publication and public artifact verification remain separate steps. This archive changes no release source and does not itself publish alpha.1.
