import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/c66a10c5a7b1')
PREVIOUS = Path('/workspace/scratch/c2b093657c17')
PYTHON = PREVIOUS / 'dev-venv/bin/python'
JOBS = int(os.environ.get('LEAN_QUALIFICATION_JOBS', '4'))
assert 1 <= JOBS <= 4
RESUME = set(os.environ.get('LEAN_QUALIFICATION_RESUME', '').split(','))
env = {key: value for key, value in os.environ.items()
       if not key.startswith('PYSTACHY_') and key != 'PYTHONPATH'}
env['PATH'] = str(PREVIOUS / 'toolchains/lean-4.35.0-linux/bin') + ':' + str(PYTHON.parent) + ':' + env['PATH']
env['PYSTACHY_LLVM'] = str(PREVIOUS / 'toolchains/llvm18/payload/usr/lib/llvm-18/bin')
env['LD_LIBRARY_PATH'] = str(PREVIOUS / 'toolchains/llvm18/payload/usr/lib/llvm-18/lib')
env['PYTHON'] = str(PYTHON)

for name in sys.argv[1:] or ['alpha1', 'alpha2']:
    assert name in ('alpha1', 'alpha2')
    repo = ROOT / ('lean-' + name)
    report = ROOT / (name + '-lean-report.md')
    records = ROOT / (name + '-lean-records.jsonl')
    log = ROOT / (name + '-lean.log')
    resume = name in RESUME
    assert records.exists() if resume else not records.exists(), 'Records must match the requested fresh/resume mode'
    started = time.time()
    command = ['make', 'lean-report', 'PY=' + str(PYTHON),
               'LEAN_REPORT_FLAGS=--jobs ' + str(JOBS) + (' --resume' if resume else '') + ' --start-method spawn --timeout 300 --progress --output ' + str(report) + ' --records ' + str(records)]
    state = {'name': name, 'command': command, 'started': started,
             'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
             'resume': resume, 'existing_record_lines': len(records.read_text().splitlines()) - 1 if resume else 0}
    (ROOT / (name + '-lean-status.json')).write_text(json.dumps(state, indent=2) + '\n')
    with log.open('w') as output:
        result = subprocess.run(command, cwd=repo, env=env, stdout=output, stderr=subprocess.STDOUT)
        state['report_exit'] = result.returncode
        if result.returncode == 0:
            status = subprocess.run([str(PYTHON), 'tools/lean_report.py', '--status', '--output', str(report)], cwd=repo, env=env, stdout=output, stderr=subprocess.STDOUT)
            state['status_exit'] = status.returncode
    state['seconds'] = round(time.time() - started, 2)
    (ROOT / (name + '-lean-status.json')).write_text(json.dumps(state, indent=2) + '\n')
    print(json.dumps(state), flush=True)
    if state['report_exit'] or state.get('status_exit', 1):
        raise SystemExit(1)
