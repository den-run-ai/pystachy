"""Snapshot final sources and capture only completed exact-source native builds."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/c66a10c5a7b1')
OUT = ROOT / 'ir-audit'
OLD = Path('/workspace/scratch/c2b093657c17')
REFS = {
    'v4': '5f81cc2563d231501952104e991d858e670325ac',
    'a1': '41cc2dde4705efcf03d9d910455ac72fd5da2312',
    'a2': '591cd8bdab6fdb54aa036d5094079a32af4fac25',
}
BUILD_REFS = {'a1': '0d695f5a5df049b30d891bd5f43b05ed1e117352',
              'a2': '9997bf2c1551f177506c2c3b2d095c940df715d9'}
TREES = {'a1': 'd41286e801afd97f1fb45553d96ca76ccc336583',
         'a2': '9493b8219a543ddbc1d8c17e5c24b026e2c82d38'}
REPOS = {'v4': ROOT / 'alpha1', 'a1': ROOT / 'alpha1', 'a2': ROOT / 'alpha2'}

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def checked_replace(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)

def prepare(key, log):
    ref, repo = REFS[key], REPOS[key]
    if key == 'v4':
        previous = json.loads((OLD / 'final-irsame-homes.json').read_text())['v4']
        assert previous['source_ref'] == ref
        binary = Path(previous['home']) / 'pystachy'
        assert digest(binary) == previous['binary']['sha256']
        for name, expected in previous['source_files'].items():
            assert digest(Path(previous['home']) / name) == expected, name
        bootstrap = {'baseline_manifest': str(OLD / 'final-irsame-homes.json'),
                     'baseline_manifest_sha256': digest(OLD / 'final-irsame-homes.json')}
    else:
        assert git(repo, 'rev-parse', 'HEAD').decode().strip() in (ref, BUILD_REFS[key])
        assert git(repo, 'rev-parse', ref + '^{tree}').decode().strip() == TREES[key]
        assert git(repo, 'rev-parse', BUILD_REFS[key] + '^{tree}').decode().strip() == TREES[key]
        assert not git(repo, 'status', '--porcelain', '--untracked-files=all').strip()
        assert log is not None and log.is_file()
        text = log.read_text()
        assert 'fixed point: stage1 == stage2 == stage3 (' in text
        assert "fixed point: runtime.py's IR, rt1 == rt2 == rt3 (" in text
        groups = (('stage1.ll', 'stage2.ll', 'stage3.ll'), ('rt1.ll', 'rt2.ll', 'rt3.ll'))
        for group in groups:
            assert len({digest(repo / 'build' / name) for name in group}) == 1, group
        binary = repo / 'pystachy'
        assert digest(binary) == digest(repo / 'build/pystachy2')
        bootstrap = {'log': str(log), 'log_sha256': digest(log),
                     'local_build_source_ref': BUILD_REFS[key],
                     'published_source_ref': ref, 'identical_source_tree': TREES[key],
                     'files': {n: digest(repo / 'build' / n) for g in groups for n in g}}
    home = OUT / ('home-' + key)
    home.mkdir()  # Refuse overwriting any prior evidence.
    archive = git(repo, 'archive', ref)
    with tarfile.open(fileobj=io.BytesIO(archive)) as source:
        source.extractall(home, filter='data')
    for name in ('commit', 'REVISION'):
        (home / name).write_text(ref + '\n')
    snapshot = {str(p.relative_to(home)): digest(p) for p in sorted(home.rglob('*')) if p.is_file()}
    # Home-location comparisons must never hide a user-authored matching literal.
    audit_homes = [str(OUT / ('home-' + name)).encode() for name in REFS]
    for name in snapshot:
        data = (home / name).read_bytes()
        assert not any(prefix in data for prefix in audit_homes), name
    shutil.copy2(binary, home / 'pystachy')
    record = {'key': key, 'source_ref': ref, 'home': str(home),
              'source_archive_sha256': hashlib.sha256(archive).hexdigest(),
              'source_files': snapshot,
              'binary': {'source_path': str(binary), 'sha256': digest(home / 'pystachy')},
              'bootstrap': bootstrap}
    if key != 'v4':
        shell = '''. tests/corpus.sh
corpus
'''
        env = {'PATH': '/usr/bin:/bin', 'LC_ALL': 'C'}
        canonical = subprocess.check_output(['sh', '-c', shell], cwd=home, env=env, text=True).splitlines()
        listing = '''for f in pystachy.py runtime.py tests/programs/*/*.py tests/deviations/*.py bench/*.py bench/pyperformance/*.py tests/ir/*.py tests/errors/*/*.py; do
  [ ! -f "$f" ] || printf '%s\\n' "$f"
done
'''
        cases = subprocess.check_output(['sh', '-c', listing], cwd=home, env=env, text=True).splitlines()
        assert len(cases) == len(set(cases))
        assert set(canonical) <= set(cases)
        assert set(cases) <= set(snapshot)
        record['corpus'] = {'canonical_count': len(canonical), 'total': len(cases),
                            'cases': [{'path': c, 'sha256': snapshot[c]} for c in cases]}
        (OUT / f'{key}-cases.txt').write_text('\n'.join(cases) + '\n')
        original = (home / 'tools/irsame.sh').read_text()
        script = checked_replace(original, 'cd "$(dirname "$0")/.." || exit 1', f'cd {home} || exit 1')
        script = checked_replace(script, 'SHOW=3', 'SHOW=99999')
        script = checked_replace(script, "trap 'rm -rf \"$T\"' EXIT", 'echo "Audit directory: $T"\ntrap \'echo "Audit retained: $T"\' EXIT')
        script = checked_replace(script, 'same() {\n', 'same() {\n  printf \'%s\\n\' "$1" > "$2/case"\n')
        script = checked_replace(script, '  messages=0\n', '  printf \'%s\\n\' "$a" > "$2/old.status"\n  printf \'%s\\n\' "$b" > "$2/new.status"\n  messages=0\n')
        script = checked_replace(script, '  rm -f "$2/old.ll" "$2/new.ll"\n', '''  if [ -s "$2/report" ]; then
    diff -u "$2/old.msg" "$2/new.msg" > "$2/messages.raw.diff" || :
    if [ -f "$2/old.ll" ] && [ -f "$2/new.ll" ]; then
      diff -u "$2/old.ll" "$2/new.ll" > "$2/ir.raw.diff" || :
    fi
  else
    rm -f "$2/old.ll" "$2/new.ll"
  fi
''')
        path = OUT / f'{key}-irsame.sh'
        path.write_text(script)
        subprocess.run(['sh', '-n', str(path)], check=True)
        record['oracle'] = {'original_sha256': digest(home / 'tools/irsame.sh'),
                            'retaining_wrapper': str(path), 'wrapper_sha256': digest(path)}
    (OUT / f'{key}-identity.json').write_text(json.dumps(record, indent=2) + '\n')
    assert len(str(OUT / 'home-v4')) == len(str(OUT / 'home-a1')) == len(str(OUT / 'home-a2'))
    print(json.dumps({'key': key, 'source': ref, 'binary': record['binary']['sha256'],
                      'cases': record.get('corpus', {}).get('total')}))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('candidate', choices=REFS)
    parser.add_argument('--bootstrap-log', type=Path)
    args = parser.parse_args()
    prepare(args.candidate, args.bootstrap_log)
