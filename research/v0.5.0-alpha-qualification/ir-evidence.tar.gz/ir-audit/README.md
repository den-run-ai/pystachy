# v0.5.0 alpha.1 / alpha.2 final-source IR qualification

The two complete corpus audits found no new rejection and no unexplained difference.
Read `a1-report.md` and `a2-report.md` for the exact source identities and every substantive explanation.

| Comparison | Cases | Raw-identical | Home-only IR | Home-only diagnostics | New acceptances | Semantic IR changes | Refined diagnostics |
|---|---:|---:|---:|---:|---:|---:|---:|
| v0.4.0 → alpha.1 | 4,544 | 4,200 | 269 | 14 | 18 | 43 | 0 |
| alpha.1 → alpha.2 | 4,579 | 4,270 | 262 | 14 | 17 | 10 | 6 |

`identities.json` records public commits, equal local build trees, binary hashes, three-stage fixed points, source-archive hashes and complete-manifest hashes. The case ledgers contain every case's input hash, exact statuses, raw diagnostic hashes, retained-output hashes and explanation where required. `*-differences.txt` includes every changed raw LLVM diff, diagnostics and complete LLVM for every new acceptance. Complete old/new LLVM for all changed cases remains retained at the recorded scratch audit paths; large duplicated unchanged bodies are represented here by SHA-256 hashes. Raw-identical LLVM was removed by the oracle after a successful byte comparison, so those rows carry the original oracle result rather than an invented output hash.

The raw oracle returns 1 for any difference. Its semantics were preserved. Auxiliary generated-home comparisons are restricted to reviewed generated source-location constants and diagnostics, with every substituted line retained. Shared-corpus location literals are byte-identical in both raw outputs and remain unmodified. All source/binary inventories were verified before and after both runs.

The reports establish emitted IR compatibility on the exact candidate sources. They do not replace native execution, Lean proof reports, exact-main release workflows or postpublication artifact verification.

Historical performance comment 6875913105 measured alpha.1 `9becfdd64709f792b5b0a803624ed0a2fb1c303c` and alpha.2 `18372f55e8741a312bf5432beb5a92dbbcc6b93b`. Its three advisory workload files are unchanged in the final candidates, but those `bench/smoke` files are outside the corpus oracle's glob. The measurements must remain labeled historical; they are not final-head timings. `smoke_continuity.py` is a prepared, separately gated six-comparison follow-up using the preserved measured binaries and exact-source homes. At this package creation, no compiler invocation or new timing for that follow-up has run. Even a passing follow-up establishes only workload LLVM continuity.

All scripts are audit scratch tooling, not changes to release sources. Their embedded absolute paths identify the retained execution environment. `SHA256SUMS` covers this payload; hashes of complete original identities/reports allow comparison with retained records.
