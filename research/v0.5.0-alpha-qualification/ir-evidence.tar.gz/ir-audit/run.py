"""Run the unchanged comparison semantics with complete retained evidence."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/c66a10c5a7b1/ir-audit')
TOOLS = Path('/workspace/scratch/c2b093657c17/toolchains/llvm18/payload/usr/lib/llvm-18')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify(record):
    home = Path(record['home'])
    assert sha(home / 'pystachy') == record['binary']['sha256']
    for name, expected in record['source_files'].items():
        assert sha(home / name) == expected, name
    expected = set(record['source_files']) | {'pystachy'}
    actual = {str(p.relative_to(home)) for p in home.rglob('*') if p.is_file()}
    assert actual == expected, sorted(actual ^ expected)

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('candidate', choices=('a1', 'a2'))
args = parser.parse_args()
old, new = ('v4', 'a1') if args.candidate == 'a1' else ('a1', 'a2')
records = [json.loads((ROOT / f'{k}-identity.json').read_text()) for k in (old, new)]
for record in records:
    verify(record)
cases = [x['path'] for x in records[1]['corpus']['cases']]
script = ROOT / f'{new}-irsame.sh'
assert sha(script) == records[1]['oracle']['wrapper_sha256']
temporary = ROOT / f'{new}-retained'
temporary.mkdir()
env = {k: v for k, v in os.environ.items() if not k.startswith('PYSTACHY_') and k not in ('PYTHONPATH', 'PYTHONHOME')}
env.update(PYSTACHY_JOBS='2', PYSTACHY_CASE_TIMES=str(ROOT / f'{new}-times.txt'),
           PYSTACHY_LLVM=str(TOOLS / 'bin'), LD_LIBRARY_PATH=str(TOOLS / 'lib'),
           TMPDIR=str(temporary), LC_ALL='C')
command = ['sh', str(script), *[str(Path(r['home']) / 'pystachy') for r in records], *cases]
(ROOT / f'{new}-command.json').write_text(json.dumps({'command': command,
    'overrides': {k: v for k, v in env.items() if k.startswith('PYSTACHY_') or k in ('TMPDIR', 'LC_ALL', 'LD_LIBRARY_PATH')},
    'cleared': 'All inherited PYSTACHY_* plus PYTHONHOME and PYTHONPATH'}, indent=2) + '\n')
with (ROOT / f'{new}-raw.log').open('x') as out:
    result = subprocess.run(command, cwd=ROOT, env=env, stdout=out, stderr=subprocess.STDOUT)
(ROOT / f'{new}-raw.status').write_text(str(result.returncode) + '\n')
for record in records:
    verify(record)
(ROOT / f'{new}-source-rechecked.json').write_text(json.dumps({'before_and_after_inputs_identical': True,
    'identities': [str(ROOT / f'{k}-identity.json') for k in (old, new)], 'raw_exit': result.returncode}, indent=2) + '\n')
print(new, 'raw audit exit:', result.returncode)
print((ROOT / f'{new}-raw.log').read_text()[-1800:])
