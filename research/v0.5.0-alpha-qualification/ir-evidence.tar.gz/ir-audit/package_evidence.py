"""Assemble publication-ready text evidence without changing release sources."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path('/workspace/scratch/c66a10c5a7b1')
SOURCE = ROOT / 'ir-audit'
DEST = ROOT / 'research-evidence' / 'ir-audit'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(name, obj):
    (DEST / name).write_text(json.dumps(obj, indent=2) + '\n')

def main():
    DEST.mkdir(parents=True)
    identities = {}
    for key in ['v4', 'a1', 'a2']:
        path = SOURCE / f'{key}-identity.json'
        data = json.loads(path.read_text())
        full = data.pop('source_files')
        corpus = data.pop('corpus', None)
        data['source_inventory'] = {'file_count': len(full),
            'canonical_json_sha256': hashlib.sha256(json.dumps(full, sort_keys=True, separators=(',', ':')).encode()).hexdigest()}
        data['complete_identity_file_sha256'] = sha(path)
        if corpus:
            data['corpus'] = {'canonical_count': corpus['canonical_count'], 'total': corpus['total'],
                'cases_and_source_hashes': f'{key}-cases.jsonl'}
        identities[key] = data
    write_json('identities.json', identities)
    for key in ['a1', 'a2']:
        report = json.loads((SOURCE / f'{key}-explained.json').read_text())
        identity = json.loads((SOURCE / f'{key}-identity.json').read_text())
        hashes = {x['path']: x['sha256'] for x in identity['corpus']['cases']}
        summary = {k: v for k, v in report.items() if k not in ['cases', 'location_substitutions']}
        summary['complete_explained_report_sha256'] = sha(SOURCE / f'{key}-explained.json')
        summary['raw_oracle_exit_status'] = int((SOURCE / f'{key}-raw.status').read_text())
        summary['raw_oracle_exit_explanation'] = 'Exit 1 deliberately retains all differences; classification/review explains every difference without modifying oracle comparisons.'
        summary['location_substitution_count'] = len(report['location_substitutions'])
        summary['case_ledger'] = f'{key}-cases.jsonl'
        summary['all_changed_raw_diffs'] = f'{key}-differences.txt'
        write_json(f'{key}-summary.json', summary)
        write_json(f'{key}-location-substitutions.json', report['location_substitutions'])
        with (DEST / f'{key}-cases.jsonl').open('w') as ledger, (DEST / f'{key}-differences.txt').open('w') as differences:
            for row in report['cases']:
                row = dict(row)
                directory = Path(row.pop('directory'))
                row['source_sha256'] = hashes[row['case']]
                row['retained_raw_directory'] = str(directory)
                row['evidence'] = {}
                for filename in ['old.status', 'new.status', 'old.msg', 'new.msg', 'report', 'old.ll', 'new.ll',
                                 'messages.raw.diff', 'ir.raw.diff', 'review.diff']:
                    path = directory / filename
                    if path.is_file():
                        row['evidence'][filename] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
                ledger.write(json.dumps(row, separators=(',', ':')) + '\n')
                if row['category'] == 'identical':
                    continue
                differences.write(f"\n===== CASE {row['number']} {row['case']} [{row['category']}] =====\n")
                if row.get('explanation'):
                    differences.write(row['explanation'] + '\n')
                for filename in ['old.msg', 'new.msg', 'messages.raw.diff', 'ir.raw.diff']:
                    path = directory / filename
                    if path.is_file() and path.stat().st_size:
                        differences.write(f'\n--- {filename} ---\n' + path.read_text())
                if row['category'] == 'new_acceptance':
                    differences.write('\n--- complete newly accepted new.ll ---\n' + (directory / 'new.ll').read_text())
        for suffix in ['report.md', 'historical-ir-recheck.json', 'home-location-review.json', 'raw.log', 'raw.status', 'source-rechecked.json', 'irsame.sh']:
            shutil.copy2(SOURCE / f'{key}-{suffix}', DEST / f'{key}-{suffix}')
    for name in ['super-ir-independent-review.md', 'prepare.py', 'run.py', 'inspect.py', 'explain_a1.py', 'explain_a2.py',
                 'alpha1-historical-explanation-seed.json', 'alpha2-historical-explanation-seed.json', 'smoke_continuity.py', 'package_evidence.py']:
        shutil.copy2(SOURCE / name, DEST / name)
    (DEST / 'README.md').write_text('''# v0.5.0 alpha.1 / alpha.2 final-source IR qualification

The two complete corpus audits found no new rejection and no unexplained difference.
Read `a1-report.md` and `a2-report.md` for the exact source identities and every substantive explanation.

| Comparison | Cases | Raw-identical | Home-only IR | Home-only diagnostics | New acceptances | Semantic IR changes | Refined diagnostics |
|---|---:|---:|---:|---:|---:|---:|---:|
| v0.4.0 → alpha.1 | 4,544 | 4,200 | 269 | 14 | 18 | 43 | 0 |
| alpha.1 → alpha.2 | 4,579 | 4,270 | 262 | 14 | 17 | 10 | 6 |

`identities.json` records public commits, equal local build trees, binary hashes, three-stage fixed points, source-archive hashes and complete-manifest hashes. The case ledgers contain every case's input hash, exact statuses, raw diagnostic hashes, retained-output hashes and explanation where required. `*-differences.txt` includes every changed raw LLVM diff, diagnostics and complete LLVM for every new acceptance. Complete old/new LLVM for all changed cases remains retained at the recorded scratch audit paths; large duplicated unchanged bodies are represented here by SHA-256 hashes. Raw-identical LLVM was removed by the oracle after a successful byte comparison, so those rows carry the original oracle result rather than an invented output hash.

The raw oracle returns 1 for any difference. Its semantics were preserved. Auxiliary generated-home comparisons are restricted to reviewed generated source-location constants and diagnostics, with every substituted line retained. Shared-corpus location literals are byte-identical in both raw outputs and remain unmodified. All source/binary inventories were verified before and after both runs.

The reports establish emitted IR compatibility on the exact candidate sources. They do not replace native execution, Lean proof reports, exact-main release workflows or postpublication artifact verification.

Historical performance comment 6875913105 measured alpha.1 `9becfdd64709f792b5b0a803624ed0a2fb1c303c` and alpha.2 `18372f55e8741a312bf5432beb5a92dbbcc6b93b`. Its three advisory workload files are unchanged in the final candidates, but those `bench/smoke` files are outside the corpus oracle's glob. The measurements must remain labeled historical; they are not final-head timings. `smoke_continuity.py` is a prepared, separately gated six-comparison follow-up using the preserved measured binaries and exact-source homes. At this package creation, no compiler invocation or new timing for that follow-up has run. Even a passing follow-up establishes only workload LLVM continuity.

All scripts are audit scratch tooling, not changes to release sources. Their embedded absolute paths identify the retained execution environment. `SHA256SUMS` covers this payload; hashes of complete original identities/reports allow comparison with retained records.
''')
    files = sorted(p for p in DEST.rglob('*') if p.is_file())
    (DEST / 'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(DEST)}\n' for p in files))
    print(json.dumps({'directory': str(DEST), 'files': len(files) + 1,
        'bytes': sum(p.stat().st_size for p in DEST.rglob('*') if p.is_file())}))

if __name__ == '__main__':
    main()
