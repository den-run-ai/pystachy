from pathlib import Path
import json

root = Path('/workspace/scratch/c66a10c5a7b1/ir-audit')
report = json.loads((root / 'a1-summary.json').read_text())
explanations = json.loads((root / 'alpha1-historical-explanation-seed.json').read_text())['explanations']
explanations.update({
 'tests/programs/classes/class_call_none_super_init.py': 'Nullable explicit calls lose the incorrect nonnull contract. The original super receiver is captured once, null returns from the temporary super no-argument initializer, and non-null calls the same base initializer; redundant receiver reloads are removed.',
 'tests/programs/classes/class_call_none_super_init_args.py': 'Explicit nullable exception methods are accepted. The original receiver selects own-super versus bound-base initialization before argument evaluation. The null arm evaluates all arguments before arity/type checks, supports class and None replacement pairs, and propagates argument errors in order.',
 'tests/programs/classes/class_call_none_super_repr.py': 'Explicit nullable calls are accepted. A null original receiver returns the temporary unbound-super string/repr using the declared start class; non-null keeps its base method. Imported class naming, explicit super start classes and reassigned local receivers are exercised.',
 'tests/programs/classes/super_init_builtin_bound.py': 'The explicit call becomes nullable. Its non-null arm retains Base.__init__(self, map, 1); the hypothetical null arm alone raises the documented unsupported builtin instance-check NotImplementedError. The accepted bound program remains valid.',
 'tests/programs/classes/super_init_class_property_bound.py': 'The explicit call becomes nullable and evaluates the proxy argument before entry. Its non-null arm retains the base initializer without inspecting __class__; only the null arm applies the documented __class__-override limit, with a None short-circuit.',
 'tests/programs/classes/super_init_dynamic_class_bound.py': 'The formerly rejected explicit class call is accepted. Its bound receiver keeps exception-base initialization with the dynamic class argument; unsupported checks for the temporary unbound-super case cannot reject the bound program.',
 'tests/programs/classes/super_init_dynamic_class_none.py': 'Explicit nullable calls accept runtime class values with no replacement receiver or a None replacement. The null-arm class test rejects a string with TypeError after evaluating the argument; it does not reject valid boxed class values.',
 'tests/programs/classes/super_init_dynamic_receiver_bound.py': 'The formerly rejected explicit class call is accepted. A non-null original receiver initializes the exception base with its dynamic argument; the limitation on dynamic replacement receivers applies only to the null original-receiver arm.',
 'tests/programs/classes/super_init_star_prior_arg.py': 'Captures the original super receiver and the preceding positional self argument before starred-argument rebinding assigns None to the local. The bound base call receives the saved values; the null arm performs the own-super type check without dereferencing None.',
 'tests/programs/classes/super_init_star_rebind_none.py': 'The explicit class call is newly accepted; its super receiver is captured before the starred walrus assignment. Original-null execution checks the evaluated None argument as a super type; original-bound execution initializes the original exception object, despite the rebound local.',
 'tests/programs/classes/super_init_star_rebind_object.py': 'The explicit class call is newly accepted. The replacement-producing argument executes once after receiver capture; original-null versus original-bound dispatch follows the saved receiver, retaining argument error/effect order.',
 'tests/programs/exceptions/exc_explicit_base_descriptor_none.py': 'Explicit nullable exception calls are accepted. Builtin descriptors validate None only after explicit argument evaluation, with the actual descriptor owner in TypeError. User-defined base methods retain nullable specialization and may handle None themselves.',
 'tests/programs/exceptions/exc_explicit_base_nullable.py': 'Explicit exception-base method chains retain nullable specialization. Arguments and the selected method body execute before guarded field read/write failures; a base method that safely accepts None returns normally. Recursive and inherited chains retain this boundary.',
 'tests/programs/exceptions/exc_keep_fields_super.py': 'Only captures Pair self before the two starred tuple-local loads. The argument values, tuple representation and receiver field writes are unchanged modulo SSA numbering; neither local load has intervening effects.',
 'tests/programs/exceptions/exc_super_imported.py': 'Imported exception methods split nullable super __str__/__repr__ into an unbound-super literal arm and guarded non-null base field accesses. Explicit builtin-base __str__ retains a descriptor TypeError on None. Other differences are dependent literal/SSA renumbering.',
 'tests/deviations/super_init_class_property.py': 'Nullable explicit calls reach own-super initialization. The proxy argument is evaluated before a bounded NotImplementedError for __class__ overrides; a None replacement succeeds; non-null original-receiver calls retain the ordinary base initializer. This is an explicit documented deviation, not full supercheck support.',
 'tests/deviations/super_init_dynamic_receiver.py': 'The previously rejected explicit nullable call is accepted with the documented boundary: runtime-selected ordinary classes or dynamic non-None replacement receivers raise NotImplementedError in the null original-receiver arm after argument effects. CPython accepts the shown replacement pairs.',
})
changed = [x for x in report['cases'] if x['category'] in ('new_acceptance', 'ir_change')]
assert set(explanations) == {x['case'] for x in changed}, (set(explanations) ^ {x['case'] for x in changed})
assert report['counts'] == {'identical': 4200, 'generated_home_only': 269, 'new_acceptance': 18,
                            'ir_change': 43, 'diagnostic_home_only': 14}
for case in changed:
    case['explanation'] = explanations[case['case']]
locations = json.loads((root / 'a1-home-location-review.json').read_text())
assert len(locations) == 20 and all('byte-identical' in x['review'] for x in locations)
historical = json.loads((root / 'a1-historical-ir-recheck.json').read_text())
assert sum(x['old_baseline_ir_identical_to_prior_audit'] and x['identical_final_ir_to_prior_audit'] for x in historical) == 43
assert all(x['test_source_identical_to_prior_audit'] for x in historical)
report.update(source_old='5f81cc2563d231501952104e991d858e670325ac',
              source_new='41cc2dde4705efcf03d9d910455ac72fd5da2312',
              explained=True, retained_shared_corpus_locations=locations,
              historical_ir_recheck=str(root / 'a1-historical-ir-recheck.json'),
              independent_super_ir_review=str(root / 'super-ir-independent-review.md'))
(root / 'a1-explained.json').write_text(json.dumps(report, indent=2) + '\n')
lines = [
 '# Alpha.1 exact-source IR audit', '',
 'Baseline `5f81cc2563d231501952104e991d858e670325ac` → published candidate `41cc2dde4705efcf03d9d910455ac72fd5da2312`.', '',
 '**4,544 cases complete; 0 new rejections; 0 substantive diagnostic changes; all 61 substantive differences explained.** Raw oracle exit 1 records 344 differences: 4,200 raw-identical cases, 269 generated-home-only LLVM differences, 14 source-location-only diagnostic differences, 18 new acceptances and 43 substantive LLVM differences. Compiler-self and runtime IR are raw-identical between the two compilers.', '',
 'The candidate binary came from the completed local `0d695f5a5df049b30d891bd5f43b05ed1e117352` bootstrap; its tree equals the published candidate tree `d41286e801afd97f1fb45553d96ca76ccc336583`. All three compiler stages and all three runtime stages were byte-identical; the installed audit binary matched stage 2. The v0.4.0 binary and its previous complete compiler-source inventory matched the preserved hashes. Identities, full source snapshots, corpus identities and post-run source/binary checks are retained in `a1-identity.json`, `v4-identity.json` and `a1-source-rechecked.json`.', '',
 'Both compilers read their own exact source library in equal-length `home-v4`/`home-a1` directories. The unchanged repository oracle compares exit status, complete diagnostics and raw LLVM, with evidence retention added. Every case has status/messages and changed cases retain full LLVM/diffs. The case list includes the complete canonical differential/rejection corpus plus compiler/runtime, benchmark and IR cases; inventory order and coverage were verified after execution.', '',
 'Auxiliary location comparison substitutes only recognized generated ImportError module locations and exact compiler-home sys.prefix/base_prefix strings; diagnostic substitutions change only reviewed source-location forms. All tracked inputs were checked not to contain the audit-home literals. Twenty additional shared-corpus path strings are byte-identical in both raw outputs and were kept unchanged, not normalized. Their explicit review is in `a1-home-location-review.json`. No unexplained path substitution is used.', '',
 'Of the previously substantive cases, 43 complete old/new LLVM pairs are byte-identical to the prior independently explained audit, and their test sources are unchanged. The tuple-union-kinds case differs from its prior output only in the generated import-location string and corresponding string length. Remaining final-repair differences were inspected directly; five newly substantive super cases also received a separate read-only control-flow review. Evidence is recorded in `a1-historical-ir-recheck.json` and `super-ir-independent-review.md`.', '',
 'The two super-init deviation fixtures describe bounded runtime limitations for dynamic replacement receivers and __class__ overrides. This report does not establish complete first-class super support, native execution correctness, Lean proofs or exact-main CI; those gates are separate.', '',
 '| Case | Category | Explanation |', '|---|---|---|']
for case in changed:
    lines.append(f"| `{case['case']}` | {case['category']} | {case['explanation']} |")
(root / 'a1-report.md').write_text('\n'.join(lines) + '\n')
print('Explained', len(changed), 'substantive cases;', root / 'a1-report.md')
