"""Six bounded historical-to-final LLVM comparisons; never performance timing.

Prepare now with `prepare`; run only after the release owner allows `run`.
Sources are independently archived at exact commits into equal-length homes.
"""
import argparse
import difflib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/c66a10c5a7b1')
AUDIT = ROOT / 'ir-audit'
OUT = AUDIT / 'smoke-continuity'
PRIOR = Path('/workspace/scratch/c2b093657c17')
REPO = ROOT / 'alpha1'
CASES = ['bench/smoke/ml.py', 'bench/smoke/text.py', 'bench/smoke/identity.py']
OLD = {
    'a1': ('9becfdd64709f792b5b0a803624ed0a2fb1c303c', 'bceb61f6455989b8b0f6f31496a9db910c169ad4309f2d67f4ec7b56f924de85'),
    'a2': ('18372f55e8741a312bf5432beb5a92dbbcc6b93b', 'cfe03116a8bde06608929a50cb7329c78de19839439984c5f68fcb9f0606d1f9'),
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

def verify(record):
    home = Path(record['home'])
    assert sha(home / 'pystachy') == record['binary_sha256']
    assert {str(p.relative_to(home)) for p in home.rglob('*') if p.is_file()} == set(record['source_files']) | {'pystachy'}
    for name, expected in record['source_files'].items():
        assert sha(home / name) == expected, name

def prepare():
    OUT.mkdir()
    measured = json.loads((PRIOR / 'final-alpha-performance/results.json').read_text())
    previous = json.loads((PRIOR / 'final-irsame-homes.json').read_text())
    records = {}
    for alpha, (ref, binary_sha) in OLD.items():
        ident = json.loads((AUDIT / f'{alpha}-identity.json').read_text())
        side = 'base' if alpha == 'a1' else 'head'
        assert measured['built_revisions'][side] == ref
        assert measured['identity_before'][side]['compiler_sha256'] == binary_sha
        old_home = Path(previous[alpha]['home'])
        assert previous[alpha]['source_ref'] == ref
        assert previous[alpha]['binary']['sha256'] == binary_sha
        for name, expected in previous[alpha]['source_files'].items():
            assert sha(old_home / name) == expected, name
        for generation, source_ref, binary, expected in [
            ('old', ref, old_home / 'pystachy', binary_sha),
            ('new', ident['source_ref'], Path(ident['home']) / 'pystachy', ident['binary']['sha256']),
        ]:
            assert sha(binary) == expected
            home = OUT / f'{generation}-{alpha}'
            home.mkdir()
            archive = git('archive', source_ref)
            with tarfile.open(fileobj=io.BytesIO(archive)) as tf:
                tf.extractall(home, filter='data')
            for name in ['commit', 'REVISION']:
                (home / name).write_text(source_ref + '\n')
            inventory = {str(p.relative_to(home)): sha(p) for p in sorted(home.rglob('*')) if p.is_file()}
            for name in inventory:
                assert str(OUT).encode() not in (home / name).read_bytes(), name
            shutil.copy2(binary, home / 'pystachy')
            key = f'{generation}-{alpha}'
            records[key] = {'home': str(home), 'ref': source_ref,
                'tree': git('rev-parse', source_ref + '^{tree}').decode().strip(),
                'binary_sha256': expected, 'source_archive_sha256': hashlib.sha256(archive).hexdigest(),
                'source_files': inventory}
        old, new = records[f'old-{alpha}'], records[f'new-{alpha}']
        assert len(old['home']) == len(new['home'])
        for name in CASES:
            assert old['source_files'][name] == new['source_files'][name]
    (OUT / 'identities.json').write_text(json.dumps(records, indent=2) + '\n')
    (OUT / 'prepared.json').write_text(json.dumps({'status': 'prepared, not executed',
        'comparison_count': 6, 'compiler_invocation_count': 12, 'workers': 1,
        'workloads': CASES, 'historical_measurements': str(PRIOR / 'final-alpha-performance/results.json'),
        'historical_measurements_sha256': sha(PRIOR / 'final-alpha-performance/results.json'),
        'identities_sha256': sha(OUT / 'identities.json'), 'script_sha256': sha(Path(__file__))}, indent=2) + '\n')
    print('Prepared six comparisons; no compilers were invoked.')

def normalize(data, own_home, target_home):
    own, target = own_home.encode(), target_home.encode()
    assert len(own) == len(target)
    changes = []
    result = []
    for n, line in enumerate(data.splitlines(keepends=True), 1):
        allowed = False
        if own in line:
            generated = line.startswith(b'@s.') and b' = private unnamed_addr global ' in line
            module = b'c"cannot import name ' in line and re.search(rb" from '[^']+' \(" + re.escape(own) + rb'/lib/[A-Za-z0-9_./-]+\.py\)\\00"\}, align 8\s*$', line)
            prefix = re.search(rb' c"' + re.escape(own) + rb'\\00"\}, align 8\s*$', line)
            allowed = bool(generated and (module or prefix))
            changes.append({'line': n, 'allowed': allowed, 'text': line.decode().rstrip()})
        result.append(line.replace(own, target) if allowed else line)
    return b''.join(result), changes

def run():
    prepared = json.loads((OUT / 'prepared.json').read_text())
    assert prepared['script_sha256'] == sha(Path(__file__))
    assert prepared['identities_sha256'] == sha(OUT / 'identities.json')
    records = json.loads((OUT / 'identities.json').read_text())
    for record in records.values():
        verify(record)
    result_dir = OUT / 'results'
    result_dir.mkdir()
    env = {k: v for k, v in os.environ.items() if not k.startswith('PYSTACHY_') and k not in ['PYTHONPATH', 'PYTHONHOME']}
    llvm = PRIOR / 'toolchains/llvm18/payload/usr/lib/llvm-18'
    env.update(PYSTACHY_PROGRAM_CACHE='0', PYSTACHY_LLVM=str(llvm / 'bin'), LD_LIBRARY_PATH=str(llvm / 'lib'), LC_ALL='C')
    rows = []
    for alpha in OLD:
        old_home, new_home = (records[f'{g}-{alpha}']['home'] for g in ['old', 'new'])
        for case in CASES:
            d = result_dir / f'{alpha}-{Path(case).stem}'
            d.mkdir()
            row = {'alpha': alpha, 'source': case, 'source_sha256': records[f'new-{alpha}']['source_files'][case], 'outputs': {}}
            for generation in ['old', 'new']:
                home = Path(records[f'{generation}-{alpha}']['home'])
                cmd = [str(home / 'pystachy'), 'ir', case]
                with (d / f'{generation}.ll').open('xb') as out, (d / f'{generation}.msg').open('xb') as err:
                    proc = subprocess.run(cmd, cwd=new_home, env=env, stdout=out, stderr=err, timeout=180)
                row['outputs'][generation] = {'command': cmd, 'cwd': new_home, 'exit_status': proc.returncode,
                    'ir_sha256': sha(d / f'{generation}.ll'), 'message_sha256': sha(d / f'{generation}.msg')}
            old, new = (d / 'old.ll').read_bytes(), (d / 'new.ll').read_bytes()
            nmold, old_locs = normalize(old, old_home, old_home)
            nmnew, new_locs = normalize(new, new_home, old_home)
            messages_same = (d / 'old.msg').read_bytes() == (d / 'new.msg').read_bytes()
            if any(r['exit_status'] for r in row['outputs'].values()):
                category = 'requires_review_status'
            elif not messages_same:
                category = 'requires_review_diagnostics'
            elif old == new:
                category = 'raw_identical'
            elif nmold == nmnew and all(x['allowed'] for x in old_locs + new_locs):
                category = 'generated_home_only'
            else:
                category = 'requires_review_ir'
            row.update(category=category, generated_locations={'old': old_locs, 'new': new_locs})
            (d / 'raw.diff').write_text(''.join(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True), fromfile='old.ll', tofile='new.ll')))
            (d / 'location-normalized.diff').write_text(''.join(difflib.unified_diff(nmold.decode().splitlines(True), nmnew.decode().splitlines(True), fromfile='old.location-normalized.ll', tofile='new.location-normalized.ll')))
            rows.append(row)
    for record in records.values():
        verify(record)
    report = {'status': 'complete', 'all_inputs_unchanged': True, 'workers': 1, 'comparisons': rows,
        'limitation': 'Emitted workload LLVM continuity only. No fresh timing, machine-code, executable-size, runtime-cache, or JIT/AOT performance claim.'}
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({f"{r['alpha']}:{r['source']}": r['category'] for r in rows}, indent=2))
    assert len(rows) == 6
    assert all(r['category'] in ['raw_identical', 'generated_home_only'] for r in rows), 'Differences retained; manual review required.'

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode', choices=['prepare', 'run'])
    mode = p.parse_args().mode
    prepare() if mode == 'prepare' else run()
