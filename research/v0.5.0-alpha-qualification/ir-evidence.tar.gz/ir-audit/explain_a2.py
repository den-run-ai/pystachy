from pathlib import Path
import difflib
import json

root = Path('/workspace/scratch/c66a10c5a7b1/ir-audit')
report = json.loads((root / 'a2-summary.json').read_text())
explanations = json.loads((root / 'alpha2-historical-explanation-seed.json').read_text())['explanations']
changed = [c for c in report['cases'] if c['category'] in ('ir_change', 'new_acceptance', 'diagnostic_change')]
assert {c['case'] for c in changed} == set(explanations)
assert report['counts'] == {'identical': 4270, 'generated_home_only': 262, 'new_acceptance': 17,
                            'ir_change': 10, 'diagnostic_change': 6, 'diagnostic_home_only': 14}
history = json.loads((root / 'a2-historical-ir-recheck.json').read_text())
assert len(history) == 33
for row in history:
    assert row['old_raw_messages_identical'] and row['new_raw_messages_identical']
    if row['old_raw_ir_identical'] and row['new_raw_ir_identical']:
        row['review'] = 'Both raw LLVM outputs and diagnostics are identical to the prior explained audit.'
        continue
    # Exactly one known generated location constant differs on each side;
    # verify its entire declaration, including all string-size fields.
    for side, key in (('old', 'a1'), ('new', 'a2')):
        oldhome = '/workspace/scratch/c2b093657c17/irsame-' + key
        newhome = str(root / ('home-' + key))
        def constant(home):
            content = "cannot import name 'MappingProxyType' from 'types' (" + home + '/lib/types.py)'
            n = len(content.encode()) + 1
            return f'@s.10 = private unnamed_addr global {{i64, i64, i64, [{n} x i8]}} {{i64 {n-1}, i64 0, i64 {n}, [{n} x i8] c"{content}\\00"}}, align 8'
        old = (Path(row['prior']) / (side + '.ll')).read_text()
        new = (Path(row['current']) / (side + '.ll')).read_text()
        assert old.count(constant(oldhome)) == new.count(constant(newhome)) == 1
        assert old.replace(constant(oldhome), constant(newhome)) == new
    row['review'] = 'Both LLVM outputs are identical to prior evidence except the exactly checked MappingProxyType ImportError source-home constant and its string-length fields; diagnostics are identical.'
(root / 'a2-historical-ir-recheck.json').write_text(json.dumps(history, indent=2) + '\n')
for case in changed:
    case['explanation'] = explanations[case['case']]
    directory = Path(case['directory'])
    if case['category'] == 'ir_change':
        before = (directory / 'old.location-normalized.ll').read_text()
        after = (directory / 'new.location-normalized.ll').read_text()
        (directory / 'review.diff').write_text('\n'.join(difflib.unified_diff(before.splitlines(), after.splitlines(), n=3)) + '\n')
locations = json.loads((root / 'a2-home-location-review.json').read_text())
assert len(locations) == 20 and all('byte-identical' in x['review'] for x in locations)
report.update(source_old='41cc2dde4705efcf03d9d910455ac72fd5da2312',
              source_new='591cd8bdab6fdb54aa036d5094079a32af4fac25', explained=True,
              retained_shared_corpus_locations=locations,
              historical_ir_recheck=str(root / 'a2-historical-ir-recheck.json'))
(root / 'a2-explained.json').write_text(json.dumps(report, indent=2) + '\n')
lines = ['# Alpha.2 exact-source IR audit', '',
 'Final alpha.1 `41cc2dde4705efcf03d9d910455ac72fd5da2312` → published alpha.2 candidate `591cd8bdab6fdb54aa036d5094079a32af4fac25`.', '',
 '**4,579 cases complete; 0 new rejections; all 33 substantive differences explained.** Raw oracle exit 1 records 309 differences: 4,270 raw-identical cases, 262 generated-home-only LLVM differences, 14 source-location-only diagnostics, 17 intended new acceptances, 10 shared-dispatch LLVM changes and 6 more precise diagnostics on already-rejected programs. Compiler-self and runtime IR are raw-identical between the compilers.', '',
 'The candidate binary came from the completed local `9997bf2c1551f177506c2c3b2d095c940df715d9` bootstrap; its tree equals public candidate tree `9493b8219a543ddbc1d8c17e5c24b026e2c82d38`. All three compiler stages and all three runtime stages were byte-identical, and the audit binary matched stage 2. Final alpha.1 uses the already qualified snapshot. Identity files record public/local source equivalence, all compiler/runtime hashes, full source inventory, corpus identities and unchanged post-run inputs.', '',
 'Both compilers use separate exact-source libraries in equal-length `home-a1`/`home-a2` directories. The oracle retains complete exit statuses, diagnostics and every changed raw LLVM/diff. The complete canonical corpus plus compiler/runtime, benchmark and IR cases is verified in inventory order.', '',
 'Only recognized generated home strings and reviewed diagnostic source locations receive auxiliary location comparison. Twenty shared-corpus import strings are byte-identical on both sides and remain unchanged, as recorded separately. No broader normalization is used.', '',
 'The 33-case substantive set exactly matches the prior independently explained audit. All fixture sources and all diagnostics are unchanged. Twenty-five complete old/new LLVM pairs are byte-identical to prior evidence; the remaining eight pairs differ only in the individually verified MappingProxyType ImportError source-home constant and its corresponding string-size fields. Thus the original shared-dispatch control-flow explanations still describe these exact final outputs. Full evidence is in `a2-historical-ir-recheck.json`.', '',
 'This comparison does not measure AOT runtime-cache performance or replace native execution, Lean proof coverage or exact-main release CI. Those are separate qualification evidence.', '',
 '| Case | Category | Explanation |', '|---|---|---|']
for case in changed:
    lines.append(f"| `{case['case']}` | {case['category']} | {case['explanation']} |")
(root / 'a2-report.md').write_text('\n'.join(lines) + '\n')
print('Explained', len(changed), 'substantive cases;', root / 'a2-report.md')
