# Storage gate repair qualification

Commit `35aef1be5c45433df91d11892b4c25d6c28136ba`, tree `3c9a009434d68906889651d148cb29f6022d2f1f`, parent main `7cb962f03c46c4b015d8e5a69f5aa759c2fa4e7e`. Worktree is clean. Changes are limited to the Python storage adapter and its two existing test files; compiler, runtime, exporter, Lean theorem/checker sources, corpus and CI gates are unchanged.

The required exact-main storage gate previously exited 2 because two functions in `classes/contextmanager_python_int_args.py` read a `kw[extra:int+]` producer through its equivalent `tuple[int+]` view. Their obligation count was unknown, despite all 18,570 inventoried obligations passing elsewhere. The earlier full census's completion status did not satisfy this strict gate.

The adapter now derives the ordered keyword tuple layout only from an actual declared parameter or typed `mem.load` result. It preserves item order, nested representations and `int` versus `int+`. Existing provenance precedence remains intact. Consuming operand views supply no source evidence. Unknown pointers and keyword-record phi/select/call-result sources remain unsupported; general keyword-record joins and transport are outside this bounded model. Existing boundary checks, marker guards, Lean verification and strict corpus failure behavior are unchanged.

| Check | Result |
| --- | --- |
| Full required storage selection | 175 unique programs, accepted; exit 0 in 324.9 seconds with one worker |
| Modeled storage obligations | 18,582 / 18,582 proved; zero rejected, unsupported, unclassified or error functions |
| Registered storage unit glob | All 50 tests passed in 14.684 seconds; Lean executables required |
| Focused changed test files | All 25 tests passed |
| Ruff and diff whitespace | Passed |
| Independent reviews | Root, release_gates and ci_contracts found no blocking issue |

The independent comparison confirms the exact prior 175-program inventory. Only the repaired program changes: 7 to 19 modeled/proved storage obligations, with both previously unsupported functions now accepted (six newly inventoried obligations each). Function inventory remains unchanged. Every other storage count and all arithmetic/inline inventories match the prior exact compiler-source census.

Negative controls reject width changes in both directions, including nested values; preserve ordered mixed widths through pack/unpack; keep unknown pointers and unsupported producer kinds closed; and reject bypassing each actual kwargs tail marker guard. The corrected integration test fails against the original adapter specifically on the original unknown source, and passes with the fix. An earlier test-fixture selection failure (`3 != 1`) is retained separately in `storage-repair-negative-before.log`; it is not used as red-control evidence.

Commands used pinned CPython 3.13.16 with `PYTHONPATH=.:tools` and `LEAN_BOUNDARY_REQUIRED=1`:

```sh
python -m unittest discover -s tools -p 'test_lean_storage*.py'
python tools/check_lean_storage_corpus.py --jobs 1 --timeout 300 --progress --report /workspace/scratch/c66a10c5a7b1/storage-repair-corpus.json
ruff check tools/check_lean_storage.py tools/test_lean_storage.py tools/test_lean_storage_layout.py
git diff --check
```

The three built Lean executables were copied from the previously qualified alpha1 worktree only after verifying all 36 tracked checker-package files were byte-identical. No partial proof records or superseded full-census records were used in the fresh strict storage run.

Evidence: `storage-repair-corpus.json`, `storage-repair-corpus.log`, `storage-repair-corpus-independent-acceptance.json`, `storage-repair-all-unit.log`, `storage-repair-unit.log`, `storage-repair-before.json`, `storage-repair-corrected-negative-before.log`. SHA-256 values and source hashes are in `storage-repair-qualification.json`.

Publication remains blocked pending integration/review, fresh full alpha1 and alpha2 Lean censuses on frozen final identities, and the required exact-main CI/artifact qualification. This document establishes the narrow repair and strict storage gate only; neither alpha is published.
