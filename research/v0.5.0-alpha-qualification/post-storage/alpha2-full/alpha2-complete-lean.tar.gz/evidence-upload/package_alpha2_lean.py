import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

root = Path('/workspace/scratch/7dd0519bc14a')
out = root / 'evidence-upload'
paths = []
for name in ['lean-reports', 'alpha2-independent-review', 'alpha2-independent-runtime-review']:
    paths.extend(p for p in (root / name).iterdir() if p.is_file())
paths.extend(root / name for name in [
    'alpha2-premerge-preflight.json', 'alpha2-premerge-final.json',
    'release-bookkeeping/alpha2-qualified-pr-body.md',
    'evidence-upload/package_alpha2_lean.py',
])
contents = {str(p.relative_to(root)): p.read_bytes() for p in sorted(paths)}
contents['README.md'] = (out / 'alpha2-complete-lean-README.md').read_bytes()
required_hashes = {
    'lean-reports/alpha2-storage-lean-records.jsonl': '98d2cd703064e39dbb14e41f3d13bb1b5df7bbcf4d30903966db4b427ecd09a6',
    'lean-reports/alpha2-storage-lean-report.md': '18eb6dc0772dfbd4b2d95036c724ff9c438a08d7766027cc502587fa403e76cd',
    'alpha2-independent-review/alpha2-final-lean-independent-audit.json': '2fc8ec22aaaa6d1380b937209ecb952d42e263a30ce930512e93cd65f36439bc',
}
for name, expected in required_hashes.items():
    if hashlib.sha256(contents[name]).hexdigest() != expected:
        raise SystemExit('Frozen evidence identity changed: ' + name)
entries = [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
           for name, data in sorted(contents.items())]
manifest = {'version': 'v0.5.0-alpha.2', 'candidate_commit': '950c0440ad793dc6c34664f591383a5e6bba14dd',
            'merged_main_commit': '80490143498d149d407343ba1cb7aedb1db2d2c5',
            'complete_source_tree': '717a8c9386ae9f5f6545cc3686a9e22282fc560c', 'files': entries}
contents['FILE_MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive = out / 'alpha2-complete-lean.tar.gz'
with archive.open('xb') as raw:
    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, data in sorted(contents.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
payload = archive.read_bytes()
manifest['archive'] = {'name': archive.name, 'bytes': len(payload),
                       'sha256': hashlib.sha256(payload).hexdigest(),
                       'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(payload)).encode() + b'\0' + payload).hexdigest()}
with (out / 'alpha2-complete-lean-manifest.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)
    stream.write('\n')
with tarfile.open(archive, 'r:gz') as tar:
    for entry in entries:
        data = tar.extractfile(entry['path']).read()
        if len(data) != entry['bytes'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
            raise SystemExit('Archive verification failed: ' + entry['path'])
print(json.dumps({'archive': manifest['archive'], 'files': len(entries), 'verified': True}, indent=2))
