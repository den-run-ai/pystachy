import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path('/workspace/scratch/7dd0519bc14a/lean-reports')
OLD = Path('/workspace/scratch/c2b093657c17')
PYTHON = OLD / 'dev-venv/bin/python'
name = sys.argv[1]
assert name in ('alpha1', 'alpha2')
prepared = json.loads((OUT / (name + '-storage-lean-prepared.json')).read_text())
repo = Path(prepared['worktree'])
records = OUT / (name + '-storage-lean-records.jsonl')
report = OUT / (name + '-storage-lean-report.md')
resume = '--resume' in sys.argv[2:]
assert records.exists() if resume else not records.exists()
env = {key: value for key, value in os.environ.items() if not key.startswith('PYSTACHY_') and key != 'PYTHONPATH'}
env['PATH'] = str(OLD / 'toolchains/lean-4.35.0-linux/bin') + ':' + str(PYTHON.parent) + ':' + env['PATH']
env['PYSTACHY_LLVM'] = str(OLD / 'toolchains/llvm18/payload/usr/lib/llvm-18/bin')
env['LD_LIBRARY_PATH'] = str(OLD / 'toolchains/llvm18/payload/usr/lib/llvm-18/lib')
env['PYTHON'] = str(PYTHON)
command = [str(PYTHON), 'tools/lean_report.py', '--jobs', '1', '--start-method', 'spawn', '--timeout', '300', '--progress', '--output', str(report), '--records', str(records)]
if resume:
    command.append('--resume')
state = {'name': name, 'started': time.time(), 'command': command, 'commit': subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(), 'tree': subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=repo,text=True).strip(), 'resume':resume, 'existing_record_count':len(records.read_text().splitlines())-1 if resume else 0, 'prepared_provenance':str(OUT/(name+'-storage-lean-prepared.json'))}
assert state['commit']==prepared['commit']
assert state['tree']==prepared['tree']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
status = OUT / (name + '-storage-lean-status.json')
status.write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps(state),flush=True)
with (OUT/(name+'-storage-lean.log')).open('w') as output:
    result = subprocess.run(command,cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
    state['report_exit']=result.returncode
    if result.returncode==0:
        result = subprocess.run([str(PYTHON),'tools/lean_report.py','--status','--output',str(report)],cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
        state['status_exit']=result.returncode
if state.get('status_exit')==0:
    with (OUT/(name+'-storage-lean-full-acceptance.log')).open('w') as output:
        result = subprocess.run([str(PYTHON),str(OUT/'verify-lean-storage-full.py'),name],cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
        state['audit_exit']=result.returncode
state['seconds']=round(time.time()-state['started'],2)
status.write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps(state),flush=True)
raise SystemExit(0 if state.get('report_exit')==state.get('status_exit')==state.get('audit_exit')==0 else 1)
