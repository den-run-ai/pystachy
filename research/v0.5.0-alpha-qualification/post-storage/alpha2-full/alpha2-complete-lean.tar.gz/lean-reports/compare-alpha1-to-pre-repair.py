import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/7dd0519bc14a/lean-reports')
BEFORE = Path('/workspace/scratch/c66a10c5a7b1/alpha1-lean-records.jsonl')
AFTER = ROOT / 'alpha1-storage-lean-records.jsonl'

def load(path):
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    header = rows[0]['header']
    records = rows[1:]
    by_name = {row['program']: row for row in records}
    assert len(records) == len(by_name) == 2529
    assert not any(row.get('error') or row.get('failed') for row in records)
    return header, by_name

old_header, old = load(BEFORE)
new_header, new = load(AFTER)
assert set(old) == set(new)
assert old_header['inputs']['compiler'] == new_header['inputs']['compiler']
changes = []
for name in sorted(new):
    assert set(old[name]['checks']) == set(new[name]['checks'])
    for key, current in new[name]['checks'].items():
        previous = old[name]['checks'][key]
        if previous != current:
            changes.append({'program': name, 'check': key, 'before': previous, 'after': current})
assert len(changes) == 1, changes
change = changes[0]
assert change['program'] == 'tests/programs/classes/contextmanager_python_int_args.py'
assert change['check'] == 'storage'
assert change['before']['functions'] == change['after']['functions']
assert change['before']['obligations'] == change['before']['proved'] == 7
assert change['after']['obligations'] == change['after']['proved'] == 19
assert len(change['before']['unproved']) == 2
assert all(item['status'] == 'unsupported' for item in change['before']['unproved'])
assert not change['after']['unproved']
result = {'before_commit': old_header['commit'], 'after_commit': new_header['commit'], 'unique_programs': 2529,
          'same_compiler_inputs': True, 'same_complete_program_inventory': True,
          'all_nonstorage_checks_identical': True, 'all_other_storage_checks_identical': True,
          'newly_modeled_and_proved_storage_obligations': 12, 'only_change': change,
          'before_records_sha256': hashlib.sha256(BEFORE.read_bytes()).hexdigest(),
          'after_records_sha256': hashlib.sha256(AFTER.read_bytes()).hexdigest()}
(ROOT / 'alpha1-storage-lean-proof-delta.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
