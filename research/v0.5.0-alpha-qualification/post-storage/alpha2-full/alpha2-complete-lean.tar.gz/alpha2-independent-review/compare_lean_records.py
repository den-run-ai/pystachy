"""Read-only comparison of completed or partial Lean records; writes a new summary.

Usage: python compare_lean_records.py BEFORE.jsonl AFTER.jsonl OUTPUT.json
Failed records stay explicit and are excluded from semantic verdict comparisons.
"""
import collections
import json
from pathlib import Path
import re
import sys


def load(path):
    lines = [json.loads(line) for line in path.read_text().splitlines()]
    records = {}
    duplicates = []
    for row in lines[1:]:
        if row['program'] in records:
            duplicates.append(row['program'])
        records[row['program']] = row
    return lines[0]['header'], records, duplicates


def identity(item):
    reason = re.sub(r'%t\d+', '%tN', item['reason'])
    reason = re.sub(r'\bL\d+\b', 'LN', reason)
    return re.sub(r'\.\d+$', '', item['function'] or ''), item['status'], reason


before_path, after_path, output_path = map(Path, sys.argv[1:])
old_header, old, old_duplicates = load(before_path)
new_header, new, new_duplicates = load(after_path)
new_unproved = []
losses = []
changes = []
for program in sorted(old.keys() & new.keys()):
    if any(row.get('error') or row.get('failed') for row in [old[program], new[program]]):
        continue
    for check in sorted(set(old[program].get('checks', {})) | set(new[program].get('checks', {}))):
        before = old[program].get('checks', {}).get(check, {})
        after = new[program].get('checks', {}).get(check, {})
        if before != after:
            changes.append({'program': program, 'check': check, 'before': before, 'after': after})
        previous = collections.Counter(identity(item) for item in before.get('unproved', []))
        for item in after.get('unproved', []):
            key = identity(item)
            if previous[key]:
                previous[key] -= 1
            else:
                new_unproved.append({'program': program, 'check': check, **item})
        if after.get('obligations', 0) < before.get('obligations', 0):
            losses.append({'program': program, 'check': check,
                           'before': before.get('obligations', 0),
                           'after': after.get('obligations', 0)})
result = {
    'baseline_path': str(before_path), 'current_path': str(after_path),
    'baseline_commit': old_header['commit'], 'current_commit': new_header['commit'],
    'baseline_programs': len(old), 'current_programs': len(new),
    'baseline_duplicate_records': old_duplicates, 'current_duplicate_records': new_duplicates,
    'shared_programs': len(old.keys() & new.keys()),
    'added_programs': sorted(new.keys() - old.keys()),
    'missing_programs': sorted(old.keys() - new.keys()),
    'baseline_failed_records': [row for row in old.values() if row.get('error') or row.get('failed')],
    'current_failed_records': [row for row in new.values() if row.get('error') or row.get('failed')],
    'new_unproved_shared_programs': new_unproved, 'obligation_decreases': losses,
    'shared_changes': changes,
    'limitation': 'Historical/partial comparisons do not establish final-source completeness or identities.'
}
with output_path.open('x') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
print(json.dumps({key: value for key, value in result.items()
                  if key in ['baseline_commit', 'current_commit', 'baseline_programs', 'current_programs',
                             'shared_programs', 'new_unproved_shared_programs', 'obligation_decreases']}, indent=2))
