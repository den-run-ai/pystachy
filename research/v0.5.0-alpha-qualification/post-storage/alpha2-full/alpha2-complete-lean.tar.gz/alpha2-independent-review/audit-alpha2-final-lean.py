"""Independently audit frozen full Lean evidence without running any proof checks."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import re
import subprocess
import sys

ROOT = Path("/workspace/scratch/7dd0519bc14a/lean-reports")
OUT = ROOT.parent / "alpha2-independent-review"
REPO = ROOT / "alpha2-source"
SOURCE = "950c0440ad793dc6c34664f591383a5e6bba14dd"
TREE = "717a8c9386ae9f5f6545cc3686a9e22282fc560c"
BASE = "a73c56c92f3aad4b490307a5d1b882e487a57f55"
inputs = {}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def read(path):
    data = path.read_bytes()
    row = {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(), "size": len(data)}
    require(str(path) not in inputs or inputs[str(path)] == row, f"Input changed: {path}")
    inputs[str(path)] = row
    return data


def js(path):
    return json.loads(read(path))


def git(*args, repo=REPO):
    return subprocess.check_output(["git", "-C", str(repo), *args]).decode().strip()


def inv(names):
    names = sorted(names, key=str.encode)
    return {"count": len(names), "sha256": hashlib.sha256(json.dumps(names).encode()).hexdigest()}


require(platform.python_version() == "3.13.16" and sys.flags.optimize == 0, "Use ordinary pinned Python")
prepared = js(ROOT / "alpha2-storage-lean-prepared.json")
status = js(ROOT / "alpha2-storage-lean-status.json")
acceptance = js(ROOT / "alpha2-storage-lean-full-acceptance.json")
delta = js(ROOT / "alpha2-storage-lean-proof-delta.json")
comparison = js(ROOT / "alpha2-vs-alpha1-proof-comparison.json")
preflight = js(ROOT / "python-assertion-preflight.json")
baseline_audit = js(OUT / "alpha1-final-lean-independent-audit.json")
records_path = ROOT / "alpha2-storage-lean-records.jsonl"
report_path = ROOT / "alpha2-storage-lean-report.md"
records_bytes = read(records_path)
report_bytes = read(report_path)
baseline_bytes = read(ROOT / "alpha1-storage-lean-records.jsonl")
require(hashlib.sha256(records_bytes).hexdigest() == "98d2cd703064e39dbb14e41f3d13bb1b5df7bbcf4d30903966db4b427ecd09a6", "Record handoff digest differs")
require(hashlib.sha256(report_bytes).hexdigest() == "18eb6dc0772dfbd4b2d95036c724ff9c438a08d7766027cc502587fa403e76cd", "Report handoff digest differs")
require(hashlib.sha256(baseline_bytes).hexdigest() == "5d70d5faeaecbfb6ddf5a89ae31c5381a443a0d91dc5359c5729eaaf525e34b7", "Baseline records changed")
require(inputs[str(OUT / "alpha1-final-lean-independent-audit.json")]["sha256"] == "c2e43e36908ea2e3c2b7027ce2b1775877ab36d5ef2436c4bbdb1f8c52407e30", "Baseline audit changed")
require(prepared["commit"] == status["commit"] == git("rev-parse", "HEAD") == SOURCE, "Census head differs")
require(prepared["tree"] == status["tree"] == git("rev-parse", "HEAD^{tree}") == TREE, "Census tree differs")
require(git("rev-parse", SOURCE, repo=ROOT.parent / "alpha2") == SOURCE and
        git("rev-parse", SOURCE + "^{tree}", repo=ROOT.parent / "alpha2") == TREE, "Candidate tree differs")
require(prepared["worktree"] == str(REPO) and not git("status", "--porcelain", "--untracked-files=all"),
        "Census checkout not clean")
require(baseline_audit["status"] == "passed" and baseline_audit["release_commit"] == BASE,
        "Baseline not accepted for release source")
require(preflight["optimization_level"] == 0 and preflight["assertions_enabled"] and
        not preflight["pythonoptimize_env_present"], "Recorded validator assertions disabled")
require(prepared["fresh_records"] and prepared["workers"] == 1 and not status["resume"] and
        status["existing_record_count"] == 0 and status["fresh_census_no_records_reused"], "Unexpected record reuse")
require(all(status[k] == 0 for k in ("report_exit", "status_exit", "audit_exit", "proof_delta_exit")),
        "Incomplete report or acceptance execution")
require("--resume" not in status["command"] and status["command"][0] == preflight["executable"] and
        status["command"][1:4] == ["tools/lean_report.py", "--jobs", "1"], "Wrong recorded census command")

lines = [json.loads(line) for line in records_bytes.decode().splitlines()]
old_lines = [json.loads(line) for line in baseline_bytes.decode().splitlines()]
require(set(lines[0]) == set(old_lines[0]) == {"header"}, "Malformed records header")
header, records = lines[0]["header"], lines[1:]
old_header, old_records = old_lines[0]["header"], old_lines[1:]
names = [row["program"] for row in records]
old_names = [row["program"] for row in old_records]
require(len(names) == len(set(names)) == 2550 and len(old_names) == len(set(old_names)) == 2529,
        "Duplicate or incomplete program records")
require(header["inventory"] == inv(names) and old_header["inventory"] == inv(old_names), "Inventory hash differs")
require(header["commit"] == SOURCE[:12] and header["python"] == "3.13.16" and
        header["platform"] == "linux" and header["lean"] == "Lean 4.35.0", "Header tool/source identity differs")
require(header["inputs"]["corpus"]["programs"] == [], "Not a full-corpus run")

# These calls inspect source inventories and aggregate saved records only. None
# invokes a compiler, check_program, a Lean executable, or a workflow.
sys.path.insert(0, str(REPO / "tools"))
import lean_report as r
programs = r.corpus.corpus()
promoting = set(r.storage_corpus.select(programs))
require(set(programs) == set(names) and len(programs) == 2550, "Records differ from current corpus")
require(len(promoting) == 175 and len(header["promoting"]) == 175 and
        set(header["promoting"]) == promoting, "Strict-storage inventory differs")
current_inputs = r.inputs()
require(header["inputs"] == current_inputs == r.recorded(report_path) and
        r.clean_inputs(current_inputs), "Source inputs no longer match census")
require(r.checker_executables(r.boundary.DEFAULT_CHECKER, r.access.DEFAULT_CHECKER) ==
        header["checker_executables"], "Recorded checker executable identity differs")
for executable, expected_hash in prepared["checker_sha256"].items():
    actual = read(REPO / "tools/lean_boundary/.lake/build/bin" / executable)
    require(hashlib.sha256(actual).hexdigest() == expected_hash, "Prepared checker hash differs")
require(set(prepared["checker_sha256"]) == {"pystachy-access", "pystachy-boundary", "pystachy-int"},
        "Missing prepared checker identity")
read(REPO / "tools/lean_report.py")
read(ROOT / "verify-lean-storage-full.py")
read(ROOT / "run-full.py")
read(OUT / "compare_lean_records.py")

keys = {key for key, *_ in r.CHECKS}
conditional = {"int", "int_inline", "storage"}
totals = {key: dict(programs=0, functions=0, obligations=0, proved=0) for key in keys}
for row in records:
    require("error" not in row and not row.get("failed"), "Failed program/check: " + row["program"])
    require(set(row["checks"]) == (keys if row["program"] in promoting else keys - conditional),
            "Missing or extra required check")
    require(re.fullmatch(r"[0-9a-f]{64}", row["snapshot_sha256"]) is not None, "Missing inspected-source digest")
    for key, check in row["checks"].items():
        require(set(check) == {"functions", "obligations", "proved", "unproved"}, "Malformed check")
        require(all(type(check[k]) is int and check[k] >= 0 for k in ("functions", "obligations", "proved")) and
                check["proved"] <= check["obligations"], "Invalid proof counts")
        require(isinstance(check["unproved"], list) and
                all(item["status"] in {"rejected", "unsupported"} for item in check["unproved"]),
                "Failed/unknown verdict")
        totals[key]["programs"] += int(check["obligations"] > 0)
        for field in ("functions", "obligations", "proved"):
            totals[key][field] += check[field]
    if row["program"] in promoting:
        check = row["checks"]["storage"]
        require(check["proved"] == check["obligations"] and check["unproved"] == [], "Strict-storage rejection")
require(totals["storage"]["proved"] == totals["storage"]["obligations"] == 18582, "Wrong strict storage total")

summary = r.summarize(records)
require(summary["programs"] == 2550 and summary["failed"] == [], "Incomplete summary")
for key in keys:
    require(all(summary["checks"][key][field] == value for field, value in totals[key].items()),
            "Independent proof totals differ from report summary")
expected_completion = {"version": 1, "expected": inv(programs), "evaluated": inv(names),
                       "promoting": inv(promoting), "failed": 0}
require(r.recorded_completion(report_path) == expected_completion == r.meta(header, records)["completion"],
        "Completion metadata mismatch")
require(not r.completion_problem(expected_completion, inv(programs), inv(promoting)), "Report incomplete")
render_meta = r.meta(header, records)
render_meta["date"] = datetime.fromtimestamp(status["started"], timezone.utc).strftime("%Y-%m-%d")
require(r.render(summary, render_meta).encode() == report_bytes, "Full Markdown does not reconstruct")
for field in ("unique_names_exactly_match_current_corpus", "required_checks_present_in_every_record",
              "strict_storage_all_selected_programs_accepted_without_unproved_functions",
              "no_error_or_failed_checks", "clean_inputs_match_current_source",
              "checker_executables_match", "all_three_prepared_lean_executable_hashes_match",
              "full_completion_metadata_matches"):
    require(acceptance[field] is True, "Acceptance flag differs from independent result")
require(acceptance["full_census_count"] == 2550 and acceptance["promoting_programs"] == 175 and
        acceptance["records_sha256"] == inputs[str(records_path)]["sha256"] and
        acceptance["report_sha256"] == inputs[str(report_path)]["sha256"], "Acceptance identity differs")

old = {row["program"]: row for row in old_records}
new = {row["program"]: row for row in records}
require(set(old) <= set(new), "A baseline program disappeared")
added = sorted(set(new) - set(old))
require(len(added) == 21 and added == comparison["added_programs"], "Added program inventory mismatch")
changes = []
for program in sorted(old):
    require("error" not in old[program] and not old[program].get("failed"), "Failed baseline record")
    before, after = old[program]["checks"], new[program]["checks"]
    require(set(before) == set(after), "Shared check inventory changed")
    for key in sorted(before):
        b, a = before[key], after[key]
        require(all(a[k] >= b[k] for k in ("functions", "obligations", "proved")),
                "Shared coverage/function/proved count decreased")
        require(a["unproved"] == b["unproved"], "Shared unproved verdict/list changed")
        if a != b:
            require(key == "null" and a["unproved"] == [] and
                    all(a[k] - b[k] == 1 for k in ("functions", "obligations", "proved")),
                    "Unexpected shared proof change")
            changes.append({"program": program, "check": key, "before": b, "after": a})
require(len(changes) == 8 and changes == comparison["shared_changes"], "Shared proof delta differs")
positive = [{"program": c["program"], "check": c["check"],
             "delta": {k: c["after"][k] - c["before"][k] for k in ("functions", "obligations", "proved")}}
            for c in changes]
require(positive == delta["shared_positive_changes"], "Positive delta summary differs")
new_totals = {key: 0 for key in keys - conditional}
new_programs = []
for program in added:
    row = new[program]
    counts = {}
    for key, check in row["checks"].items():
        require(check["proved"] == check["obligations"] and check["unproved"] == [],
                "New program has an unproved obligation")
        new_totals[key] += check["obligations"]
        counts[key] = check["obligations"]
    new_programs.append({"program": program, "proved_obligations": counts})
require(new_totals == {"access": 44, "fields": 605, "gc": 444, "null": 102,
                      "payload": 0, "union": 0, "union_payload": 0} == delta["new_program_obligations"],
        "Added-program totals differ")
require(sum(new_totals.values()) == 1195, "Added obligations count differs")
old_total_proved = sum(check["proved"] for row in old_records for check in row["checks"].values())
new_total_proved = sum(value["proved"] for value in totals.values())
require(new_total_proved - old_total_proved == delta["total_additional_proved_obligations"] == 1203,
        "Total proved delta differs")
for key in ("baseline_duplicate_records", "current_duplicate_records", "missing_programs",
            "baseline_failed_records", "current_failed_records", "new_unproved_shared_programs",
            "obligation_decreases"):
    require(comparison[key] == [], "Comparator reports a failure/loss")
require(new["tests/programs/library/lib_logging.py"]["checks"] ==
        old["tests/programs/library/lib_logging.py"]["checks"], "Historical failed logging case changed proof verdicts")
cm = new["tests/programs/classes/contextmanager_python_int_args.py"]["checks"]["storage"]
require(cm == old["tests/programs/classes/contextmanager_python_int_args.py"]["checks"]["storage"] and
        cm["proved"] == cm["obligations"] == 19 and cm["unproved"] == [], "Storage repair regressed")
for row in inputs.values():
    data = Path(row["path"]).read_bytes()
    require(len(data) == row["size"] and hashlib.sha256(data).hexdigest() == row["sha256"],
            "Input changed during audit")
require(not git("status", "--porcelain", "--untracked-files=all"), "Source changed during audit")

receipt = {
    "kind": "Independent agent audit of complete alpha2 Lean acceptance",
    "status": "passed", "created_utc": datetime.now(timezone.utc).isoformat(),
    "census_commit": SOURCE, "reviewed_candidate_commit": SOURCE, "source_tree": TREE,
    "baseline_release_commit": BASE, "baseline_census_commit": baseline_audit["census_commit"],
    "inputs": list(inputs.values()), "fresh_census_no_records_reused": True,
    "complete_programs": 2550, "baseline_programs": 2529, "shared_programs": 2529,
    "added_programs": 21, "strict_storage_programs": 175, "strict_storage_obligations_proved": 18582,
    "independently_recomputed_proof_totals": {key: totals[key] for key, *_ in r.CHECKS},
    "full_markdown_exactly_reconstructs_from_records": True,
    "full_inventory_and_all_required_checks_verified": True,
    "clean_current_source_and_all_three_checker_hashes_verified": True,
    "recorded_execution_and_acceptance_exit_codes_all_zero": True,
    "new_failed_or_unproved_outcomes_relative_to_alpha1": [],
    "proof_coverage_or_proved_count_decreases_relative_to_alpha1": [],
    "all_existing_unproved_lists_exactly_unchanged": True,
    "shared_check_changes": changes, "all_other_shared_check_dictionaries_identical": True,
    "new_programs": new_programs, "new_program_obligations_fully_proved": new_totals,
    "new_program_obligations_total": 1195, "total_additional_proved_obligations": 1203,
    "historical_lib_logging_failure_not_present": True, "contextmanager_storage_repair_preserved": True,
    "supports_merge_and_publication_from_lean_evidence": True,
    "scope": "Evidence-only independent agent review; no compiler, Lean checker, census, network or workflow reruns and no repository source changes. This certifies complete proof evidence for exact candidate 950c0440 and its source tree. Publication still requires exact-main and artifact gates after integration. This is not a successful GitHub/CLI Codex review.",
}
destination = OUT / "alpha2-final-lean-independent-audit.json"
with destination.open("x") as f:
    f.write(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"status": receipt["status"], "path": str(destination),
                  "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
                  "programs": 2550, "shared_changes": len(changes),
                  "added_program_obligations": 1195, "total_additional_proved": 1203}, indent=2))
