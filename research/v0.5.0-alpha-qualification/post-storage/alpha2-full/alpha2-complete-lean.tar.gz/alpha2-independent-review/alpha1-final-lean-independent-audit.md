# Alpha.1 independent Lean acceptance audit

**Passed. The complete Lean evidence supports publication of alpha.1 from release commit `a73c56c92f3aad4b490307a5d1b882e487a57f55`.** Other workflow and artifact gates remain separate.

The census ran at `6b9e89ee3eaef0c15cfe7ffb7d586ae9e4db9fd8`. Its entire Git source tree `3c9a009434d68906889651d148cb29f6022d2f1f` equals the release commit's tree, independently resolved from the local Git objects.

- All **2,529** unique programs exactly match the current corpus, with every required check present and no inspection or checker failures.
- All **175** selected strict-storage programs are accepted: **18,582/18,582** obligations proved, with no unproved functions.
- The entire Markdown report exactly reconstructs from the final records. Proof totals were also independently summed before comparison with the report summary.
- Current source/input identities, the three Lean checker executable hashes, Python 3.13.16, enabled assertions, completion metadata and all recorded command exits were verified.
- The original **185** resumed records and header remain byte-for-byte unchanged; the original input's recorded hash matches.
- Across all **2,529** programs, comparison with the complete pre-repair baseline identifies exactly one changed check dictionary: context-manager kwargs storage improves from **7/7** to **19/19** proved obligations, eliminating both unsupported functions. Every other proof dictionary is identical; there are no new failed or unproved outcomes or unexplained coverage losses.

The companion JSON records exact hashes of the frozen evidence and all independent conditions. This audit ran no compiler or Lean checks, changed no repository source and made no network requests.
