from collections import deque


class Unused:
    values: deque[int]
    untouched: "list["

    def __init__(self) -> None:
        self.values = deque()
        self.other = []


print("ok")
