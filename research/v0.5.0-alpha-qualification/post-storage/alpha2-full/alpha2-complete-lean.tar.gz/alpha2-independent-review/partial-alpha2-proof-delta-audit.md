# Alpha.2 partial proof-delta audit

**Partial explanatory evidence; not final acceptance.** The complete repaired census and final delta audit supersede this receipt.

The historical alpha.2 attempt has 1,709 records from `591cd8bdab6f`, compared with the complete 2,529-program alpha.1 baseline at `41cc2dde4705`. It covers 1,689 shared programs and 20 added programs. One shared inspection (`lib_logging.py`) was interrupted; 841 requested programs have no record in this attempt.

## Observed deltas

- Among the 1,688 successful shared programs, exactly eight check dictionaries change. Each adds one fully proved null-check obligation and function in an Enum/IntFlag case. The saved IR audit explains these cases through shared `_value_repr_` dispatch extraction.
- No successful shared program loses functions, obligations or proved counts; no new shared rejected or unsupported outcome appears. All other shared check dictionaries are identical.
- All 20 added programs have every obligation proved and no unproved functions: 44 access, 601 field-initialization, 444 collector-scanning and 102 null-check obligations.
- The existing isolated `lib_logging.py` probe succeeds, and all its check dictionaries exactly match alpha.1. This does not replace its required result in the full census.
- The remaining new program is `tests/programs/library/typing_classvar.py`; its final proof result remains outstanding.

## Remaining acceptance requirements

The historical context-manager storage result still contains the two known unsupported kwargs tuple views: 7 proved obligations. The integrated storage-checker repair must produce 19/19 proved obligations, with no unproved functions, in both final censuses. This old partial result does not establish acceptance of that repair.

No additional publication blocker, expected proof-coverage reduction or expected new unsupported outcome was found in these records. Publication still requires the complete 2,550-program alpha.2 census, all 175 strict-storage selections, no inspection/check failures, and a complete delta audit against repaired alpha.1.

## Reproducible evidence

The companion JSON records exact input SHA-256 hashes, all eight complete before/after check dictionaries, the twenty added program names, proof totals, probe status and frozen-source inventory. The analysis reads existing evidence only; it runs no compiler or Lean checks and changes no repository source.
