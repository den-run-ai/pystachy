# Independent alpha.2 compiler review

Independent agent code review; not a successful GitHub Codex or CLI Codex review.

Base: `a73c56c92f3aad4b490307a5d1b882e487a57f55`  
Head: `950c0440ad793dc6c34664f591383a5e6bba14dd`

No actionable new correctness, acceptance, evaluation-order, or merged-stack integration regression found in this reviewed scope.

## Scope

Compiler/class/typing/shared-dispatch changes, related regression/rejection tests and language/release documentation. Driver/AOT runtime cache/verification integration belongs to the other independent reviewer.

## Reviewed contracts

### Shared dispatch

Receiver and explicit arguments are captured once; override-owned defaults remain in selected arms; helper keys include receiver/method/argument types and keyword ordering; None ABI arguments are omitted; dynamic-Any identity, dunders, incompatible/inferred results, generators and context-sensitive paths retain inline dispatch. Helper recursion is disabled and its own frame is uncounted. Nested function compilation retains generated helpers while restoring caller Frame state.

Source: `calls.py:1252-1399`, `functions.py:86-94`.

### Generic visitor binding

Base arity/type arguments are checked, constructor-binding and pass-through unsupported boundaries remain explicit, return bindings resolve through concrete ancestry before recursive specialization. Inherited cls-using methods preserve binding metadata after declaration annotation erasure; field inference distinguishes instance/static/class parameter layouts.

Source: `program.py:155-172`, `program.py:200-225`, `declarations.py:1488-1520`, `templates.py:773-783`.

### Fixed annotated fields and lazy validation

Only hierarchies and their transitive ordinary constructor-parameter dependencies opt into fixed-field classification. Varargs/kwargs and unrelated classes stay outside that expansion; concrete field annotations are still required. Existing positive and rejection fixtures cover those distinctions.

Source: `program.py:324-424`, `program.py:1061-1110`.

### Class constants and typing forms

Substitution is limited to earlier singly bound literal constants in eligible ordinary module-level classes; method defaults and comprehension first iterables receive class scope, lambda bodies and remaining comprehension scopes do not. Dataclass/NamedTuple/unsupported-class boundaries remain guarded; Final-derived assignments preserve reflection annotation marking.

Source: `declarations.py:825-968`, `reflection.py:1039-1057`.

### Composition tests

Read coverage combining wide dispatch, generic visitors, typed defaultdict fields, inherited classmethods, class constants/defaults, override defaults/keywords, exceptions, nullable receivers, and recursion accounting. Reviewed positive and rejection fixtures; did not rerun suites.

Source: `tests/programs/classes/generic_visitor_class_fields.py`, `tests/programs/classes/inheritance_dispatch_wide.py`, `tests/programs/classes/generic_visitor_inherited_classmethod_field.py`, `tests/programs/language/recursion_virtual_frames.py`.

## Targeted check

Hypothesized eager parsing regression disproved: CPython accepts the unused quoted malformed annotation; both alpha1 and alpha2 reject identically. No new acceptance regression and no finding.

Exact commands, binaries, hashes and outputs: `unused-annotation-repro.json`.

## Limits and remaining gates

No builds, native runtime executions, full suites, or heavy checks. Only the coordinated tiny CPython plus two native frontend-only probe invocations. All outputs are scratch-only; no repository or GitHub mutations.

Fresh repaired-source full Lean census, current applicable CI, exact-main gates and publication artifact verification remain separate requirements.

Machine-readable source SHA-256 identities and symbol line ranges are in `compiler-review.json`.
