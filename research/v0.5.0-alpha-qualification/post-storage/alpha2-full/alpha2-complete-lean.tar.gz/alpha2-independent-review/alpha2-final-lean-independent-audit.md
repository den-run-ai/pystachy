# Alpha.2 independent full Lean acceptance audit

**Passed. The complete Lean evidence supports merging the qualified alpha.2 candidate.** Exact-main and publication artifact gates remain separate after integration.

Candidate and census commit: 950c0440ad793dc6c34664f591383a5e6bba14dd. Source tree: 717a8c9386ae9f5f6545cc3686a9e22282fc560c. Comparison baseline: the published alpha.1 commit a73c56c92f3aad4b490307a5d1b882e487a57f55, whose accepted census tree is identical to its release tree.

## Completeness and provenance

All **2,550 unique programs** exactly match the current corpus. Every required check is present, with no failed inspections or checker executions. This was a fresh census: no old records were reused. The whole Markdown report reconstructs byte for byte from the final records, and its numerical proof totals were independently recomputed before checking the renderer's summary.

The frozen source remains clean; current compiler/checker/corpus input identities match the record header and report. All three prepared Lean checker executable hashes match. Python 3.13.16, enabled assertions, Lean 4.35.0, completion metadata, and all recorded report/status/acceptance/comparison exits were verified.

All **175 selected strict-storage programs** are accepted: **18,582 of 18,582 obligations proved**, with no unproved storage functions. The repaired context-manager kwargs case remains 19/19, without unsupported functions. The historical interrupted logging case completed successfully and its check dictionaries equal alpha.1's.

## Complete comparison with alpha.1

All **2,529 baseline programs** remain present. Every shared check dictionary was compared directly, including its exact unproved list. Exactly **eight** shared dictionaries change: each is a null-check result gaining one function, one obligation and one proved result, with no unproved entries before or after. Every other shared dictionary is identical. There are no decreases in functions, obligations or proved counts, and no new failed, rejected or unsupported outcomes. Existing bounded-model unproved verdicts from alpha.1 remain unchanged.

All **21 added programs** have every obligation proved:

| Check | Added programs' obligations | Proved |
|---|---:|---:|
| Unchecked accesses | 44 | 44 |
| Field initialization | 605 | 605 |
| Collector scanning | 444 | 444 |
| Removed null checks | 102 | 102 |
| Other checks | 0 | 0 |
| **Total** | **1,195** | **1,195** |

Together with the eight shared-program gains, the full census adds **1,203 proved obligations**. The final records include typing_classvar.py's four field obligations, which were absent from the historical partial census.

## Frozen evidence

- Full records SHA-256: 98d2cd703064e39dbb14e41f3d13bb1b5df7bbcf4d30903966db4b427ecd09a6
- Full report SHA-256: 18eb6dc0772dfbd4b2d95036c724ff9c438a08d7766027cc502587fa403e76cd
- Independent JSON receipt SHA-256: 2fc8ec22aaaa6d1380b937209ecb952d42e263a30ce930512e93cd65f36439bc

The JSON receipt preserves exact hashes of the evidence and current checker binaries, every shared change, all 21 added programs and independently summed totals for every check. This audit performed no compiler, Lean checker, census, network or workflow reruns, and made no repository source changes. It is an independent agent review, not a successful GitHub or CLI Codex review.
