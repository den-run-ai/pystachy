# Alpha.2 independent runtime source review

**Completed independent agent source review: no concrete new release-blocking defect found in the assigned scope.** This is a source review, not a completed GitHub Codex/CLI review or an execution qualification result.

## Source identity

| Item | Value |
| --- | --- |
| Reviewer | `/root/release_pipeline` (did not author these changes) |
| Repository | `den-run-ai/pystachy` |
| Base | `a73c56c92f3aad4b490307a5d1b882e487a57f55` |
| Head | `950c0440ad793dc6c34664f591383a5e6bba14dd` |
| Base tree | `3c9a009434d68906889651d148cb29f6022d2f1f` |
| Head tree | `717a8c9386ae9f5f6545cc3686a9e22282fc560c` |
| Full binary diff SHA-256 | `0c1c14eea19277a49e52aad572156d6ae14845c7192e218644f7facef8e6b5d7` |
| Captured UTC | `2026-11-14T16:03:39.829031+00:00` |
| Checkout state | Clean before and after review |

The base is the merge base and an ancestor of the reviewed head. Review was read-only: no source edits, GitHub writes, builds or tests.

## Scope and findings

Reviewed the actual diff and surrounding implementation for the driver, new AOT runtime splitter, runtime opt-in guard, cache tests, AOT qualification tools, verification registration and counts, and storage-proof integration. Compiler class, typing and dispatch semantics are assigned to the other independent reviewer. **Findings: none in this scope.**

### Runtime identity and linking

The object/interface split exposes formerly local runtime symbols as hidden external definitions in the object while supplying available-external bodies or declarations to the optimizer. Inlined code and out-of-line runtime code therefore address the same static state. Replaceable function definitions are never offered for inlining, and unsupported replaceable globals or unnamed definitions cause reuse preparation to fail. Interface assembly verifies LLVM legality before the driver selects reuse. The existing state-sharing test includes a negative control that deliberately duplicates static state.

The driver specializes the runtime for the program's plain/opt-in mode before splitting. ASan, JIT and extensions remain outside object reuse. The late allocator module uses an externally reachable anchor to import the allocator body, then forces late inlining and eliminates available-external definitions before code generation. The new dynamic-wide-int formatting guard matches the existing opt-in representation boundary.

### Cache and fallback

The hosted compiler cache identity includes the new AOT module; the native compiler identity includes its executable. Source and tool stability checks still gate publication. All three reuse artifacts must be present, and preparation failure falls back to full-runtime compilation. Partial publication switches each moved artifact to its published path while retaining unmoved private artifacts, preventing deleted-input links. The targeted test covers all eight subsets of publication moves and checks resulting input bytes and cleanup.

### Verification integration

The new runtime test file is selected by the existing CI runtime-test wildcard with the configured LLVM toolchain. Cache verification now expects all 192 checks across the native and hosted lanes. The AOT probe checks that the expected mode-specific runtime object was actually linked and that the matching interface has the expected `pys_plain` constant; output-only success via silent fallback cannot satisfy those assertions. The added inheritance scaling checks strengthen the existing verification script without removing checks.

### Storage proof and #1492

The merged storage repair is identical in the review base and head. The repair recovers keyword tuple layout only from declared parameter representations or typed memory-read producers, and preserves the obligations for promoting/narrowing tuple views. A consuming tuple view is not accepted as source-layout evidence. Unsupported keyword joins/calls continue to fail normalization.

The strict corpus treats inspection failures, unsupported functions, rejected proofs and checker failures as non-success. It rejects a vanished obligation inventory and incomplete accounting. Batch coverage checks require every recorded obligation exactly once. The full Lean report remains distinct from this strict acceptance gate. The added producer-mutation and guard-removal tests exercise the relevant fail-closed boundaries in source; this reviewer did not execute them.

## Limits and remaining evidence

This review does not establish executed behavior on Linux/macOS, measured performance, completed exact-head CI, or the result of the active Lean census. Those results and the exact-main release/artifact gates remain required. Declared parameter and typed memory-read layout remain documented trust inputs; general keyword transport and physical allocation extents are not claimed as proved.

Two GitHub Codex execution failures were reported by the owner. The local CLI first rejected `--base` with a custom prompt (exit 2), then failed before review during app-server initialization with a read-only-filesystem error (exit 1). Those attempts are **incomplete**, are recorded separately, and are not converted into this review's completion status. No credentials, permissions, model defaults or CLI initialization were changed.

The accompanying JSON contains per-file SHA-256 identities, reviewed invariants and the evidence paths for those failed automated attempts.
