"""Check retained performance artifact, provenance and statistics without running workloads."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "alpha2"
BASE = "a73c56c92f3aad4b490307a5d1b882e487a57f55"
HEAD = "80490143498d149d407343ba1cb7aedb1db2d2c5"
TREE = "717a8c9386ae9f5f6545cc3686a9e22282fc560c"
RUN = 43624131736
ARTIFACT = 14125423722
inputs = {}

def require(condition, reason):
    if not condition:
        raise RuntimeError(reason)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    path = Path(path)
    data = path.read_bytes()
    identity = {"path": str(path), "sha256": sha(data), "size": len(data)}
    require(str(path) not in inputs or inputs[str(path)] == identity, "Changed input: " + str(path))
    inputs[str(path)] = identity
    return data

def js(path):
    return json.loads(read(path))

def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args])

def source(path):
    data = read(REPO / path)
    require(data == git("show", HEAD + ":" + path), "Source differs from exact head: " + path)
    return data

def assignment(data, name):
    nodes = [n.value for n in ast.parse(data).body if isinstance(n, ast.Assign)
             and any(isinstance(t, ast.Name) and t.id == name for t in n.targets)]
    require(len(nodes) == 1, "Ambiguous source constant: " + name)
    return nodes[0]

require(git("rev-parse", "HEAD").decode().strip() == HEAD and
        git("rev-parse", "HEAD^{tree}").decode().strip() == TREE, "Wrong local source identity")
require(not git("status", "--porcelain", "--untracked-files=all"), "Source working tree changed")
runner = source("tools/perf_smoke.py")
bench = source("tools/bench_pyperformance.py")
source("tools/bench_extended.py")
source(".github/workflows/performance.yml")
require(source(".python-version").strip() == b"3.13.16", "Wrong pinned Python")
benchmarks = ast.literal_eval(assignment(bench, "BENCHMARKS"))

def constant(node):
    if isinstance(node, ast.Name):
        require(node.id == "BENCHMARKS", "Unexpected computed source constant")
        return benchmarks
    if isinstance(node, ast.Subscript):
        return constant(node.value)[constant(node.slice)]
    if isinstance(node, ast.Tuple):
        return tuple(constant(x) for x in node.elts)
    if isinstance(node, ast.List):
        return [constant(x) for x in node.elts]
    if isinstance(node, ast.Dict):
        return {constant(k): constant(v) for k, v in zip(node.keys, node.values, strict=True)}
    return ast.literal_eval(node)

cases = constant(assignment(runner, "CASES"))
metrics = ast.literal_eval(assignment(runner, "METRICS"))
require(len(cases) == 11 and metrics == ("build_s", "jit_process_s", "jit_loop_s", "aot_process_s", "aot_loop_s"),
        "Unexpected performance suite coverage")
report_path = ROOT / "tested/perf-smoke/perf-smoke.json"
report_bytes = read(report_path)
require(sha(report_bytes) == "fb048bd33de058f38336aef962fb57674acf0f9b5053248d832e98d138c16f1c", "Report changed")
report = json.loads(report_bytes)
retrieval = js(ROOT / "artifact-perf-smoke-retrieval.json")
provenance = js(ROOT / "tested/perf-smoke/ARTIFACT_PROVENANCE.json")
archive = ROOT / "workflow-zips/perf-smoke.zip"
archive_bytes = read(archive)
require(retrieval["status"] == "passed" and retrieval["phase"] == "artifact" and
        retrieval["version"] == "v0.5.0-alpha.2" and retrieval["expected_commit"] == HEAD,
        "Artifact retrieval failed or used wrong source")
require(retrieval["name"] == provenance["name"] == "perf-smoke" and provenance["id"] == ARTIFACT and
        provenance["expired"] is False, "Wrong artifact identity")
require(retrieval["zip"] == str(archive) and retrieval["files"] == ["perf-smoke.json"] and
        retrieval["sha256"] == sha(archive_bytes) and provenance["digest"] == "sha256:" + sha(archive_bytes) and
        provenance["size_in_bytes"] == len(archive_bytes), "Artifact ZIP digest/size mismatch")
require(retrieval["workflow_run"] == provenance["workflow_run"], "Artifact run binding differs")
run = provenance["workflow_run"]
require(run["id"] == RUN and run["head_sha"] == HEAD and run["head_branch"] == "main" and
        run["repository_id"] == run["head_repository_id"] == 1409192014, "Artifact from wrong workflow/source")
with zipfile.ZipFile(archive) as z:
    require(z.namelist() == ["perf-smoke.json"] and z.read("perf-smoke.json") == report_bytes,
            "Retained report not equal to downloaded artifact")

require(report["schema"] == 2 and report["suite"] == "smoke" and
        report["status"] == report["phase"] == "complete" and
        not report.get("error") and not report.get("budget_exhausted"), "Incomplete/failed report")
require(report["revisions"] == {"base": BASE, "head": HEAD}, "Wrong comparison source revisions")
require(report["runner_sha256"] == sha(runner) and report["python"].startswith("3.13.16 ") and
        report["environment"]["PYSTACHY_PROGRAM_CACHE"] == "0" and len(report["affinity"]) == 1 and
        "clang version 18.1.3" in report["clang"], "Wrong source/interpreter/cache/CPU/toolchain binding")
require([r["name"] for r in report["results"]] == list(cases), "Missing, duplicate or reordered workload")
analysis = js(ROOT / "analysis.json")
require(inputs[str(ROOT / "analysis.json")]["sha256"] ==
        "385d4fea1827d8ffcd70aa43d9cdf8de59f615759c0692edd4338d0f1b448b0a", "Analysis changed")
require(analysis["status"] == "passed" and analysis["source_report"] == str(report_path) and
        analysis["source_report_sha256"] == sha(report_bytes) and analysis["analyzer_sha256"] ==
        sha(read(ROOT / "analyze-smoke.py")) and analysis["revisions"] == report["revisions"] and
        analysis["run_url"] == f"https://github.com/den-run-ai/pystachy/actions/runs/{RUN}", "Analysis not bound")

def compare(base, head):
    require(len(base) == len(head) == 3 and
            all(isinstance(v, (int, float)) and math.isfinite(v) and v > 0 for v in base + head),
            "Invalid metric observations")
    b, h = statistics.median(base), statistics.median(head)
    ratio = h / b
    candidate = (ratio >= 1.20 or math.isclose(ratio, 1.20)) and (
        h - b >= 0.005 or math.isclose(h - b, 0.005))
    return {"base_s": b, "head_s": h, "ratio": ratio, "candidate": candidate, "separated": min(head) > max(base)}

rows = []
sources = set()
oracle_records = 0
for result in report["results"]:
    name = result["name"]
    path, arguments = cases[name]
    require(result["source"] == path and result["arguments"] == arguments, "Wrong workload invocation")
    payload = source(path)
    require(result["source_sha256"] == sha(payload), "Workload hash differs")
    require(git("show", BASE + ":" + path) == payload, "Workload differs from baseline source")
    require(result["loop_clock"] == ("process_time_ns" if name == "graph_copy" else "perf_counter"),
            "Wrong timing clock description")
    measured = metrics if path not in sources else metrics[1:]
    sources.add(path)
    require(set(result["samples"]) == {"base", "head", "cpython"} and
            all(set(result["samples"][side]) == set(measured) for side in ("base", "head")) and
            set(result["comparison"]) == set(measured), "Missing or extra samples")
    cp = result["samples"]["cpython"]
    require(len(cp) == 3, "Wrong CPython oracle count")
    for record in cp:
        command = record["command"]
        require(command == ["/opt/hostedtoolcache/Python/3.13.16/x64/bin/python3",
                            "/home/runner/work/pystachy/pystachy/head/" + path, *arguments],
                "Wrong CPython command")
        require(record["returncode"] == 0 and record["stdout"] == result["output"] and
                math.isfinite(record["wall_s"]) and record["wall_s"] > 0 and
                math.isfinite(record["loop_s"]) and record["loop_s"] > 0, "Oracle failed or mismatched")
        oracle_records += 1
    require(result["confirmation"] is None, "Unexpected confirmation; audit this changed evidence separately")
    for metric in measured:
        base, head = (result["samples"][side][metric] for side in ("base", "head"))
        first = compare(base, head)
        require(first["candidate"] is False, "New threshold candidate requires confirmation review")
        actual = dict(first, status="ok", confirmation=None)
        require(result["comparison"][metric] == actual, "Saved comparison arithmetic differs")
        rows.append({"workload": name, "metric": metric, **actual,
                     "change_percent": (first["ratio"] - 1) * 100,
                     "absolute_change_s": first["head_s"] - first["base_s"],
                     "base_range_s": [min(base), max(base)], "head_range_s": [min(head), max(head)],
                     "base_samples_s": base, "head_samples_s": head,
                     "confirmation_base_samples_s": None, "confirmation_head_samples_s": None})
require(len(rows) == 49 and len(sources) == 5 and oracle_records == 33, "Incomplete suite counts")
require(analysis["rows"] == rows and analysis["workloads"] == 11 and analysis["comparisons"] == 49 and
        analysis["comparison_outcomes"] == {"ok": 49} and analysis["non_ok"] == [] and
        analysis["confirmation_workloads"] == [], "Analysis omitted or changed results")
metric_summary = {}
for metric in metrics:
    selected = [row for row in rows if row["metric"] == metric]
    low, high = min(selected, key=lambda x: x["ratio"]), max(selected, key=lambda x: x["ratio"])
    metric_summary[metric] = {"comparisons": len(selected),
                              "smallest_ratio": {"workload": low["workload"], "ratio": low["ratio"]},
                              "largest_ratio": {"workload": high["workload"], "ratio": high["ratio"]},
                              "outcomes": dict(Counter(r["status"] for r in selected))}
require(analysis["metric_summary"] == metric_summary, "Metric summary arithmetic differs")
bootstrap = {}
for side in ("base", "head"):
    raw = report["bootstrap"][side]
    require(raw["returncode"] == 0 and raw["stdout"] == raw["stderr"] == "" and
            math.isfinite(raw["wall_s"]) and raw["wall_s"] > 0, "Bootstrap failed")
    require(raw["command"][:4] == ["/opt/hostedtoolcache/Python/3.13.16/x64/bin/python3",
             f"/home/runner/work/pystachy/pystachy/{side}/pystachy.py", "build",
             f"/home/runner/work/pystachy/pystachy/{side}/pystachy.py"] and
            raw["command"][4] == "-o" and raw["command"][5].endswith(f"/{side}/compiler"),
            "Wrong bootstrap command")
    bootstrap[side] = {"wall_s": raw["wall_s"], "returncode": 0}
bootstrap["ratio"] = bootstrap["head"]["wall_s"] / bootstrap["base"]["wall_s"]
bootstrap["note"] = "One sequential sample per revision; no confirmation or statistical speed claim."
require(analysis["bootstrap"] == bootstrap, "Bootstrap summary differs")
require(analysis["environment"] == {k: report[k] for k in
        ("python", "platform", "cpu", "affinity", "load_average", "clang", "environment")},
        "Analysis environment differs")
markdown = read(ROOT / "analysis.md").decode()
actual_table = [line for line in markdown.splitlines() if line.startswith("| ")][1:]
expected_table = [f"| {row['workload']} | {row['metric']} | {row['base_s']:.6f} | {row['head_s']:.6f} | {row['change_percent']:+.2f}% | ok |"
                  for row in rows]
require(actual_table == expected_table, "Readable table omitted or changed a comparison")
require("+4.4%" in markdown and "one sequential observation per revision" in markdown and
        all(text in markdown for text in analysis["limitations"]), "Readable summary omits limits")
for identity in list(inputs.values()):
    read(identity["path"])
require(git("rev-parse", "HEAD").decode().strip() == HEAD and not git("status", "--porcelain", "--untracked-files=all"),
        "Source changed during audit")
receipt = {"kind": "Independent agent audit of exact-main alpha2 Performance smoke evidence",
    "status": "passed_artifact_and_statistics", "created_utc": datetime.now(timezone.utc).isoformat(),
    "version": "v0.5.0-alpha.2", "base": BASE, "head": HEAD, "head_tree": TREE,
    "run_id": RUN, "artifact_id": ARTIFACT, "inputs": list(inputs.values()),
    "zip_and_extracted_payload_match_recorded_api_digest_and_size": True,
    "exact_main_source_provenance_verified": True, "all_five_workload_sources_equal_base_and_head": True,
    "workloads": 11, "metric_comparisons": 49, "metric_samples": 294,
    "cpython_oracle_records": 33, "outcomes": {"ok": 49},
    "all_comparison_statistics_recomputed_exactly": True,
    "analysis_rows_metric_summaries_and_markdown_table_verified": True,
    "bootstrap": bootstrap, "metric_summary": metric_summary, "rows": rows,
    "limits": analysis["limitations"] + [
        "This accepts the retained complete Performance artifact. Workflow completion and all other release gates are separate evidence.",
        "The retained artifact has timing arrays and CPython records; native correctness follows the pinned runner's explicit successful-exit and output-equality checks, rather than retained individual native execution logs.",
        "The separate exact-source bounded build-memory experiment supplies RSS and executable-size evidence; this artifact does not."],
    "scope": "Read-only source/evidence inspection, hashes and independent arithmetic. No source module execution, compiler, workload, test, network, download, workflow polling or monitoring."}
output = ROOT / "independent-acceptance.json"
with output.open("x") as stream:
    stream.write(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"path": str(output), "sha256": sha(output.read_bytes()), "status": receipt["status"]}))
