# Independent alpha.2 Performance artifact audit

**Accepted: all 49 retained comparisons independently recompute to `ok`.** The complete smoke artifact compares alpha.1 `a73c56c92f3aad4b490307a5d1b882e487a57f55` with alpha.2 `80490143498d149d407343ba1cb7aedb1db2d2c5`, tree `717a8c9386ae9f5f6545cc3686a9e22282fc560c`.

The downloaded ZIP digest and size match the saved GitHub artifact metadata for artifact `14125423722` from Performance run `43624131736`. The extracted report is byte equal to its ZIP member. Its runner hash, all five workload source hashes, pinned Python 3.13.16 and LLVM 18.1.3 identity match the exact main source; the workload bytes are identical in both compared revisions.

The audit independently checked 11 workloads, 49 metric comparisons, all 294 native timing samples and 33 successful CPython oracle records. Every median, ratio, range, comparison classification, metric summary and readable table row matches the frozen analysis. No metric reaches the initial slowdown threshold, so no confirmation batch is missing.

| Metric | Comparisons | Outcomes |
|---|---:|---|
| Warm AOT build | 5 | 5 ok |
| JIT process | 11 | 11 ok |
| JIT loop | 11 | 11 ok |
| AOT process | 11 | 11 ok |
| AOT loop | 11 | 11 ok |

The reported bootstrap pair is also correct: 155.481 seconds for alpha.1 and 162.397 seconds for alpha.2, a 4.4% increase. There is one sequential observation per revision, which does not establish a sustained bootstrap performance change.

These results describe a bounded smoke run on one shared Linux x86-64 CI host with one pinned CPU. Three interleaved observations per revision determine each metric. A median slowdown of at least 20% and 5 ms would trigger three more observations; a warning also requires nonoverlapping ranges in both batches. JIT process time includes frontend and LLVM work; AOT process time includes startup. The graph-copy loop uses CPU time, while other loops use wall time. These thresholds and observations do not establish broad application performance.

The artifact retains timing arrays and CPython execution records. Native correctness is enforced by the pinned runner's explicit successful-exit and output-equality checks; individual native execution logs are not retained in this artifact. The separate build-cost and memory experiment supplies peak RSS and executable-size evidence. This artifact makes neither claim.

## Evidence identity

- Source artifact report: SHA256 `fb048bd33de058f38336aef962fb57674acf0f9b5053248d832e98d138c16f1c`.
- Frozen analysis: SHA256 `385d4fea1827d8ffcd70aa43d9cdf8de59f615759c0692edd4338d0f1b448b0a`.
- Independent receipt: `independent-acceptance.json`, SHA256 `5b10e0abfa0f129322fa31b786f65aa03891196d1bfe58a0cc664a0c979f39ce`.
- Auditor: `independent-audit.py`; its detailed receipt lists all input paths, sizes and hashes.

This independent agent audit read saved evidence and exact source, verified hashes and recomputed arithmetic. It executed no source modules, compiler, workload, test, download or network request. No workflow polling or monitoring was used. It accepts the retained performance evidence; completion of the workflow and the other release gates are separately established.
