"""Independently validate and summarize a retained exact-main performance artifact.

Only reads existing bytes and writes new evidence. No builds, runs, or network calls.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import statistics
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def comparison(base, head):
    assert len(base) == len(head) == 3
    assert all(math.isfinite(v) and v > 0 for v in base + head)
    b, h = statistics.median(base), statistics.median(head)
    ratio = h / b
    candidate = (ratio >= 1.20 or math.isclose(ratio, 1.20)) and (
        h - b >= .005 or math.isclose(h - b, .005))
    return {"base_s": b, "head_s": h, "ratio": ratio,
            "candidate": candidate, "separated": min(head) > max(base)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--head", required=True)
    parser.add_argument("--base", required=True)
    parser.add_argument("--run-url", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert sys.flags.optimize == 0 and __debug__
    args.output.mkdir(parents=True, exist_ok=True)
    outputs = [args.output / "analysis.json", args.output / "analysis.md"]
    assert not any(p.exists() for p in outputs), "Preserve existing evidence"
    data = json.loads(args.report.read_text())
    assert data["schema"] == 2 and data["suite"] == "smoke"
    assert data["status"] == data["phase"] == "complete"
    assert not data.get("error") and not data.get("budget_exhausted")
    assert data["revisions"] == {"base": args.base, "head": args.head}
    assert data["environment"]["PYSTACHY_PROGRAM_CACHE"] == "0"
    assert len(data["affinity"]) == 1
    runner = args.source / "tools/perf_smoke.py"
    assert data["runner_sha256"] == digest(runner)
    sys.path.insert(0, str(runner.parent))
    spec = importlib.util.spec_from_file_location("qualified_smoke_runner", runner)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    expected = module.CASES
    assert len(data["results"]) == len(expected)
    assert {r["name"] for r in data["results"]} == set(expected)
    seen_sources = set()
    rows = []
    confirmation_cases = []
    for result in data["results"]:
        name = result["name"]
        source, arguments = expected[name]
        assert result["source"] == source and result["arguments"] == arguments
        assert result["source_sha256"] == digest(args.source / source)
        metrics = module.METRICS if source not in seen_sources else module.METRICS[1:]
        seen_sources.add(source)
        assert set(result["comparison"]) == set(metrics)
        assert set(result["samples"]) == {"base", "head", "cpython"}
        for side in ("base", "head"):
            assert set(result["samples"][side]) == set(metrics)
        cp = result["samples"]["cpython"]
        assert len(cp) == 3 and all(x["returncode"] == 0 and x["stdout"] == result["output"] for x in cp)
        confirms = result["confirmation"]
        first_candidates = []
        if confirms is not None:
            confirmation_cases.append(name)
            assert set(confirms) == {"base", "head", "cpython"}
            assert len(confirms["cpython"]) == 3
            assert all(x["returncode"] == 0 and x["stdout"] == result["output"] for x in confirms["cpython"])
            assert all(set(confirms[side]) == set(metrics) for side in ("base", "head"))
        for metric in metrics:
            base = result["samples"]["base"][metric]
            head = result["samples"]["head"][metric]
            first = comparison(base, head)
            second = comparison(confirms["base"][metric], confirms["head"][metric]) if confirms else None
            first_candidates.append(first["candidate"])
            status = "ok" if not first["candidate"] else (
                "warning" if second and second["candidate"] and first["separated"] and second["separated"] else "unconfirmed")
            actual = dict(first, status=status, confirmation=second)
            assert result["comparison"][metric] == actual, (name, metric)
            rows.append({"workload": name, "metric": metric, **actual,
                         "change_percent": (first["ratio"] - 1) * 100,
                         "absolute_change_s": first["head_s"] - first["base_s"],
                         "base_range_s": [min(base), max(base)],
                         "head_range_s": [min(head), max(head)],
                         "base_samples_s": base, "head_samples_s": head,
                         "confirmation_base_samples_s": confirms["base"][metric] if confirms else None,
                         "confirmation_head_samples_s": confirms["head"][metric] if confirms else None})
        assert bool(confirms) == any(first_candidates)
    assert len(rows) == len(seen_sources) + 4 * len(expected)
    by_metric = {}
    for metric in module.METRICS:
        measured = [r for r in rows if r["metric"] == metric]
        low = min(measured, key=lambda r: r["ratio"])
        high = max(measured, key=lambda r: r["ratio"])
        by_metric[metric] = {"comparisons": len(measured),
                             "smallest_ratio": {"workload": low["workload"], "ratio": low["ratio"]},
                             "largest_ratio": {"workload": high["workload"], "ratio": high["ratio"]},
                             "outcomes": dict(Counter(r["status"] for r in measured))}
    bootstrap = {}
    for side in ("base", "head"):
        raw = data["bootstrap"][side]
        assert raw["returncode"] == 0 and math.isfinite(raw["wall_s"]) and raw["wall_s"] > 0
        bootstrap[side] = {"wall_s": raw["wall_s"], "returncode": raw["returncode"]}
    bootstrap["ratio"] = bootstrap["head"]["wall_s"] / bootstrap["base"]["wall_s"]
    bootstrap["note"] = "One sequential sample per revision; no confirmation or statistical speed claim."
    limits = [
        "Eleven bounded workloads on one shared CI host and one pinned CPU; not a whole-project performance claim.",
        "Three interleaved base/head samples per metric, with three more only when the first median slowdown is at least 20% and 5 ms. Confirmed warnings also require nonoverlapping ranges in both batches.",
        "Builds use warmed runtime caches; the program cache is disabled. JIT process times include frontend and LLVM work; AOT process times include process startup.",
        "graph_copy loop time is CPU time; other loop times are wall time. The medians describe this run and do not establish sustained changes by themselves.",
        "This artifact does not measure executable size or peak RSS. Earlier paired local executable-size measurements remain separate evidence.",
    ]
    result = {"status": "passed", "created_utc": datetime.now(timezone.utc).isoformat(),
              "run_url": args.run_url, "source_report": str(args.report),
              "source_report_sha256": digest(args.report), "analyzer_sha256": digest(Path(__file__)),
              "runner_sha256": data["runner_sha256"], "revisions": data["revisions"],
              "environment": {k: data[k] for k in ("python", "platform", "cpu", "affinity", "load_average", "clang", "environment")},
              "workloads": len(expected), "comparisons": len(rows),
              "comparison_outcomes": dict(Counter(r["status"] for r in rows)),
              "confirmation_workloads": confirmation_cases, "bootstrap": bootstrap,
              "metric_summary": by_metric, "non_ok": [r for r in rows if r["status"] != "ok"],
              "comparisons_recomputed_exactly_from_samples": True,
              "all_workload_and_runner_hashes_match_qualified_source": True,
              "rows": rows, "limitations": limits}
    outputs[0].write_text(json.dumps(result, indent=2) + "\n")
    lines = ["# Alpha.2 exact-main performance evidence", "",
             f"[Fresh Performance run]({args.run_url}) compares `{args.base}` with `{args.head}`.", "",
             f"The complete artifact contains {len(expected)} workloads and {len(rows)} paired comparisons. "
             f"Independent recomputation gives `{json.dumps(result['comparison_outcomes'], sort_keys=True)}`. "
             "Every workload source hash and the runner hash match the qualified tree.", "",
             f"The bootstrap pair took {bootstrap['base']['wall_s']:.3f} s for base and "
             f"{bootstrap['head']['wall_s']:.3f} s for head ({(bootstrap['ratio'] - 1) * 100:+.1f}%). "
             "This is one sequential observation per revision.", "",
             f"Host: {data['cpu'].strip().lstrip(':').strip()}; {data['platform']}; "
             f"Python {data['python'].split()[0]}; CPU affinity {data['affinity']}.", "",
             "## Paired metric medians", "",
             "| Workload | Metric | Base seconds | Head seconds | Change | Result |",
             "|---|---|---:|---:|---:|---|"]
    for row in rows:
        lines.append(f"| {row['workload']} | {row['metric']} | {row['base_s']:.6f} | {row['head_s']:.6f} | {row['change_percent']:+.2f}% | {row['status']} |")
    lines += ["", "## Interpretation limits", ""] + [f"- {s}" for s in limits]
    lines += ["", f"Source report SHA-256: `{result['source_report_sha256']}`.", ""]
    outputs[1].write_text("\n".join(lines))
    print(json.dumps({"status": "passed", "outcomes": result["comparison_outcomes"],
                      "report": str(outputs[0]), "non_ok": len(result["non_ok"])}))


if __name__ == "__main__":
    main()
