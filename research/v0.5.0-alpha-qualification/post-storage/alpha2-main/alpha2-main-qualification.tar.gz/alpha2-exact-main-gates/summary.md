# Alpha.2 exact-main workflow gate

All seven applicable push workflows completed successfully on `80490143498d149d407343ba1cb7aedb1db2d2c5`.

CI, Installation, Lint and Packages are the documented publication gates. Performance smoke, Coverage and Variants are additional separate exact-main workflows, all included and complete.

| Workflow | Run | Successful jobs | Expected skipped jobs | Longest executed job |
|---|---|---:|---:|---:|
| CI | [43624131788](https://github.com/den-run-ai/pystachy/actions/runs/43624131788) | 73 | 1 | 619 s |
| Coverage | [43624131838](https://github.com/den-run-ai/pystachy/actions/runs/43624131838) | 23 | 0 | 621 s |
| Installation | [43624131831](https://github.com/den-run-ai/pystachy/actions/runs/43624131831) | 7 | 0 | 561 s |
| Lint | [43624131842](https://github.com/den-run-ai/pystachy/actions/runs/43624131842) | 1 | 0 | 670 s |
| Packages | [43624131798](https://github.com/den-run-ai/pystachy/actions/runs/43624131798) | 1 | 0 | 327 s |
| Performance smoke | [43624131736](https://github.com/den-run-ai/pystachy/actions/runs/43624131736) | 1 | 0 | 626 s |
| Variants | [43624131795](https://github.com/den-run-ai/pystachy/actions/runs/43624131795) | 25 | 0 | 379 s |

CI pr-variants is guarded by github.event_name == pull_request and therefore skipped for this main push. Full native/alternate-configuration groups ran separately on both architectures.

Complete pagination covered 7 workflow runs and 132 commit check runs. Every executed job finished within 15 minutes. Raw run/job records retain step conclusions, timestamps and all attempt histories.

Both full architecture reports were revalidated against the exact source corpus and source hashes. Their complete step/group coverage, toolchains, corpus counts and timings are retained in verification-acceptance.json.

Fresh Performance smoke and the separate bounded warm-build memory/size measurement have independent acceptance receipts. Their limits remain explicit; no whole-project runtime or simultaneous process-tree memory improvement is inferred.
