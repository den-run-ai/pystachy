"""Make the final exact-main receipt from complete saved GitHub/API and artifact evidence."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/scratch/7dd0519bc14a/alpha2')
SHA = '80490143498d149d407343ba1cb7aedb1db2d2c5'
EXPECTED = {'CI', 'Installation', 'Lint', 'Packages', 'Performance smoke', 'Coverage', 'Variants'}
DOCUMENTED = {'CI', 'Installation', 'Lint', 'Packages'}
SKIP = 'native JIT and variants (worker ${{ matrix.worker }})'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def time(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00'))


def main():
    assert __debug__ and sys.flags.optimize == 0 and sys.version_info[:2] == (3, 13)
    out = ROOT / 'report.json'
    assert not out.exists()
    assert subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip() == SHA
    inventory = read(ROOT / 'runs-final.json')
    all_runs = inventory['workflow_runs']
    assert inventory['total_count'] == len(all_runs) == 7
    assert inventory['pagination_complete'] is True
    assert len({r['id'] for r in all_runs}) == len(all_runs)
    assert {r['name'] for r in all_runs} == EXPECTED
    sys.path.insert(0, str(SOURCE / 'tools'))
    spec = importlib.util.spec_from_file_location('qualified_merge_verification', SOURCE / 'tools/merge_verification.py')
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    groups = verifier.load_groups('full')
    expected_ci = {f'verify ({group}, {machine})' for group in groups if group != 'all'
                   for machine in ('x86_64', 'aarch64')}
    expected_ci |= {'Bootstrap tier and native archive qualification',
                    'make verify (Linux x86-64, LLVM 18, Python 3.13)',
                    'make verify (Linux ARM64, LLVM 18, Python 3.13)', SKIP}
    runs = []
    jobs_all = []
    files = [ROOT / 'runs-final.json', ROOT / 'check-runs-final.json']
    for observed in all_runs:
        path = ROOT / 'runs' / f"{observed['id']}.json"
        raw = read(path)
        run, payload = raw['run'], raw['jobs']
        assert run['id'] == observed['id'] and run['name'] == observed['name']
        for record in (run, observed):
            assert record['head_sha'] == SHA and record['head_branch'] == 'main' and record['event'] == 'push'
            assert record['status'] == 'completed' and record['conclusion'] == 'success'
        assert run['run_attempt'] == observed['run_attempt']
        assert payload['filter'] == 'all' and payload['total_count'] == len(payload['jobs'])
        assert payload['pages_read'] == (payload['total_count'] + payload['per_page'] - 1) // payload['per_page']
        ids = [j['id'] for j in payload['jobs']]
        assert len(ids) == len(set(ids))
        jobs = [j for j in payload['jobs'] if j['run_attempt'] == run['run_attempt']]
        assert jobs and len({j['name'] for j in jobs}) == len(jobs)
        if run['name'] == 'CI':
            assert {j['name'] for j in jobs} == expected_ci
        skipped = []
        timings = []
        for job in jobs:
            assert job['head_sha'] == SHA and job['run_id'] == run['id']
            assert job['status'] == 'completed'
            if job['conclusion'] == 'skipped':
                assert run['name'] == 'CI' and job['name'] == SKIP
                skipped.append(job['name'])
                continue
            assert job['conclusion'] == 'success'
            seconds = (time(job['completed_at']) - time(job['started_at'])).total_seconds()
            assert 0 <= seconds <= 900, (job['name'], seconds)
            timings.append({'id': job['id'], 'name': job['name'], 'seconds': seconds,
                            'started_at': job['started_at'], 'completed_at': job['completed_at']})
            assert all(step['conclusion'] in ('success', 'skipped') for step in job['steps'])
        assert len(skipped) == (1 if run['name'] == 'CI' else 0)
        jobs_all.extend(jobs)
        runs.append({'id': run['id'], 'name': run['name'], 'url': run['html_url'],
                     'documented_release_gate': run['name'] in DOCUMENTED,
                     'source_sha': SHA, 'event': run['event'], 'status': run['status'],
                     'conclusion': run['conclusion'], 'attempt': run['run_attempt'],
                     'jobs': dict(Counter(j['conclusion'] for j in jobs)),
                     'jobs_total': len(jobs), 'all_attempt_job_records': len(payload['jobs']),
                     'job_pages_read': payload['pages_read'], 'expected_skipped_jobs': skipped,
                     'max_job_seconds': max(t['seconds'] for t in timings),
                     'longest_job': max(timings, key=lambda t: t['seconds']),
                     'job_timings': timings,
                     'prior_attempt_outcomes': [dict(id=j['id'], name=j['name'], attempt=j['run_attempt'],
                         conclusion=j['conclusion']) for j in payload['jobs'] if j['run_attempt'] != run['run_attempt']]})
        files.append(path)
    check_inventory = read(ROOT / 'check-runs-final.json')
    checks = check_inventory['check_runs']
    assert check_inventory['pagination_complete'] and len(checks) == check_inventory['total_count']
    assert len({c['id'] for c in checks}) == len(checks)
    job_check_ids = {int(j['check_run_url'].rsplit('/', 1)[1]) for j in jobs_all}
    assert job_check_ids.issubset({c['id'] for c in checks})
    for check in checks:
        assert check['head_sha'] == SHA and check['status'] == 'completed'
        assert check['conclusion'] in ('success', 'skipped')
        if check['conclusion'] == 'skipped':
            assert check['name'] == SKIP
    verification_path = ROOT / 'verification-acceptance.json'
    verification = read(verification_path)
    assert verification['status'] == 'passed' and verification['source_sha'] == SHA
    perf_dir = ROOT.parent / 'alpha2-exact-main-performance'
    perf = read(perf_dir / 'analysis.json')
    assert perf['status'] == 'passed' and perf['revisions']['head'] == SHA
    assert perf['comparison_outcomes'] == {'ok': 49}
    memory_dir = ROOT.parent / 'alpha2-build-memory'
    memory = read(memory_dir / 'report.json')
    assert memory['status'] == 'passed'
    files += [verification_path, ROOT / 'qualification-acceptance.json',
              perf_dir / 'analysis.json', perf_dir / 'independent-acceptance.json',
              memory_dir / 'report.json', memory_dir / 'independent-acceptance.json']
    result = {'status': 'passed', 'created_utc': datetime.now(timezone.utc).isoformat(),
              'source_sha': SHA, 'source_tree': subprocess.check_output(
                  ['git', '-C', str(SOURCE), 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
              'documented_release_workflows': sorted(DOCUMENTED),
              'additional_source_relevant_workflows': sorted(EXPECTED - DOCUMENTED),
              'all_seven_applicable_push_workflows_complete_and_successful': True,
              'workflow_run_pages_read': inventory['pages_read'], 'workflow_runs_total': len(all_runs),
              'check_run_pages_read': check_inventory['pages_read'], 'check_runs_total': len(checks),
              'all_job_check_runs_in_complete_commit_check_inventory': True,
              'workflow_job_outcomes': dict(Counter(j['conclusion'] for j in jobs_all)),
              'all_executed_jobs_within_15_minute_cap': True,
              'expected_skip_explanation': 'CI pr-variants is guarded by github.event_name == pull_request and therefore skipped for this main push. Full native/alternate-configuration groups ran separately on both architectures.',
              'runs': sorted(runs, key=lambda r: r['name']),
              'verification': verification['architectures'],
              'strict_storage_log': str(ROOT / 'logs/132537773886-scaling-x86_64.log'),
              'strict_storage_result': {'programs': 175, 'obligations': 18582, 'proved': 18582, 'seconds': 95.2},
              'performance_analysis': str(perf_dir / 'analysis.json'),
              'memory_build_analysis': str(memory_dir / 'report.json'),
              'inputs': [{'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)} for path in files],
              'summary_script_sha256': sha(Path(__file__))}
    out.write_text(json.dumps(result, indent=2) + '\n')
    lines = ['# Alpha.2 exact-main workflow gate', '',
             f"All seven applicable push workflows completed successfully on `{SHA}`.", '',
             'CI, Installation, Lint and Packages are the documented publication gates. Performance smoke, Coverage and Variants are additional separate exact-main workflows, all included and complete.', '',
             '| Workflow | Run | Successful jobs | Expected skipped jobs | Longest executed job |',
             '|---|---|---:|---:|---:|']
    for run in result['runs']:
        lines.append(f"| {run['name']} | [{run['id']}]({run['url']}) | {run['jobs'].get('success', 0)} | {run['jobs'].get('skipped', 0)} | {run['max_job_seconds']:.0f} s |")
    lines += ['', result['expected_skip_explanation'], '',
              f"Complete pagination covered {len(all_runs)} workflow runs and {len(checks)} commit check runs. Every executed job finished within 15 minutes. Raw run/job records retain step conclusions, timestamps and all attempt histories.", '',
              'Both full architecture reports were revalidated against the exact source corpus and source hashes. Their complete step/group coverage, toolchains, corpus counts and timings are retained in verification-acceptance.json.', '',
              'Fresh Performance smoke and the separate bounded warm-build memory/size measurement have independent acceptance receipts. Their limits remain explicit; no whole-project runtime or simultaneous process-tree memory improvement is inferred.', '']
    (ROOT / 'summary.md').write_text('\n'.join(lines))
    print(json.dumps({'status': 'passed', 'report': str(out), 'workflows': len(runs),
                      'jobs': result['workflow_job_outcomes'], 'checks': len(checks)}))


if __name__ == '__main__':
    main()
