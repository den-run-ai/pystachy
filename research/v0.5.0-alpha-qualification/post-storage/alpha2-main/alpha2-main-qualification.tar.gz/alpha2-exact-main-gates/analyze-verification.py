"""Validate retained full CI aggregate reports against the exact release source."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--run-id', type=int, required=True)
    parser.add_argument('--x86', type=Path, required=True)
    parser.add_argument('--arm', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert __debug__ and sys.flags.optimize == 0 and sys.version_info[:2] == (3, 13)
    assert not args.output.exists()
    assert subprocess.check_output(['git', '-C', str(args.source), 'rev-parse', 'HEAD'], text=True).strip() == args.commit
    assert subprocess.check_output(['git', '-C', str(args.source), 'status', '--porcelain'], text=True).strip() == ''
    sys.path.insert(0, str(args.source / 'tools'))
    module_path = args.source / 'tools/merge_verification.py'
    spec = importlib.util.spec_from_file_location('qualified_merge_verification', module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    groups = module.load_groups('full')
    expected_groups = set(groups) - {'all'}
    result = {'status': 'incomplete', 'created_utc': datetime.now(timezone.utc).isoformat(),
              'source_sha': args.commit, 'ci_run_id': args.run_id,
              'validator_sha256': sha(module_path), 'analyzer_sha256': sha(Path(__file__)),
              'expected_check_names': groups['all'], 'expected_groups': sorted(expected_groups),
              'architectures': {}}
    for machine, path in (('x86_64', args.x86), ('aarch64', args.arm)):
        data = json.loads(path.read_text())
        assert data['git']['commit'] == args.commit
        assert data['git']['dirty'] is False
        assert data['profile'] == 'full' and data['group'] == 'all'
        assert data['platform']['machine'] == machine
        module.validate_report(data, 'all', groups['all'], 'full')
        actual_groups = [row['group'] for row in data['ci']['groups']]
        assert len(actual_groups) == len(set(actual_groups)) == len(expected_groups)
        assert set(actual_groups) == expected_groups
        sources = {}
        for name, entry in data['sources'].items():
            if isinstance(entry, dict) and 'sha256' in entry:
                source = args.source / name
                payload = source.read_bytes()
                assert entry['sha256'] == hashlib.sha256(payload).hexdigest(), name
                if 'lines' in entry:
                    assert entry['lines'] == payload.count(b'\n'), name
                sources[name] = entry
        assert sources and 'pystachy.py' in sources and 'runtime.c' in sources and 'runtime.py' in sources
        assert data['steps'][0]['ir_identical'] is True
        selected = []
        for step in data['steps']:
            selected.append({k: step[k] for k in (
                'name', 'result', 'seconds', 'ci_group', 'expected', 'passed', 'failed', 'modes',
                'cases', 'corpus_cases', 'shard_cases', 'shard_count', 'shard_index',
                'ir_identical', 'ir_sha256', 'compiler_interval', 'bootstrap_reused') if k in step})
        result['architectures'][machine] = {'report': str(path), 'report_sha256': sha(path),
             'summary': data['summary'], 'toolchain': data['toolchain'], 'platform': data['platform'],
             'source_files_verified': len(sources),
             'source_suite_checks': data['sources']['suite_checks'],
             'source_mode_checks': data['sources']['mode_checks'],
             'ci': data['ci'], 'steps': selected,
             'all_required_steps_and_groups_present': True,
             'all_source_file_hashes_match_exact_release': True}
    before = result['architectures']['x86_64']
    after = result['architectures']['aarch64']
    for key in ('source_files_verified', 'source_suite_checks', 'source_mode_checks'):
        assert before[key] == after[key]
    result['status'] = 'passed'
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': 'passed', 'report': str(args.output),
                     'architectures': {key: {'checks': value['summary']['passed'],
                         'groups': len(value['ci']['groups'])} for key, value in result['architectures'].items()}}))


if __name__ == '__main__':
    main()
