"""Package frozen exact-main evidence; no compilation, tests, network or Git writes."""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile

GROUPS = ('alpha2-exact-main-gates', 'alpha2-exact-main-performance', 'alpha2-build-memory')
STEM = 'alpha2-main-qualification'
SOURCE_SHA = '80490143498d149d407343ba1cb7aedb1db2d2c5'
SOURCE_TREE = '717a8c9386ae9f5f6545cc3686a9e22282fc560c'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def identities(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def archive_bytes(payloads):
    target = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=target, compresslevel=9, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for name, payload in sorted(payloads.items()):
                member = tarfile.TarInfo(name)
                member.size = len(payload)
                member.mode = 0o644
                member.mtime = 0
                member.uid = member.gid = 0
                member.uname = member.gname = ''
                archive.addfile(member, io.BytesIO(payload))
    return target.getvalue()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--readme', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    root = args.source_root.resolve()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    archive_path = output / (STEM + '.tar.gz')
    manifest_path = output / (STEM + '-manifest.json')
    require(not archive_path.exists() and not manifest_path.exists(), 'Refuse to replace evidence')
    payloads = {}
    records = []
    manifests = []
    verified = 0
    for group in GROUPS:
        group_root = root / group
        manifest_path_in = group_root / 'evidence-files-final.json'
        manifest_bytes = manifest_path_in.read_bytes()
        manifest = json.loads(manifest_bytes)
        declared = manifest['files']
        require(isinstance(declared, list) and declared, f'Empty manifest: {group}')
        names = set()
        for entry in declared:
            relative = PurePosixPath(entry['path'])
            require(not relative.is_absolute() and '..' not in relative.parts and relative.parts,
                    f'Unsafe declared path: {relative}')
            require(str(relative) not in names, f'Duplicate declaration: {relative}')
            names.add(str(relative))
            source = group_root / relative
            require(source.is_file() and not source.is_symlink(), f'Not an ordinary file: {source}')
            data = source.read_bytes()
            identity = identities(data)
            require(identity['bytes'] == entry['bytes'] and identity['sha256'] == entry['sha256'],
                    f'Declared size/hash mismatch: {source}')
            name = f'{group}/{relative}'
            require(name not in payloads, f'Duplicate member: {name}')
            payloads[name] = data
            records.append({'archive_path': name, 'source_path': str(source),
                            'declared_by': f'{group}/evidence-files-final.json', **identity})
            verified += 1
        name = f'{group}/evidence-files-final.json'
        require(name not in payloads, f'Manifest declares itself: {name}')
        payloads[name] = manifest_bytes
        identity = identities(manifest_bytes)
        records.append({'archive_path': name, 'source_path': str(manifest_path_in),
                        'kind': 'authoritative final input manifest', **identity})
        manifests.append({'group': group, 'archive_path': name,
                          'declared_files_verified': len(declared), **identity})
    for name, source in (('README.md', args.readme.resolve()),
                         ('package_alpha2_main.py', Path(__file__).resolve())):
        data = source.read_bytes()
        require(name not in payloads, f'Duplicate package member: {name}')
        payloads[name] = data
        records.append({'archive_path': name, 'source_path': str(source),
                        'kind': 'package documentation or reproducible packager', **identities(data)})
    compressed = archive_bytes(payloads)
    require(compressed == archive_bytes(payloads), 'Deterministic serialization differs')
    with tarfile.open(fileobj=io.BytesIO(compressed), mode='r:gz') as archive:
        members = archive.getmembers()
        require([member.name for member in members] == sorted(payloads), 'Archive member inventory differs')
        for member in members:
            require(member.isfile() and member.mode == 0o644 and member.mtime == 0 and
                    member.uid == member.gid == 0 and member.uname == member.gname == '',
                    f'Noncanonical metadata: {member.name}')
            stream = archive.extractfile(member)
            require(stream is not None and stream.read() == payloads[member.name],
                    f'Archive content mismatch: {member.name}')
    with archive_path.open('xb') as stream:
        stream.write(compressed)
    require(archive_path.read_bytes() == compressed, 'Written archive differs')
    manifest = {'schema': 1, 'package': STEM,
                'created_utc': datetime.now(timezone.utc).isoformat(),
                'source_commit': SOURCE_SHA, 'source_tree': SOURCE_TREE,
                'archive': {'path': str(archive_path), 'file_name': archive_path.name, **identities(compressed)},
                'declared_final_manifest_entries_verified': verified,
                'input_manifests': manifests, 'archive_member_count': len(payloads),
                'uncompressed_selected_bytes': sum(len(data) for data in payloads.values()),
                'all_declared_final_hashes_and_sizes_match': True,
                'archive_member_contents_verified': True,
                'deterministic_serializations_byte_identical': True,
                'serialization': {'tar_format': 'PAX', 'order': 'lexicographic path', 'uid': 0, 'gid': 0,
                                  'uname': '', 'gname': '', 'mtime': 0, 'mode': '0644',
                                  'gzip_filename': '', 'gzip_mtime': 0, 'gzip_compresslevel': 9},
                'historical_manifest_note': 'The initial memory inventory is retained history. Its later auditor-script change is explicitly recorded by the authoritative final memory manifest; measurement records are unchanged.',
                'files': sorted(records, key=lambda record: record['archive_path'])}
    with manifest_path.open('x') as stream:
        json.dump(manifest, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'archive': manifest['archive'], 'external_manifest': str(manifest_path),
                      'external_manifest_identity': identities(manifest_path.read_bytes()),
                      'declared_files_verified': verified, 'members': len(payloads),
                      'readme': {'path': str(args.readme.resolve()), **identities(args.readme.read_bytes())}}, indent=2))


if __name__ == '__main__':
    main()
