# Independent alpha.2 build cost and memory audit

**Accepted as bounded measurement evidence.** The frozen report and all underlying observations support the reported warm AOT build comparison between alpha.1 source `a73c56c92f3aad4b490307a5d1b882e487a57f55` and alpha.2 source `80490143498d149d407343ba1cb7aedb1db2d2c5`.

The independent audit checked six warmups and eighteen measured builds, comprising three alternating pairs for each workload. All 24 retained executable outputs match the pinned CPython oracle. Their stderr contains only each workload's documented elapsed-time line; those correctness executions are not used as timing samples. Every build exited successfully without a timeout, and the measured intervals are sequential on one CPU.

| Workload | Build seconds, alpha.1 → alpha.2 | Change | Recorded peak RSS KiB, alpha.1 → alpha.2 | Change | Executable bytes, alpha.1 → alpha.2 | Change |
|---|---:|---:|---:|---:|---:|---:|
| numeric | 1.450922 → 0.396689 | -72.7% | 93,540 → 88,136 | -5.8% | 107,072 → 145,200 | +35.6% |
| json | 12.863427 → 9.186604 | -28.6% | 140,776 → 133,436 | -5.2% | 668,808 → 701,704 | +4.9% |
| copy_float | 1.377891 → 0.227626 | -83.5% | 93,604 → 85,492 | -8.7% | 112,304 → 151,048 | +34.5% |

Every median, ratio, range and sample count was independently recomputed from the raw records. Executable sizes increase for all three workloads and remain an explicit tradeoff. Private warmed runtime-cache bytes remained unchanged during the measured pairs; program caching was disabled. Source homes, workload bytes, LLVM 18.1.3 binaries, retained native compiler binaries and their original three-stage compiler/runtime fixed points were rehashed. The only changes between the original compiler sources and these release sources are the three verified Lean storage checker/test files, so compiler/runtime reuse is source-identical.

The collector uses a fresh pinned Python 3.13.16 process and blocking Linux `wait4` per build. Its `ru_maxrss` values are KiB with waited-descendant accounting; they do not represent a simultaneous sum of all process-tree resident memory. This is three workloads with three paired observations on one Linux x86-64 host. It makes no broad application speed, application memory, startup or compiler-bootstrap-memory claim. The six warmups are excluded from the medians.

The original ordinary Python launch commands are retained in the transcript-derived invocation receipt. The separate optimization-context observation was recorded after completion and is explicitly identified as such; it is not presented as a contemporaneous measurement field. The new independent auditor uses explicit checks that remain active under optimized Python.

## Evidence identity

- Frozen report: `report.json`, SHA256 `d55886fab7fa7e993e12676ba897b5e5cc1309bbf01cac0c7d304c10a7a367da`.
- Independent detailed receipt: `independent-acceptance.json`, SHA256 `6ae8b3876e4244a5d70d101efb192faa53245511936d41cda4d40e5f70247790`.
- Auditor: `independent-audit.py`. The receipt records every source, script, raw record, output and retained payload used in the audit with its path, size and SHA256.

This was an independent agent review of saved source and evidence, with file/hash verification and arithmetic recomputation. No compiler, built workload, test, measurement, network request or workflow was executed. No monitoring or process sampling was used.
