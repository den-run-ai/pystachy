"""Three alternating pairs of native AOT build cost and peak-RSS observations."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
LLVM = Path('/workspace/scratch/c2b093657c17/toolchains/llvm18/payload/usr/lib/llvm-18/bin')
CASES = {'numeric': ('bench/smoke/ml.py', ['numeric', '20000']),
         'json': ('bench/smoke/text.py', ['json', '6000']),
         'copy_float': ('bench/smoke/identity.py', ['float', '6000000', '123'])}


def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


def cache_manifest(path):
    return [{'path': str(p.relative_to(path)), 'sha256': sha(p), 'bytes': p.stat().st_size}
            for p in sorted(path.rglob('*')) if p.is_file()]


def main():
    assert sys.version_info[:2] == (3, 13) and __debug__ and sys.flags.optimize == 0
    identity = json.loads((OUT / 'identity.json').read_text())
    assert identity['status'] == 'passed'
    final = OUT / 'report.json'
    assert not final.exists()
    for name in ('raw', 'cache', 'executables'):
        (OUT / name).mkdir(exist_ok=False)
    original_affinity = sorted(os.sched_getaffinity(0))
    os.sched_setaffinity(0, {original_affinity[0]})
    env = {k: v for k, v in os.environ.items()
           if not k.startswith('PYSTACHY_') and k not in ('PYTHONPATH', 'PYTHONOPTIMIZE')}
    env.update(PYSTACHY_LLVM=str(LLVM), PYSTACHY_PROGRAM_CACHE='0', PYSTACHY_JOBS='1',
               PYTHONHASHSEED='0', LD_LIBRARY_PATH=str(LLVM.parent / 'lib'))
    env['PATH'] = str(Path(sys.executable).parent) + ':' + str(LLVM) + ':' + env.get('PATH', '')
    envs = {}
    for side, ident in identity['revisions'].items():
        home = Path(ident['home'])
        assert git(home, 'rev-parse', 'HEAD') == ident['release_sha']
        assert git(home, 'status', '--porcelain') == ''
        assert sha(home / 'pystachy') == ident['binary_sha256']
        (OUT / 'cache' / side).mkdir()
        (OUT / 'executables' / side).mkdir()
        envs[side] = dict(env, PYSTACHY_HOME=str(home), PYSTACHY_CACHE=str(OUT / 'cache' / side))
    report = {'status': 'incomplete', 'started_utc': datetime.now(timezone.utc).isoformat(),
              'identity': str(OUT / 'identity.json'), 'identity_sha256': sha(OUT / 'identity.json'),
              'runner_sha256': sha(Path(__file__)), 'collector_sha256': sha(OUT / 'measure-command.py'),
              'python': sys.version, 'python_executable': sys.executable, 'platform': platform.platform(),
              'cpu': Path('/proc/cpuinfo').read_text().split('model name', 1)[-1].splitlines()[0].strip(),
              'affinity': sorted(os.sched_getaffinity(0)), 'load_before': os.getloadavg(),
              'environment': {side: {k: v for k, v in value.items()
                  if k.startswith('PYSTACHY_') or k in ('PYTHONHASHSEED', 'PATH', 'LD_LIBRARY_PATH')}
                  for side, value in envs.items()},
              'toolchain': {name: {'path': str(LLVM / name), 'sha256': sha(LLVM / name),
                  'version': subprocess.check_output([str(LLVM / name), '--version'], env=env, text=True).splitlines()[0]}
                  for name in ('clang', 'opt', 'llc', 'llvm-link')},
              'cases': CASES, 'warmups': [], 'samples': [], 'summary': [],
              'scope': 'Three paired warm-runtime-cache native builds per workload; program cache disabled; one CPU; sequential. No compiler bootstrap or timed runtime claim.',
              'memory_scope': 'Linux wait4 ru_maxrss in KiB at command completion, including waited-descendant accounting. Not simultaneous summed process-tree RSS.',
              'collector': 'Fresh pinned-Python process per build uses os.fork, os.execvpe and blocking os.wait4; stdout/stderr are ordinary files; no /proc sampling.'}
    start = time.monotonic()
    def save():
        temporary = OUT / 'report.tmp'
        temporary.write_text(json.dumps(report, indent=2) + '\n')
        temporary.replace(final)
    def build(side, name, phase, repeat):
        source, arguments = CASES[name]
        home = Path(identity['revisions'][side]['home'])
        prefix = OUT / 'raw' / f'{name}-{phase}-{repeat}-{side}'
        exe = OUT / 'executables' / side / name
        spec = {'command': [str(home / 'pystachy'), 'build', str(home / source), '-o', str(exe)],
                'cwd': str(home), 'record': str(prefix.with_suffix('.json')),
                'stdout': str(prefix.with_suffix('.stdout')), 'stderr': str(prefix.with_suffix('.stderr')),
                'timeout_s': 180}
        spec_path = prefix.with_suffix('.spec.json')
        spec_path.write_text(json.dumps(spec, indent=2) + '\n')
        with prefix.with_suffix('.wrapper.log').open('xb') as log:
            completed = subprocess.run([sys.executable, str(OUT / 'measure-command.py'), str(spec_path)],
                cwd=OUT, env=envs[side], stdout=log, stderr=subprocess.STDOUT, timeout=195)
        raw = json.loads(Path(spec['record']).read_text())
        record = {'workload': name, 'side': side, 'phase': phase, 'repeat': repeat,
                  'raw_record': spec['record'], 'raw_record_sha256': sha(Path(spec['record'])),
                  **{k: raw[k] for k in ('wall_s', 'ru_maxrss_kib', 'ru_utime_s', 'ru_stime_s', 'returncode', 'timed_out')}}
        report['warmups' if phase == 'warmup' else 'samples'].append(record)
        save()
        assert completed.returncode == raw['returncode'] == 0 and not raw['timed_out'], record
        assert raw['affinity'] == report['affinity']
        record['executable_bytes'] = exe.stat().st_size
        record['executable_sha256'] = sha(exe)
        output = subprocess.run([str(exe), *arguments], cwd=home, env=envs[side],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        prefix.with_suffix('.check.stdout').write_bytes(output.stdout)
        prefix.with_suffix('.check.stderr').write_bytes(output.stderr)
        assert output.returncode == 0 and output.stdout == oracles[name], (name, side, output.returncode)
        record['output_matches_pinned_cpython'] = True
        save()
        print(json.dumps({k: record[k] for k in ('workload', 'side', 'phase', 'repeat', 'wall_s', 'ru_maxrss_kib', 'executable_bytes')}), flush=True)
    oracles = {}
    try:
        save()
        for name, (source, arguments) in CASES.items():
            home = Path(identity['revisions']['head']['home'])
            oracle = subprocess.run([sys.executable, str(home / source), *arguments], env=envs['head'],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60, check=True)
            (OUT / 'raw' / f'{name}-oracle.stdout').write_bytes(oracle.stdout)
            (OUT / 'raw' / f'{name}-oracle.stderr').write_bytes(oracle.stderr)
            oracles[name] = oracle.stdout
            for side in ('base', 'head'):
                build(side, name, 'warmup', 0)
        report['cache_after_warmups'] = {side: cache_manifest(OUT / 'cache' / side) for side in envs}
        save()
        for name in CASES:
            for repeat in range(3):
                for side in (('base', 'head') if repeat % 2 == 0 else ('head', 'base')):
                    build(side, name, 'sample', repeat)
        report['cache_after_samples'] = {side: cache_manifest(OUT / 'cache' / side) for side in envs}
        assert report['cache_after_samples'] == report['cache_after_warmups']
        for name in CASES:
            row = {'workload': name, 'pairs': 3}
            for metric in ('wall_s', 'ru_maxrss_kib', 'ru_utime_s', 'ru_stime_s', 'executable_bytes'):
                data = {side: [r[metric] for r in report['samples'] if r['workload'] == name and r['side'] == side] for side in envs}
                assert all(len(values) == 3 for values in data.values())
                medians = {side: statistics.median(values) for side, values in data.items()}
                row[metric] = {'base_median': medians['base'], 'head_median': medians['head'],
                               'ratio_of_medians': medians['head'] / medians['base'],
                               'change_percent': (medians['head'] / medians['base'] - 1) * 100,
                               'ranges': {side: [min(values), max(values)] for side, values in data.items()},
                               'samples': data}
            report['summary'].append(row)
        for side, ident in identity['revisions'].items():
            home = Path(ident['home'])
            assert git(home, 'status', '--porcelain') == ''
            assert git(home, 'rev-parse', 'HEAD') == ident['release_sha']
            assert sha(home / 'pystachy') == ident['binary_sha256']
        report.update(status='passed', clean_source_and_binary_identities_after=True,
                      runtime_cache_bytes_unchanged_during_samples=True)
    except BaseException as error:
        report.update(status='failed', error_type=type(error).__name__, error=str(error))
        raise
    finally:
        report.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_s=time.monotonic() - start,
                      load_after=os.getloadavg())
        save()
        os.sched_setaffinity(0, original_affinity)
    print(json.dumps({'status': report['status'], 'report': str(final), 'elapsed_s': report['elapsed_s']}), flush=True)


if __name__ == '__main__':
    main()
