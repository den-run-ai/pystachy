"""Bind previously qualified fixed-point compilers to exact release source homes."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

OUT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/7dd0519bc14a/alpha2')
SOURCE = Path('/workspace/scratch/c66a10c5a7b1')
EXPECTED = {'base': ('alpha1', 'a1', 'a73c56c92f3aad4b490307a5d1b882e487a57f55'),
            'head': ('alpha2', 'a2', '80490143498d149d407343ba1cb7aedb1db2d2c5')}
CHANGED = ['tools/check_lean_storage.py', 'tools/test_lean_storage.py', 'tools/test_lean_storage_layout.py']


def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


def main():
    output = OUT / 'identity.json'
    assert not output.exists()
    result = {'created_utc': datetime.now(timezone.utc).isoformat(), 'status': 'incomplete',
              'source_repo': str(REPO), 'revisions': {},
              'note': 'Native binary reuse is justified by exact compiler/runtime/library/workload equality; only three Lean checker/test files differ from original fixed-point sources.'}
    for side, (directory, key, revision) in EXPECTED.items():
        old = SOURCE / directory
        original_path = SOURCE / 'ir-audit' / (key + '-identity.json')
        original = json.loads(original_path.read_text())
        bootstrap = original['bootstrap']
        built = bootstrap['local_build_source_ref']
        assert git(old, 'rev-parse', 'HEAD') == built
        assert git(old, 'status', '--porcelain') == ''
        assert git(REPO, 'diff', '--name-only', built, revision).splitlines() == CHANGED
        assert sha(old / 'pystachy') == sha(old / 'build/pystachy2') == original['binary']['sha256']
        assert sha(Path(bootstrap['log'])) == bootstrap['log_sha256']
        fixed = {name: sha(old / 'build' / name) for name in bootstrap['files']}
        assert fixed == bootstrap['files']
        assert len({fixed[f'stage{i}.ll'] for i in (1, 2, 3)}) == 1
        assert len({fixed[f'rt{i}.ll'] for i in (1, 2, 3)}) == 1
        home = OUT / side
        subprocess.run(['git', '-C', str(REPO), 'worktree', 'add', '--detach', str(home), revision], check=True)
        shutil.copy2(old / 'pystachy', home / 'pystachy')
        assert sha(home / 'pystachy') == original['binary']['sha256']
        assert git(home, 'status', '--porcelain') == ''
        result['revisions'][side] = {'release_sha': revision, 'release_tree': git(home, 'rev-parse', 'HEAD^{tree}'),
             'home': str(home), 'binary': str(home / 'pystachy'), 'binary_sha256': sha(home / 'pystachy'),
             'source_binary': str(old / 'pystachy'), 'built_source_sha': built,
             'source_changes_since_fixed_point': CHANGED,
             'original_identity': str(original_path), 'original_identity_sha256': sha(original_path),
             'bootstrap': bootstrap, 'current_fixed_point_hashes': fixed,
             'workloads': {name: sha(home / name) for name in ('bench/smoke/ml.py', 'bench/smoke/text.py', 'bench/smoke/identity.py')}}
    assert len(str(OUT / 'base')) == len(str(OUT / 'head'))
    assert result['revisions']['base']['workloads'] == result['revisions']['head']['workloads']
    result['status'] = 'passed'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': 'passed', 'identity': str(output)}))


if __name__ == '__main__':
    main()
