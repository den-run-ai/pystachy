"""Measure one owned command with blocking Linux wait4, without process sampling."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import sys
import time


def main():
    spec_path = Path(sys.argv[1])
    spec = json.loads(spec_path.read_text())
    output = Path(spec["record"])
    assert sys.platform == "linux" and __debug__ and sys.flags.optimize == 0
    assert not output.exists()
    start_utc = datetime.now(timezone.utc).isoformat()
    expired = False
    with Path(spec["stdout"]).open("xb") as stdout, Path(spec["stderr"]).open("xb") as stderr:
        start = time.monotonic()
        pid = os.fork()
        if pid == 0:
            try:
                os.setsid()
                os.chdir(spec["cwd"])
                os.dup2(stdout.fileno(), 1)
                os.dup2(stderr.fileno(), 2)
                os.execvpe(spec["command"][0], spec["command"], os.environ)
            except BaseException:
                import traceback
                traceback.print_exc()
                os._exit(127)
        def timeout(signum, frame):
            nonlocal expired
            expired = True
            try:
                os.killpg(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        previous = signal.signal(signal.SIGALRM, timeout)
        signal.setitimer(signal.ITIMER_REAL, spec.get("timeout_s", 180))
        try:
            while True:
                try:
                    actual_pid, status, usage = os.wait4(pid, 0)
                    break
                except InterruptedError:
                    pass
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            signal.signal(signal.SIGALRM, previous)
        elapsed = time.monotonic() - start
    assert actual_pid == pid
    returncode = os.waitstatus_to_exitcode(status)
    record = {"collector": "os.wait4(pid, 0) at command completion; no sampling",
              "python": sys.version, "start_utc": start_utc,
              "end_utc": datetime.now(timezone.utc).isoformat(),
              "command": spec["command"], "cwd": spec["cwd"],
              "stdout": spec["stdout"], "stderr": spec["stderr"],
              "returncode": returncode, "timed_out": expired,
              "raw_wait_status": status, "wall_s": elapsed,
              "ru_maxrss_kib": usage.ru_maxrss,
              "ru_utime_s": usage.ru_utime, "ru_stime_s": usage.ru_stime,
              "ru_minflt": usage.ru_minflt, "ru_majflt": usage.ru_majflt,
              "ru_inblock": usage.ru_inblock, "ru_oublock": usage.ru_oublock,
              "ru_nvcsw": usage.ru_nvcsw, "ru_nivcsw": usage.ru_nivcsw,
              "affinity": sorted(os.sched_getaffinity(0)),
              "memory_scope": "Linux ru_maxrss is the command's maximum resident size accounting, including waited descendants; it is not simultaneous summed process-tree RSS."}
    output.write_text(json.dumps(record, indent=2) + "\n")
    return (128 - returncode if returncode < 0 else returncode) or (124 if expired else 0)


if __name__ == "__main__":
    sys.exit(main())
