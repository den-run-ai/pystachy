"""Audit frozen build-cost data without running compilers, programs or measurements."""
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "alpha2"
inputs = {}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def identify(path):
    path = Path(path)
    with path.open("rb") as stream:
        sha = hashlib.file_digest(stream, "sha256").hexdigest()
    row = {"path": str(path), "sha256": sha, "size": path.stat().st_size}
    require(str(path) not in inputs or inputs[str(path)] == row, "Input changed: " + str(path))
    inputs[str(path)] = row
    return row


def read(path):
    identify(path)
    return Path(path).read_bytes()


def js(path):
    return json.loads(read(path))


def git(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()


report_path = ROOT / "report.json"
report = js(report_path)
identity = js(ROOT / "identity.json")
invocation = js(ROOT / "invocation-receipt.json")
session = js(ROOT / "session.json")
summary_text = read(ROOT / "summary.md").decode()
require(inputs[str(report_path)]["sha256"] == "d55886fab7fa7e993e12676ba897b5e5cc1309bbf01cac0c7d304c10a7a367da",
        "Report differs from frozen handoff")
require(report["status"] == identity["status"] == "passed", "Measurement not successful")
require(report["identity"] == str(ROOT / "identity.json") and
        report["identity_sha256"] == inputs[str(ROOT / "identity.json")]["sha256"], "Source identity not bound")
require(report["runner_sha256"] == identify(ROOT / "run.py")["sha256"] and
        report["collector_sha256"] == identify(ROOT / "measure-command.py")["sha256"], "Runner/collector changed")
identify(ROOT / "prepare.py")
require(report["python"].startswith("3.13.16 ") and report["python_executable"] ==
        "/workspace/scratch/c2b093657c17/dev-venv/bin/python", "Unpinned measurement interpreter")
require(invocation["prepare_command"] == [report["python_executable"], str(ROOT / "prepare.py")] and
        invocation["run_command"] == session["command"] ==
        [report["python_executable"], str(ROOT / "run.py")], "Invocation identity mismatch")
require(invocation["prepare_exit"] == invocation["run_exit"] == 0 and
        invocation["optimization_flags_in_commands"] == [], "Run failed or used optimization flags")
require(invocation["unchanged_result_sha256"] == inputs[str(report_path)]["sha256"], "Invocation receipt not bound")
context = invocation["current_post_run_interpreter_check"]
require(context["optimize"] == 0 and context["debug"] and context["PYTHONOPTIMIZE"] is None,
        "Post-run assertion context differs")

expected = {"base": "a73c56c92f3aad4b490307a5d1b882e487a57f55",
            "head": "80490143498d149d407343ba1cb7aedb1db2d2c5"}
changes = ["tools/check_lean_storage.py", "tools/test_lean_storage.py", "tools/test_lean_storage_layout.py"]
require(set(identity["revisions"]) == set(expected), "Wrong revisions")
for side, commit in expected.items():
    row = identity["revisions"][side]
    home = Path(row["home"])
    require(home == ROOT / side and row["release_sha"] == git(home, "rev-parse", "HEAD") == commit,
            "Wrong source home")
    require(row["release_tree"] == git(home, "rev-parse", "HEAD^{tree}") ==
            git(REPO, "rev-parse", commit + "^{tree}"), "Wrong source tree")
    require(not git(home, "status", "--porcelain", "--untracked-files=all"), "Dirty source home")
    require(git(REPO, "diff", "--name-only", row["built_source_sha"], commit).splitlines() ==
            row["source_changes_since_fixed_point"] == changes, "Compiler/runtime reuse is not source-identical")
    original_path = Path(row["original_identity"])
    original = js(original_path)
    require(inputs[str(original_path)]["sha256"] == row["original_identity_sha256"], "Original identity changed")
    require(row["bootstrap"] == original["bootstrap"] and
            row["built_source_sha"] == original["bootstrap"]["local_build_source_ref"], "Bootstrap identity differs")
    require(row["binary"] == str(home / "pystachy"), "Wrong binary path")
    require(identify(home / "pystachy")["sha256"] == identify(row["source_binary"])["sha256"] ==
            identify(Path(row["source_binary"]).parent / "build/pystachy2")["sha256"] ==
            row["binary_sha256"] == original["binary"]["sha256"], "Native compiler binary changed")
    require(identify(row["bootstrap"]["log"])["sha256"] == row["bootstrap"]["log_sha256"], "Bootstrap log changed")
    fixed = {name: identify(Path(row["source_binary"]).parent / "build" / name)["sha256"]
             for name in row["bootstrap"]["files"]}
    require(fixed == row["bootstrap"]["files"] == row["current_fixed_point_hashes"], "Fixed-point files changed")
    require(len({fixed[f"stage{i}.ll"] for i in (1, 2, 3)}) == 1 and
            len({fixed[f"rt{i}.ll"] for i in (1, 2, 3)}) == 1, "Fixed points differ")
    for source, sha in row["workloads"].items():
        require(identify(home / source)["sha256"] == sha, "Workload source changed")
require(identity["revisions"]["base"]["workloads"] == identity["revisions"]["head"]["workloads"] and
        len(str(ROOT / "base")) == len(str(ROOT / "head")), "Uncontrolled input or home-length difference")

cases = {"numeric": ["bench/smoke/ml.py", ["numeric", "20000"]],
         "json": ["bench/smoke/text.py", ["json", "6000"]],
         "copy_float": ["bench/smoke/identity.py", ["float", "6000000", "123"]]}
require(report["cases"] == cases and len(report["affinity"]) == 1, "Wrong workloads/CPU affinity")
for side in expected:
    env = report["environment"][side]
    require(env["PYSTACHY_HOME"] == str(ROOT / side) and env["PYSTACHY_CACHE"] == str(ROOT / "cache" / side),
            "Wrong source/cache environment")
    require(env["PYSTACHY_PROGRAM_CACHE"] == "0" and env["PYSTACHY_JOBS"] == "1" and
            env["PYTHONHASHSEED"] == "0", "Wrong cache/parallel environment")
require({k: v for k, v in report["environment"]["base"].items() if k not in {"PYSTACHY_HOME", "PYSTACHY_CACHE"}} ==
        {k: v for k, v in report["environment"]["head"].items() if k not in {"PYSTACHY_HOME", "PYSTACHY_CACHE"}},
        "Uncontrolled tool environment difference")
require(set(report["toolchain"]) == {"clang", "opt", "llc", "llvm-link"}, "Missing tool identities")
for tool in report["toolchain"].values():
    require(identify(tool["path"])["sha256"] == tool["sha256"] and "18.1.3" in tool["version"],
            "Toolchain identity differs")

warm_expected = [(name, side, "warmup", 0) for name in cases for side in expected]
sample_expected = [(name, side, "sample", repeat) for name in cases for repeat in range(3)
                   for side in (("base", "head") if repeat % 2 == 0 else ("head", "base"))]
def key(row):
    return row["workload"], row["side"], row["phase"], row["repeat"]
require([key(r) for r in report["warmups"]] == warm_expected and
        [key(r) for r in report["samples"]] == sample_expected, "Incomplete/incorrect paired sample order")
oracles = {name: read(ROOT / "raw" / f"{name}-oracle.stdout") for name in cases}
def check_runtime_stderr(path):
    # The three pinned workload sources each print their elapsed time here.
    # These correctness executions are not samples for the build-cost summary.
    content = read(path)
    match = re.fullmatch(rb"seconds ([0-9]+(?:\.[0-9]+)?(?:e[+-]?[0-9]+)?)\n", content)
    require(match is not None and math.isfinite(float(match[1])) and float(match[1]) >= 0,
            "Unexpected workload diagnostic: " + str(path))
for name in cases:
    check_runtime_stderr(ROOT / "raw" / f"{name}-oracle.stderr")
last_end = None
measurements = report["warmups"] + report["samples"]
for row in measurements:
    name, side, phase, repeat = key(row)
    prefix = ROOT / "raw" / f"{name}-{phase}-{repeat}-{side}"
    require(row["raw_record"] == str(prefix.with_suffix(".json")), "Wrong raw record path")
    raw = js(prefix.with_suffix(".json"))
    spec = js(prefix.with_suffix(".spec.json"))
    require(inputs[str(prefix.with_suffix(".json"))]["sha256"] == row["raw_record_sha256"], "Raw result changed")
    source, arguments = cases[name]
    home = ROOT / side
    command = [str(home / "pystachy"), "build", str(home / source), "-o",
               str(ROOT / "executables" / side / name)]
    require(raw["command"] == spec["command"] == command and raw["cwd"] == spec["cwd"] == str(home),
            "Wrong measured command/source")
    require(spec["record"] == row["raw_record"] and spec["timeout_s"] == 180, "Wrong measurement spec")
    require(raw["affinity"] == report["affinity"] and raw["python"] == report["python"], "Collector environment differs")
    require(raw["returncode"] == raw["raw_wait_status"] == row["returncode"] == 0 and
            raw["timed_out"] is row["timed_out"] is False, "Build failed or timed out")
    require(row["output_matches_pinned_cpython"] is True, "Execution acceptance missing")
    for metric in ("wall_s", "ru_maxrss_kib", "ru_utime_s", "ru_stime_s"):
        require(raw[metric] == row[metric] and math.isfinite(raw[metric]) and raw[metric] >= 0,
                "Raw metric differs/invalid")
    require(raw["wall_s"] > 0 and type(raw["ru_maxrss_kib"]) is int and raw["ru_maxrss_kib"] > 0 and
            type(row["executable_bytes"]) is int and row["executable_bytes"] > 0, "Invalid time/memory/size")
    start, end = (datetime.fromisoformat(raw[k]) for k in ("start_utc", "end_utc"))
    require(end >= start and (last_end is None or start >= last_end), "Overlapping or invalid measured intervals")
    last_end = end
    for stream in ("stdout", "stderr"):
        path = prefix.with_suffix("." + stream)
        require(raw[stream] == spec[stream] == str(path), "Wrong stream path")
        identify(path)
    require(read(prefix.with_suffix(".wrapper.log")) == b"", "Collector wrapper reported diagnostics")
    require(read(prefix.with_suffix(".check.stdout")) == oracles[name], "Executable output differs from pinned oracle")
    check_runtime_stderr(prefix.with_suffix(".check.stderr"))

require(report["cache_after_samples"] == report["cache_after_warmups"] and
        report["runtime_cache_bytes_unchanged_during_samples"] is True, "Warm cache changed")
for side, manifest in report["cache_after_samples"].items():
    actual = []
    for path in sorted((ROOT / "cache" / side).rglob("*")):
        if path.is_file():
            i = identify(path)
            actual.append({"path": str(path.relative_to(ROOT / "cache" / side)), "sha256": i["sha256"], "bytes": i["size"]})
    require(actual == manifest, "Current cache differs from measured manifest")
for name in cases:
    for side in expected:
        last = [r for r in report["samples"] if r["workload"] == name and r["side"] == side][-1]
        value = identify(ROOT / "executables" / side / name)
        require(value["sha256"] == last["executable_sha256"] and value["size"] == last["executable_bytes"],
                "Last measured executable changed")

recomputed = []
for name in cases:
    row = {"workload": name, "pairs": 3}
    for metric in ("wall_s", "ru_maxrss_kib", "ru_utime_s", "ru_stime_s", "executable_bytes"):
        values = {side: [r[metric] for r in report["samples"] if r["workload"] == name and r["side"] == side]
                  for side in expected}
        require(all(len(v) == 3 for v in values.values()), "Wrong median sample count")
        medians = {side: statistics.median(v) for side, v in values.items()}
        row[metric] = {"base_median": medians["base"], "head_median": medians["head"],
                       "ratio_of_medians": medians["head"] / medians["base"],
                       "change_percent": (medians["head"] / medians["base"] - 1) * 100,
                       "ranges": {side: [min(v), max(v)] for side, v in values.items()}, "samples": values}
    recomputed.append(row)
require(recomputed == report["summary"], "Reported medians, ratios or ranges differ")
for row in recomputed:
    a, b, c = (row[k] for k in ("wall_s", "ru_maxrss_kib", "executable_bytes"))
    line = (f"| {row['workload']} | {a['base_median']:.6f} → {a['head_median']:.6f} | {a['change_percent']:+.1f}% | "
            f"{b['base_median']:,} → {b['head_median']:,} | {b['change_percent']:+.1f}% | "
            f"{c['base_median']:,} → {c['head_median']:,} | {c['change_percent']:+.1f}% |")
    require(line in summary_text, "Readable summary table differs")
for required in ("medians of three", "not a broad runtime-speed or application-memory claim",
                 "not the sum of simultaneously resident child processes", "excluded from the medians",
                 "No steady-state runtime or startup comparison"):
    require(required in summary_text, "Readable summary omits a material limit")
require(report["clean_source_and_binary_identities_after"] is True, "Final identity check missing")
for side, ident in identity["revisions"].items():
    require(not git(ROOT / side, "status", "--porcelain", "--untracked-files=all") and
            git(ROOT / side, "rev-parse", "HEAD") == expected[side], "Source changed during audit")
for value in list(inputs.values()):
    require(identify(value["path"]) == value, "Input changed during audit")

receipt = {
    "kind": "Independent audit of exact-source alpha2 bounded AOT build cost and memory evidence",
    "status": "passed_bounded_measurement_evidence", "created_utc": datetime.now(timezone.utc).isoformat(),
    "revisions": expected, "inputs": list(inputs.values()),
    "warmups": 6, "measured_builds": 18, "workloads": 3, "pairs_per_workload": 3,
    "all_24_built_executables_match_pinned_cpython_output": True,
    "stderr_contains_only_the_workload_sources_expected_elapsed_time_lines": True,
    "all_builds_exit_zero_without_timeout": True,
    "all_exact_source_and_original_fixed_point_binary_bindings_verified": True,
    "only_changes_from_built_compiler_sources": changes,
    "all_commands_sequential_on_one_cpu_with_private_warm_runtime_caches": True,
    "program_cache_disabled_and_warmed_cache_bytes_unchanged": True,
    "raw_metrics_and_all_medians_ratios_ranges_recomputed_exactly": True,
    "readable_summary_table_and_material_limits_verified": True,
    "summary": recomputed, "invocation_provenance": invocation,
    "limits": [
        "Three workloads and three paired observations per workload on one local Linux x86-64 host; no broad speed or memory claim.",
        "Warm-runtime-cache AOT build costs only. No compiler-bootstrap memory, steady-state application memory, startup or runtime speed claim.",
        "Linux wait4 ru_maxrss in KiB includes waited-descendant resource accounting; it is not simultaneously summed process-tree RSS.",
        "All three executable-size medians increase; lower build time and recorded RSS do not erase that tradeoff.",
        "Original invocations are retained from the executed transcript; optimization context was separately observed after completion and is labeled as such."
    ],
    "scope": "Independent read-only source/evidence review and arithmetic recomputation. No compiler, executable, workload, measurement, test, network or workflow execution. No monitoring or process sampling."
}
path = ROOT / "independent-acceptance.json"
with path.open("x") as stream:
    stream.write(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"path": str(path), "sha256": identify(path)["sha256"], "status": receipt["status"],
                  "warmups": 6, "measured_builds": 18}, indent=2))
