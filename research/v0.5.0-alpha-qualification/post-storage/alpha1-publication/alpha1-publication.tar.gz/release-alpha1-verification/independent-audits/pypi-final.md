# Alpha.1 PyPI independent acceptance

**Passed. The public wheel and source distribution equal the packages tested and published by Release run 43621120891.**

Release version: v0.5.0-alpha.1. PyPI version: 0.5.0a1. Exact source commit: a73c56c92f3aad4b490307a5d1b882e487a57f55. Source tree: 3c9a009434d68906889651d148cb29f6022d2f1f.

The existing PyPI publisher branch ran at 6e5544cfa3eecb8329e4f4cb19d2e0ac3e99b1bf. Its PyPI workflow section and gate helpers are identical to the release source. The workflow checked out the published release tag separately and built from exact commit a73c56c92f3aad4b490307a5d1b882e487a57f55; the recorded source provenance, published tag gate and immutable source comparison all agree.

## Actual execution and publication

Both jobs completed successfully, with the four expected native-path skips. Verification took 110 seconds and publication took 22 seconds. The installed-package smoke ran from the exact released source, in fresh pip and uv environments outside the checkout. The recorded output confirms version, JIT, standalone AOT and external cache checks passed for both installations. Both uninstall checks also passed. The helper compares JIT/AOT output with CPython, executes the AOT binary with an empty PATH, and checks the external runtime cache and Linux JIT runner. This job did not request the optional PyPI GC-stress mode.

The tested artifact ZIP, ID 14124630426, hashes identically in the verification upload, publication download and retained local ZIP. All four ZIP entries equal the retained tested files. Publication verifies both distribution checksums, then uploads both packages successfully; each upload returned HTTP 200.

| Public distribution | SHA-256 | Bytes |
|---|---|---:|
| pystachy-0.5.0a1-py3-none-any.whl | 7d2cd50086e08b2a3535dcca2ccad7cd30daae828feb62ad4ec29a251fb30dc4 | 1,917,999 |
| pystachy-0.5.0a1.tar.gz | b405829de6610ade481215ac835d057d751054acfb074f245262111da8f6b8f0 | 1,846,374 |

Actual downloaded public distribution bytes equal the tested artifact bytes and saved PyPI API hashes/sizes. Neither distribution is yanked. All wheel RECORD entries are complete and verify. All **162 wheel source files**, **3 wheel license files** and **167 source-distribution source files** match immutable Git blobs from the release commit byte for byte; generated packaging metadata is separately enumerated in the JSON receipt.

## Hosted version and stable pointers

The hosted wheel intentionally carries VERSION without REVISION. Its driver therefore prints “pystachy v0.5.0-alpha.1 (commit unknown)”. The retained extra local probe expected a native binary's full-commit format and stopped after a successful pip install/version exit; it had not attempted uv. The captured diagnostic matches the source-defined hosted format. Source identity is established by SOURCE.json, all distribution hashes and the direct Git source-byte comparison. The workflow's successful clean pip/uv JIT/AOT checks are independent of that supplemental probe.

Saved public stable metadata independently matches the pre-alpha baseline: GitHub latest remains v0.4.0 at 5f81cc2563d231501952104e991d858e670325ac, PyPI's default version remains 0.4.0, and Docker latest remains sha256:037f5691b17c9ae9a8afb6be79bf6870a1a81fb9ada67ec5e3d9dd5b08d60d01.

The companion JSON records exact input hashes, actual execution log lines, source identities and every packaged source comparison. This audit performed no network requests, downloads, installations or compiler execution.
