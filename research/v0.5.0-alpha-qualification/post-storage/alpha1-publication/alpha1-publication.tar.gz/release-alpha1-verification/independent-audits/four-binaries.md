# Alpha.1 four-binary independent audit

**All four native binary components passed. This receipt does not claim complete workflow or publication success.**

Release: `v0.5.0-alpha.1`. Exact source: `a73c56c92f3aad4b490307a5d1b882e487a57f55`. Release workflow run: `43618595752`.

| Target | Job | Duration | Independent audit |
|---|---:|---:|---|
| linux-x86_64 | 132519115777 | 5m 04s | Passed |
| linux-aarch64 | 132519115760 | 6m 14s | Passed |
| macos-arm64 | 132519115842 | 7m 18s | Passed |
| macos-x86_64 | 132519115814 | 12m 10s | Passed |

Each job establishes three-stage compiler and runtime fixed points (**923,418** and **21,214** IR lines), exact native/installed version and commit, Python-free relocated JIT/AOT, GC-stressed execution, and warm reuse of the intended ordinary JIT runtime cache. The warm-cache test explicitly disables the default program cache before priming and comparing runtime artifacts. All four jobs complete within the 15-minute cap.

Both Linux jobs additionally establish default program-cache fill/hit behavior and complete ELF ABI audits with zero violations. Their glibc symbol floor is **2.38**, within the **2.39** ceiling. Both macOS jobs skip the one Linux-only release-unit cache test; their native execution checks pass.

The audit independently matches each downloaded ZIP to its logged upload digest, each extracted file to the ZIP, every release archive to its checksum, all packaged files to manifest hashes, and each native executable to its expected architecture and source version. Linux ABI reports also exactly match actual log output and the same packaged ELF bytes.

The companion JSON binds all four component receipt hashes and preserves artifact identities. Installer unit tests and synthetic publication messages are distinguished from actual relocated compiler execution. Containers, publication and PyPI remain outside this receipt's scope. No local payload execution or network requests were performed.
