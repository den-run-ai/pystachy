# Alpha.1 native-container independent audit

**Both native container components passed. This receipt does not claim publication or public availability.**

Run `43618595752`, exact source `a73c56c92f3aad4b490307a5d1b882e487a57f55`, version `v0.5.0-alpha.1`.

| Architecture | Job | Duration | Verified layer references |
|---|---:|---:|---:|
| linux/amd64 | 132522672916 | 2m 18s | 7 |
| linux/arm64 | 132522672870 | 2m 33s | 7 |

Both jobs consume the previously verified native binary artifacts, assert actual image architecture, build a Python-free final image, and pass actual installed JIT/AOT smoke. Explicit runs as UID **10001** report the exact version and commit and pass the same smoke checks. Bind-mounted JIT produces the expected `332833500`; the standalone AOT output assertion also succeeds.

The byte audit matches downloaded ZIPs to logged upload digests, extracted images to ZIP entries and sidecar checksums, and saved configuration digests to actual Buildx export output. Architecture, release labels, entrypoint and working directory match. All saved content-addressed blobs and all **14** ordered decompressed layer identities verify. The companion JSON records exact component receipt and image hashes for later comparison with public Docker manifests.

Assertions in successful workflow steps are distinguished from emitted execution output. No containers, compilers or payloads ran locally; the image check uses bounded buffers and a sequential read. Publication and public registry verification remain separate.
