# Alpha.1 native and Docker final acceptance

**Passed. The published GitHub native release and both Docker architectures match the successfully tested release artifacts. PyPI remains separate.**

Version `v0.5.0-alpha.1`, exact commit `a73c56c92f3aad4b490307a5d1b882e487a57f55`, source tree `3c9a009434d68906889651d148cb29f6022d2f1f`.

The native Release run `43618595752` completed successfully with **8 successful jobs** and the **2 expected PyPI skips**. The longest job took **12m 10s**, within the 15-minute cap. Prepare and publication both report successful CI, Installation, Lint and Packages gates for the exact source commit. All four native binaries and both native container jobs have separate passed independent audit receipts.

## Publication and native artifacts

The publish job downloads the same six tested artifact ZIPs, verifies all four native archives and both saved images, loads both tested native images, and reports successful Docker and GitHub publication. GitHub metadata confirms a published, non-draft **prerelease** at the exact source commit and tag. Both stable/latest promotion steps are skipped.

All **11 public GitHub assets** were independently rehashed from saved downloads and match API digest/size/asset identity. Native archives, checksum sidecars and Linux ABI reports are byte-identical to the independently audited tested artifacts; the aggregate checksum file lists exactly the four accepted archives. The recorded downloaded Linux executable version check reports the exact release version and commit.

## Docker identity and public blobs

The public Docker index contains exactly `linux/amd64` and `linux/arm64`. Manifest and configuration hashes resolve correctly, and complete public configurations match the independently audited saved-image configurations. Native execution evidence includes Python-free images, exact version/commit, UID 10001 JIT/AOT and bind mounts.

The additional public-layer audit verifies **11 distinct blobs**, **14 ordered layer references**, and **407,072,225 compressed download bytes**. Every compressed digest/size and decompressed `diff_id`/size matches the saved registry metadata and previously tested image. All input hashes match the independently reviewed helper and exact release source.

Public Docker index: `sha256:1ae046bdbb9a72202a9daa44b756673cf1436166db2345f8ed2ab69fa2a954f2`.

The companion JSON records evidence hashes, public asset identities, job/log links and Docker platform identities. This aggregation performed no downloads, network requests or payload execution. It certifies native and Docker delivery only; the separate PyPI run must supply its own acceptance evidence.
