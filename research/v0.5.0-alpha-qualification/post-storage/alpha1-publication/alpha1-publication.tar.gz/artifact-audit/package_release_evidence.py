#!/usr/bin/env python3
"""Archive small, immutable release evidence; keep large public payloads by hash."""
import argparse
import gzip
import hashlib
import io
import json
import re
import tarfile
from pathlib import Path


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', required=True, type=Path)
    ap.add_argument('--alpha', required=True, choices=['alpha1', 'alpha2'])
    ap.add_argument('--source-commit', required=True)
    ap.add_argument('--notes', required=True, type=Path)
    args = ap.parse_args()
    root = args.root.resolve()
    out = root / 'evidence-upload'
    out.mkdir(exist_ok=True)
    stem = args.alpha + '-publication'
    archive = out / (stem + '.tar.gz')
    manifest_path = out / (stem + '-manifest.json')
    if archive.exists() or manifest_path.exists():
        raise SystemExit('Evidence archive already exists; preserve it and use a new destination.')
    files = {}
    for dirname in [f'release-{args.alpha}-verification', f'release-{args.alpha}-public-layers', 'pre-alpha-stable']:
        directory = root / dirname
        if not directory.is_dir():
            raise SystemExit(f'Missing evidence directory: {dirname}')
        for path in sorted(directory.rglob('*')):
            if not path.is_file() or '__pycache__' in path.parts:
                continue
            if path.suffix not in {'.json', '.md', '.py', '.log', '.sha256'} and path.name != 'SHA256SUMS':
                continue
            if path.stat().st_size > 2_000_000:
                raise SystemExit(f'Unexpected large text evidence: {path}')
            files[str(path.relative_to(root))] = path.read_bytes()
    for path in sorted((root / 'artifact-audit').glob('*')):
        if path.is_file() and path.suffix in {'.py', '.md', '.json'}:
            files[str(path.relative_to(root))] = path.read_bytes()
    for name in [f'{args.alpha}-native-dispatch.json', f'{args.alpha}-pypi-dispatch.json']:
        path = root / name
        if not path.is_file():
            raise SystemExit(f'Missing dispatch record: {name}')
        files[name] = path.read_bytes()
    helpers = Path('/workspace/scratch/c66a10c5a7b1/artifact-audit')
    for name in ['retrieve.py', 'verify.py']:
        files['retrieval-helpers/' + name] = (helpers / name).read_bytes()
    files['README.md'] = args.notes.read_bytes()
    secret_patterns = [
        re.compile(rb'(?:github_pat_|ghp_|gho_)[A-Za-z0-9_]{20,}'),
        re.compile(rb'[?&](?:sig|token|access_token)=(?!\*|%2A)[A-Za-z0-9_%+/-]{12,}'),
    ]
    for name, data in files.items():
        if any(pattern.search(data) for pattern in secret_patterns):
            raise SystemExit('Possible sensitive credential in ' + name + '; values not printed.')
    entries = [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
               for name, data in sorted(files.items())]
    manifest = {
        'version': 'v0.5.0-' + args.alpha.replace('alpha', 'alpha.'),
        'source_commit': args.source_commit,
        'scope': 'Completed publication, public byte identity, independent audits and raw workflow logs. Large public payloads are retained by their verified hashes and public URLs, not duplicated here.',
        'files': entries,
    }
    files['FILE_MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    with archive.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
            with tarfile.open(mode='w', fileobj=gz, format=tarfile.PAX_FORMAT) as tar:
                for name, data in sorted(files.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    tar.addfile(info, io.BytesIO(data))
    payload = archive.read_bytes()
    manifest['archive'] = {'name': archive.name, 'bytes': len(payload),
                           'sha256': hashlib.sha256(payload).hexdigest(),
                           'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(payload)).encode() + b'\0' + payload).hexdigest()}
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    with tarfile.open(archive, 'r:gz') as tar:
        for entry in entries:
            data = tar.extractfile(entry['path']).read()
            assert len(data) == entry['bytes']
            assert hashlib.sha256(data).hexdigest() == entry['sha256']
    print(json.dumps({'archive': manifest['archive'], 'files': len(entries), 'verified': True}, indent=2))


if __name__ == '__main__':
    main()
