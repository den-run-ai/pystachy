"""One-shot public release retrieval; no publishing, polling, or mutation APIs.

Only invokes GET requests. Run each selected phase after the corresponding
publication completes. Offline payload validation lives in adjacent verify.py.
"""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import sys
import tarfile
import urllib.parse
import urllib.request
import zipfile

API = 'https://api.github.com/repos/den-run-ai/pystachy'
IMAGE = 'dta67/pystachy'
TYPES = ', '.join(['application/vnd.oci.image.index.v1+json',
    'application/vnd.docker.distribution.manifest.list.v2+json',
    'application/vnd.oci.image.manifest.v1+json',
    'application/vnd.docker.distribution.manifest.v2+json'])

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def get(url, headers=None):
    request = urllib.request.Request(url, headers={'User-Agent': 'Pystachy-release-qualification', **(headers or {})})
    with urllib.request.urlopen(request, timeout=60) as response:
        return response.read(), dict(response.headers)

def get_json(url, saved=None):
    return json.loads(saved.read_text()) if saved else json.loads(get(url)[0])

def save_json(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')

def download(url, path, headers=None):
    # A completed local input may be reused, but every caller rechecks its hash.
    if path.exists():
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_name(path.name + '.part')
    request = urllib.request.Request(url, headers={'User-Agent': 'Pystachy-release-qualification', **(headers or {})})
    try:
        with urllib.request.urlopen(request, timeout=60) as response, partial.open('wb') as output:
            shutil.copyfileobj(response, output)
        partial.replace(path)
    finally:
        partial.unlink(missing_ok=True)

class Registry:
    def __init__(self):
        query = urllib.parse.urlencode({'service': 'registry.docker.io', 'scope': f'repository:{IMAGE}:pull'})
        token = get_json('https://auth.docker.io/token?' + query)['token']
        self.headers = {'Authorization': 'Bearer ' + token, 'Accept': TYPES}
        self.base = f'https://registry-1.docker.io/v2/{IMAGE}'

    def manifest(self, reference, path):
        data, headers = get(self.base + '/manifests/' + reference, self.headers)
        digest = 'sha256:' + hashlib.sha256(data).hexdigest()
        claimed = next((v for k, v in headers.items() if k.lower() == 'docker-content-digest'), None)
        assert not claimed or digest == claimed, 'Registry response digest mismatch'
        assert not reference.startswith('sha256:') or digest == reference
        path.write_bytes(data)  # Do not reserialize JSON: its digest covers exact bytes.
        return json.loads(data), digest

    def config(self, descriptor, path):
        assert re.fullmatch(r'sha256:[0-9a-f]{64}', descriptor['digest'])
        download(self.base + '/blobs/' + descriptor['digest'], path, self.headers)
        assert 'sha256:' + sha(path) == descriptor['digest']
        assert path.stat().st_size == descriptor['size']

def native(args, verifier):
    meta = args.output / 'native-metadata'
    meta.mkdir(exist_ok=True)
    release = get_json(API + '/releases/tags/' + args.version, args.release_json)
    tag = get_json(API + '/commits/' + urllib.parse.quote(args.version, safe=''), args.tag_json)
    save_json(meta / 'release.json', release)
    save_json(meta / 'tag.json', tag)
    assert release['tag_name'] == args.version and not release['draft'] and release['prerelease']
    assert tag['sha'] == args.commit and args.commit in release['body']
    assets = {entry['name']: entry for entry in release['assets']}
    archives = {f'pystachy-{args.version}-{target}.tar.gz' for target in verifier.TARGETS}
    expected = archives | {name + '.sha256' for name in archives} | {
        'SHA256SUMS', 'linux-abi-linux-x86_64.json', 'linux-abi-linux-aarch64.json'}
    assert len(release['assets']) == len(assets) == 11 and set(assets) == expected
    args.directory = args.output / 'native'
    args.directory.mkdir(exist_ok=True)
    received = {}
    for name, entry in sorted(assets.items()):
        path = args.directory / name
        download(entry['browser_download_url'], path)
        assert path.stat().st_size == entry['size'], name
        digest = sha(path)
        assert not entry.get('digest') or entry['digest'] == 'sha256:' + digest, name
        received[name] = {'sha256': digest, 'size': path.stat().st_size, 'asset_id': entry['id']}
        if args.tested_dir and name != 'SHA256SUMS':
            tested = list(args.tested_dir.rglob(name))
            assert len(tested) == 1 and tested[0].is_file(), 'Missing or ambiguous tested native asset'
            assert sha(tested[0]) == digest and tested[0].stat().st_size == path.stat().st_size
            received[name]['tested_artifact'] = str(tested[0])
    return {'release_url': release['html_url'], 'tag_commit': tag['sha'],
        'public_assets': received, 'offline_verification': verifier.native(args)}

def docker(args, verifier):
    from release_images import index_images
    args.directory = args.output / 'docker'
    args.directory.mkdir(exist_ok=True)
    registry = Registry()
    index, args.index_digest = registry.manifest(args.version, args.directory / 'index.json')
    images = index_images(index)
    tested = {}
    for arch, digest in images.items():
        manifest, actual = registry.manifest(digest, args.directory / f'manifest-{arch}.json')
        assert actual == digest
        _, tagged = registry.manifest(args.version + '-' + arch, args.directory / f'tag-{arch}.json')
        assert tagged == digest, 'Per-architecture tag differs from version index'
        registry.config(manifest['config'], args.directory / f'config-{arch}.json')
        if args.tested_dir:
            tested[arch] = tested_image(args.tested_dir, arch, verifier)
            assert tested[arch]['config_digest'] == manifest['config']['digest']
            config = json.loads((args.directory / f'config-{arch}.json').read_text())
            assert tested[arch]['diff_ids'] == config['rootfs']['diff_ids']
            assert len(manifest['layers']) == len(config['rootfs']['diff_ids'])
    return {**verifier.docker(args), 'tested_images': tested,
        'public_layers_downloaded': False, 'local_container_execution': False,
        'execution_evidence_required': 'Matching native Release container jobs must have successful JIT/AOT, unprivileged-user and bind-mount steps.'}

def tested_image(directory, architecture, verifier):
    paths = list(directory.rglob(f'pystachy-image-{architecture}.tar.gz'))
    assert len(paths) == 1, 'Missing or ambiguous tested image'
    path = paths[0]
    assert verifier.checksums(path.with_name(path.name + '.sha256').read_text()) == {path.name: sha(path)}
    with tarfile.open(path, 'r:gz') as archive:
        saved = json.load(archive.extractfile('manifest.json'))
        assert len(saved) == 1
        config_bytes = archive.extractfile(saved[0]['Config']).read()
        config = json.loads(config_bytes)
        decoded = []
        for name in saved[0]['Layers']:
            with archive.extractfile(name) as stream:
                magic = stream.read(2)
                stream.seek(0)
                if magic == b'\x1f\x8b':
                    with gzip.GzipFile(fileobj=stream) as payload:
                        value = hashlib.file_digest(payload, 'sha256').hexdigest()
                else:
                    value = hashlib.file_digest(stream, 'sha256').hexdigest()
            decoded.append('sha256:' + value)
        assert decoded == config['rootfs']['diff_ids']
    return {'tested_archive': str(path), 'archive_sha256': sha(path),
        'config_digest': 'sha256:' + hashlib.sha256(config_bytes).hexdigest(), 'diff_ids': decoded}

def pypi(args, verifier):
    from pypi_release import package_version
    assert args.workflow_zip and args.workflow_zip.is_file(), 'Require the publisher run artifact ZIP'
    version = package_version(args.version)
    metadata = get_json(f'https://pypi.org/pypi/pystachy/{version}/json', args.pypi_json)
    args.pypi_json = args.output / 'pypi-metadata.json'
    save_json(args.pypi_json, metadata)
    expected = {f'pystachy-{version}.tar.gz', f'pystachy-{version}-py3-none-any.whl'}
    assert len(metadata['urls']) == 2 and {x['filename'] for x in metadata['urls']} == expected
    args.directory = args.output / 'pypi'
    args.directory.mkdir(exist_ok=True)
    for entry in metadata['urls']:
        assert not entry['yanked']
        download(entry['url'], args.directory / entry['filename'])
    return {**verifier.pypi(args), 'verification_mode': 'Actual public distribution bytes equal the tested workflow artifact bytes',
        'public_distribution_bytes_downloaded': True, 'local_pip_uv_install': False}

def pypi_metadata(args, verifier):
    """Explicit narrow fallback after a retained public distribution failure."""
    from pypi_release import package_version
    assert args.blocked_retrieval and args.tested_dir and args.workflow_zip
    blocked = json.loads(args.blocked_retrieval.read_text())
    assert blocked['phase'] == 'pypi' and blocked['status'] == 'failed'
    assert blocked['version'] == args.version and blocked['expected_commit'] == args.commit
    version = package_version(args.version)
    metadata = get_json(f'https://pypi.org/pypi/pystachy/{version}/json', args.pypi_json)
    args.pypi_json = args.output / 'pypi-metadata-only.json'
    save_json(args.pypi_json, metadata)
    args.directory = args.tested_dir / ('pypi-' + version) / 'dist'
    result = verifier.pypi(args)
    return {**result, 'verification_mode': 'Public SHA-256 and size metadata equal the retained tested workflow bytes',
        'public_distribution_bytes_downloaded': False, 'local_public_pip_uv_install': False,
        'retained_public_download_failure': str(args.blocked_retrieval),
        'execution_evidence_required': 'The same publishing run must show successful clean pip/uv JIT/AOT verification and successful upload.',
        'limitation': 'This proves public metadata/tested-artifact identity. It does not claim these public distributions were downloaded or locally installed.'}

def stable(args, verifier):
    directory = args.output / 'stable'
    directory.mkdir(exist_ok=True)
    latest = get_json(API + '/releases/latest', args.latest_json)
    save_json(directory / 'github-latest.json', latest)
    assert not latest['draft'] and not latest['prerelease']
    tag = get_json(API + '/commits/' + urllib.parse.quote(latest['tag_name'], safe=''), args.stable_tag_json)
    save_json(directory / 'github-stable-tag.json', tag)
    registry = Registry()
    _, digest = registry.manifest('latest', directory / 'docker-latest.json')
    package = get_json('https://pypi.org/pypi/pystachy/json', args.pypi_latest_json)
    save_json(directory / 'pypi-latest.json', package)
    identity = {'github_tag': latest['tag_name'], 'github_commit': tag['sha'],
        'docker_image': IMAGE, 'docker_latest_digest': digest, 'pypi_version': package['info']['version']}
    if args.stable_baseline:
        baseline = json.loads(args.stable_baseline.read_text())
        assert identity == baseline['identity'], 'A prerelease changed a stable pointer or stable moved concurrently'
    return {'identity': identity, 'compared_to': str(args.stable_baseline) if args.stable_baseline else None}

def artifact(args, verifier):
    assert args.artifact_metadata and args.artifact_run and args.artifact_name
    data = json.loads(args.artifact_metadata.read_text())
    assert data['name'] == args.artifact_name and not data['expired']
    assert data['workflow_run']['id'] == args.artifact_run
    expected_sha = args.publisher_commit if data['name'].startswith('pypi-') else args.commit
    assert data['workflow_run']['head_sha'] == expected_sha
    path = args.output / 'workflow-zips' / (data['name'] + '.zip')
    download(data['download_url'], path)
    assert 'sha256:' + sha(path) == data['digest'] and path.stat().st_size == data['size_in_bytes']
    directory = args.output / 'tested' / data['name']
    directory.mkdir(parents=True)
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names))
        for entry in archive.infolist():
            relative = Path(entry.filename)
            assert relative.parts and not relative.is_absolute() and '..' not in relative.parts
            target = directory / relative
            if entry.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(entry) as source, target.open('wb') as output:
                    shutil.copyfileobj(source, output)
    clean = {k: v for k, v in data.items() if k != 'download_url'}
    save_json(directory / 'ARTIFACT_PROVENANCE.json', clean)
    return {'name': data['name'], 'zip': str(path), 'sha256': sha(path),
        'workflow_run': data['workflow_run'], 'files': names,
        'note': 'Signed download URL deliberately excluded from evidence. Delete the temporary metadata input after success.'}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=['native', 'docker', 'pypi', 'pypi-metadata', 'stable', 'artifact'])
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--version', required=True)
    parser.add_argument('--commit', required=True, help='Exact merged/released SHA, not an earlier PR head')
    parser.add_argument('--output', type=Path, required=True)
    for flag in ['release-json', 'tag-json', 'latest-json', 'stable-tag-json', 'pypi-json', 'pypi-latest-json',
                 'stable-baseline', 'workflow-zip', 'artifact-metadata', 'tested-dir', 'blocked-retrieval']:
        parser.add_argument('--' + flag, type=Path)
    parser.add_argument('--artifact-run', type=int)
    parser.add_argument('--artifact-name')
    parser.add_argument('--publisher-commit', default='6e5544cfa3eecb8329e4f4cb19d2e0ac3e99b1bf')
    args = parser.parse_args()
    assert re.fullmatch(r'v0\.5\.0-alpha\.[12]', args.version)
    assert re.fullmatch(r'[0-9a-f]{40}', args.commit)
    assert not args.artifact_name or re.fullmatch(r'[A-Za-z0-9._-]+', args.artifact_name)
    args.output.mkdir(parents=True, exist_ok=True)
    suffix = '-' + args.artifact_name if args.phase == 'artifact' and args.artifact_name else ''
    receipt = args.output / (args.phase + suffix + '-retrieval.json')
    assert not receipt.exists(), 'Refuse to overwrite retrieval evidence; use a fresh output directory after failure'
    sys.path.insert(0, str(args.source / 'tools'))
    spec = importlib.util.spec_from_file_location('offline_release_verify', Path(__file__).with_name('verify.py'))
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    report = {'phase': args.phase, 'version': args.version, 'expected_commit': args.commit,
        'started_utc': datetime.now(timezone.utc).isoformat(), 'retriever_sha256': sha(Path(__file__)),
        'offline_verifier_sha256': sha(Path(__file__).with_name('verify.py')), 'status': 'incomplete'}
    try:
        result = globals()[args.phase.replace('-', '_')](args, verifier)
        report.update(status='passed', **result)
    except Exception as error:
        report.update(status='failed', error_type=type(error).__name__,
            error=str(error), note='No metadata-only or tested-artifact substitution counts as downloaded public bytes.')
        raise
    finally:
        report['finished_utc'] = datetime.now(timezone.utc).isoformat()
        save_json(receipt, report)
    print(json.dumps({'status': report['status'], 'receipt': str(receipt)}))

if __name__ == '__main__':
    main()
