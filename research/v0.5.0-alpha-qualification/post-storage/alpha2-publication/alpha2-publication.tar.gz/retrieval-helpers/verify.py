"""Offline verification of downloaded release assets and registry evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import tarfile
import tempfile
import zipfile

TARGETS = ('linux-x86_64', 'linux-aarch64', 'macos-arm64', 'macos-x86_64')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def file_digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def checksums(text):
    rows = {}
    for line in text.splitlines():
        match = re.fullmatch(r'([0-9a-f]{64}) [ *](.+)', line)
        assert match, f'malformed checksum: {line!r}'
        checksum, name = match.groups()
        name = name.removeprefix('./')
        assert name not in rows and not Path(name).is_absolute() and '..' not in Path(name).parts
        rows[name] = checksum
    assert rows
    return rows

def native(args):
    from release_smoke import extract, verify_manifest
    directory = args.directory
    archives = {f'pystachy-{args.version}-{target}.tar.gz': target for target in TARGETS}
    aggregate = checksums((directory / 'SHA256SUMS').read_text())
    assert set(aggregate) == set(archives)
    expected = set(archives) | {name + '.sha256' for name in archives} | {
        'SHA256SUMS', 'linux-abi-linux-x86_64.json', 'linux-abi-linux-aarch64.json'}
    actual = {p.name for p in directory.iterdir() if p.is_file()}
    assert actual == expected, sorted(actual ^ expected)
    results = []
    with tempfile.TemporaryDirectory(prefix='pystachy-release-audit-') as temporary:
        for name, target in archives.items():
            path = directory / name
            assert file_digest(path) == aggregate[name]
            individual = checksums((directory / (name + '.sha256')).read_text())
            assert individual == {name: aggregate[name]}
            with tarfile.open(path) as archive:
                names = archive.getnames()
                assert len(names) == len(set(names)), name + ': duplicate members'
            payload = extract(path, Path(temporary) / target)
            manifest = verify_manifest(payload)
            assert (manifest['version'], manifest['commit'], manifest['target']) == (args.version, args.commit, target)
            row = {'archive': name, 'sha256': aggregate[name], 'target': target,
                   'files_checked': len(manifest['files_sha256'])}
            if target.startswith('linux-'):
                abi = json.loads((directory / ('linux-abi-' + target + '.json')).read_text())
                assert abi['schema_version'] == 1
                assert abi['expected_architecture'] == target.removeprefix('linux-')
                assert abi['max_glibc'] == '2.39' and not abi['violations']
                # The workflow audits the extraction parent, so paths include the
                # archive root directory rather than starting at libexec/.
                prefix = payload.name + '/'
                assert all(entry['path'].startswith(prefix) for entry in abi['binaries'])
                binaries = {entry['path'].removeprefix(prefix): entry for entry in abi['binaries']}
                assert len(binaries) == len(abi['binaries']) == abi['elf_count']
                actual_elf = set()
                for entry in payload.rglob('*'):
                    if entry.is_file():
                        with entry.open('rb') as stream:
                            if stream.read(4) == b'\x7fELF':
                                actual_elf.add(str(entry.relative_to(payload)))
                assert set(binaries) == actual_elf and actual_elf
                for rel, binary in binaries.items():
                    assert binary['sha256'] == manifest['files_sha256'][rel]
                    assert binary['architecture'] == target.removeprefix('linux-')
                row['abi_binaries_checked'] = len(binaries)
            results.append(row)
    return {'archives': results, 'assets_checked': 11,
            'limitation': 'Offline payload verification; host execution smoke and successful native Release jobs are separate required evidence.'}

def docker(args):
    from release_images import index_images, image_labels
    directory = args.directory
    index_bytes = (directory / 'index.json').read_bytes()
    assert 'sha256:' + digest(index_bytes) == args.index_digest
    index = json.loads(index_bytes)
    architectures = index_images(index)
    results = {}
    for architecture, manifest_digest in architectures.items():
        manifest_bytes = (directory / f'manifest-{architecture}.json').read_bytes()
        assert 'sha256:' + digest(manifest_bytes) == manifest_digest
        descriptor = next(entry for entry in index['manifests'] if entry['platform']['architecture'] == architecture)
        assert len(manifest_bytes) == descriptor['size']
        manifest = json.loads(manifest_bytes)
        assert manifest['schemaVersion'] == 2
        config_bytes = (directory / f'config-{architecture}.json').read_bytes()
        assert 'sha256:' + digest(config_bytes) == manifest['config']['digest']
        assert len(config_bytes) == manifest['config']['size']
        image_labels(json.loads(config_bytes), architecture, args.version, args.commit)
        results[architecture] = {'manifest_digest': manifest_digest, 'config_digest': manifest['config']['digest']}
    return {'index_digest': args.index_digest, 'platforms': results,
            'limitation': 'Public raw OCI evidence; native container execution is verified separately by matching Release jobs.'}

def pypi(args):
    from pypi_release import audit_dist, package_version
    version = package_version(args.version)
    expected = {f'pystachy-{version}.tar.gz', f'pystachy-{version}-py3-none-any.whl'}
    advertised = json.loads(args.pypi_json.read_text())
    assert advertised['info']['name'] == 'pystachy' and advertised['info']['version'] == version
    public = {entry['filename']: entry for entry in advertised['urls']}
    assert len(advertised['urls']) == len(public) == 2
    assert set(public) == expected and all(not entry['yanked'] for entry in public.values())
    audit_dist(args.directory, version)
    with zipfile.ZipFile(args.workflow_zip) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert set(names) == {'SOURCE.json', 'SHA256SUMS'} | {'dist/' + name for name in expected}
        source = json.loads(archive.read('SOURCE.json'))
        assert (source['RELEASE_VERSION'], source['SOURCE_COMMIT'], source['PACKAGE_VERSION'], source['GITHUB_SHA']) == (
            args.version, args.commit, version, args.publisher_commit)
        tested = checksums(archive.read('SHA256SUMS').decode())
        assert set(tested) == {'dist/' + name for name in expected}
        rows = []
        for name in sorted(expected):
            uploaded = archive.read('dist/' + name)
            checksum = digest(uploaded)
            assert checksum == tested['dist/' + name] == public[name]['digests']['sha256']
            downloaded = args.directory / name
            assert file_digest(downloaded) == checksum and downloaded.stat().st_size == public[name]['size']
            assert downloaded.read_bytes() == uploaded
            rows.append({'filename': name, 'sha256': checksum, 'size': len(uploaded)})
    return {'source': source, 'files': rows,
            'limitation': 'Artifact identity and metadata; clean installed pip/uv JIT/AOT smoke is separate required evidence.'}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('kind', choices=('native', 'docker', 'pypi'))
    parser.add_argument('--source', type=Path, required=True, help='Exact source checkout for reviewed verification helpers')
    parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--version', required=True)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--index-digest')
    parser.add_argument('--workflow-zip', type=Path)
    parser.add_argument('--pypi-json', type=Path)
    parser.add_argument('--publisher-commit', default='6e5544cfa3eecb8329e4f4cb19d2e0ac3e99b1bf')
    args = parser.parse_args()
    assert re.fullmatch(r'v0\.5\.0-alpha\.[12]', args.version)
    assert re.fullmatch(r'[0-9a-f]{40}', args.commit)
    assert not args.output.exists(), 'Refuse to overwrite verification evidence'
    sys.path.insert(0, str(args.source / 'tools'))
    result = {'kind': args.kind, 'version': args.version, 'commit': args.commit,
              'evidence_directory': str(args.directory), 'passed': True, **globals()[args.kind](args)}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
