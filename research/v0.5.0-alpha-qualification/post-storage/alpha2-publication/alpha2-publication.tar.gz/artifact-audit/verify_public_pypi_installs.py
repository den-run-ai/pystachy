"""Verify fresh local installs of an already hash-verified public wheel.

This does not compile or execute user programs. The publisher workflow provides
the separate JIT/AOT evidence. Native REVISION metadata is not assumed to exist
in a hosted wheel; its absence and the actual console output are recorded.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--version', required=True)
    parser.add_argument('--commit', required=True)
    args = parser.parse_args()
    assert re.fullmatch(r'v0\.5\.0-alpha\.[12]', args.version)
    assert re.fullmatch(r'[0-9a-f]{40}', args.commit)
    destination = args.evidence / 'public-pypi-installs.json'
    assert not destination.exists(), 'Refuse to overwrite an install receipt'
    verified_path = args.evidence / 'pypi-retrieval.json'
    verified = json.loads(verified_path.read_text())
    assert verified['status'] == 'passed' and verified['public_distribution_bytes_downloaded']
    assert verified['version'] == args.version and verified['expected_commit'] == args.commit
    assert verified['source']['SOURCE_COMMIT'] == args.commit
    wheels = list((args.evidence / 'pypi').glob('*.whl'))
    assert len(wheels) == 1
    wheel = wheels[0]
    entry = next(x for x in verified['files'] if x['filename'] == wheel.name)
    assert hashlib.sha256(wheel.read_bytes()).hexdigest() == entry['sha256']
    with zipfile.ZipFile(wheel) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names))
        payload = {name: archive.read(name) for name in names
                   if name.startswith('_pystachy_source/') and not name.endswith('/')}
    assert payload['_pystachy_source/VERSION'].decode().strip() == args.version
    revision_bytes = payload.get('_pystachy_source/REVISION')
    revision = revision_bytes.decode().strip() if revision_bytes is not None else 'unknown'
    assert revision == 'unknown' or revision == args.commit
    expected_console = f'pystachy {args.version} (commit {revision})'
    uv = shutil.which('uv')
    assert uv and '--no-config' in subprocess.check_output([uv, '--help'], text=True)
    result = {
        'status': 'incomplete', 'version': args.version, 'source': args.commit,
        'package_version': verified['source']['PACKAGE_VERSION'],
        'public_wheel': wheel.name, 'wheel_sha256': entry['sha256'],
        'public_retrieval_receipt_sha256': hashlib.sha256(verified_path.read_bytes()).hexdigest(),
        'verifier_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'python': sys.version.split()[0],
        'uv': subprocess.check_output([uv, '--version'], text=True).strip(),
        'wheel_contains_revision_file': revision_bytes is not None,
        'expected_hosted_console': expected_console, 'installations': [],
        'scope': 'Fresh pip/uv installs from the verified public wheel, all installed payload bytes, metadata and console version. JIT/AOT execution is separate publisher-workflow evidence.',
    }
    try:
        with tempfile.TemporaryDirectory(prefix='public-pypi-install-', dir=args.evidence) as temporary:
            work = Path(temporary)
            env = {k: v for k, v in os.environ.items()
                   if not k.startswith('PYSTACHY_') and k not in ('PYTHONPATH', 'VIRTUAL_ENV', 'CONDA_PREFIX')}
            env.update(PIP_DISABLE_PIP_VERSION_CHECK='1', PIP_CONFIG_FILE='/dev/null',
                       PIP_CACHE_DIR=str(work / 'pip-cache'), UV_CACHE_DIR=str(work / 'uv-cache'))

            def run(command):
                completed = subprocess.run([str(x) for x in command], cwd=work, env=env,
                                           capture_output=True, text=True, timeout=45)
                if completed.returncode:
                    raise RuntimeError({'command': [str(x) for x in command],
                                        'returncode': completed.returncode,
                                        'stdout': completed.stdout, 'stderr': completed.stderr})
                return completed

            for installer in ('pip', 'uv'):
                location = work / (installer + '-env')
                command = [sys.executable, '-m', 'venv']
                if installer == 'uv':
                    command.append('--without-pip')
                run(command + [location])
                python = location / 'bin/python'
                command = ([python, '-m', 'pip', '--isolated', '--disable-pip-version-check',
                            'install', '--no-index', '--no-deps', wheel] if installer == 'pip' else
                           [uv, '--no-config', '--offline', 'pip', 'install', '--python', python,
                            '--no-index', '--no-deps', wheel])
                installed = run(command)
                probe = ('import importlib.metadata as m,json; d=m.distribution("pystachy"); '
                         'print(json.dumps({"version":d.version,"location":str(d.locate_file(""))}))')
                identity = json.loads(run([python, '-I', '-c', probe]).stdout)
                package_root = Path(identity['location']).resolve()
                assert identity['version'] == result['package_version']
                assert package_root.is_relative_to(location.resolve())
                for name, data in payload.items():
                    target = package_root / name
                    assert target.resolve().is_relative_to(package_root)
                    assert target.is_file() and not target.is_symlink()
                    assert target.read_bytes() == data, name
                console = run([location / 'bin/pystachy', '--version'])
                assert console.stdout.strip() == expected_console and not console.stderr
                result['installations'].append({
                    'installer': installer, 'install_returncode': installed.returncode,
                    'install_stdout': installed.stdout, 'install_stderr': installed.stderr,
                    'installed_version': identity['version'], 'isolated_location_verified': True,
                    'installed_payload_files_byte_equal_to_public_wheel': len(payload),
                    'version_returncode': console.returncode, 'version_stdout': console.stdout,
                })
        result['status'] = 'passed'
    except BaseException as error:
        result.update(status='failed', error_type=type(error).__name__, error=str(error))
        raise
    finally:
        destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'receipt': str(destination),
                      'installers': [row['installer'] for row in result['installations']],
                      'hosted_console': expected_console}))


if __name__ == '__main__':
    main()
