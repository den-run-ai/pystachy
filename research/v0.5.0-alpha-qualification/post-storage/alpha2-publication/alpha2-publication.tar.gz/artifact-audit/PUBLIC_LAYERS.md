# Public Docker layer verification

`verify_public_layers.py` adds an independent public-blob receipt after the existing
`retrieve.py docker` phase succeeds. It does not change the earlier receipt. No
actual alpha layer has been requested or verified during helper preparation.

## Inputs and command

Pass the successful `docker-retrieval.json` from the published version. Its sibling
`docker/` directory must contain the saved raw `index.json`, `manifest-amd64.json`,
`manifest-arm64.json`, `config-amd64.json`, and `config-arm64.json`.

Use the exact published version and merged source commit. The following is a
command template; replace the retrieval path and commit with the actual published
evidence. Use a new output directory for this single attempt.

```bash
python3 /workspace/scratch/7dd0519bc14a/artifact-audit/verify_public_layers.py \
  --source /workspace/scratch/7dd0519bc14a/alpha1 \
  --retrieval /absolute/path/to/docker-retrieval.json \
  --version v0.5.0-alpha.1 \
  --commit EXACT_PUBLISHED_40_CHARACTER_COMMIT \
  --output /workspace/scratch/7dd0519bc14a/alpha1-public-layer-attempt
```

For alpha.2, change the source checkout, version, exact merged commit, retrieval
receipt and output directory to the corresponding alpha.2 evidence.

## Behavior

- Requires the prior Docker metadata receipt to be successful and to identify the
  supplied version/commit; rechecks the index digest, both manifest and config
  digests and sizes, the two supported platforms, and the image release labels.
- Checks that each manifest layer corresponds, in order, to a config rootfs
  `diff_id`, and rejects inconsistent duplicate blob descriptors.
- Uses the existing `/workspace/scratch/c66a10c5a7b1/artifact-audit/retrieve.py`
  public `Registry` and `download` helpers. Only the registry's blob endpoint is
  requested; layer descriptor URLs are not used as alternate sources.
- Downloads each distinct compressed blob once, sequentially, into a fresh
  temporary file. The existing downloader streams to disk. Hashing and gzip
  decoding use bounded reads; at most one blob is retained on disk at a time.
- Checks the compressed SHA-256 and exact byte count, then the raw or gzip-decoded
  SHA-256 against the corresponding config `diff_id`. Gzip is read through EOF so
  its CRC/trailer is checked. Other encodings, including zstd, fail closed.
- Removes temporary blobs after verification. The receipt retains the exact
  inputs, compressed and decoded hashes and byte counts for each unique blob,
  plus each architecture's ordered layer references.

## Results and limits

Exit 0 plus `status: passed` and `public_layers_downloaded: true` in
`OUTPUT/docker-public-layers.json` means every public layer was downloaded and
validated in this attempt. Exit 1 or 130 is a failed/interrupted attempt. A failed
receipt retains the active step/layer and any earlier verified layers, while the
overall `public_layers_downloaded` flag remains false.

HTTP/network/proxy failures are retained with a sanitized error class and HTTP
status where available. Request headers, tokens, signed redirect URLs and raw
network exception messages are not recorded. There are no automatic retries,
permission changes, alternate-host fallbacks or monitoring. The helper refuses
to overwrite an existing attempt directory.

This checks public availability and byte identity. It does not start a container;
the matching Release jobs' JIT/AOT, unprivileged-user and bind-mount evidence is
still required separately.

## Preparation checks

`offline-layer-checks.json` records seven tiny synthetic cases: gzip/raw success
and deduplication, compressed digest mismatch, compressed size mismatch, decoded
digest mismatch, bad gzip trailer, unsupported compression, and an HTTP 403 whose
mock signed URL and token must not appear in output. All expected outcomes were
observed. These tests made zero public network requests and are not alpha artifact
qualification.
