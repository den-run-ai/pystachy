#!/usr/bin/env python3
"""One-shot public Docker layer verification, additive to retrieve.py's receipt.

Uses the existing public Registry/download helpers. No publishing, polling,
retry, alternate blob host, archive extraction, or container execution occurs.
Each distinct compressed blob is downloaded once, streamed through both hashes,
then removed. A fresh output directory preserves an immutable attempt receipt.
"""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import tempfile
import urllib.error


RETRIEVER = Path('/workspace/scratch/c66a10c5a7b1/artifact-audit/retrieve.py')
ENCODINGS = {
    'application/vnd.oci.image.layer.v1.tar': 'identity',
    'application/vnd.oci.image.layer.v1.tar+gzip': 'gzip',
    'application/vnd.oci.image.layer.nondistributable.v1.tar': 'identity',
    'application/vnd.oci.image.layer.nondistributable.v1.tar+gzip': 'gzip',
    'application/vnd.docker.image.rootfs.diff.tar': 'identity',
    'application/vnd.docker.image.rootfs.diff.tar.gzip': 'gzip',
    'application/vnd.docker.image.rootfs.foreign.diff.tar.gzip': 'gzip',
}
MANIFEST_TYPES = {
    'application/vnd.oci.image.manifest.v1+json',
    'application/vnd.docker.distribution.manifest.v2+json',
}
CHUNK = 1024 * 1024


class InvalidEvidence(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise InvalidEvidence(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def stream_hash(stream):
    digest, size = hashlib.sha256(), 0
    while block := stream.read(CHUNK):
        digest.update(block)
        size += len(block)
    return 'sha256:' + digest.hexdigest(), size


def valid_digest(value):
    return isinstance(value, str) and re.fullmatch(r'sha256:[0-9a-f]{64}', value) is not None


def descriptor(value, context):
    require(isinstance(value, dict), context + ': missing descriptor')
    require(valid_digest(value.get('digest')), context + ': invalid SHA-256 digest')
    require(type(value.get('size')) is int and value['size'] >= 0, context + ': invalid size')
    return value


def read_json(path, report, expected=None):
    raw = path.read_bytes()
    actual = 'sha256:' + hashlib.sha256(raw).hexdigest()
    report['inputs'][str(path)] = {'sha256': actual, 'size': len(raw)}
    if expected:
        require(actual == expected['digest'], path.name + ': digest mismatch')
        require(len(raw) == expected['size'], path.name + ': size mismatch')
    return json.loads(raw)


def metadata(args, report, images):
    prior = read_json(args.retrieval, report)
    require(prior.get('phase') == 'docker' and prior.get('status') == 'passed',
            'Require the successful public Docker metadata retrieval receipt')
    require(prior.get('version') == args.version and prior.get('expected_commit') == args.commit,
            'Prior retrieval identifies a different release')
    require(valid_digest(prior.get('index_digest')), 'Prior retrieval has no valid index digest')
    directory = args.retrieval.parent / 'docker'
    index_path = directory / 'index.json'
    index = read_json(index_path, report)
    require(report['inputs'][str(index_path)]['sha256'] == prior['index_digest'],
            'Saved index differs from the public retrieval receipt')
    try:
        platforms = images.index_images(index)
    except RuntimeError:
        raise InvalidEvidence('Saved index does not identify exactly linux/amd64 and linux/arm64') from None
    report['index_digest'] = prior['index_digest']
    rows = []
    for arch, digest in sorted(platforms.items()):
        entry = descriptor(next(x for x in index['manifests']
                                if x['platform']['architecture'] == arch), arch + ' manifest')
        manifest = read_json(directory / f'manifest-{arch}.json', report, entry)
        require(manifest.get('schemaVersion') == 2 and manifest.get('mediaType') in MANIFEST_TYPES,
                arch + ': unsupported image manifest')
        config_desc = descriptor(manifest.get('config'), arch + ' config')
        config = read_json(directory / f'config-{arch}.json', report, config_desc)
        try:
            images.image_labels(config, arch, args.version, args.commit)
        except RuntimeError:
            raise InvalidEvidence(arch + ': platform or release labels mismatch') from None
        rootfs = config.get('rootfs', {})
        layers, diff_ids = manifest.get('layers'), rootfs.get('diff_ids')
        require(rootfs.get('type') == 'layers' and isinstance(layers, list) and layers
                and isinstance(diff_ids, list) and len(layers) == len(diff_ids),
                arch + ': missing layers or inconsistent rootfs inventory')
        for position, (layer, diff_id) in enumerate(zip(layers, diff_ids, strict=True)):
            context = f'{arch} layer {position}'
            descriptor(layer, context)
            require(valid_digest(diff_id), context + ': invalid rootfs diff_id')
            media = layer.get('mediaType')
            require(media in ENCODINGS, context + ': unsupported layer compression/media type')
            rows.append({'architecture': arch, 'position': position, 'digest': layer['digest'],
                         'compressed_size': layer['size'], 'media_type': media,
                         'encoding': ENCODINGS[media], 'expected_diff_id': diff_id})
        report['platforms'][arch] = {'manifest_digest': digest, 'config_digest': config_desc['digest'],
                                     'layer_count': len(layers), 'diff_ids': diff_ids}
    # One digest must have one size, encoding and unpacked identity across references.
    identities = {}
    for row in rows:
        identity = (row['compressed_size'], row['encoding'], row['expected_diff_id'])
        require(row['digest'] not in identities or identities[row['digest']] == identity,
                'Conflicting descriptors or diff_ids for the same compressed blob')
        identities[row['digest']] = identity
    report.update(layer_references=len(rows), unique_layers=len(identities),
                  expected_download_bytes=sum(x[0] for x in identities.values()))
    return rows


def verify_layer(path, row):
    with path.open('rb') as stream:
        digest, size = stream_hash(stream)
    require(digest == row['digest'], 'Downloaded layer compressed SHA-256 mismatch')
    require(size == row['compressed_size'], 'Downloaded layer compressed size mismatch')
    if row['encoding'] == 'gzip':
        # Reading to EOF also verifies the gzip CRC/trailer, including concatenated members.
        with gzip.open(path, 'rb') as stream:
            diff_id, unpacked_size = stream_hash(stream)
    elif row['encoding'] == 'identity':
        diff_id, unpacked_size = digest, size
    else:
        raise InvalidEvidence('Unsupported layer compression')
    require(diff_id == row['expected_diff_id'], 'Downloaded layer decompressed diff_id mismatch')
    return {'digest': digest, 'compressed_size': size, 'encoding': row['encoding'],
            'diff_id': diff_id, 'uncompressed_size': unpacked_size,
            'downloaded_from_public_registry': True}


def safe_error(error):
    # Never serialize request objects, Authorization headers, redirect URLs or raw
    # network exception messages; they can contain bearer tokens or signed URLs.
    result = {'error_type': type(error).__name__}
    if isinstance(error, InvalidEvidence):
        result['error'] = str(error)
    elif isinstance(error, urllib.error.HTTPError):
        result.update(error='Public registry request failed or was denied', http_status=error.code)
    elif isinstance(error, urllib.error.URLError):
        result['error'] = 'Public registry network/proxy request failed'
    elif isinstance(error, KeyboardInterrupt):
        result['error'] = 'Verification interrupted'
    else:
        result['error'] = 'Verification failed at the recorded step; exception details omitted'
    return result


def run(args):
    args.output.mkdir(parents=True, exist_ok=False)
    receipt = args.output / 'docker-public-layers.json'
    report = {'phase': 'docker-public-layers', 'status': 'incomplete', 'version': args.version,
              'expected_commit': args.commit, 'image': 'dta67/pystachy', 'started_utc': now(),
              'metadata_retrieval': str(args.retrieval), 'inputs': {}, 'platforms': {},
              'layers': [], 'verified_blobs': {}, 'public_layers_downloaded': False,
              'local_container_execution': False, 'current_step': 'load-helpers',
              'limitation': 'Byte identity and public availability only; container execution requires separate release-job evidence.'}
    def save():
        receipt.write_text(json.dumps(report, indent=2) + '\n')
    save()
    try:
        for path in (Path(__file__).resolve(), RETRIEVER, args.source / 'tools/release_images.py'):
            with path.open('rb') as stream:
                digest, size = stream_hash(stream)
            report['inputs'][str(path)] = {'sha256': digest, 'size': size}
        retrieve = load_module('public_layer_retriever', RETRIEVER)
        images = load_module('public_layer_images', args.source / 'tools/release_images.py')
        require(retrieve.IMAGE == report['image'], 'Retriever targets a different public image')
        report['current_step'] = 'validate-saved-metadata'
        rows = metadata(args, report, images)
        report['current_step'] = 'public-registry-token'
        save()
        registry = retrieve.Registry()
        for row in rows:
            report['current_layer'] = row
            digest = row['digest']
            if digest not in report['verified_blobs']:
                report['current_step'] = 'download-public-blob'
                save()
                with tempfile.TemporaryDirectory(prefix='layer-', dir=args.output) as temporary:
                    path = Path(temporary) / digest.removeprefix('sha256:')
                    # Only the registry's standard blob endpoint; descriptor URLs are unused.
                    retrieve.download(registry.base + '/blobs/' + digest, path, registry.headers)
                    report['current_step'] = 'verify-compressed-and-unpacked-bytes'
                    report['verified_blobs'][digest] = verify_layer(path, row)
            require(report['verified_blobs'][digest]['diff_id'] == row['expected_diff_id'],
                    'Shared layer disagrees with the architecture rootfs')
            report['layers'].append({**row, 'status': 'passed'})
            save()
        require(len(report['layers']) == report['layer_references']
                and len(report['verified_blobs']) == report['unique_layers'], 'Incomplete layer verification')
        report.update(status='passed', public_layers_downloaded=True, current_step='complete')
        report.pop('current_layer', None)
        code = 0
    except (Exception, KeyboardInterrupt) as error:
        report.update(status='failed', **safe_error(error))
        code = 130 if isinstance(error, KeyboardInterrupt) else 1
    finally:
        report['finished_utc'] = now()
        save()
    print(json.dumps({'status': report['status'], 'receipt': str(receipt),
                      'verified_unique_layers': len(report['verified_blobs']),
                      'public_layers_downloaded': report['public_layers_downloaded']}))
    return code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True, help='Checkout containing reviewed tools/release_images.py')
    parser.add_argument('--retrieval', type=Path, required=True, help='Successful docker-retrieval.json beside saved docker/ metadata')
    parser.add_argument('--version', required=True)
    parser.add_argument('--commit', required=True, help='Exact published merged commit')
    parser.add_argument('--output', type=Path, required=True, help='New attempt directory; existing directories are refused')
    args = parser.parse_args()
    if not re.fullmatch(r'v0\.5\.0-alpha\.[12]', args.version) or not re.fullmatch(r'[0-9a-f]{40}', args.commit):
        parser.error('Require alpha.1/alpha.2 and a complete 40-character source commit')
    return run(args)


if __name__ == '__main__':
    raise SystemExit(main())
