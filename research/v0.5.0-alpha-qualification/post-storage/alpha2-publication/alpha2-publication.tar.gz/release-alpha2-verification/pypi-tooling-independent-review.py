"""Inspect immutable publisher/tag source and retained evidence; execute no release code."""

from datetime import datetime, timezone
from email.parser import BytesParser
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
import tomllib
import zipfile

BASE = Path('/workspace/scratch/7dd0519bc14a')
REPO = BASE / 'alpha2'
OUT = BASE / 'release-alpha2-verification'
OLD = BASE / 'release-alpha1-verification'
PUBLISHER = '6e5544cfa3eecb8329e4f4cb19d2e0ac3e99b1bf'
ALPHA1 = 'a73c56c92f3aad4b490307a5d1b882e487a57f55'
ALPHA2 = '80490143498d149d407343ba1cb7aedb1db2d2c5'
REVISIONS = {'publisher': PUBLISHER, 'alpha1': ALPHA1, 'alpha2': ALPHA2}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def git(*args):
    return subprocess.run(['git', '-C', str(REPO), *args], check=True,
                          stdout=subprocess.PIPE).stdout


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_identity(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(BASE)), 'sha256': digest(data), 'bytes': len(data)}


def job_blocks(data):
    header, jobs = data.split(b'\njobs:\n', 1)
    matches = list(re.finditer(rb'^  ([A-Za-z0-9_-]+):\n', jobs, re.MULTILINE))
    blocks = {m[1].decode(): jobs[m.start():matches[i + 1].start() if i + 1 < len(matches) else len(jobs)]
              for i, m in enumerate(matches)}
    return header, blocks


paths = ['.github/workflows/release.yml', 'tools/pypi_release.py',
         'tools/release_gate.py', 'pyproject.toml']
source = {label: {path: git('show', f'{commit}:{path}') for path in paths}
          for label, commit in REVISIONS.items()}
files = {}
for path in paths:
    require(source['alpha1'][path] == source['alpha2'][path], f'Alpha source differs: {path}')
    files[path] = {'sha256': {label: digest(source[label][path]) for label in REVISIONS},
                   'alpha1_equals_alpha2': True,
                   'publisher_equals_alpha2': source['publisher'][path] == source['alpha2'][path]}
for path in ('tools/pypi_release.py', 'tools/release_gate.py'):
    require(files[path]['publisher_equals_alpha2'], f'Gate helper changed: {path}')

workflow_parts = {label: job_blocks(source[label]['.github/workflows/release.yml'])
                  for label in REVISIONS}
require(all(workflow_parts[label][0] == workflow_parts['publisher'][0] for label in REVISIONS),
        'Workflow header changed')
require(all(set(workflow_parts[label][1]) == set(workflow_parts['publisher'][1]) for label in REVISIONS),
        'Workflow job inventory changed')
jobs = {}
for name in ('pypi-build', 'pypi-publish'):
    blocks = {label: workflow_parts[label][1][name] for label in REVISIONS}
    require(len(set(blocks.values())) == 1, f'PyPI job changed: {name}')
    jobs[name] = {'byte_identical_across_all_three': True,
                  'sha256': digest(blocks['publisher']), 'bytes': len(blocks['publisher'])}
changed_native_jobs = sorted(name for name, value in workflow_parts['publisher'][1].items()
                             if value != workflow_parts['alpha2'][1][name])
require(changed_native_jobs == ['prepare', 'publish'], 'Unexpected native job difference')
workflow = source['publisher']['.github/workflows/release.yml'].decode()
require("    if: inputs.pypi != 'verify' && inputs.pypi != 'publish'" in workflow_parts['publisher'][1]['prepare'].decode(),
        'Native preparation not excluded')
require(b'    needs: prepare\n' in workflow_parts['publisher'][1]['binaries'], 'Unexpected binary dependency')
require(b'    needs: [prepare, binaries]\n' in workflow_parts['publisher'][1]['container'], 'Unexpected container dependency')
require(b'    needs: [prepare, binaries, container]\n' in workflow_parts['publisher'][1]['publish'],
        'Unexpected native publication dependency')

project = {label: tomllib.loads(source[label]['pyproject.toml'].decode()) for label in REVISIONS}
require(project['alpha2']['tool']['setuptools']['dynamic']['version'] == {'file': 'VERSION'},
        'Version source changed')
require(project['alpha2']['project']['name'] == 'pystachy', 'Package name changed')
base_data = project['publisher']['tool']['setuptools']['package-data']['_pystachy_source']
tag_data = project['alpha2']['tool']['setuptools']['package-data']['_pystachy_source']
require([v for v in tag_data if v != 'lljit.c'] == base_data and tag_data.count('lljit.c') == 1,
        'Unexpected package-data difference')
require(source['publisher']['pyproject.toml'].replace(b'"pyembed.c",', b'"pyembed.c", "lljit.c",')
        == source['alpha2']['pyproject.toml'], 'Additional pyproject change')

ref_path = OUT / 'pypi-publisher-ref-independent.json'
ref = json.loads(ref_path.read_text())['response']
require(ref['ref'] == 'refs/heads/release/pypi-v0.2.0'
        and ref['object'] == {'sha': PUBLISHER, 'type': 'commit',
                            'url': f'https://api.github.com/repos/den-run-ai/pystachy/git/commits/{PUBLISHER}'},
        'Publisher ref changed')

run_path = OLD / 'pypi-workflow-complete.json'
run = json.loads(run_path.read_text())
require(run['run']['id'] == 43621120891 and run['run']['head_sha'] == PUBLISHER
        and run['run']['head_branch'] == 'release/pypi-v0.2.0'
        and run['run']['status'] == 'completed' and run['run']['conclusion'] == 'success',
        'Alpha1 publication precedent changed')
require(run['outcomes'] == {'success': 2, 'skipped': 4}, 'Unexpected alpha1 job outcome')
source_path = OLD / 'tested/pypi-0.5.0a1/SOURCE.json'
provenance = json.loads(source_path.read_text())
require(provenance == {'RELEASE_VERSION': 'v0.5.0-alpha.1', 'SOURCE_COMMIT': ALPHA1,
                       'PACKAGE_VERSION': '0.5.0a1', 'GITHUB_SHA': PUBLISHER}, 'Alpha1 provenance mismatch')
audit_path = OLD / 'independent-audits/pypi-final.json'
audit = json.loads(audit_path.read_text())
require(audit['status'] == 'passed_pypi' and audit['commit'] == ALPHA1
        and audit['publisher_commit'] == PUBLISHER and audit['run_id'] == 43621120891,
        'Alpha1 independent acceptance mismatch')

wheel_path = OLD / 'tested/pypi-0.5.0a1/dist/pystachy-0.5.0a1-py3-none-any.whl'
sdist_path = OLD / 'tested/pypi-0.5.0a1/dist/pystachy-0.5.0a1.tar.gz'
with zipfile.ZipFile(wheel_path) as z:
    wheel_lljit = z.read('_pystachy_source/lljit.c')
    require(wheel_lljit == git('show', f'{ALPHA1}:lljit.c'), 'Alpha1 wheel lljit mismatch')
    require(z.read('_pystachy_source/VERSION') == git('show', f'{ALPHA1}:VERSION'),
            'Alpha1 wheel version mismatch')
    metadata = BytesParser().parsebytes(z.read('pystachy-0.5.0a1.dist-info/METADATA'))
    require(metadata.get_all('Name') == ['pystachy'] and metadata.get_all('Version') == ['0.5.0a1'],
            'Alpha1 wheel metadata mismatch')
with tarfile.open(sdist_path, 'r:gz') as t:
    require(t.extractfile('pystachy-0.5.0a1/pyproject.toml').read() == source['alpha1']['pyproject.toml'],
            'Alpha1 sdist does not carry tag pyproject')
    require(t.extractfile('pystachy-0.5.0a1/lljit.c').read() == wheel_lljit, 'Alpha1 sdist lljit mismatch')
    metadata = BytesParser().parsebytes(t.extractfile('pystachy-0.5.0a1/PKG-INFO').read())
    require(metadata.get_all('Name') == ['pystachy'] and metadata.get_all('Version') == ['0.5.0a1'],
            'Alpha1 source distribution metadata mismatch')

diff_path = OUT / 'pypi-tooling-independent-source.diff'
diff_path.write_bytes(git('diff', PUBLISHER, ALPHA2, '--', *paths))
report = {
    'kind': 'Independent scoped PyPI publisher tooling equivalence preflight',
    'status': 'passed_static_scope',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'revisions': REVISIONS,
    'publisher_branch': 'release/pypi-v0.2.0',
    'files': files,
    'workflow_header_byte_identical': True,
    'workflow_header_sha256': digest(workflow_parts['publisher'][0]),
    'pypi_jobs': jobs,
    'changed_native_jobs_only': changed_native_jobs,
    'whole_workflow_equal': False,
    'explained_native_differences': [
        'prepare adds a release-notes check against docs/writing.md',
        'publish replaces native release-notes shell rendering with tools/release_notes.py render'],
    'native_path_excluded_in_pypi_mode': True,
    'package_source_binding': {
        'workflow_tools': 'First checkout: approved publisher revision',
        'package_source': 'Second checkout: refs/tags/${{ inputs.version }} at source, fetch-depth 0',
        'metadata_and_build': 'uv build runs with working-directory source; pyproject.toml, VERSION, setuptools configuration and packaged sources come from the tag checkout',
        'version': 'Tag pyproject uses dynamic version from tag VERSION; gate requires VERSION to equal the requested release tag',
        'packaging_requirements': 'source/tools/requirements-packaging.txt plus twine==7.0.0',
        'python': 'source/.python-version',
        'installed_package_smoke': 'source/tools/compiler_install_smoke.py',
        'gate': 'tools/pypi_release.py with --source source; unchanged helper requires clean full tag checkout, origin/main ancestry, published non-draft GitHub release, exact tag/commit and successful exact-main workflows',
        'distribution_gate': 'Exactly one versioned sdist and universal wheel; safe unique paths and Name/Version metadata checked; twine strict and pip/uv JIT/AOT smoke precede upload',
        'publication': 'pypi-publish downloads the same run artifact and verifies SHA256SUMS before Trusted Publishing',
        'pyproject_difference': 'Publisher omits lljit.c; both alpha tag pyprojects include it. The publisher pyproject is outside the build working directory and is not the project built.'},
    'unchanged_execution_policy': {
        'workflow_permissions': {'contents': 'read'},
        'pypi_build_permissions': {'contents': 'read', 'actions': 'read'},
        'pypi_publish_permissions': {'id-token': 'write'},
        'environment': 'pypi',
        'build_timeout_minutes': 15,
        'publish_timeout_minutes': 10,
        'checkout_persist_credentials': False,
        'permission_branch_or_environment_changes_required': False,
        'scope': 'All declarations byte-identical; current publisher ref equals approved revision. No administrative settings were queried or modified.'},
    'alpha1_precedent': {
        'run_id': 43621120891, 'publisher_commit': PUBLISHER, 'tag_source_commit': ALPHA1,
        'run_completed_successfully': True, 'successful_jobs': 2, 'expected_native_skips': 4,
        'retained_source_json_exact': True,
        'retained_sdist_pyproject_equals_alpha1_tag_and_alpha2_source': True,
        'retained_wheel_and_sdist_lljit_equals_alpha1_git_blob': True,
        'retained_sdist_and_wheel_metadata_version': '0.5.0a1',
        'public_distribution_equality': 'Established by retained independent alpha1 audit; this static review directly rechecks retained tested package metadata and selected source bindings only'},
    'inputs': [file_identity(p) for p in (Path(__file__), ref_path, run_path, source_path,
              audit_path, wheel_path, sdist_path, diff_path,
              OUT / 'pypi-tooling-initial-diagnostic.json', OUT / 'pypi-tooling-preflight.json')],
    'scope_and_prerequisite': 'Source inspection, hashes and retained-evidence reading only. No release dispatch, package build/install/test, compiler execution, workflow edits or permission/environment changes. This receipt does not establish alpha2 native publication or authorize bypassing it. Alpha2 PyPI dispatch must wait for the native release to be published and its artifacts independently verified.'}
output = OUT / 'pypi-tooling-independent-review.json'
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'report': file_identity(output),
                  'pypi_jobs': jobs, 'changed_native_jobs_only': changed_native_jobs}, indent=2))
