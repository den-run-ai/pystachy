"""Evidence-only audit of handed-off completed binary jobs; never polls or executes payloads."""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import struct
import subprocess
import tarfile
import zipfile

EVIDENCE = Path("/workspace/scratch/7dd0519bc14a/release-alpha2-verification")
REPO = Path("/workspace/scratch/7dd0519bc14a/alpha2")
VERSION = "v0.5.0-alpha.2"
COMMIT = "80490143498d149d407343ba1cb7aedb1db2d2c5"
EXPECTED_COMPILER_LINES = 932028
EXPECTED_RUNTIME_LINES = 21214


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def native_target(data):
    header = data[:32]
    if header[:7] == b'\x7fELF\x02\x01\x01':
        kind, machine = struct.unpack('<HH', header[16:20])
        require(kind in (2, 3), 'Unsupported ELF type')
        return {62: 'linux-x86_64', 183: 'linux-aarch64'}.get(machine)
    endian = {b'\xcf\xfa\xed\xfe': '<', b'\xfe\xed\xfa\xcf': '>'}.get(header[:4])
    require(endian is not None, 'Unsupported native format')
    cpu, _, kind = struct.unpack(endian + 'III', header[4:16])
    require(kind == 2, 'Mach-O is not executable')
    return {0x01000007: 'macos-x86_64', 0x0100000C: 'macos-arm64'}.get(cpu)


def audit(args, target):
    artifact_name = 'binary-' + target
    base = args.evidence
    paths = {
        'log': base / 'workflow-logs' / (artifact_name + '.log'),
        'job': base / 'workflow-logs' / (artifact_name + '.job.json'),
        'retrieval': base / ('artifact-' + artifact_name + '-retrieval.json'),
    }
    raw = {key: path.read_bytes() for key, path in paths.items()}
    inputs = {key: {'path': str(paths[key]), 'sha256': digest(data), 'bytes': len(data)} for key, data in raw.items()}
    job_wrapper, retrieval = (json.loads(raw[key]) for key in ('job', 'retrieval'))
    job = job_wrapper['job']
    require(job_wrapper['source'] == args.commit == job['head_sha'], 'Wrong source commit')
    require(job_wrapper['run_id'] == args.run_id == job['run_id'], 'Wrong workflow run')
    require(job['name'] == f'Binary ({target})' and job['workflow_name'] == 'Release', 'Wrong component')
    require(job['head_branch'] == 'main' and job['status'] == 'completed' and job['conclusion'] == 'success', 'Job is not completed successfully on main')
    platforms = {'linux-x86_64': 'ubuntu-24.04', 'linux-aarch64': 'ubuntu-24.04-arm', 'macos-arm64': 'macos-15', 'macos-x86_64': 'macos-15-intel'}
    require(job['labels'] == [platforms[target]], 'Wrong native runner')
    duration = (datetime.fromisoformat(job['completed_at']) - datetime.fromisoformat(job['started_at'])).total_seconds()
    require(0 < duration <= 900, 'Job exceeded the 15-minute cap')
    steps = {step['name']: step for step in job['steps']}
    is_linux = target.startswith('linux-')
    for name, step in steps.items():
        expected = 'success'
        if name == ('LLVM 20 (macOS)' if is_linux else 'LLVM 18 (Linux)') or (not is_linux and name == 'Audit the complete Linux archive payload'):
            expected = 'skipped'
        require(step['status'] == 'completed' and step['conclusion'] == expected, 'Unexpected step state: ' + name)
    phase = steps['Bootstrap, package, and test relocation without Python']
    rows = []
    for number, raw_line in enumerate(raw['log'].decode('utf-8-sig').splitlines(), 1):
        if 'Z ' in raw_line:
            stamp, body = raw_line.split('Z ', 1)
            stamp += 'Z'
        else:
            require(rows, 'Untimestamped log starts before any timestamp')
            stamp, body = rows[-1]['timestamp'], raw_line
        body = re.sub(r'\x1b\[[0-9;]*m', '', body)
        rows.append({'line': number, 'timestamp': stamp, 'text': body})
    require(not any(row['text'].startswith('##[error]') for row in rows), 'Log contains an Actions error')
    execution = [row for row in rows if phase['started_at'] <= row['timestamp'] <= phase['completed_at'][:-1] + '.9999999Z']
    markers = {}

    def evidence(name, pattern, subset=execution):
        found = [row for row in subset if re.fullmatch(pattern, row['text'])]
        require(len(found) == 1, 'Missing or duplicate executed result: ' + name)
        markers[name] = found[0]
        return re.fullmatch(pattern, found[0]['text'])

    compiler_lines = int(evidence('compiler_fixed_point', r'fixed point: stage1 == stage2 == stage3 \(\s*(\d+) lines of IR\)').group(1))
    runtime_lines = int(evidence('runtime_fixed_point', r"fixed point: runtime\.py's IR, rt1 == rt2 == rt3 \(\s*(\d+) lines\)").group(1))
    require(compiler_lines == EXPECTED_COMPILER_LINES and runtime_lines == EXPECTED_RUNTIME_LINES, 'Unexpected alpha2 compiler/runtime fixed-point line counts')
    exact_version = f'pystachy {args.version} (commit {args.commit}): native and installed --version, without LLVM or Python'
    evidence('exact_native_and_installed_version', re.escape(exact_version))
    for key, text in {
        'jit_aot': 'relocated release JIT/AOT: CPython output matches',
        'gc_stress': 'relocated release JIT/AOT with GC stress: CPython output matches',
        'warm_runtime': 'relocated release warm JIT: CPython output matches, cached runtime reused',
        'relocation': f'release {args.version} {target}: Python-free PATH, read-only resources, external cache',
    }.items():
        evidence(key, re.escape(text))
    if is_linux:
        evidence('default_program_cache', re.escape('relocated release default cache: fill and hit match CPython; hit skips the frontend'))
    test_runs = [row for row in execution if re.fullmatch(r'Ran \d+ tests in [0-9.]+s', row['text'])]
    test_results = [row for row in execution if re.fullmatch(r'OK(?: \(skipped=\d+\))?', row['text'])]
    require(len(test_runs) == len(test_results) == 2, 'Expected release and installer unit-test runs')
    require(test_results[1]['text'] == 'OK', 'Installer unit tests are not fully successful')
    if is_linux:
        require(test_results[0]['text'] == 'OK', 'Linux release unit tests skipped unexpectedly')
    else:
        require(test_results[0]['text'] == 'OK (skipped=1)', 'Unexpected macOS release-unit skip count')
    require(retrieval['phase'] == 'artifact' and retrieval['status'] == 'passed', 'Artifact retrieval failed')
    require(retrieval['name'] == artifact_name and retrieval['version'] == args.version and retrieval['expected_commit'] == args.commit, 'Artifact retrieval identity differs')
    require(retrieval['workflow_run']['id'] == args.run_id and retrieval['workflow_run']['head_sha'] == args.commit, 'Artifact belongs to another workflow/source')
    zip_path = Path(retrieval['zip'])
    zip_bytes = zip_path.read_bytes()
    zip_sha = digest(zip_bytes)
    require(zip_sha == retrieval['sha256'], 'Retrieved ZIP digest mismatch')
    evidence('upload_digest', re.escape('SHA256 digest of uploaded artifact is ' + zip_sha), rows)
    artifact_id = int(evidence('upload_finalized', re.escape('Artifact ' + artifact_name + ' successfully finalized. Artifact ID ') + r'(\d+)', rows).group(1))
    inputs['artifact_zip'] = {'path': str(zip_path), 'sha256': zip_sha, 'bytes': len(zip_bytes)}
    archive_name = f'pystachy-{args.version}-{target}.tar.gz'
    expected_files = {archive_name, archive_name + '.sha256'}
    if is_linux:
        expected_files.add('linux-abi-' + target + '.json')
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as archive:
        require(len(archive.namelist()) == len(expected_files) and set(archive.namelist()) == expected_files == set(retrieval['files']), 'Wrong ZIP inventory')
        packed = {name: archive.read(name) for name in archive.namelist()}
    for name, data in packed.items():
        path = base / 'tested' / artifact_name / name
        require(path.read_bytes() == data, 'Extracted artifact differs from ZIP: ' + name)
        inputs[name] = {'path': str(path), 'sha256': digest(data), 'bytes': len(data)}
    archive_sha = digest(packed[archive_name])
    require(packed[archive_name + '.sha256'].decode() == f'{archive_sha}  {archive_name}\n', 'Native archive checksum differs')
    basename = archive_name[:-7]
    payload = {}
    with tarfile.open(fileobj=io.BytesIO(packed[archive_name]), mode='r:gz') as archive:
        seen = set()
        for member in archive.getmembers():
            path = PurePosixPath(member.name)
            require(member.name not in seen and not path.is_absolute() and '..' not in path.parts and path.parts[0] == basename, 'Unsafe or duplicate tar path')
            seen.add(member.name)
            require(member.isfile() or member.isdir(), 'Unsupported tar member type')
            if member.isfile():
                payload['/'.join(path.parts[1:])] = archive.extractfile(member).read()
    manifest = json.loads(payload.pop('manifest.json'))
    require(manifest['schema_version'] == 1 and manifest['version'] == args.version and manifest['commit'] == args.commit and manifest['target'] == target, 'Manifest release identity differs')
    require({name: digest(data) for name, data in payload.items()} == manifest['files_sha256'], 'Manifest payload hashes differ')
    require(payload['libexec/pystachy/VERSION'].decode().strip() == args.version and payload['libexec/pystachy/REVISION'].decode().strip() == args.commit, 'Packaged version/revision differs')
    native = payload['libexec/pystachy/pystachy']
    require(native_target(native) == target, 'Native executable architecture differs')
    abi = None
    if is_linux:
        abi = json.loads(packed['linux-abi-' + target + '.json'])
        require(abi['schema_version'] == 1 and abi['expected_architecture'] == target[6:] and abi['max_glibc'] == '2.39' and abi['violations'] == [], 'Linux ABI report failed')
        elf_payload = {basename + '/' + name: data for name, data in payload.items() if data.startswith(b'\x7fELF')}
        require(abi['elf_count'] == len(abi['binaries']) == len(elf_payload) and {row['path'] for row in abi['binaries']} == set(elf_payload), 'ABI inventory omitted ELF payload')
        for row in abi['binaries']:
            require(row['architecture'] == target[6:] and row['sha256'] == digest(elf_payload[row['path']]), 'ABI binary identity differs')
            require(not row['non_numeric_glibc'] and (row['glibc_symbol_floor'] is None or tuple(map(int, row['glibc_symbol_floor'].split('.'))) <= (2, 39)), 'Unsupported glibc requirements')
        text = '\n'.join(row['text'] for row in rows)
        decoder = json.JSONDecoder()
        printed = []
        for match in re.finditer(r'^\{$', text, re.MULTILINE):
            try:
                value, _ = decoder.raw_decode(text[match.start():])
                if isinstance(value, dict) and 'elf_count' in value:
                    printed.append(value)
            except ValueError:
                pass
        require(printed == [abi], 'Saved ABI report differs from executed log output')
    source_files = ['.github/workflows/release.yml', 'Makefile', 'tools/release.py', 'tools/release_smoke.py', 'tools/test_release.py', 'tools/linux_abi.py']
    source_hashes = {}
    for name in source_files:
        data = subprocess.check_output(['git', 'show', args.commit + ':' + name], cwd=args.repo)
        source_hashes[name] = digest(data)
    # Read-only evidence checks end here: preserve input hashes before writing the new receipt.
    for key, path in paths.items():
        require(path.read_bytes() == raw[key], 'Evidence changed during audit: ' + key)
    result = {
        'kind': 'Independent incremental native binary release audit', 'status': 'passed_component_only',
        'created_utc': datetime.now(timezone.utc).isoformat(), 'version': args.version, 'commit': args.commit,
        'target': target, 'run_id': args.run_id, 'job_id': job['id'], 'job_url': job['html_url'],
        'runner': platforms[target], 'job_seconds': duration, 'inputs': inputs, 'reviewed_source_sha256': source_hashes,
        'executed_result_evidence': markers,
        'bootstrap': {'compiler_lines': compiler_lines, 'runtime_lines': runtime_lines, 'all_three_stages_identical_for_each': True},
        'unit_tests': {'runs': test_runs, 'results': test_results, 'macos_skip_reason': None if is_linux else 'Linux default program cache (tools/test_release.py:214)'},
        'artifact': {'id': artifact_id, 'zip_sha256_matches_upload_log_and_retrieval': zip_sha,
                     'native_archive_sha256': archive_sha, 'native_binary_sha256': digest(native),
                     'manifest_files_verified': len(payload), 'native_architecture_verified': target},
        'linux_abi': abi,
        'scope': 'Completed native binary component only. Actual success output is distinguished from echoed scripts; unit-test mock publication messages are excluded. make test-install is an installer unit suite; relocated release_smoke supplies actual Python-free native JIT/AOT/GC/version/cache execution evidence. No local payload, compiler, tests or network requests were executed.',
        'full_workflow_or_publication_success_claimed': False,
    }
    output = base / 'independent-audits' / (artifact_name + '.json')
    output.parent.mkdir(exist_ok=True)
    with output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'target': target, 'status': result['status'], 'receipt': str(output), 'receipt_sha256': digest(output.read_bytes()), 'native_archive_sha256': archive_sha}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, default=EVIDENCE)
    parser.add_argument('--repo', type=Path, default=REPO)
    parser.add_argument('--version', default=VERSION, choices=[VERSION])
    parser.add_argument('--commit', default=COMMIT, choices=[COMMIT])
    parser.add_argument('--run-id', type=int, help='Optional assertion against completed job metadata')
    parser.add_argument('targets', nargs='+', choices=['linux-x86_64', 'linux-aarch64', 'macos-arm64', 'macos-x86_64'])
    arguments = parser.parse_args()
    require(len(set(arguments.targets)) == len(arguments.targets), 'Duplicate binary targets')
    first = json.loads((arguments.evidence / 'workflow-logs' / ('binary-' + arguments.targets[0] + '.job.json')).read_text())
    derived_run = first['run_id']
    require(type(derived_run) is int and derived_run > 0, 'Invalid derived run ID')
    require(arguments.run_id is None or arguments.run_id == derived_run, 'Explicit run ID differs from evidence')
    arguments.run_id = derived_run
    # Bind every requested component before writing any component acceptance.
    for target in arguments.targets:
        wrapper = json.loads((arguments.evidence / 'workflow-logs' / ('binary-' + target + '.job.json')).read_text())
        job = wrapper['job']
        require(wrapper['source'] == job['head_sha'] == COMMIT, 'Source mismatch in requested component')
        require(wrapper['run_id'] == job['run_id'] == derived_run, 'Requested components mix workflow runs')
        require(job['status'] == 'completed' and job['conclusion'] == 'success', 'Requested component is incomplete')
        require(not (arguments.evidence / 'independent-audits' / ('binary-' + target + '.json')).exists(), 'Preserve existing component acceptance')
    for target in arguments.targets:
        audit(arguments, target)


if __name__ == '__main__':
    main()
