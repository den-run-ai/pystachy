"""Read-only independent audit of saved alpha.2 PyPI publication evidence."""

import base64
import csv
import fnmatch
import tomllib
from datetime import datetime, timezone
from email.parser import BytesParser
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile
from urllib.parse import urlparse
import zipfile


B = Path("/workspace/scratch/7dd0519bc14a/release-alpha2-verification")
REPO = Path("/workspace/scratch/7dd0519bc14a/alpha2")
OUT = B / "independent-audits"
VERSION = "v0.5.0-alpha.2"
PACKAGE = "0.5.0a2"
SOURCE = "80490143498d149d407343ba1cb7aedb1db2d2c5"
TREE = "717a8c9386ae9f5f6545cc3686a9e22282fc560c"
WHEEL = "pystachy-0.5.0a2-py3-none-any.whl"
SDIST = "pystachy-0.5.0a2.tar.gz"
inputs = {}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    path = Path(path)
    data = path.read_bytes()
    identity = {"path": str(path), "sha256": digest(data), "size": len(data)}
    require(str(path) not in inputs or inputs[str(path)] == identity, f"Changed input: {path}")
    inputs[str(path)] = identity
    return data


def js(path):
    return json.loads(read(path))


def git(*args, input=None):
    result = subprocess.run(["git", "-C", str(REPO), *args], input=input, capture_output=True,
                            env=dict(os.environ, GIT_NO_LAZY_FETCH="1"))
    require(result.returncode == 0, f"Read-only Git command failed: {args!r}")
    return result.stdout


def git_source(commit, path):
    data = git("show", f"{commit}:{path}")
    return data, {"commit": commit, "path": path, "sha256": digest(data),
                  "git_blob": git("rev-parse", f"{commit}:{path}").decode().strip(),
                  "size": len(data)}


def parse_log(path):
    data = read(path).decode()
    rows = []
    for line_number, line in enumerate(data.splitlines(), 1):
        # Blue bold text is Actions' echoed script, not execution output.
        if "\x1b[36;1m" in line:
            continue
        clean = re.sub(r"\x1b\[[0-9;]*m", "", line)
        match = re.match(r"(\d{4}-\d\d-\d\dT\S+Z) (.*)", clean)
        if match and not match[2].startswith("##["):
            rows.append({"line": line_number, "time": match[1], "text": match[2]})
    return rows


def matches(rows, pattern, count=1):
    result = [r for r in rows if re.fullmatch(pattern, r["text"])]
    require(len(result) == count, f"Expected {count} actual output lines for {pattern!r}: {len(result)}")
    return result


def safe_names(names):
    require(len(names) == len(set(names)), "Duplicate archive names")
    for name in names:
        p = PurePosixPath(name)
        require(not p.is_absolute() and ".." not in p.parts and "\\" not in name, "Unsafe archive name")


def check_metadata(data):
    m = BytesParser().parsebytes(data)
    require(m.get_all("Name") == ["pystachy"] and m.get_all("Version") == [PACKAGE],
            "Wrong distribution metadata")


require(git("rev-parse", SOURCE + "^{tree}").decode().strip() == TREE, "Release source tree mismatch")
workflow = js(B / "pypi-workflow-complete.json")
PUBLISHER = workflow["publisher"]
run = workflow["run"]
RUN = run["id"]
require(workflow["source"] == SOURCE and re.fullmatch(r"[0-9a-f]{40}", PUBLISHER) is not None and type(RUN) is int and RUN > 0, "Workflow source/run binding")
require(run["id"] == RUN and run["head_sha"] == PUBLISHER and
        run["head_branch"] == "release/pypi-v0.2.0" and run["event"] == "workflow_dispatch" and
        run["status"] == "completed" and run["conclusion"] == "success", "Unsuccessful/wrong PyPI run")
all_jobs = workflow["jobs"]
require(len(all_jobs) == 6 and len({j["id"] for j in all_jobs}) == 6, "Wrong job inventory")
success_jobs = {j["id"]: j for j in all_jobs if j["conclusion"] == "success"}
require(len(success_jobs) == 2 and {j["name"] for j in success_jobs.values()} == {"Verify PyPI source packages", "Publish verified packages to PyPI"}, "Wrong successful job inventory")
job_ids = {label: next(j["id"] for j in success_jobs.values() if j["name"] == name) for label, name in (("verify", "Verify PyPI source packages"), ("publish", "Publish verified packages to PyPI"))}
require({j["name"] for j in all_jobs if j["conclusion"] == "skipped"} ==
        {"prepare", "Binary ($" + "{{ matrix.target }})", "Container (linux/$" + "{{ matrix.arch }})", "publish"},
        "Unexpected skipped jobs")
require(workflow["outcomes"] == {"success": 2, "skipped": 4}, "Wrong outcomes summary")
jobs = {}
for label, job_id in job_ids.items():
    wrapper = js(B / f"workflow-logs/pypi-{label}.job.json")
    require(wrapper["run_id"] == RUN and wrapper["publisher"] == PUBLISHER and
            wrapper["expected_source"] == SOURCE, "Job wrapper identity mismatch")
    job = wrapper["job"]
    require(all(job.get(k) == value for k, value in success_jobs[job_id].items()),
            "Run summary and full job metadata differ")
    require(job["id"] == job_id and job["run_id"] == RUN and job["head_sha"] == PUBLISHER and
            job["status"] == "completed" and job["conclusion"] == "success", "Bad job outcome")
    require(all(s["status"] == "completed" and s["conclusion"] == "success" for s in job["steps"]),
            "Incomplete or skipped required PyPI step")
    seconds = int((datetime.fromisoformat(job["completed_at"]) -
                   datetime.fromisoformat(job["started_at"])).total_seconds())
    require(0 < seconds <= 900, "15-minute cap exceeded")
    jobs[label] = {"id": job_id, "seconds": seconds, "url": job["html_url"],
                   "steps": [{"number": s["number"], "name": s["name"],
                              "conclusion": s["conclusion"]} for s in job["steps"]]}
require(max(j["seconds"] for j in jobs.values()) == workflow["max_job_seconds"],
        "Job duration summary differs")

verify_log = parse_log(B / "workflow-logs/pypi-verify.log")
publish_log = parse_log(B / "workflow-logs/pypi-publish.log")
log_evidence = {
    "publisher_checkout": matches(verify_log, PUBLISHER, 2),
    "release_source_checkout": matches(verify_log, SOURCE),
    "built_sdist": matches(verify_log, r"Successfully built .*/" + re.escape(SDIST)),
    "built_wheel": matches(verify_log, r"Successfully built .*/" + re.escape(WHEEL)),
    "pip_install": matches(verify_log, "Successfully installed pystachy-0.5.0a2"),
    "pip_runtime": matches(verify_log, r"/tmp/pystachy-compiler-install-[^/]+/outside checkout/pip env/bin/pystachy: version, JIT, standalone AOT and external cache passed"),
    "uv_runtime": matches(verify_log, r"/tmp/pystachy-compiler-install-[^/]+/outside checkout/uv-bin/pystachy: version, JIT, standalone AOT and external cache passed"),
    "pip_uninstall": matches(verify_log, r"  Successfully uninstalled pystachy-0.5.0a2"),
    "uv_uninstall": matches(verify_log, r"Uninstalled 1 executable: pystachy"),
    "upload_wheel": matches(publish_log, "Uploading " + re.escape(WHEEL)),
    "upload_sdist": matches(publish_log, "Uploading " + re.escape(SDIST)),
    "upload_http_success": matches(publish_log, r" +200 OK +", 2),
    "public_url": matches(publish_log, r"https://pypi.org/project/pystachy/0.5.0a2/"),
}
for name in (WHEEL, SDIST):
    log_evidence["verify_metadata_" + name] = matches(verify_log, r"Checking pypi/dist/" + re.escape(name) + r": PASSED")
    log_evidence["publish_checksums_" + name] = matches(publish_log, "dist/" + re.escape(name) + ": OK")

source_files = {}
for commit, paths in [
    (PUBLISHER, [".github/workflows/release.yml", "tools/pypi_release.py", "tools/release_gate.py"]),
    (SOURCE, ["tools/compiler_install_smoke.py", "tools/install_smoke.py", "pyproject.toml",
              "src/pystachy_compiler/driver.py", ".python-version", "tools/requirements-packaging.txt"])
]:
    for path in paths:
        data, identity = git_source(commit, path)
        source_files[f"{commit}:{path}"] = identity
publisher_workflow, _ = git_source(PUBLISHER, ".github/workflows/release.yml")
release_workflow, _ = git_source(SOURCE, ".github/workflows/release.yml")
require(publisher_workflow.split(b"\n  prepare:\n", 1)[0] ==
        release_workflow.split(b"\n  prepare:\n", 1)[0], "PyPI workflow differs from released workflow")
for path in ("tools/pypi_release.py", "tools/release_gate.py"):
    require(git_source(PUBLISHER, path)[0] == git_source(SOURCE, path)[0], "Gate helper differs from release")
require(git_source(SOURCE, ".python-version")[0].strip() == b"3.13.16", "Wrong pinned Python")

artifact = js(B / "artifact-pypi-0.5.0a2-retrieval.json")
require(artifact["status"] == "passed" and artifact["phase"] == "artifact" and
        artifact["version"] == VERSION and artifact["expected_commit"] == SOURCE and
        artifact["name"] == "pypi-" + PACKAGE, "Wrong tested artifact receipt")
require(artifact["workflow_run"]["id"] == RUN and artifact["workflow_run"]["head_sha"] == PUBLISHER,
        "Artifact belongs to another publisher run")
zip_path = B / "workflow-zips/pypi-0.5.0a2.zip"
zip_bytes = read(zip_path)
zip_sha = digest(zip_bytes)
require(artifact["zip"] == str(zip_path) and artifact["sha256"] == zip_sha, "Artifact ZIP digest mismatch")
log_evidence["artifact_upload"] = matches(verify_log, "SHA256 digest of uploaded artifact is " + zip_sha)
log_evidence["artifact_download"] = matches(publish_log, "SHA256 digest of downloaded artifact is " + zip_sha)
log_evidence["artifact_id"] = matches(verify_log, r"Artifact pypi-" + re.escape(PACKAGE) + r" successfully finalized\. Artifact ID \d+")
ARTIFACT_ID = int(re.search(r"Artifact ID (\d+)$", log_evidence["artifact_id"][0]["text"])[1])
require(ARTIFACT_ID > 0, "Invalid artifact ID")
log_evidence["publish_artifact_id"] = matches(publish_log, re.escape(f"- pypi-{PACKAGE} (ID: {ARTIFACT_ID}, Size: {len(zip_bytes)}, Expected Digest: sha256:{zip_sha})"))
expected_artifact_files = {"SHA256SUMS", "SOURCE.json", "dist/" + WHEEL, "dist/" + SDIST}
require(set(artifact["files"]) == expected_artifact_files, "Artifact receipt has wrong file inventory")
tested = B / "tested/pypi-0.5.0a2"
with zipfile.ZipFile(io.BytesIO(zip_bytes)) as z:
    names = z.namelist()
    safe_names(names)
    require(set(names) == expected_artifact_files, "Wrong artifact ZIP entries")
    for name in names:
        require(z.read(name) == read(tested / name), f"Extracted tested artifact changed: {name}")
source_record = js(tested / "SOURCE.json")
require(source_record == {"RELEASE_VERSION": VERSION, "SOURCE_COMMIT": SOURCE,
                          "PACKAGE_VERSION": PACKAGE, "GITHUB_SHA": PUBLISHER}, "Wrong source provenance")
checksums = {}
for line in read(tested / "SHA256SUMS").decode().splitlines():
    m = re.fullmatch(r"([0-9a-f]{64})  (dist/[^\s]+)", line)
    require(m is not None and m[2] not in checksums, "Bad distribution checksum rows")
    checksums[m[2]] = m[1]
require(set(checksums) == {"dist/" + WHEEL, "dist/" + SDIST}, "Wrong distribution checksum inventory")

retrieved = js(B / "pypi-retrieval.json")
require(retrieved["phase"] == "pypi" and retrieved["status"] == "passed" and
        retrieved["version"] == VERSION and retrieved["expected_commit"] == SOURCE and
        retrieved["public_distribution_bytes_downloaded"] is True and
        retrieved["source"] == source_record, "Wrong public package retrieval identity")
metadata = js(B / "pypi-metadata.json")
require(metadata["info"]["name"] == "pystachy" and metadata["info"]["version"] == PACKAGE,
        "Wrong public PyPI metadata")
require(len(metadata["urls"]) == 2 and {u["filename"] for u in metadata["urls"]} == {WHEEL, SDIST},
        "Wrong public PyPI distribution inventory")
distributions = []
for entry in metadata["urls"]:
    name = entry["filename"]
    actual = read(B / "pypi" / name)
    tested_bytes = read(tested / "dist" / name)
    sha = digest(actual)
    require(actual == tested_bytes and sha == checksums["dist/" + name] == entry["digests"]["sha256"],
            "Public/tested/API distribution hashes differ")
    require(len(actual) == entry["size"] and entry["yanked"] is False, "Public distribution size/yank mismatch")
    require(urlparse(entry["url"]).scheme == "https" and urlparse(entry["url"]).hostname == "files.pythonhosted.org",
            "Unexpected public distribution host")
    require(entry["packagetype"] == ("bdist_wheel" if name == WHEEL else "sdist"), "Wrong package type")
    require(any(f["filename"] == name and f["sha256"] == sha and f["size"] == len(actual)
                for f in retrieved["files"]), "Retrieval result differs from actual package")
    distributions.append({"filename": name, "sha256": sha, "size": len(actual),
                          "public_url": entry["url"], "uploaded_at": entry["upload_time_iso_8601"],
                          "tested_bytes_identical": True})
    log_evidence["published_hash_" + name] = matches(publish_log, "SHA256: " + sha)

# Compare all packaged source files directly to immutable Git blobs, with no
# compiler invocation or package execution. Generated packaging metadata is
# enumerated separately.
with zipfile.ZipFile(B / "pypi" / WHEEL) as z:
    wheel_names = z.namelist()
    safe_names(wheel_names)
    wheel = {name: z.read(name) for name in wheel_names}
require(len(wheel_names) > 8, "Empty wheel source inventory")
dist_info = "pystachy-0.5.0a2.dist-info/"
check_metadata(wheel[dist_info + "METADATA"])
require(BytesParser().parsebytes(wheel[dist_info + "WHEEL"]).get_all("Tag") == ["py3-none-any"], "Non-universal wheel")
require(wheel[dist_info + "entry_points.txt"].decode().strip() ==
        "[console_scripts]\npystachy = _pystachy_source.pystachy_cli:main", "Wrong console entry point")
record_rows = list(csv.reader(io.StringIO(wheel[dist_info + "RECORD"].decode())))
require(len(record_rows) == len(wheel) and len({r[0] for r in record_rows}) == len(wheel) and
        {r[0] for r in record_rows} == set(wheel), "Incomplete/duplicate wheel RECORD")
for name, hash_field, length in record_rows:
    if name == dist_info + "RECORD":
        require(hash_field == length == "", "RECORD self-entry malformed")
    else:
        want = base64.urlsafe_b64encode(hashlib.sha256(wheel[name]).digest()).rstrip(b"=").decode()
        require(hash_field == "sha256=" + want and int(length) == len(wheel[name]), "Wheel RECORD hash mismatch")
with tarfile.open(B / "pypi" / SDIST, "r:gz") as t:
    members = t.getmembers()
    safe_names([m.name for m in members])
    require(all(m.isfile() or m.isdir() for m in members), "Special sdist entry")
    require(all(m.name == "pystachy-0.5.0a2" or m.name.startswith("pystachy-0.5.0a2/") for m in members),
            "Wrong sdist root")
    sdist = {m.name.split("/", 1)[1]: t.extractfile(m).read() for m in members if m.isfile()}
check_metadata(sdist["PKG-INFO"])
check_metadata(sdist["pystachy.egg-info/PKG-INFO"])
require(wheel["_pystachy_source/VERSION"].strip() == VERSION.encode() and
        "_pystachy_source/REVISION" not in wheel, "Unexpected hosted version metadata")

tree_entries = {}
for item in git("ls-tree", "-r", "-z", SOURCE).split(b"\0"):
    if item:
        meta, path = item.split(b"\t", 1)
        mode, kind, object_id = meta.decode().split()
        tree_entries[path.decode()] = (mode, kind, object_id)
wheel_source = {name.removeprefix("_pystachy_source/"): data for name, data in wheel.items()
                if name.startswith("_pystachy_source/")}
wheel_licenses = {name.removeprefix(dist_info + "licenses/"): data for name, data in wheel.items()
                  if name.startswith(dist_info + "licenses/")}
package_data = tomllib.loads(git_source(SOURCE, "pyproject.toml")[0].decode())["tool"]["setuptools"]["package-data"]["_pystachy_source"]
expected_sources = {name for name in tree_entries if ("/" not in name and name.endswith(".py")) or any(fnmatch.fnmatchcase(name, pattern) for pattern in package_data)}
require(set(wheel_source) == expected_sources, "Wheel source inventory differs from declared package inputs")
expected_metadata = {dist_info + name for name in ("METADATA", "WHEEL", "entry_points.txt", "top_level.txt", "RECORD", "licenses/LICENSE", "licenses/THIRD_PARTY_NOTICES", "licenses/ryu/LICENSE-Boost")}
require(set(wheel) == {"_pystachy_source/" + name for name in expected_sources} | expected_metadata, "Unexpected wheel entries")
generated_sdist = {"PKG-INFO", "pystachy.egg-info/PKG-INFO", "pystachy.egg-info/SOURCES.txt",
                   "pystachy.egg-info/dependency_links.txt", "pystachy.egg-info/entry_points.txt",
                   "pystachy.egg-info/top_level.txt", "setup.cfg"}
require(set(sdist) - set(tree_entries) == generated_sdist, "Unexpected generated sdist content")
tracked_paths = sorted(set(wheel_source) | set(wheel_licenses) | (set(sdist) - generated_sdist))
require(all(p in tree_entries and tree_entries[p][1] == "blob" for p in tracked_paths),
        "Packaged source is not in release commit")
query = b"".join(f"{SOURCE}:{p}\n".encode() for p in tracked_paths)
stream = io.BytesIO(git("cat-file", "--batch", input=query))
source_comparison = []
for path in tracked_paths:
    oid, kind, length = stream.readline().decode().split()
    data = stream.read(int(length))
    require(stream.read(1) == b"\n" and kind == "blob" and oid == tree_entries[path][2],
            "Git blob stream mismatch")
    locations = []
    for collection, label in ((wheel_source, "wheel"), (wheel_licenses, "wheel-license"), (sdist, "sdist")):
        if path in collection:
            require(collection[path] == data, f"Packaged bytes differ from {SOURCE}:{path}")
            locations.append(label)
    source_comparison.append({"path": path, "git_blob": oid, "sha256": digest(data),
                              "size": len(data), "locations": locations})
require(stream.read() == b"", "Trailing Git blob stream output")
require(set(wheel_source) <= set(sdist), "Wheel sources missing from sdist")

stable = js(B / "stable-retrieval.json")
baseline_path = Path("/workspace/scratch/7dd0519bc14a/pre-alpha-stable/stable-retrieval.json")
baseline = js(baseline_path)
require(stable["phase"] == baseline["phase"] == "stable" and stable["status"] == baseline["status"] == "passed",
        "Stable comparison failed")
require(stable["compared_to"] == str(baseline_path) and stable["identity"] == baseline["identity"],
        "Stable pointers changed")
for prefix, receipt in ((B, stable), (baseline_path.parent, baseline)):
    latest = js(prefix / "stable/github-latest.json")
    tag = js(prefix / "stable/github-stable-tag.json")
    pypi_latest = js(prefix / "stable/pypi-latest.json")
    docker_bytes = read(prefix / "stable/docker-latest.json")
    require(latest["draft"] is False and latest["prerelease"] is False and latest["published_at"],
            "Stable GitHub release metadata invalid")
    identity = {"github_tag": latest["tag_name"], "github_commit": tag["sha"],
                "docker_image": "dta67/pystachy", "docker_latest_digest": "sha256:" + digest(docker_bytes),
                "pypi_version": pypi_latest["info"]["version"]}
    require(identity == receipt["identity"], "Stable receipt differs from saved public metadata")
require(stable["identity"]["github_tag"] == "v0.4.0" and stable["identity"]["pypi_version"] == "0.4.0",
        "Unexpected stable baseline")

# Supplemental public-wheel installations are separately audited after their
# receipt freezes. Alpha2 does not require alpha1's failed diagnostic probe.

# Ensure the frozen input set was stable throughout this audit.
for identity in inputs.values():
    data = Path(identity["path"]).read_bytes()
    require(len(data) == identity["size"] and digest(data) == identity["sha256"],
            f"Input changed during audit: {identity['path']}")

receipt = {
    "kind": "Independent agent audit of completed alpha2 PyPI release evidence",
    "status": "passed_pypi",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "version": VERSION, "package_version": PACKAGE, "commit": SOURCE, "source_tree": TREE,
    "publisher_commit": PUBLISHER, "publisher_branch": "release/pypi-v0.2.0",
    "run_id": RUN, "run_url": run["html_url"], "workflow_outcomes": workflow["outcomes"],
    "max_job_seconds": workflow["max_job_seconds"], "jobs": jobs, "inputs": list(inputs.values()),
    "source_code_identities": source_files,
    "pypi_workflow_and_gate_code_equal_release_source": True,
    "actual_execution_evidence": log_evidence,
    "clean_pip_and_uv_jit_aot_external_cache_checks": True,
    "pip_and_uv_uninstall_checks": True,
    "pypi_gc_stress_claimed": False,
    "tested_artifact": {"name": "pypi-" + PACKAGE, "id": ARTIFACT_ID, "zip_sha256": zip_sha,
                        "zip_size": len(zip_bytes), "files": sorted(expected_artifact_files)},
    "source_provenance": source_record, "public_distributions": distributions,
    "wheel_record_complete_and_hashes_verified": True,
    "wheel_source_files_identical_to_exact_release_git_blobs": len(wheel_source),
    "wheel_license_files_identical_to_exact_release_git_blobs": len(wheel_licenses),
    "sdist_source_files_identical_to_exact_release_git_blobs": len(sdist) - len(generated_sdist),
    "generated_sdist_files": sorted(generated_sdist),
    "exact_source_comparison": source_comparison,
    "stable_pointers_unchanged": stable["identity"],
    "hosted_version": {
        "expected_stdout": f"pystachy {VERSION} (commit unknown)\n",
        "reason": "driver.compiler_version defaults absent REVISION to unknown; the released pyproject package-data and actual wheel include VERSION but no REVISION.",
        "identity_binding": "SOURCE.json plus exact immutable Git source-byte comparison, workflow/tested/public SHA-256 identity.",
        "additional_local_probe": "Supplemental public-wheel pip/uv installation and version checks have a separate receipt. No local installation or runtime execution is claimed by this evidence-only audit.",
    },
    "scope": "Saved evidence and immutable source inspection only. No network, downloads, installations, package execution, compilation or Lean reruns. Actual runtime claims come from the completed publishing workflow's exact released-source helper. This is independent agent review, not a successful GitHub/CLI Codex review.",
}
out = OUT / "pypi-final.json"
with out.open("x") as f:
    f.write(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"path": str(out), "sha256": digest(out.read_bytes()), "status": receipt["status"],
                  "wheel_source_files": len(wheel_source), "sdist_source_files": len(sdist) - len(generated_sdist),
                  "input_files": len(inputs)}, indent=2))
