## Problem

Deliver v0.5.0 through qualified alphas and release candidates, starting from v0.4.0 (`5f81cc2563d231501952104e991d858e670325ac`).

## Scope

Alpha.1 and alpha.2 are published and verified.

Alpha.1: #1470, #1440, #1443, #1293, #1278, #1386, #1387, #1410, #1428, #1429, #1339; repair #1492.

Alpha.2 via #1488: #1277, #1415, #1280, #1281, #1282, #1298, #1274, #1377.

Continue alpha.3 values/numeric protocols; alpha.4 library workflows; alpha.5 final integration/performance; RC.1, further RCs for fixes, then stable. The [PR disposition inventory](https://github.com/den-run-ai/pystachy/blob/3790f5ac4ca4ee660bf747bfc062b22b53d5d897/research/v0.5.0-alpha-qualification/dispositions/README.md) records scope decisions.

Async, full native mypy, broad concurrency, libuv/process-worker research, collector experiments and native-wheel prototypes remain outside committed scope.

Prepared with ChatGPT assistance. Publication is authorized; no gate bypasses.

## Done when

Each published version has reviewed source, explained IR/diagnostic changes, full Lean/proof coverage, successful exact-main CI/Installation/Lint/Packages/Performance/Coverage/Variants, full Linux x86/ARM verification and verified native/Docker/PyPI artifacts.

Preserve the 19-row PR budget and 15-minute job cap. Record source SHAs, artifact/run links, exclusions, incomplete verification and #1303 compatibility/build-cost comparisons, with no unexplained new failures or proof-coverage losses. Refs #5, #1322.

