# Alpha.1/alpha.2 publication and closure addendum — unapplied draft

Prepared from the bounded metadata read recorded at **2026-11-14 19:04:33 UTC**. Root must complete the pending fields from final publication and closure evidence before applying this addendum.

This addendum supplements the [immutable 180-PR disposition inventory](https://github.com/den-run-ai/pystachy/blob/3790f5ac4ca4ee660bf747bfc062b22b53d5d897/research/v0.5.0-alpha-qualification/dispositions/README.md). That inventory remains the historical scope and metadata snapshot: 21 included, 65 conditional, 94 deferred and zero proven superseded heads. Its recorded publication and PR states are not rewritten.

| Release | Exact source | State established when this draft was prepared |
| --- | --- | --- |
| [v0.5.0-alpha.1](https://github.com/den-run-ai/pystachy/releases/tag/v0.5.0-alpha.1) | `a73c56c92f3aad4b490307a5d1b882e487a57f55` | Published and independently verified in the retained alpha.1 evidence |
| [v0.5.0-alpha.2](https://github.com/den-run-ai/pystachy/releases/tag/v0.5.0-alpha.2) | `80490143498d149d407343ba1cb7aedb1db2d2c5` | Non-draft GitHub prerelease published; final PyPI and public distribution acceptance still required for this addendum |

The bounded read confirms that the complete, unchanged heads of #1415 (`42f7576d77dc08273c2136b1754fc2515b465e71`), #1281 (`869a61db4c79511235c3a1243e22c215d2d8ebeb`) and #1282 (`cc6c4cabddfc85e5a4ae759509d29331fdf42b52`) are ancestors of the published alpha.2 source through #1488. Each has zero commits outside that source. All three remained open, non-draft and unmerged at this read.

## Complete after final acceptance

- Record the successful alpha.2 PyPI run and immutable final public artifact verification link; then mark both releases published and verified.
- Recheck the three live heads, close them as integrated, and record each actual closure result/readback. A changed head requires fresh ancestry evidence.
- Link the completed publication/closure receipt from tracker #1476. Keep the inventory unchanged and retain this draft and the bounded ancestry proof as preparation history.

Later-alpha scope, exclusions, the 19-row PR budget, the 15-minute cap and all exact-commit release gates remain as recorded. No GitHub change or closure is represented by this draft.
