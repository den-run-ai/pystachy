## Problem

Class typing and repeated dispatch/runtime compilation limit typed workloads; the selected stacks need combined release qualification.

## Change

Integrate #1277/#1415, #1280/#1281/#1282, #1298, #1274 and #1377 with original histories. Repair partial cache publication, add combined generic/class-field regressions and alpha.2 notes, and include alpha.1's nullable-call, super and strict-storage corrections. Codex assisted implementation and independent reviews. Refs #1476.

## Validation

Current-head CI and Lint pass. Three-stage compiler/runtime fixed points are 932028/21214 IR lines; 46 focused native GC executions and 95 native/97 hosted cache checks pass. The complete 4579-case IR comparison has zero new rejections; 17 acceptances, ten IR changes and six diagnostic improvements are explained.

The fresh 2550-program Lean census passes, including all 175 promoting-storage programs and 18582/18582 storage obligations. All 2529 prior programs remain covered; 21 new programs and eight existing null checks add 1203 proved obligations, with no coverage losses or new unproved results.

Two independent current-head source reviews found no actionable issues. Four GitHub Codex refresh attempts failed before completion and are not counted as reviews. Exact-main and distribution gates follow merge; alpha.1 is published.
