"""Compare frozen release bookkeeping and narrative with accepted local evidence only."""

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/7dd0519bc14a')
OUT = ROOT / 'release-alpha2-verification/bookkeeping'
SOURCE = '80490143498d149d407343ba1cb7aedb1db2d2c5'
inputs = {}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def read(name):
    path = ROOT / name
    data = path.read_bytes()
    record = {'path': name, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
    require(name not in inputs or inputs[name] == record, 'Input changed: ' + name)
    inputs[name] = record
    return data


def js(name):
    return json.loads(read(name))


addendum = js('release-bookkeeping/publication-closure-addendum.json')
addendum_md = read('release-bookkeeping/publication-closure-addendum.md').decode()
closed = js('release-bookkeeping/alpha2-closed-included-prs.json')
preflight = js('release-bookkeeping/alpha2-stacked-pr-closure-preflight.json')
inventory = js('release-bookkeeping/pr-disposition-inventory.json')
inventory_manifest = js('release-bookkeeping/pr-disposition-archive-manifest.json')
readme_name = 'evidence-upload/alpha2-publication-README.md'
readme = read(readme_name).decode()
alpha1_name = 'release-alpha1-verification/independent-audits/alpha1-final-with-public-installs.json'
alpha2_name = 'release-alpha2-verification/independent-audits/alpha2-final.json'
alpha1 = js(alpha1_name)
alpha2 = js(alpha2_name)
read('release-alpha2-verification/independent-audits/alpha2-final.md')
native = js('release-alpha2-verification/independent-audits/native-docker-final.json')
pypi = js('release-alpha2-verification/independent-audits/pypi-final.json')
native_run = js('release-alpha2-verification/native-workflow-complete.json')
pypi_run = js('release-alpha2-verification/pypi-workflow-complete.json')
gates = js('alpha2-exact-main-gates/report.json')
lean = js('alpha2-independent-review/alpha2-final-lean-independent-audit.json')
performance = js('alpha2-exact-main-performance/independent-acceptance.json')
memory = js('alpha2-build-memory/independent-acceptance.json')
review = js('alpha2-independent-review/review-disposition-latest.json')

require(addendum['status'] == closed['status'] == 'completed', 'Completion state mismatch')
require(alpha1['status'] == 'passed_alpha1_delivery_and_lean_acceptance'
        and alpha2['status'] == 'passed_alpha2_delivery_and_qualification', 'Final acceptance missing')
require(addendum['alpha2_closed_prs'] == closed['prs'], 'Addendum closure rows differ')
require(closed['source'] == alpha2['commit'] == SOURCE, 'Closed PR source differs')
require(closed['independent_final_acceptance_sha256'] == inputs[alpha2_name]['sha256'], 'Closure acceptance hash differs')
require(len(addendum['releases']) == 2, 'Unexpected release inventory')
for release, accepted, name in zip(addendum['releases'], (alpha1, alpha2), (alpha1_name, alpha2_name)):
    require(release['version'] == accepted['version'] and release['source'] == accepted['commit']
            and release['final_acceptance_sha256'] == inputs[name]['sha256'], 'Addendum release identity differs')
    require(release['source'] in addendum_md and release['version'] in addendum_md, 'Markdown release identity missing')
require(addendum['stable_pointers'] == alpha2['stable_pointers_unchanged'] == pypi['stable_pointers_unchanged'],
        'Stable-pointer statement differs')

accepted_at = datetime.fromisoformat(alpha2['created_utc'])
old_rows = {row['number']: row for row in preflight['prs']}
require({row['pr'] for row in closed['prs']} == {1415, 1281, 1282}, 'Unexpected closure set')
for row in closed['prs']:
    old = old_rows[row['pr']]
    require(row['head'] == old['head_sha'] and row['source'] == SOURCE
            and row['whole_head_ancestry_checked'] is True and row['commits_outside_source'] == 0,
            'Closure head or ancestry differs')
    require(old['entire_current_head_in_published_source'] is True
            and old['git_evidence']['ancestor']['returncode'] == 0
            and old['git_evidence']['merge_base']['stdout'] == row['head']
            and old['git_evidence']['commits_outside_release']['stdout'] == '0', 'Preparation ancestry differs')
    require(row['before']['state'] == old['state'] == 'open' and row['before']['merged'] is False
            and row['before']['updated_at'] == old['updated_at']
            and row['after']['state'] == 'closed' and row['after']['merged'] is False,
            'Closure state change differs')
    require(accepted_at < datetime.fromisoformat(row['after']['closed_at'])
            <= datetime.fromisoformat(addendum['recorded_at_utc']), 'Closure preceded acceptance or followed addendum')
    require(row['head'] in addendum_md and row['after']['closed_at'] in addendum_md
            and f"{row['url']}#issuecomment-{row['comment_result']['id']}" in addendum_md,
            'Markdown closure provenance differs')

counts = Counter(row['disposition'] for row in inventory['prs'])
expected_counts = {'rows': 180, 'included': 21, 'conditional': 65, 'deferred': 94, 'superseded': 0}
require(len(inventory['prs']) == 180 and all(counts[key] == value for key, value in expected_counts.items() if key != 'rows'),
        'Frozen inventory counts differ')
require(addendum['inventory_counts'] == expected_counts and addendum['inventory_unchanged'] is True,
        'Addendum inventory scope differs')
for item in inventory_manifest['files']:
    name = 'release-bookkeeping/' + item['path']
    read(name)
    require(inputs[name]['sha256'] == item['sha256'] and inputs[name]['bytes'] == item['bytes'], 'Frozen inventory input changed')
for name in ('publication-closure-addendum.json', 'publication-closure-addendum.md', 'alpha2-closed-included-prs.json'):
    copied = ROOT / 'release-alpha2-verification/bookkeeping' / name
    if copied.exists():
        require(read(str(copied.relative_to(ROOT))) == read('release-bookkeeping/' + name), 'Archive preparation copy differs')

require(native['run_id'] == closed['native_run'] == 43626857296 and pypi['run_id'] == closed['pypi_run'] == 43630294045,
        'Publication run identity differs')
require(native_run['run']['run_number'] == 67 and pypi_run['run']['run_number'] == 68
        and native_run['run']['conclusion'] == pypi_run['run']['conclusion'] == 'success', 'Publication run numbering/state differs')
require(native['workflow_outcomes'] == {'success': 8, 'skipped': 2} and native['max_job_seconds'] == 683
        and pypi['workflow_outcomes'] == {'success': 2, 'skipped': 4} and pypi['max_job_seconds'] == 76,
        'Publication timing or job count differs')
require(len(native['public_native_assets']) == 11 and native['docker']['verified_unique_blobs'] == 11
        and native['docker']['verified_layer_references'] == 14
        and native['docker']['downloaded_compressed_bytes'] == 407152903, 'Public artifact count differs')
require(pypi['wheel_source_files_identical_to_exact_release_git_blobs'] == 163
        and pypi['wheel_license_files_identical_to_exact_release_git_blobs'] == 3
        and pypi['sdist_source_files_identical_to_exact_release_git_blobs'] == 168, 'Package source counts differ')
require(gates['workflow_job_outcomes'] == {'success': 131, 'skipped': 1}
        and max(job['seconds'] for run in gates['runs'] for job in run['job_timings']) == 670,
        'Exact-main count or maximum differs')
require(lean['complete_programs'] == 2550 and lean['shared_programs'] == 2529 and lean['added_programs'] == 21
        and lean['new_program_obligations_total'] == 1195 and lean['total_additional_proved_obligations'] == 1203
        and lean['strict_storage_programs'] == 175 and lean['strict_storage_obligations_proved'] == 18582,
        'Lean summary counts differ')

cost_rows = []
for row, label in zip(memory['summary'], ('Numeric', 'JSON', 'Float copy')):
    def metric(key, precision, comma=False):
        value = row[key]
        format_spec = f',.{precision}f' if comma else f'.{precision}f'
        change = f"{value['change_percent']:+.1f}%".replace('-', '−')
        return f"{value['base_median']:{format_spec}} → {value['head_median']:{format_spec}} ({change})"
    expected = f"| {label} | {metric('wall_s', 6)} | {metric('ru_maxrss_kib', 0, True)} | {metric('executable_bytes', 0, True)} |"
    require(expected in readme, 'Readable build/memory/size table differs: ' + label)
    cost_rows.append({'workload': row['workload'], 'verified_markdown_row': expected})
require(memory['warmups'] == 6 and memory['measured_builds'] == 18
        and memory['all_24_built_executables_match_pinned_cpython_output'] is True, 'Bounded measurement scope differs')
require(performance['outcomes'] == {'ok': 49} and performance['workloads'] == 11, 'Performance summary differs')
build = performance['metric_summary']['build_s']
require(round((1 - build['largest_ratio']['ratio']) * 100, 1) == 23.5
        and round((1 - build['smallest_ratio']['ratio']) * 100, 1) == 82.3, 'Fresh warm-build range differs')
bootstrap = performance['bootstrap']
require(f"{bootstrap['base']['wall_s']:.3f} to {bootstrap['head']['wall_s']:.3f} seconds (+{(bootstrap['ratio'] - 1) * 100:.1f}%)" in readme,
        'Bootstrap observation differs')
require('one pair is not a confirmed trend' in readme and 'wait4' in readme and 'waited-descendant accounting' in readme
        and 'Runtime\nchanges were mixed' in readme and 'do not establish universal performance gains' in readme,
        'Performance limits missing')
require(len(review['codex_request_comments']) == 4 and len(review['actual_review_threads']) == 1
        and review['actual_review_threads'][0]['is_resolved'] is True
        and alpha2['automated_review_limit']['github_codex_completed_current_head_review'] is False
        and alpha2['automated_review_limit']['local_cli_review_completed'] is False,
        'Review outcome statement differs')
for identity in list(inputs.values()):
    read(identity['path'])

receipt = {'kind': 'Independent completed alpha publication bookkeeping and README consistency review',
    'status': 'passed_bookkeeping_and_publication_narrative', 'created_utc': datetime.now(timezone.utc).isoformat(),
    'source': SOURCE, 'inputs': list(inputs.values()), 'findings': [],
    'completed_addendum_matches_final_acceptance_hashes': True,
    'closure_rows_exactly_match_completed_root_record': True,
    'all_three_heads_equal_prior_independent_ancestry_proof': True,
    'recorded_closed_states_are_not_additional_merges': True,
    'all_closure_times_follow_final_acceptance': True,
    'closure_heads': {str(row['pr']): row['head'] for row in closed['prs']},
    'frozen_inventory_all_manifest_hashes_unchanged': True, 'inventory_counts': expected_counts,
    'publication_sources_runs_artifact_counts_and_stable_defaults_match': True,
    'cost_table_rows_verified': cost_rows, 'separate_bootstrap_observation': bootstrap,
    'runtime_memory_scope_and_failed_codex_limits_retained': True,
    'scope': 'Read-only comparison of frozen local records and prose; no network, GitHub mutation, tests, compilation, installation or payload execution. Closure state evidence is the completed root API/readback record, cross-checked against the earlier independent ancestry proof; no new live read was performed. This does not verify the not-yet-packaged final archive membership or bytes.'}
path = OUT / 'publication-closure-independent-acceptance.json'
with path.open('x') as stream:
    stream.write(json.dumps(receipt, indent=2) + '\n')
receipt_hash = hashlib.sha256(path.read_bytes()).hexdigest()
markdown = f'''# Completed publication bookkeeping review

**Passed. No discrepancy found.** The completed addendum, closure record and publication README agree with the frozen independent release acceptance and measurement evidence.

- Both release source commits and final acceptance hashes match. Native/PyPI run identities, job counts and timings, artifact counts, package source counts and stable v0.4.0 defaults agree.
- #1415, #1281 and #1282 retain the exact full heads proved in the independent preflight. The addendum exactly reproduces root's completed closure records. Each recorded closure follows final alpha.2 acceptance and records closed/unmerged state, correctly distinguishing bookkeeping closure from another merge.
- All original inventory-manifest hashes remain unchanged. Its 180 rows retain 21 included, 65 conditional, 94 deferred and zero superseded classifications; the addendum preserves that historical scope.
- Every displayed warm-build, peak-RSS and executable-size table value matches the accepted bounded measurement. The fresh 49-ok Performance result, separate single-pair +4.4% bootstrap observation, size increases, per-command RSS limit and absence of a broad speed claim remain clear.
- Failed GitHub/CLI Codex attempts remain separate from the completed independent source reviews. Later alphas, RCs and stable remain future work.

This review read local evidence only and changed none of its inputs. It performed no network request, test, build, installation or payload execution. It checks the completed root API/readback records against prior independent ancestry evidence; it is not a new live GitHub read or a verification of final archive membership.

Detailed receipt SHA-256: `{receipt_hash}`.
'''
md_path = OUT / 'publication-closure-independent-acceptance.md'
with md_path.open('x') as stream:
    stream.write(markdown)
print(json.dumps({'status': receipt['status'], 'json': str(path), 'sha256': receipt_hash,
                  'markdown': str(md_path), 'markdown_sha256': hashlib.sha256(md_path.read_bytes()).hexdigest(),
                  'publication_readme_sha256': inputs[readme_name]['sha256']}, indent=2))
