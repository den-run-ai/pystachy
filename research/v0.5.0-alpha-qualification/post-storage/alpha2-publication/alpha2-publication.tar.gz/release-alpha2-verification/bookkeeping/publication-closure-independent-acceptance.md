# Completed publication bookkeeping review

**Passed. No discrepancy found.** The completed addendum, closure record and publication README agree with the frozen independent release acceptance and measurement evidence.

- Both release source commits and final acceptance hashes match. Native/PyPI run identities, job counts and timings, artifact counts, package source counts and stable v0.4.0 defaults agree.
- #1415, #1281 and #1282 retain the exact full heads proved in the independent preflight. The addendum exactly reproduces root's completed closure records. Each recorded closure follows final alpha.2 acceptance and records closed/unmerged state, correctly distinguishing bookkeeping closure from another merge.
- All original inventory-manifest hashes remain unchanged. Its 180 rows retain 21 included, 65 conditional, 94 deferred and zero superseded classifications; the addendum preserves that historical scope.
- Every displayed warm-build, peak-RSS and executable-size table value matches the accepted bounded measurement. The fresh 49-ok Performance result, separate single-pair +4.4% bootstrap observation, size increases, per-command RSS limit and absence of a broad speed claim remain clear.
- Failed GitHub/CLI Codex attempts remain separate from the completed independent source reviews. Later alphas, RCs and stable remain future work.

This review read local evidence only and changed none of its inputs. It performed no network request, test, build, installation or payload execution. It checks the completed root API/readback records against prior independent ancestry evidence; it is not a new live GitHub read or a verification of final archive membership.

Detailed receipt SHA-256: `174a4fe53102700d7429029f4e4430fa54b9ba0e69e764d484408085b5f5acfc`.
