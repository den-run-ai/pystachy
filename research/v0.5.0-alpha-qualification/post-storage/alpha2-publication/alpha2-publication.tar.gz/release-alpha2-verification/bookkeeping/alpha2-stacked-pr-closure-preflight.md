# Alpha.2 integrated PR closure preflight

**Passed for exact-head inclusion. No closures were performed.** Bounded live metadata was recorded at 2026-11-14 19:04:33 UTC.

The non-draft [alpha.2 GitHub release](https://github.com/den-run-ai/pystachy/releases/tag/v0.5.0-alpha.2) was published at 2026-11-14T18:45:27Z. Both its target and its live tag resolve to `80490143498d149d407343ba1cb7aedb1db2d2c5`, with tree `717a8c9386ae9f5f6545cc3686a9e22282fc560c`. This verifies native release metadata, not final PyPI publication or artifact acceptance.

| PR | Current complete head | Current state | Entire head in published source |
| --- | --- | --- | --- |
| [#1415](https://github.com/den-run-ai/pystachy/pull/1415) | `42f7576d77dc08273c2136b1754fc2515b465e71` | Open, non-draft, unmerged | Yes; zero commits outside source |
| [#1281](https://github.com/den-run-ai/pystachy/pull/1281) | `869a61db4c79511235c3a1243e22c215d2d8ebeb` | Open, non-draft, unmerged | Yes; zero commits outside source |
| [#1282](https://github.com/den-run-ai/pystachy/pull/1282) | `cc6c4cabddfc85e5a4ae759509d29331fdf42b52` | Open, non-draft, unmerged | Yes; zero commits outside source |

For each head, `git merge-base --is-ancestor HEAD SOURCE` returned zero, `git merge-base HEAD SOURCE` returned the head itself, and `git rev-list --count SOURCE..HEAD` returned zero. All three heads and base references exactly match the [immutable 180-row inventory](https://github.com/den-run-ai/pystachy/blob/3790f5ac4ca4ee660bf747bfc062b22b53d5d897/research/v0.5.0-alpha-qualification/dispositions/README.md). Its committed README equals the retained file byte for byte; every file in the original archive manifest still matches its declared hash. The frozen inventory was not edited.

Root may close these as integrated through #1488 once alpha.2 PyPI and final public artifact verification pass. A changed PR head would require new ancestry evidence. Actual close events and publication receipts belong in a separate addendum; this snapshot remains historical evidence.

The prepared tracker body is unchanged and its selected scopes, exclusions and seven-workflow release gates remain accurate. Its “published and verified” sentence is conditional on final verification and should not be applied yet. The only suggested short update is to link exact releases/source commits and the final durable publication receipt, and identify the inventory as a snapshot read together with the final addendum. The live issue #1476 remains open and was last updated at 2026-11-14T18:37:35Z.

No GitHub mutations, workflow dispatch, monitoring, builds, installations or tests were performed.
