"""Bind frozen completed alpha2 evidence; no installations, tests or network calls."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
REPO = WORK / 'alpha2'
VERSION = 'v0.5.0-alpha.2'
PACKAGE = '0.5.0a2'
COMMIT = '80490143498d149d407343ba1cb7aedb1db2d2c5'
BASE = 'a73c56c92f3aad4b490307a5d1b882e487a57f55'
CANDIDATE = '950c0440ad793dc6c34664f591383a5e6bba14dd'
TREE = '717a8c9386ae9f5f6545cc3686a9e22282fc560c'

def require(value, message):
    if not value:
        raise RuntimeError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--final-inputs-frozen', action='store_true', required=True)
    parser.parse_args()
    inputs = {}
    def read(path):
        path = Path(path)
        data = path.read_bytes()
        identity = {'path': str(path), 'sha256': sha(data), 'size': len(data)}
        require(str(path) not in inputs or inputs[str(path)] == identity, 'Input changed: ' + str(path))
        inputs[str(path)] = identity
        return data
    def js(path):
        return json.loads(read(path))
    def git(*args):
        return subprocess.check_output(['git', '-C', str(REPO), *args],
                                       env=dict(os.environ, GIT_NO_LAZY_FETCH='1'))
    def component(path, status=None):
        value = js(path)
        if status is not None:
            require(value['status'] == status, 'Required component not accepted: ' + str(path))
        return value

    out = ROOT / 'independent-audits'
    output_names = ('public-pypi-installs-independent.json', 'alpha2-final.json', 'alpha2-final.md')
    require(not any((out / name).exists() for name in output_names), 'Preserve existing final acceptance')
    native = component(out / 'native-docker-final.json', 'passed_native_and_docker')
    pypi = component(out / 'pypi-final.json', 'passed_pypi')
    lean = component(WORK / 'alpha2-independent-review/alpha2-final-lean-independent-audit.json', 'passed')
    equivalent = component(WORK / 'alpha2-independent-review/alpha2-release-tree-independent-audit.json', 'passed')
    gates = component(WORK / 'alpha2-exact-main-gates/report.json', 'passed')
    verification = component(WORK / 'alpha2-exact-main-gates/verification-acceptance.json', 'passed')
    bootstrap = component(WORK / 'alpha2-exact-main-gates/qualification-acceptance.json', 'passed')
    performance = component(WORK / 'alpha2-exact-main-performance/independent-acceptance.json', 'passed_artifact_and_statistics')
    memory = component(WORK / 'alpha2-build-memory/independent-acceptance.json', 'passed_bounded_measurement_evidence')
    body = component(out / 'release-body-review.json', 'passed_release_body_only')
    for record in (native, pypi):
        require(record['commit'] == COMMIT and record['source_tree'] == TREE and record['version'] == VERSION,
                'Published component source mismatch')
    require(equivalent['release_main_commit'] == gates['source_sha'] == verification['source_sha'] ==
            bootstrap['source_commit'] == COMMIT and equivalent['candidate_commit'] == CANDIDATE and
            equivalent['identical_complete_git_tree'] == lean['source_tree'] == gates['source_tree'] == TREE,
            'Qualification source mismatch')
    require(git('rev-parse', COMMIT + '^{tree}').decode().strip() == TREE and
            git('rev-parse', CANDIDATE + '^{tree}').decode().strip() == TREE and
            not git('diff', '--name-only', CANDIDATE, COMMIT), 'Candidate/release trees differ')
    require(lean['complete_programs'] == 2550 and lean['shared_programs'] == 2529 and lean['added_programs'] == 21 and
            lean['strict_storage_programs'] == 175 and lean['strict_storage_obligations_proved'] == 18582 and
            lean['new_failed_or_unproved_outcomes_relative_to_alpha1'] == [] and
            lean['proof_coverage_or_proved_count_decreases_relative_to_alpha1'] == [] and
            lean['total_additional_proved_obligations'] == 1203, 'Lean acceptance changed')
    require(performance['head'] == COMMIT and performance['base'] == BASE and performance['outcomes'] == {'ok': 49} and
            memory['revisions'] == {'base': BASE, 'head': COMMIT}, 'Performance/memory comparison changed')

    runs = js(WORK / 'alpha2-exact-main-gates/runs-final.json')
    checks = js(WORK / 'alpha2-exact-main-gates/check-runs-final.json')
    require(runs['pagination_complete'] and checks['pagination_complete'] and
            len(runs['workflow_runs']) == runs['total_count'] == 7 and
            len(checks['check_runs']) == checks['total_count'] == 132, 'Incomplete main-gate metadata')
    require(all(r['head_sha'] == COMMIT and r['head_branch'] == 'main' and r['event'] == 'push' and
                r['status'] == 'completed' and r['conclusion'] == 'success' for r in runs['workflow_runs']),
            'Main workflow not successful at release commit')
    require(len({c['id'] for c in checks['check_runs']}) == 132 and
            all(c['head_sha'] == COMMIT and c['status'] == 'completed' and c['conclusion'] in ('success', 'skipped')
                for c in checks['check_runs']) and
            dict(Counter(c['conclusion'] for c in checks['check_runs'])) == {'success': 131, 'skipped': 1},
            'Main check-run outcomes differ')
    require(gates['all_seven_applicable_push_workflows_complete_and_successful'] and
            gates['all_executed_jobs_within_15_minute_cap'] and gates['workflow_job_outcomes'] == {'success': 131, 'skipped': 1},
            'Exact-main acceptance differs')
    for run in gates['runs']:
        for job in run['job_timings']:
            actual = (datetime.fromisoformat(job['completed_at']) - datetime.fromisoformat(job['started_at'])).total_seconds()
            require(0 <= actual == job['seconds'] <= 900, 'Main job timing/cap differs')

    compiler = js(WORK / 'alpha2-independent-review/compiler-review.json')
    runtime = js(WORK / 'alpha2-independent-runtime-review/review.json')
    review_state = js(WORK / 'alpha2-independent-review/review-disposition-latest.json')
    require(compiler['base_commit'] == runtime['base'] == review_state['base'] == BASE and
            compiler['head_commit'] == runtime['head'] == review_state['head'] == CANDIDATE and
            compiler['head_tree'] == runtime['head_tree'] == TREE and compiler['findings'] == runtime['findings'] == [],
            'Independent review identity/findings differ')
    require(runtime['status'] == 'completed' and runtime['reviewer_authored_changes'] is False and
            'did not author' in compiler['reviewer'] and len(review_state['codex_request_comments']) == 4 and
            len(review_state['actual_review_threads']) == 1 and review_state['actual_review_threads'][0]['is_resolved'],
            'Review provenance differs')
    for row in compiler['reviewed_sources']:
        require(sha(git('show', COMMIT + ':' + row['path'])) == row['sha256'], 'Reviewed compiler source differs')
    for name, value in runtime['files_reviewed_sha256'].items():
        require(sha(git('show', COMMIT + ':' + name)) == value, 'Reviewed runtime source differs')

    ir = js(Path('/workspace/scratch/c66a10c5a7b1/ir-audit/a2-explained.json'))
    require(ir['explained'] and ir['total'] == len(ir['cases']) == len({c['case'] for c in ir['cases']}) == 4579 and
            dict(Counter(c['category'] for c in ir['cases'])) == ir['counts'] and
            not any(c['old_status'] == 0 and c['new_status'] != 0 for c in ir['cases']), 'Compatibility comparison differs')
    require(all(c.get('explanation') for c in ir['cases'] if c['category'] in ('new_acceptance', 'ir_change', 'diagnostic_change')),
            'Unexplained substantive compiler difference')
    checker_changes = ['tools/check_lean_storage.py', 'tools/test_lean_storage.py', 'tools/test_lean_storage_layout.py']
    require(git('diff', '--name-only', ir['source_old'], BASE).decode().splitlines() == checker_changes and
            git('diff', '--name-only', ir['source_new'], COMMIT).decode().splitlines() == checker_changes,
            'Retained compiler comparison is not source-equivalent')
    require(body['version'] == VERSION and body['commit'] == COMMIT and body['findings'] == [], 'Release-body review differs')

    installs = component(ROOT / 'public-pypi-installs.json', 'passed')
    retrieval = component(ROOT / 'pypi-retrieval.json', 'passed')
    helper = WORK / 'artifact-audit/verify_public_pypi_installs_with_context.py'
    helper_sha = sha(read(helper))
    require(helper_sha == '2d5a9d664bee1afefb142cb29d94ce0d603f12f3b47bd2fadae4d45d959fdebd' and
            installs['verifier_sha256'] == helper_sha, 'Reviewed public-install helper changed')
    require(installs['version'] == VERSION and installs['source'] == COMMIT and installs['package_version'] == PACKAGE and
            installs['python'] == '3.13.16' and installs['python_optimize'] == 0 and
            installs['PYTHONOPTIMIZE'] in (None, '', '0'), 'Install identity/assertion execution context differs')
    require(installs['public_retrieval_receipt_sha256'] == sha(read(ROOT / 'pypi-retrieval.json')) and
            retrieval['version'] == VERSION and retrieval['expected_commit'] == COMMIT and
            retrieval['public_distribution_bytes_downloaded'] is True, 'Public install source bytes not bound')
    wheel_name = f'pystachy-{PACKAGE}-py3-none-any.whl'
    wheel_path = ROOT / 'pypi' / wheel_name
    wheel_bytes = read(wheel_path)
    require(installs['public_wheel'] == wheel_name and installs['wheel_sha256'] == sha(wheel_bytes) and
            any(d['filename'] == wheel_name and d['sha256'] == sha(wheel_bytes) for d in pypi['public_distributions']),
            'Installed public wheel differs from accepted package')
    with zipfile.ZipFile(wheel_path) as archive:
        require(len(archive.namelist()) == len(set(archive.namelist())), 'Duplicate wheel entries')
        payload = [n for n in archive.namelist() if n.startswith('_pystachy_source/') and not n.endswith('/')]
        require(archive.read('_pystachy_source/VERSION').decode().strip() == VERSION and
                '_pystachy_source/REVISION' not in archive.namelist(), 'Hosted version contract differs')
    expected_console = f'pystachy {VERSION} (commit unknown)'
    require(installs['expected_hosted_console'] == expected_console and installs['wheel_contains_revision_file'] is False and
            len(payload) == pypi['wheel_source_files_identical_to_exact_release_git_blobs'] and
            [row['installer'] for row in installs['installations']] == ['pip', 'uv'], 'Installation coverage differs')
    for row in installs['installations']:
        require(row['install_returncode'] == row['version_returncode'] == row['installed_python_optimize'] == 0 and
                row['installed_version'] == PACKAGE and row['isolated_location_verified'] is True and
                row['installed_payload_files_byte_equal_to_public_wheel'] == len(payload) and
                row['version_stdout'] == expected_console + '\n', 'Public install check failed or incomplete')
    stable = component(ROOT / 'stable-retrieval.json', 'passed')
    require(stable['identity'] == pypi['stable_pointers_unchanged'] and
            stable['identity']['github_tag'] == 'v0.4.0' and stable['identity']['pypi_version'] == '0.4.0',
            'Stable-pointer acceptance differs')
    artifact_provenance = js(ROOT / 'tested' / ('pypi-' + PACKAGE) / 'ARTIFACT_PROVENANCE.json')
    tested_artifact = pypi['tested_artifact']
    require(artifact_provenance['id'] == tested_artifact['id'] and
            artifact_provenance['digest'] == 'sha256:' + tested_artifact['zip_sha256'] and
            artifact_provenance['size_in_bytes'] == tested_artifact['zip_size'] and
            artifact_provenance['workflow_run']['id'] == pypi['run_id'] and
            artifact_provenance['workflow_run']['head_sha'] == pypi['publisher_commit'], 'PyPI API artifact provenance differs')
    for identity in list(inputs.values()):
        read(identity['path'])

    installed_receipt = {'kind': 'Independent audit of supplemental alpha2 public-wheel installations',
        'status': 'passed_supplemental_public_installs', 'created_utc': datetime.now(timezone.utc).isoformat(),
        'version': VERSION, 'package_version': PACKAGE, 'commit': COMMIT, 'inputs': list(inputs.values()),
        'installers': ['pip', 'uv'], 'fresh_isolated_environments': 2,
        'installed_source_files_equal_public_wheel_per_environment': len(payload),
        'hosted_console': expected_console, 'install_and_version_exits_zero': True,
        'assertion_execution_context_recorded_during_actual_run': {'parent_optimize': installs['python_optimize'],
            'PYTHONOPTIMIZE': installs['PYTHONOPTIMIZE'], 'installed_python_optimize': [r['installed_python_optimize'] for r in installs['installations']]},
        'helper_logic_review': 'Reviewed fresh isolated offline/no-index/no-deps pip/uv installs, pinned public-wheel hash, contained installed payload comparisons, metadata/version checks, and explicit optimization rejection before assertions. Both installations must finish before success is written.',
        'scope': 'Independent saved-receipt/helper/public-wheel review only. The retained helper receipt supplies actual installation execution; no installations, payload execution or network was repeated. JIT/AOT comes from the separately accepted publishing workflow.'}
    component_records = {Path(path).name: identity for path, identity in inputs.items() if path.endswith('.json')}
    receipt = {'kind': 'Independent final alpha2 qualification and publication acceptance',
        'status': 'passed_alpha2_delivery_and_qualification', 'created_utc': datetime.now(timezone.utc).isoformat(),
        'version': VERSION, 'package_version': PACKAGE, 'commit': COMMIT, 'source_tree': TREE,
        'inputs': list(inputs.values()), 'native_acceptance': native['status'], 'pypi_acceptance': pypi['status'],
        'public_channels': {'github': {'url': native['native_release_url'], 'release_id': native['native_release_id'], 'assets': 11, 'prerelease': True},
            'docker': native['docker'], 'pypi': {'url': f'https://pypi.org/project/pystachy/{PACKAGE}/', 'distributions': pypi['public_distributions']}},
        'workflow_runs': {'native': {'id': native['run_id'], 'outcomes': native['workflow_outcomes'], 'max_job_seconds': native['max_job_seconds']},
                         'pypi': {'id': pypi['run_id'], 'publisher_commit': pypi['publisher_commit'], 'outcomes': pypi['workflow_outcomes'], 'max_job_seconds': pypi['max_job_seconds']}},
        'qualification': {'exact_main_workflows': 7, 'exact_main_check_outcomes': {'success': 131, 'skipped': 1},
            'complete_lean_programs': 2550, 'shared_programs': 2529, 'added_programs': 21, 'additional_proved_obligations': 1203,
            'strict_storage_programs': 175, 'strict_storage_obligations_proved': 18582, 'new_failed_or_unproved_outcomes': [], 'proof_coverage_losses': [],
            'compiler_compatibility_cases': 4579, 'compiler_compatibility_counts': ir['counts'], 'new_rejections': 0,
            'compatibility_scope': 'Retained original comparison with explained differences; both release compiler/runtime trees remain equivalent except the three independent Lean checker/test repairs.',
            'bootstrap_tier_tracked_sources_and_modes': bootstrap['all_tracked_sources_and_modes_recomputed'],
            'performance_comparisons': performance['outcomes'], 'fresh_bootstrap_observation': performance['bootstrap'],
            'build_memory_measured_builds': memory['measured_builds'],
            'build_memory_tradeoff': 'Three bounded workloads have lower median warm AOT build time and recorded wait4 peak RSS, with executable-size increases of 4.9–35.6%; no broad runtime/memory claim.'},
        'independent_source_reviews': {'count': 2, 'reviewed_candidate': CANDIDATE, 'reviewed_tree': TREE, 'release_tree_equal': True,
            'reviewers': [compiler['reviewer'], runtime['reviewer']], 'findings': [],
            'scopes': ['compiler/class/typing/dispatch', 'driver/AOT runtime cache/verification integration']},
        'automated_review_limit': {'github_codex_completed_current_head_review': False, 'github_service_attempts_recorded': 4,
            'local_cli_review_completed': False, 'detail': 'GitHub review service attempts did not complete. Local CLI attempts ended at argument validation and read-only app-server initialization; no workaround was attempted. Two independent agent source reviews completed separately. The sole historical review thread is resolved; failed-summary finding flags were stale.'},
        'supplemental_public_installs': {'status': installed_receipt['status'], 'installers': ['pip', 'uv'], 'payload_files_per_environment': len(payload),
                                      'assertion_context': installed_receipt['assertion_execution_context_recorded_during_actual_run']},
        'stable_pointers_unchanged': stable['identity'], 'hosted_version_contract': pypi['hosted_version'],
        'release_body_review': {'status': body['status'], 'findings': body['findings']},
        'supports_completed_alpha2_publication': True,
        'scope': 'Binds completed independent native/public-layer, PyPI, local-public-install, complete qualification and independent source-review evidence at one release tree. No new network, polling, downloads, payload execution, compilation, installation, tests or Lean reruns. This is independent agent review, not successful GitHub/CLI Codex review.'}
    installed_path = out / output_names[0]
    installed_bytes = (json.dumps(installed_receipt, indent=2) + '\n').encode()
    receipt['supplemental_public_installs']['receipt'] = {'path': str(installed_path), 'sha256': sha(installed_bytes), 'size': len(installed_bytes)}
    final_path = out / output_names[1]
    final_bytes = (json.dumps(receipt, indent=2) + '\n').encode()
    markdown = f'''# Independent final alpha.2 acceptance

**Accepted: v0.5.0-alpha.2 is published and verified across GitHub native assets, both native Docker architectures and PyPI.** Source `{COMMIT}`, tree `{TREE}`.

The native Release run `{native['run_id']}` passed eight jobs with two expected PyPI skips; the longest took {native['max_job_seconds']} seconds. PyPI run `{pypi['run_id']}` passed both packaging/publication jobs with four expected native skips; its longest took {pypi['max_job_seconds']} seconds. All executed jobs stayed within 15 minutes.

## Public distributions

- GitHub: {native['native_release_url']} — all 11 public assets match tested artifacts.
- Docker: `{native['docker']['image']}` — both native platforms, exact tested configurations, 11 downloaded public blobs and 14 verified layer references.
- PyPI: https://pypi.org/project/pystachy/{PACKAGE}/ — public wheel and sdist match the tested/uploaded bytes. Every packaged source file is bound to the exact release Git blobs.

Actual publishing-workflow checks cover clean pip/uv installation, JIT, standalone AOT, external caches and uninstall. The additional local public-wheel checks used two fresh isolated environments, verified all {len(payload)} payload files per environment, correct package metadata and console version. The parent and child optimization context was recorded during those actual checks. Hosted wheels correctly print `pystachy {VERSION} (commit unknown)` because their documented package contents contain VERSION and no REVISION; source identity comes from exact source-byte and distribution-hash checks.

## Qualification

All seven applicable exact-main workflows passed; their complete check inventory contains 131 successes and one expected PR-only skip. The complete Lean audit covers 2,550 programs, retains all 2,529 shared programs, adds 21 fully proved programs and 1,203 proved obligations, and records no new failed/unproved outcomes or coverage losses. The strict 175-program storage corpus proves all 18,582 obligations.

The retained 4,579-case compiler comparison has no new rejection and explains every substantive IR/diagnostic difference. Only three independent Lean checker/test files changed in the compared compiler-source trees, so that evidence remains applicable. Fresh exact-main performance has 49 `ok` comparisons. The separate three-workload warm-build experiment finds lower build time and recorded peak RSS with larger executables; size rises 4.9–35.6%. The separate fresh bootstrap observation increased from {performance["bootstrap"]["base"]["wall_s"]:.3f} to {performance["bootstrap"]["head"]["wall_s"]:.3f} seconds (+{(performance["bootstrap"]["ratio"] - 1) * 100:.1f}%); it is one sequential pair without confirmation and does not establish a sustained change. These bounded measurements do not establish broad runtime or memory improvements.

## Review provenance

Two independent agents completed complementary compiler/class/typing/dispatch and driver/runtime-cache/verification reviews on the exact candidate tree, which equals the release tree. Neither found an actionable new defect. **GitHub Codex did not complete the four recorded service attempts, and the local CLI did not complete a review.** Its attempts ended at argument validation and read-only app-server initialization, with no workaround. The completed independent reviews are recorded separately and are not represented as successful GitHub/CLI Codex reviews. The sole historical review thread is resolved. A separate published-body review found no stale or unsupported release claim.

## Stable pointers and audit scope

The final public comparison confirms GitHub stable remains `{stable['identity']['github_tag']}` at `{stable['identity']['github_commit']}`, PyPI stable remains `{stable['identity']['pypi_version']}`, and Docker latest retains `{stable['identity']['docker_latest_digest']}`.

Detailed final receipt: `alpha2-final.json`, SHA256 `{sha(final_bytes)}`. Supplemental public-install receipt: `public-pypi-installs-independent.json`, SHA256 `{sha(installed_bytes)}`. Both bind the complete component evidence and preserve its scope and limitations.

This final audit read frozen evidence, verified hashes/source bindings and recomputed inventory/timing facts. It performed no network requests, downloads, polling, payload execution, installation, compilation, tests or proof reruns.
'''
    for path, data in [(installed_path, installed_bytes), (final_path, final_bytes), (out / output_names[2], markdown.encode())]:
        with path.open('xb') as stream:
            stream.write(data)
    print(json.dumps({'status': receipt['status'], 'final': str(final_path), 'final_sha256': sha(final_bytes),
                      'public_install_receipt_sha256': sha(installed_bytes), 'markdown_sha256': sha(markdown.encode())}))

if __name__ == '__main__':
    main()
