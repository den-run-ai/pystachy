# Independent alpha.2 audit: both native containers

**Both container components passed.** They belong to Release run `43626857296`, source `80490143498d149d407343ba1cb7aedb1db2d2c5` and version `v0.5.0-alpha.2`.

| Native image | Job | Duration | Tested artifact |
|---|---:|---:|---:|
| linux/amd64 | 132547990296 | 147 s | 14127182195 |
| linux/arm64 | 132547990242 | 154 s | 14126328088 |

The actual native runner logs show exact version and commit output, Python-free image-build JIT/AOT smoke, installed JIT/AOT execution as UID 10001, and UID 10001 bind-mounted JIT and AOT checks. The container jobs use the exact Linux binary artifacts accepted by the independent binary audits.

Saved image archives were independently read, hashed and compared with their uploaded ZIP members. All seven layers per image have matching blob-name hashes and uncompressed root-filesystem diff IDs. Each configuration identifies the correct native architecture, exact release labels, installed entrypoint and working directory, and its digest matches the actual build-export log. Upload logs, saved API artifact IDs, ZIP digests/sizes and source/run metadata agree.

| Architecture | Tested configuration digest |
|---|---|
| amd64 | `sha256:ebe65f741eedb8c40f9b0473f28605c5ce975c605331e21334977df331ff2738` |
| arm64 | `sha256:64c902ca5a1aa432db79b22a1862506c3cefef906125ec83d94a96cfeeb7ba68` |

The large-image reads are complete. This receipt accepts the tested container components only; public registry identity, publication completion and PyPI remain separate evidence. All image verification was read-only, with no Docker invocation, network request, payload execution or retesting.
