# Independent alpha.2 native and Docker release acceptance

**Accepted: the native GitHub and Docker release is published and its public artifacts match the tested artifacts.** Version `v0.5.0-alpha.2` resolves to source `80490143498d149d407343ba1cb7aedb1db2d2c5`, tree `717a8c9386ae9f5f6545cc3686a9e22282fc560c`.

[GitHub prerelease](https://github.com/den-run-ai/pystachy/releases/tag/v0.5.0-alpha.2) was published at `2026-11-14T18:45:27Z`. [Native Release run 43626857296](https://github.com/den-run-ai/pystachy/actions/runs/43626857296) completed successfully with eight successful jobs and two expected PyPI skips. Every executed job stayed within the 15-minute cap; the longest took 683 seconds.

## Tested execution and publication identity

The four independent binary receipts verify actual compiler/runtime fixed points of 932,028/21,214 IR lines, exact native and installed version output, Python-free relocation, JIT/AOT correctness, GC stress and warm runtime-cache reuse. Both Linux targets also pass default program-cache fill/hit checks and complete ELF ABI checks. All four archives have verified 117-file payload manifests and the intended executable architecture.

The two independent container receipts verify execution on native amd64 and arm64 runners, Python-free image checks, JIT/AOT as UID 10001, and bind-mounted JIT/AOT builds. The complete saved-image bytes and every layer were checked before this final audit.

The actual publish log rechecks the four exact-main release gates, downloads all six tested artifacts with matching ZIP digests, verifies archive checksums, loads both tested images and completes Docker and GitHub publication. No unit-test mock publication messages are used as publication evidence.

## Public GitHub assets

All 11 public assets were independently rehashed and checked against saved API digests, sizes and asset IDs. The four native archives, their checksum sidecars and both Linux ABI reports are byte equal to the independently accepted workflow artifacts. The aggregate `SHA256SUMS` covers exactly those four archives. The public release is marked as a prerelease, and the public tag's source/tree identity agrees with the qualified source.

The retained actual public Linux x86-64 launcher probe prints the exact alpha.2 version and full source commit, exits zero and has no stderr. JIT/AOT/GC execution remains supplied by the matched successful native jobs.

## Public Docker image

Image: `dta67/pystachy:v0.5.0-alpha.2`

Index digest: `sha256:ec762302831e863f92ab31ec061131088e46ede67000ea592ecd12a846449104`

| Native platform | Tested and public configuration digest |
|---|---|
| linux/amd64 | `sha256:ebe65f741eedb8c40f9b0473f28605c5ce975c605331e21334977df331ff2738` |
| linux/arm64 | `sha256:64c902ca5a1aa432db79b22a1862506c3cefef906125ec83d94a96cfeeb7ba68` |

The public index contains exactly these two platforms. Raw manifest/configuration hashes and descriptor sizes agree, architecture-specific tags identify the same manifests, and both complete public configurations equal their tested native image configurations.

The separate one-shot public-layer verifier downloaded and checked 11 distinct blobs covering 14 ordered layer references and 407,152,903 compressed bytes. This audit independently checked the verifier receipt against every public descriptor and tested layer identity, including compressed hashes/sizes, decompressed diff IDs and unpacked sizes. The verifier and its source/helper inputs match their reviewed hashes. No saved images were reread during this final audit.

## Qualification and remaining scope

The accepted complete Lean census and exact-main gate report are bound to the same complete Git tree as this release. The publication job skipped both stable-promotion steps, as required for a prerelease. A final public stable-pointer comparison remains separate from those skipped-step checks.

PyPI publication and clean public package installation are separate required evidence and are not claimed by this native/Docker receipt.

A separate independent release-body review found no stale readiness, identity, typing or performance misstatement. The published body matches the exact curated source notes and rendered asset section, and its historical build/JSON-control figures agree with the retained original measurements. That scope-limited receipt is `release-body-review.json`, SHA256 `b2077a70dafa426c11f578efc50b2080714947be73c9f6cdbb7c164707cdcf80`.

## Receipt

Detailed acceptance: `native-docker-final.json`, SHA256 `4392355313da1d6c41a7e5329d87d3dd536bcc61449a0fdea08190be4caf6a92`. It records every input hash, actual publication output line, public asset identity and Docker layer/manifest binding.

This was an independent agent review of frozen evidence, source, hashes and metadata. It performed no compiler or workload execution, Docker invocation, network request, download, test rerun, workflow polling or monitoring.
