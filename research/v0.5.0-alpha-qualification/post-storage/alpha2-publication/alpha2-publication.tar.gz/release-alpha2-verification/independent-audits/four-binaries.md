# Independent alpha.2 audit: all four native binaries

**All four binary components passed.** They belong to Release run `43626857296`, source `80490143498d149d407343ba1cb7aedb1db2d2c5` and version `v0.5.0-alpha.2`.

| Component | Job | Duration | Tested artifact |
|---|---:|---:|---:|
| linux-x86_64 | 132544687732 | 399 s | 14126566752 |
| linux-aarch64 | 132544687772 | 363 s | 14126193793 |
| macos-arm64 | 132544687690 | 441 s | 14126647671 |
| macos-x86_64 | 132544687767 | 683 s | 14126778222 |

Actual logs confirm compiler/runtime fixed points of 932,028/21,214 IR lines, exact native and installed version, Python-free relocation, JIT/AOT correctness, GC stress and warm runtime-cache reuse. Both Linux targets also pass default program-cache fill/hit checks and complete ELF ABI reports with no violations under the glibc 2.39 cap. All jobs are within 15 minutes.

Each archive has a complete, verified 117-file payload manifest, exact VERSION/REVISION and the expected executable architecture. Upload log, retained API metadata, actual ZIP digest/size and extracted payload identities agree. The two macOS jobs have one expected Linux-only unit-test skip; installer-unit publication mocks are excluded from actual execution evidence.

The machine-readable companion and individual component receipts retain hashes, actual output lines and archive identities. This accepts the four binaries only; container, public publication and PyPI acceptance require their own evidence. The earlier three-component receipt is preserved. No polling, downloads, payload execution or retesting was performed.
