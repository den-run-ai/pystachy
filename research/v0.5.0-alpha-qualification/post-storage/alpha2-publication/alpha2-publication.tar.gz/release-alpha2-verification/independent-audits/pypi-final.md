# Independent alpha.2 PyPI acceptance

**Accepted: public PyPI version `0.5.0a2` matches the tested and uploaded release packages.** The source is `80490143498d149d407343ba1cb7aedb1db2d2c5`, tree `717a8c9386ae9f5f6545cc3686a9e22282fc560c`. Publisher commit `6e5544cfa3eecb8329e4f4cb19d2e0ac3e99b1bf` supplies the separate release workflow; its PyPI workflow section and gate helpers are byte equal to the release source versions.

[PyPI Release run 43630294045](https://github.com/den-run-ai/pystachy/actions/runs/43630294045) completed with two successful jobs and four expected native skips. Every required PyPI step passed; the longest job took 76 seconds. Actual output records clean pip and uv installation, JIT, standalone AOT, external-cache operation and uninstall. Both uploads returned HTTP 200.

The tested workflow artifact is `pypi-0.5.0a2`, ID `14127666594`, ZIP size 3,757,161 bytes and SHA256 `944204062f554dfd41d1fec48963dce0405de2cbc1d4df1481d6f2893182a798`. Upload and download logs, saved API metadata, `SOURCE.json`, distribution checksums and retained ZIP bytes agree.

| Public distribution | Bytes | SHA256 |
|---|---:|---|
| pystachy-0.5.0a2-py3-none-any.whl | 1,928,629 | `d42c6624fab8438550a99017f128929dc49833e6aaca19416a2caf3ff0725667` |
| pystachy-0.5.0a2.tar.gz | 1,856,048 | `ef085f320ea6a61db1c55c10b99ddb79f54da175e66cc68e5e8115d70d9a0e4a` |

Both actual public downloads are byte equal to the tested packages and match PyPI metadata hashes and sizes. Every wheel RECORD entry was verified. All 163 wheel source files, three wheel license files and 168 sdist source files are byte equal to their exact release Git blobs; generated packaging metadata is enumerated separately. Package metadata, the universal wheel tag and console entry point are correct.

The additional local public-wheel verification installed the already verified wheel into fresh pip and uv environments, compared all 163 installed payload files per environment and verified version metadata and console output. The parent and child interpreters recorded optimization level zero during the actual checks; `PYTHONOPTIMIZE` was explicitly `0`. These supplemental checks do not claim local JIT/AOT execution, which is supplied by the completed publishing workflow.

Hosted console output correctly reports `pystachy v0.5.0-alpha.2 (commit unknown)`: the wheel contains VERSION and no REVISION, as defined by its source. The exact release commit is established independently by `SOURCE.json`, complete immutable source comparisons and tested/public package hashes.

The final saved public metadata also confirms that GitHub stable remains `v0.4.0`, PyPI stable remains `0.4.0`, and Docker latest retains its pre-alpha digest.

## Frozen receipts

- PyPI acceptance: `pypi-final.json`, SHA256 `ed34c202f5a1c92e04558c2663c265452a4c362b6864b0501f8fcdf5d4bbb939`.
- Supplemental public installs: `public-pypi-installs-independent.json`, SHA256 `2de748d1353300673d7c000acaa7a10ef075ef694dac0b6dd8f5d60dff5e70e1`.
- Complete qualification and publication aggregate: `alpha2-final.json`, SHA256 `7ac9e86a7d4d48482d7d2a55ae77015d04daf21381529008ea6eb50e9ebbbec3`.

The independent audit read saved execution evidence, package bytes, API metadata and immutable Git objects. Git lazy fetching was explicitly disabled. It performed no installations, package execution, builds, tests, downloads, network requests or monitoring.
