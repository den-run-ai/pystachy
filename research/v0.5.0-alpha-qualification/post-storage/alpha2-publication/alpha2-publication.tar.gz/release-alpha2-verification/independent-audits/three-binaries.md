# Independent alpha.2 binary audit: first three components

**Passed for Linux x86-64, Linux AArch64 and macOS ARM64.** All three belong to Release run `43626857296`, exact source `80490143498d149d407343ba1cb7aedb1db2d2c5` and version `v0.5.0-alpha.2`.

| Component | Job | Duration | Tested artifact |
|---|---:|---:|---:|
| Linux x86-64 | 132544687732 | 399 s | 14126566752 |
| Linux AArch64 | 132544687772 | 363 s | 14126193793 |
| macOS ARM64 | 132544687690 | 441 s | 14126647671 |

Each actual execution log confirms compiler and runtime three-stage fixed points of 932,028 and 21,214 IR lines, exact native/installed version output without Python or LLVM, relocated JIT and AOT output matching CPython, GC stress, and warm runtime-cache reuse with read-only release resources. Both Linux jobs also pass the default program-cache fill/hit check, including frontend bypass on the hit.

All three native archives have matching checksum files and complete 117-file payload manifests. ELF/Mach-O headers identify the intended architecture. Both Linux reports cover the entire ELF payload and report no ABI violations under the glibc 2.39 cap. Upload-log artifact IDs and digests, retained API metadata, actual ZIP bytes and sizes, extracted archives and source/run identities agree.

Each component passed the 73-test release suite and 16-test installer suite, with one documented Linux-only release-test skip on macOS. Installer unit-test mock publication messages are excluded from actual release acceptance; the execution evidence comes from the relocated archive smoke checks.

The companion machine-readable receipts retain input hashes and exact executed output lines. This is three-component acceptance only: Intel macOS, the complete native workflow, containers, public artifacts and PyPI remain subject to their separate evidence handoffs. No polling, downloads, payload execution or retesting was performed.
