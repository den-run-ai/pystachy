"""Read handed-off container logs and saved-image bytes, without Docker or network calls."""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile
import zipfile

ROOT = Path('/workspace/scratch/7dd0519bc14a/release-alpha2-verification')
REPO = Path('/workspace/scratch/7dd0519bc14a/alpha2')
VERSION = 'v0.5.0-alpha.2'
COMMIT = '80490143498d149d407343ba1cb7aedb1db2d2c5'
CHUNK = 1024 * 1024


def require(value, message):
    if not value:
        raise ValueError(message)


def hash_stream(stream):
    digest, size = hashlib.sha256(), 0
    while block := stream.read(CHUNK):
        digest.update(block)
        size += len(block)
    return digest.hexdigest(), size


def hash_file(path):
    with path.open('rb') as stream:
        return hash_stream(stream)


class HashReader:
    def __init__(self, stream):
        self.stream, self.digest, self.size = stream, hashlib.sha256(), 0

    def read(self, size=-1):
        data = self.stream.read(size)
        self.digest.update(data)
        self.size += len(data)
        return data


class PrefixReader:
    def __init__(self, prefix, stream):
        self.prefix, self.stream = prefix, stream

    def read(self, size=-1):
        if size < 0:
            result, self.prefix = self.prefix + self.stream.read(), b''
            return result
        head, self.prefix = self.prefix[:size], self.prefix[size:]
        return head + (self.stream.read(size - len(head)) if len(head) < size else b'')


def saved_image(path, arch):
    members, metadata = {}, {}
    # Single forward pass. No member is extracted or executed; buffers are bounded.
    with tarfile.open(path, 'r|gz') as archive:
        for member in archive:
            name = PurePosixPath(member.name)
            require(not name.is_absolute() and '..' not in name.parts and member.name not in members,
                    'Unsafe or duplicate saved-image member')
            require(member.isdir() or member.isfile(), 'Nonregular saved-image member')
            if member.isdir():
                members[member.name] = {'directory': True}
                continue
            reader = HashReader(archive.extractfile(member))
            prefix = reader.read(2)
            stream = PrefixReader(prefix, reader)
            if prefix == b'\x1f\x8b':
                with gzip.GzipFile(fileobj=stream) as decoded:
                    diff, unpacked = hash_stream(decoded)
                encoding = 'gzip'
            else:
                if member.size <= CHUNK:
                    value = stream.read()
                    metadata[member.name] = value
                    diff, unpacked = hashlib.sha256(value).hexdigest(), len(value)
                else:
                    diff, unpacked = hash_stream(stream)
                encoding = 'identity'
            require(reader.size == member.size, 'Incomplete saved-image member')
            raw_sha = reader.digest.hexdigest()
            match = re.fullmatch(r'blobs/sha256/([0-9a-f]{64})', member.name)
            if match:
                require(raw_sha == match.group(1), 'Saved image blob digest differs from its name')
            members[member.name] = {'sha256': raw_sha, 'size': reader.size,
                                    'diff_id': 'sha256:' + diff, 'uncompressed_size': unpacked,
                                    'encoding': encoding}
    manifest = json.loads(metadata['manifest.json'])
    require(len(manifest) == 1, 'Expected exactly one saved image')
    entry = manifest[0]
    require(entry['RepoTags'] == ['pystachy:release-test-' + arch], 'Wrong tested image tag')
    config_bytes = metadata[entry['Config']]
    config = json.loads(config_bytes)
    labels = config['config']['Labels']
    require(config['os'] == 'linux' and config['architecture'] == arch, 'Wrong saved-image architecture')
    require(labels['org.opencontainers.image.version'] == VERSION and labels['org.opencontainers.image.revision'] == COMMIT, 'Wrong saved-image release labels')
    require(config['config']['WorkingDir'] == '/work' and config['config']['Entrypoint'] == ['/usr/local/bin/pystachy'], 'Wrong installed container interface')
    layers = [members[name] for name in entry['Layers']]
    require(config['rootfs']['type'] == 'layers' and [row['diff_id'] for row in layers] == config['rootfs']['diff_ids'], 'Saved layer bytes differ from config rootfs identities')
    return {'config_digest': 'sha256:' + hashlib.sha256(config_bytes).hexdigest(),
            'architecture': arch, 'os': 'linux', 'version': VERSION, 'commit': COMMIT,
            'config': config, 'layers': layers, 'layer_names': entry['Layers'],
            'all_saved_blob_names_match_bytes': True, 'all_decompressed_layer_diff_ids_match': True}


def evidence_paths(arch):
    name = 'container-linux-' + arch
    target = 'linux-x86_64' if arch == 'amd64' else 'linux-aarch64'
    return {'log': ROOT/'workflow-logs'/(name+'.log'), 'job': ROOT/'workflow-logs'/(name+'.job.json'),
            'retrieval': ROOT/('artifact-'+name+'-retrieval.json'),
            'binary_receipt': ROOT/'independent-audits'/('binary-'+target+'.json')}


def bind_run_id(architectures, asserted_run_id):
    # Bind only to supplied completed component evidence. No API calls or polling.
    # Preflight every requested component before writing any acceptance receipt.
    first_path = evidence_paths(architectures[0])['job']
    first = json.loads(first_path.read_bytes())
    first_job = first['job']
    require(first_job['status'] == 'completed' and first_job['conclusion'] == 'success',
            'First requested container job is not complete and successful')
    run_id = first['run_id']
    require(type(run_id) is int and run_id > 0, 'Invalid completed container run identity')
    if asserted_run_id is not None:
        require(asserted_run_id == run_id, 'Explicit run ID differs from completed job evidence')
    for arch in architectures:
        paths = evidence_paths(arch)
        wrapper = json.loads(paths['job'].read_bytes())
        retrieval = json.loads(paths['retrieval'].read_bytes())
        binary = json.loads(paths['binary_receipt'].read_bytes())
        job = wrapper['job']
        require(wrapper['run_id'] == job['run_id'] == run_id,
                'Requested job wrapper does not share the bound run ID')
        require(retrieval['workflow_run']['id'] == run_id,
                'Requested artifact retrieval does not share the bound run ID')
        require(binary['run_id'] == run_id,
                'Requested binary audit does not share the bound run ID')
        require(job['status'] == 'completed' and job['conclusion'] == 'success',
                'A requested container job is not complete and successful')
    return run_id


def audit(arch, run_id):
    name = 'container-linux-' + arch
    target = 'linux-x86_64' if arch == 'amd64' else 'linux-aarch64'
    paths = evidence_paths(arch)
    raw = {key: path.read_bytes() for key, path in paths.items()}
    inputs = {key: {'path': str(paths[key]), 'sha256': hashlib.sha256(value).hexdigest(), 'bytes': len(value)} for key, value in raw.items()}
    wrapper, receipt, binary = (json.loads(raw[key]) for key in ('job', 'retrieval', 'binary_receipt'))
    job = wrapper['job']
    require(wrapper['source'] == job['head_sha'] == COMMIT and wrapper['run_id'] == job['run_id'] == run_id, 'Wrong job/source')
    require(job['name'] == f'Container (linux/{arch})' and job['head_branch'] == 'main' and job['status'] == 'completed' and job['conclusion'] == 'success', 'Container job is not complete and successful')
    require(job['labels'] == [('ubuntu-24.04' if arch == 'amd64' else 'ubuntu-24.04-arm')], 'Wrong native runner')
    require(all(step['status'] == 'completed' and step['conclusion'] == 'success' for step in job['steps']), 'A container step did not succeed')
    seconds = (datetime.fromisoformat(job['completed_at']) - datetime.fromisoformat(job['started_at'])).total_seconds()
    require(0 < seconds <= 900, 'Container job exceeded the 15-minute cap')
    require(binary['status'] == 'passed_component_only' and binary['commit'] == COMMIT and binary['run_id'] == run_id and binary['target'] == target, 'Binary evidence mismatch')
    rows = []
    for i, line in enumerate(raw['log'].decode('utf-8-sig').splitlines(), 1):
        if 'Z ' in line:
            stamp, text = line.split('Z ', 1)
        else:
            require(rows, 'Unexpected log preamble')
            stamp, text = rows[-1]['timestamp'][:-1], line
        rows.append({'line': i, 'timestamp': stamp+'Z', 'text': re.sub(r'\x1b\[[0-9;]*m', '', text)})
    require(not any(row['text'].startswith('##[error]') for row in rows), 'Actions error in log')
    evidence = {}

    def one(label, pattern):
        found = [row for row in rows if re.fullmatch(pattern, row['text'])]
        require(len(found) == 1, 'Missing or duplicate executed result: '+label)
        evidence[label] = found[0]
        return re.fullmatch(pattern, found[0]['text'])

    one('verified_native_archive', re.escape(f'pystachy-{VERSION}-{target}.tar.gz: OK'))
    one('verified_binary_download', re.escape('SHA256 digest of downloaded artifact is '+binary['artifact']['zip_sha256_matches_upload_log_and_retrieval']))
    one('unprivileged_exact_version', re.escape(f'pystachy {VERSION} (commit {COMMIT}): installed and native --version passed without LLVM'))
    smoke = 'installed JIT/AOT smoke: passed (fnmatch, lru_cache, textwrap, arguments, JSON, Unicode indexing)'
    one('unprivileged_jit_aot', re.escape(smoke))
    one('bind_mount_jit_output', '332833500')
    one('python_free_image_build', r'#\d+ \[runtime 3/4\] RUN .*&& ! command -v python3     && pystachy-smoke')
    one('image_build_jit_aot', r'#\d+ [0-9.]+ '+re.escape(smoke))
    required_commands = [
        'docker run --rm --user 10001:10001 --entrypoint pystachy-smoke "pystachy:release-test-$RELEASE_ARCH"',
        'test "$(docker image inspect "pystachy:release-test-$RELEASE_ARCH" --format \'{{.Os}}/{{.Architecture}}\')" = "linux/$RELEASE_ARCH"',
        'test "$(build/container-smoke/demo)" = 332833500',
    ]
    for number, command in enumerate(required_commands):
        one('successful_step_assertion_'+str(number), re.escape(command))
    require(sum(row['text'] == 'docker run --rm --user 10001:10001 -v "$PWD/build/container-smoke:/work" \\' for row in rows) == 2, 'Missing UID 10001 bind-mount executions')
    require(receipt['phase'] == 'artifact' and receipt['status'] == 'passed' and receipt['version'] == VERSION and receipt['expected_commit'] == COMMIT and receipt['name'] == name, 'Artifact receipt mismatch')
    require(receipt['workflow_run']['id'] == run_id and receipt['workflow_run']['head_sha'] == COMMIT, 'Artifact run/source mismatch')
    zip_path = Path(receipt['zip'])
    zip_sha, zip_size = hash_file(zip_path)
    require(zip_sha == receipt['sha256'], 'Container ZIP digest mismatch')
    one('uploaded_image_zip_digest', re.escape('SHA256 digest of uploaded artifact is '+zip_sha))
    inputs['zip'] = {'path': str(zip_path), 'sha256': zip_sha, 'bytes': zip_size}
    image_name = f'pystachy-image-{arch}.tar.gz'
    image_path = ROOT/'tested'/name/image_name
    image_sha, image_size = hash_file(image_path)
    sidecar = image_path.with_name(image_name+'.sha256').read_bytes()
    require(sidecar.decode() == f'{image_sha}  {image_name}\n', 'Saved image sidecar checksum mismatch')
    inputs['saved_image'] = {'path': str(image_path), 'sha256': image_sha, 'bytes': image_size}
    with zipfile.ZipFile(zip_path) as archive:
        require(set(archive.namelist()) == {image_name, image_name+'.sha256'} and len(archive.namelist()) == 2, 'Container ZIP inventory mismatch')
        require(archive.read(image_name+'.sha256') == sidecar, 'Extracted checksum differs from uploaded ZIP')
        with archive.open(image_name) as stream:
            require(hash_stream(stream) == (image_sha, image_size), 'Extracted image differs from uploaded ZIP')
    identity = saved_image(image_path, arch)
    one('exported_image_config', r'#\d+ exporting config '+re.escape(identity['config_digest'])+' done')
    source_hashes = {name: hashlib.sha256(subprocess.check_output(['git', 'show', COMMIT+':'+name], cwd=REPO)).hexdigest()
                     for name in ['.github/workflows/release.yml', 'Dockerfile', 'tools/docker_smoke.sh', 'tools/release_images.py']}
    for key, path in paths.items():
        require(path.read_bytes() == raw[key], 'Evidence changed during audit')
    result = {'kind': 'Independent incremental native container release audit', 'status': 'passed_component_only',
              'created_utc': datetime.now(timezone.utc).isoformat(), 'version': VERSION, 'commit': COMMIT, 'run_id': run_id,
              'job_id': job['id'], 'job_url': job['html_url'], 'architecture': arch, 'job_seconds': seconds,
              'inputs': inputs, 'executed_evidence': evidence, 'reviewed_source_sha256': source_hashes, 'tested_image': identity,
              'native_execution_confirmed_from_runner_logs': True, 'uid_10001_and_bind_mount_assertions_passed': True,
              'actual_saved_image_architecture_matches_native_runner': True,
              'full_workflow_or_publication_success_claimed': False,
              'scope': 'Completed container component only. Config digest matches the actual build-export log; all saved layer bytes, blob digests and decompressed rootfs diff_ids are verified in a single forward pass. Assertion commands are distinguished from execution output and paired with successful job-step conclusions. No Docker invocation, payload execution, network requests, compiler or test reruns.'}
    output = ROOT/'independent-audits'/(name+'.json')
    with output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'architecture': arch, 'status': result['status'], 'receipt': str(output),
                      'receipt_sha256': hash_file(output)[0], 'config_digest': identity['config_digest'],
                      'layers': len(identity['layers']), 'image_sha256': image_sha}), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--architectures', nargs='+', choices=('amd64', 'arm64'),
                        default=['amd64', 'arm64'],
                        help='Completed container components to audit (default: both)')
    parser.add_argument('--run-id', type=int,
                        help='Optional assertion of the run ID derived from completed job evidence')
    args = parser.parse_args()
    require(len(set(args.architectures)) == len(args.architectures),
            'Duplicate requested container architecture')
    require(args.run_id is None or args.run_id > 0, 'Explicit run ID must be positive')
    run_id = bind_run_id(args.architectures, args.run_id)
    for architecture in args.architectures:
        audit(architecture, run_id)


if __name__ == '__main__':
    main()
