# Alpha.2 PyPI publisher tooling review

**Passed for the scoped publisher comparison.** The approved publisher at `6e5544cfa3eecb8329e4f4cb19d2e0ac3e99b1bf` has byte-identical PyPI build and publication jobs to both the published alpha.1 source `a73c56c92f3aad4b490307a5d1b882e487a57f55` and alpha.2 source `80490143498d149d407343ba1cb7aedb1db2d2c5`. A fresh read of `refs/heads/release/pypi-v0.2.0` still resolves to that approved publisher revision.

| Checked bytes | Result |
|---|---|
| Workflow trigger, inputs, concurrency and global permissions | Identical across all three revisions |
| `pypi-build`, 3,620 bytes | Identical; SHA-256 `39fa4946d9ef8d1be779938e25daaf5a693ad2f3afe981012215c5da8d460686` |
| `pypi-publish`, 867 bytes | Identical; SHA-256 `08dc7d8059d5ecf5ef3f1770fe977d6ffcad0bc0c185bfb2b8284f1c545837b4` |
| `tools/pypi_release.py` and `tools/release_gate.py` | Identical across all three revisions |
| All four compared files between alpha.1 and alpha.2 | Identical |

The complete workflow is intentionally reported as **different** from the publisher. The only changed jobs are native `prepare` and `publish`: the newer source adds release-note checking and uses the release-note render helper. PyPI mode excludes native preparation; the binary, container and native publication jobs depend on that excluded job. The original whole-file comparison diagnostic is retained. Its failure was a local comparison assumption, not a publication attempt or failure.

## The requested tag supplies package metadata and source

The first checkout supplies the approved publisher tools. The second checkout fetches `refs/tags/${{ inputs.version }}` into `source` with full history. The `uv build` step explicitly runs in `source`, so its `pyproject.toml`, dynamic version from `VERSION`, setuptools configuration and package files come from that release tag. Python selection, pinned packaging requirements, LLVM setup and the installed-package smoke helper also use paths under `source`.

The publisher's older `pyproject.toml` omits `lljit.c`. That is the only difference from either alpha's package configuration, and that older project is outside the build working directory. As a direct retained-artifact check, alpha.1's tested source distribution contains the exact alpha.1 tag `pyproject.toml`, which is also identical to alpha.2's configuration. Both its wheel and source distribution include `lljit.c` byte-identical to the alpha.1 Git blob. Both distribution metadata files identify version `0.5.0a1`.

The unchanged gate requires a clean full checkout, matching requested tag and `VERSION`, origin/main ancestry, a published non-draft GitHub release resolving to the exact source commit, and successful exact-main workflows. It then validates the two distribution names, archive paths and package metadata. Strict Twine and clean pip/uv JIT/AOT checks precede artifact upload. Publication downloads that same run's artifact and verifies its recorded checksums before using Trusted Publishing.

## Existing publisher and permission scope

Completed alpha.1 Release run [43621120891](https://github.com/den-run-ai/pystachy/actions/runs/43621120891) used this same publisher revision and branch. Its two PyPI jobs succeeded and its four native jobs were skipped. Retained `SOURCE.json` binds publisher `6e5544c...` separately from tag source `a73c56c...`. The retained independent alpha.1 distribution audit establishes equality between tested and public package bytes; this review rechecks the retained package metadata and selected source bindings without repeating installations.

The existing declarations remain unchanged: global `contents: read`; PyPI build `contents: read` and `actions: read`; PyPI publication `id-token: write`; environment `pypi`; 15-minute build and 10-minute publication caps; checkout credential persistence disabled. This comparison requires no branch, permission or environment changes. Administrative settings were neither queried nor modified.

**Publication prerequisite remains in force:** alpha.2 PyPI dispatch must wait for the native GitHub release to be published and its artifacts independently verified. This receipt covers source equivalence and retained evidence only; it does not establish that prerequisite. No release was dispatched, and no build, installation, compiler execution or test was performed for this review.

The companion JSON records immutable source hashes and all inspected evidence hashes. The independent source diff, current publisher-ref response and review script are retained beside it. JSON SHA-256: `b13b58e7e21eb87e168af0c63c2ddd67d1cd5805328b06e143b4f45f06065193`.
