"""Final evidence-only alpha2 native publication audit; no payload or network execution."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'alpha2'
VERSION = 'v0.5.0-alpha.2'
COMMIT = '80490143498d149d407343ba1cb7aedb1db2d2c5'
TREE = '717a8c9386ae9f5f6545cc3686a9e22282fc560c'
RUN = 43626857296
TARGETS = ('linux-x86_64', 'linux-aarch64', 'macos-arm64', 'macos-x86_64')
ARCHES = ('amd64', 'arm64')
inputs = {}

def require(value, message):
    if not value:
        raise RuntimeError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    path = Path(path)
    data = path.read_bytes()
    row = {'sha256': sha(data), 'bytes': len(data)}
    require(str(path) not in inputs or inputs[str(path)] == row, 'Input changed: ' + str(path))
    inputs[str(path)] = row
    return data

def js(path):
    return json.loads(read(path))

def source(name):
    data = read(REPO / name)
    require(data == subprocess.check_output(['git', '-C', str(REPO), 'show', COMMIT + ':' + name]),
            'Source differs from exact commit: ' + name)
    return data

require(subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', COMMIT + '^{tree}']).decode().strip() == TREE,
        'Source tree differs')
source_hashes = {name: sha(source(name)) for name in
    ('.github/workflows/release.yml', 'tools/release_gate.py', 'tools/release_images.py',
     'tools/release_notes.py', 'docs/releases/' + VERSION + '.md', 'VERSION')}
require(source('VERSION').decode().strip() == VERSION, 'Source version differs')
complete = js(ROOT / 'native-workflow-complete.json')
run = complete['run']
require(complete['source'] == run['head_sha'] == COMMIT and run['id'] == RUN and
        run['name'] == 'Release' and run['head_branch'] == 'main' and run['event'] == 'workflow_dispatch' and
        run['status'] == 'completed' and run['conclusion'] == 'success' and run['run_attempt'] == 1,
        'Native workflow did not complete successfully on exact main')
jobs = {job['name']: job for job in complete['jobs']}
expected_jobs = {'prepare', 'publish', 'Verify PyPI source packages', 'Publish verified packages to PyPI'}
expected_jobs |= {f'Binary ({target})' for target in TARGETS} | {f'Container (linux/{arch})' for arch in ARCHES}
require(len(jobs) == len(complete['jobs']) == 10 and set(jobs) == expected_jobs, 'Wrong job inventory')
skip_names = {'Verify PyPI source packages', 'Publish verified packages to PyPI'}
durations = {}
for name, job in jobs.items():
    require(job['run_id'] == RUN and job['head_sha'] == COMMIT and job['status'] == 'completed' and
            job['conclusion'] == ('skipped' if name in skip_names else 'success'), 'Unexpected job result: ' + name)
    if name not in skip_names:
        seconds = (datetime.fromisoformat(job['completed_at']) - datetime.fromisoformat(job['started_at'])).total_seconds()
        require(0 < seconds <= 900, 'Job exceeds 15 minutes: ' + name)
        durations[name] = seconds
require(dict(Counter(j['conclusion'] for j in jobs.values())) == complete['outcomes'] == {'success': 8, 'skipped': 2}
        and max(durations.values()) == complete['max_job_seconds'] == 683, 'Workflow summary differs')

frozen = {
    'prepare.json': '1d53f1d75cf5688f739ce4415d2d9dbf23650a9fb805b850e55fdb72ebfd3954',
    'four-binaries.json': '8152ad5660cb8fe021c66e4fe6f863e3b6c28e5083997dc0f6e92148f7ea12a1',
    'two-containers.json': 'e4c615f43b5f13f3c61741d390c59f42dc208cb4f0a00cd075d59d9a69eb4f17',
    'binary-linux-x86_64.json': '81615a12307506d8eff71ff0f5c5832edc2f9e75ad6c4c711255207af117e0ff',
    'binary-linux-aarch64.json': '250218e947388c888468e55fef19303cf8c2131b944d0d0767615b723af9765f',
    'binary-macos-arm64.json': '81d782d61e4739db9b255bec462b7c2ab46496a986a7b28fa497f19adfec2966',
    'binary-macos-x86_64.json': '259f4c86353a1f1015404f1d96f1562bfc5c7165bb14ea718084afa76e6fac75',
    'container-linux-amd64.json': 'ac163d07d920bc12ea99cc584cf86ce94f9152b3511a8035401d643c720f08de',
    'container-linux-arm64.json': '804761a3cd735a69dc09b7262b646927ed74a512d5917a84d61d57621a229b2e',
}
components = {}
for name, expected_sha in frozen.items():
    data = read(ROOT / 'independent-audits' / name)
    require(sha(data) == expected_sha, 'Frozen component acceptance changed: ' + name)
    components[name] = json.loads(data)
binary = {target: components['binary-' + target + '.json'] for target in TARGETS}
container = {arch: components['container-linux-' + arch + '.json'] for arch in ARCHES}
for name, audit in list((f'Binary ({t})', r) for t, r in binary.items()) + list((f'Container (linux/{a})', r) for a, r in container.items()):
    require(audit['status'] == 'passed_component_only' and audit['commit'] == COMMIT and audit['run_id'] == RUN and
            audit['version'] == VERSION and audit['job_id'] == jobs[name]['id'] and audit['job_seconds'] == durations[name],
            'Component differs from complete workflow: ' + name)
    wrapper = js(Path(audit['inputs']['job']['path']))
    require(wrapper['job'] == jobs[name], 'Component job metadata changed: ' + name)

publisher_wrapper = js(ROOT / 'workflow-logs/publish.job.json')
publisher = publisher_wrapper['job']
require(publisher_wrapper['source'] == COMMIT and publisher_wrapper['run_id'] == RUN and
        publisher == jobs['publish'] and publisher['id'] == 132548740591, 'Publisher metadata differs')
stable_steps = {'Determine whether to advance latest', 'Update latest for newer stable releases'}
for step in publisher['steps']:
    require(step['status'] == 'completed' and step['conclusion'] == ('skipped' if step['name'] in stable_steps else 'success'),
            'Unexpected publication step result')
rows = []
for number, line in enumerate(read(ROOT / 'workflow-logs/publish.log').decode('utf-8-sig').splitlines(), 1):
    if 'Z ' in line:
        stamp, text = line.split('Z ', 1)
        stamp += 'Z'
    else:
        require(rows, 'Unexpected log preamble')
        stamp, text = rows[-1]['timestamp'], line
    rows.append({'line': number, 'timestamp': stamp, 'text': re.sub(r'\x1b\[[0-9;]*m', '', text)})
require(not any(row['text'].startswith('##[error]') for row in rows), 'Publication logged an error')
markers = {}
def one(name, pattern):
    matches = [row for row in rows if re.fullmatch(pattern, row['text'])]
    require(len(matches) == 1, 'Missing or ambiguous actual publication output: ' + name)
    markers[name] = matches[0]

one('exact_main_gates_rechecked', re.escape('CI: success, Installation: success, Lint: success, Packages: success'))
one('docker_published', r'Published \S+/pystachy:' + re.escape(VERSION) + r': linux/amd64 and linux/arm64')
release_url = 'https://github.com/den-run-ai/pystachy/releases/tag/' + VERSION
one('github_published', re.escape(release_url))
for target, audit in binary.items():
    one('download_' + target, re.escape('SHA256 digest of downloaded artifact is ' + audit['artifact']['zip_sha256_matches_upload_log_and_retrieval']))
    one('checksum_' + target, re.escape(f'pystachy-{VERSION}-{target}.tar.gz: OK'))
for arch, audit in container.items():
    one('download_' + arch, re.escape('SHA256 digest of downloaded artifact is ' + audit['inputs']['zip']['sha256']))
    one('checksum_' + arch, re.escape(f'pystachy-image-{arch}.tar.gz: OK'))
    one('loaded_' + arch, re.escape('Loaded image: pystachy:release-test-' + arch))
require(any(rows[i]['text'] == '[command]/usr/bin/git log -1 --format=%H' and rows[i + 1]['text'] == COMMIT
            for i in range(len(rows) - 1)), 'Publisher checkout identity absent')

release = js(ROOT / 'public-release-api.json')
tag = js(ROOT / 'public-tag-api.json')
native = js(ROOT / 'native-retrieval.json')
retrieved_release = js(ROOT / 'native-metadata/release.json')
retrieved_tag = js(ROOT / 'native-metadata/tag.json')
for public in (release, retrieved_release):
    require(public['tag_name'] == VERSION and public['target_commitish'] == COMMIT and
            public['draft'] is False and public['prerelease'] is True and public['html_url'] == release_url and
            public['id'] == 445512234 and public['published_at'], 'Public release identity differs')
for public in (tag, retrieved_tag):
    require(public['sha'] == COMMIT and public['commit']['tree']['sha'] == TREE, 'Public tag source/tree differs')
require(native['phase'] == 'native' and native['status'] == 'passed' and native['version'] == VERSION and
        native['expected_commit'] == native['tag_commit'] == COMMIT and native['release_url'] == release_url,
        'Public native retrieval failed or identifies different source')
expected_assets = {'SHA256SUMS', 'linux-abi-linux-x86_64.json', 'linux-abi-linux-aarch64.json'}
expected_assets |= {f'pystachy-{VERSION}-{target}.tar.gz' + suffix for target in TARGETS for suffix in ('', '.sha256')}
assets = {entry['name']: entry for entry in release['assets']}
require(len(assets) == len(release['assets']) == 11 and set(assets) == expected_assets == set(native['public_assets']),
        'Public asset inventory differs')
require({(a['name'], a['id'], a['digest'], a['size']) for a in retrieved_release['assets']} ==
        {(a['name'], a['id'], a['digest'], a['size']) for a in release['assets']}, 'Public metadata snapshots differ')
public_assets = {}
for name, metadata in assets.items():
    content = read(ROOT / 'native' / name)
    measured_sha = sha(content)
    recorded = native['public_assets'][name]
    require(metadata['state'] == 'uploaded' and metadata['digest'] == 'sha256:' + measured_sha and
            metadata['size'] == len(content) == recorded['size'] and recorded['sha256'] == measured_sha and
            metadata['id'] == recorded['asset_id'] and metadata['browser_download_url'] ==
            f'https://github.com/den-run-ai/pystachy/releases/download/{VERSION}/{name}', 'Public asset bytes/API identity differs')
    if name != 'SHA256SUMS':
        tested = Path(recorded['tested_artifact'])
        require(tested.is_relative_to(ROOT / 'tested') and read(tested) == content, 'Public asset differs from tested payload')
    public_assets[name] = {'sha256': measured_sha, 'size': len(content), 'asset_id': metadata['id'], 'url': metadata['browser_download_url']}
sums = {}
for line in read(ROOT / 'native/SHA256SUMS').decode().splitlines():
    match = re.fullmatch(r'([0-9a-f]{64})  (?:\./)?([^/]+)', line)
    require(match and match[2] not in sums, 'Malformed/duplicate aggregate checksum')
    sums[match[2]] = match[1]
require(set(sums) == {f'pystachy-{VERSION}-{target}.tar.gz' for target in TARGETS}, 'Checksum inventory differs')
for target, audit in binary.items():
    archive = f'pystachy-{VERSION}-{target}.tar.gz'
    require(sums[archive] == public_assets[archive]['sha256'] == audit['artifact']['native_archive_sha256'],
            'Public archive differs from independently accepted binary')
    require(read(ROOT / 'native' / (archive + '.sha256')).decode() == f'{sums[archive]}  {archive}\n', 'Public checksum sidecar differs')
version_check = js(ROOT / 'public-native-version.json')
require(version_check['status'] == 'passed' and version_check['version'] == VERSION and version_check['source'] == COMMIT and
        version_check['archive'] == f'pystachy-{VERSION}-linux-x86_64.tar.gz' and
        version_check['sha256'] == sums[version_check['archive']] and version_check['returncode'] == 0 and
        version_check['stdout'] == f'pystachy {VERSION} (commit {COMMIT})\n' and version_check['stderr'] == '' and
        version_check['python_optimize'] == 0, 'Public downloaded launcher version probe failed')

docker = js(ROOT / 'docker-retrieval.json')
require(docker['phase'] == 'docker' and docker['status'] == 'passed' and docker['version'] == VERSION and
        docker['expected_commit'] == COMMIT and set(docker['platforms']) == set(ARCHES), 'Public Docker metadata receipt differs')
index_raw = read(ROOT / 'docker/index.json')
index = json.loads(index_raw)
require('sha256:' + sha(index_raw) == docker['index_digest'] and index['schemaVersion'] == 2 and
        index['mediaType'] in ('application/vnd.docker.distribution.manifest.list.v2+json', 'application/vnd.oci.image.index.v1+json') and
        len(index['manifests']) == 2, 'Public index digest/inventory differs')
descriptors = {d['platform']['architecture']: d for d in index['manifests']}
require(set(descriptors) == set(ARCHES) and all(d['platform']['os'] == 'linux' for d in descriptors.values()), 'Wrong public native platforms')
layer_rows = []
platforms = {}
for arch in ARCHES:
    manifest_raw = read(ROOT / 'docker' / f'manifest-{arch}.json')
    manifest = json.loads(manifest_raw)
    config_raw = read(ROOT / 'docker' / f'config-{arch}.json')
    config = json.loads(config_raw)
    desc = descriptors[arch]
    require(desc['digest'] == 'sha256:' + sha(manifest_raw) == docker['platforms'][arch]['manifest_digest'] and
            desc['size'] == len(manifest_raw) and read(ROOT / 'docker' / f'tag-{arch}.json') == manifest_raw,
            'Versioned platform manifest differs')
    require(manifest['schemaVersion'] == 2 and manifest['config']['digest'] == 'sha256:' + sha(config_raw) ==
            docker['platforms'][arch]['config_digest'] == container[arch]['tested_image']['config_digest'] and
            manifest['config']['size'] == len(config_raw), 'Public configuration identity differs')
    require(config == container[arch]['tested_image']['config'] and config['os'] == 'linux' and config['architecture'] == arch,
            'Public configuration differs from tested native image')
    require(config['config']['Labels']['org.opencontainers.image.version'] == VERSION and
            config['config']['Labels']['org.opencontainers.image.revision'] == COMMIT, 'Public release labels differ')
    tested = docker['tested_images'][arch]
    require(tested['archive_sha256'] == container[arch]['inputs']['saved_image']['sha256'] and
            tested['config_digest'] == container[arch]['tested_image']['config_digest'] and
            tested['diff_ids'] == config['rootfs']['diff_ids'], 'Tested/public saved-image binding differs')
    require(len(manifest['layers']) == len(config['rootfs']['diff_ids']) == 7, 'Incomplete layer inventory')
    for position, (layer, diff_id) in enumerate(zip(manifest['layers'], config['rootfs']['diff_ids'], strict=True)):
        require(layer['mediaType'] == 'application/vnd.docker.image.rootfs.diff.tar.gzip', 'Unsupported layer encoding')
        layer_rows.append({'architecture': arch, 'position': position, 'digest': layer['digest'],
                           'compressed_size': layer['size'], 'media_type': layer['mediaType'], 'encoding': 'gzip',
                           'expected_diff_id': diff_id, 'status': 'passed'})
    platforms[arch] = {'manifest_digest': desc['digest'], 'config_digest': manifest['config']['digest'],
                       'layer_count': 7, 'diff_ids': config['rootfs']['diff_ids']}

layers_path = ROOT.parent / 'release-alpha2-public-layers/docker-public-layers.json'
layers = js(layers_path)
require(layers['phase'] == 'docker-public-layers' and layers['status'] == 'passed' and layers['current_step'] == 'complete' and
        layers['version'] == VERSION and layers['expected_commit'] == COMMIT and layers['image'] == 'dta67/pystachy' and
        layers['public_layers_downloaded'] is True and layers['local_container_execution'] is False,
        'Public layer verification did not complete successfully')
require(layers['metadata_retrieval'] == str(ROOT / 'docker-retrieval.json') and layers['index_digest'] == docker['index_digest'] and
        layers['platforms'] == platforms and layers['layers'] == layer_rows, 'Public layer receipt has different metadata/references')
unique = {row['digest']: row for row in layer_rows}
require(set(layers['verified_blobs']) == set(unique) and len(unique) == layers['unique_layers'] == 11 and
        len(layer_rows) == layers['layer_references'] == 14 and
        sum(row['compressed_size'] for row in unique.values()) == layers['expected_download_bytes'] == 407152903,
        'Public layer download counts or byte totals differ')
for row in layer_rows:
    blob = layers['verified_blobs'][row['digest']]
    saved = container[row['architecture']]['tested_image']['layers'][row['position']]
    require(blob['digest'] == row['digest'] and blob['compressed_size'] == row['compressed_size'] and
            blob['encoding'] == 'gzip' and blob['diff_id'] == row['expected_diff_id'] == saved['diff_id'] and
            blob['uncompressed_size'] == saved['uncompressed_size'] and blob['downloaded_from_public_registry'] is True,
            'Downloaded layer verification differs from public manifest/tested image')
for path, identity in layers['inputs'].items():
    data = read(Path(path))
    require(identity == {'sha256': 'sha256:' + sha(data), 'size': len(data)}, 'Layer verifier inputs changed')
require(sha(read(ROOT.parent / 'artifact-audit/verify_public_layers.py')) ==
        '3ddf1a5cff2a9d756938efce794adbc084453e19029f9353f100366aee1e5a4b', 'Reviewed layer verifier changed')
for path, key in [(Path('/workspace/scratch/c66a10c5a7b1/artifact-audit/retrieve.py'), 'retriever_sha256'),
                  (Path('/workspace/scratch/c66a10c5a7b1/artifact-audit/verify.py'), 'offline_verifier_sha256')]:
    value = sha(read(path))
    require(native[key] == docker[key] == value, 'Public retrieval helper changed')

lean = js(ROOT.parent / 'alpha2-independent-review/alpha2-final-lean-independent-audit.json')
equivalence = js(ROOT.parent / 'alpha2-independent-review/alpha2-release-tree-independent-audit.json')
main_gates = js(ROOT.parent / 'alpha2-exact-main-gates/report.json')
require(lean['status'] == equivalence['status'] == main_gates['status'] == 'passed' and
        lean['source_tree'] == equivalence['identical_complete_git_tree'] == main_gates['source_tree'] == TREE and
        equivalence['release_main_commit'] == main_gates['source_sha'] == COMMIT and
        equivalence['complete_lean_evidence_applies_to_release_main_tree'] and
        main_gates['all_seven_applicable_push_workflows_complete_and_successful'], 'Qualification/source binding differs')
for path in list(inputs):
    read(Path(path))
receipt = {'kind': 'Independent final native and Docker release acceptance', 'status': 'passed_native_and_docker',
    'created_utc': datetime.now(timezone.utc).isoformat(), 'version': VERSION, 'commit': COMMIT, 'source_tree': TREE,
    'native_release_url': release_url, 'native_release_id': release['id'], 'native_published_at': release['published_at'],
    'prerelease': True, 'run_id': RUN, 'run_url': run['html_url'], 'workflow_outcomes': complete['outcomes'],
    'max_job_seconds': max(durations.values()), 'publish_job_id': publisher['id'], 'inputs': inputs,
    'reviewed_source_sha256': source_hashes, 'publish_log_evidence': markers,
    'public_native_assets': public_assets, 'public_native_assets_downloaded_and_byte_equal_to_tested': True,
    'public_native_exact_version_probe': version_check,
    'docker': {'image': 'dta67/pystachy:' + VERSION, 'index_digest': docker['index_digest'], 'platforms': platforms,
               'all_public_configs_equal_tested_native_images': True, 'all_public_layers_downloaded': True,
               'verified_unique_blobs': 11, 'verified_layer_references': 14, 'downloaded_compressed_bytes': 407152903,
               'all_downloaded_blob_hash_size_diff_id_records_match_tested_images': True},
    'stable_promotion_steps_skipped': True,
    'qualification_binding': {'complete_lean_receipt_status': lean['status'], 'complete_lean_programs': lean['complete_programs'],
                              'exact_main_gates_status': main_gates['status'], 'candidate_to_release_tree_equal': True},
    'pypi_acceptance': 'Separate publication and install evidence required; not claimed by this receipt.',
    'stable_pointer_comparison': 'Final independent public stable-pointer comparison is separate; native publication promotion steps are confirmed skipped.',
    'scope': 'Independent saved-evidence audit. Public native asset bytes were rehashed and compared with tested files. Existing frozen component audits supply binary/container execution and saved-image checks. Public layer receipts and their reviewed verifier/source bindings were audited; downloaded blobs were verified by the handed-off one-shot verifier. No redundant saved-image reads, compiler, workload, Docker, network, download, test or polling execution.'}
output = ROOT / 'independent-audits/native-docker-final.json'
with output.open('x') as stream:
    stream.write(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': receipt['status'], 'path': str(output), 'sha256': sha(output.read_bytes()),
                  'public_assets': len(public_assets), 'unique_public_blobs': len(unique)}))
