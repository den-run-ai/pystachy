# Completed gates and independent reviews

Alpha.1 exact-main CI, Installation, Lint, Packages and Performance smoke pass at a73c56c92f3aad4b490307a5d1b882e487a57f55. The retained performance artifact compares the pre-repair main commit 7cb962f03c46c4b015d8e5a69f5aa759c2fa4e7e to this repaired commit: 49 measured comparisons across 11 workloads are classified ok. This is bounded shared-host smoke evidence, not a general speed claim.

Two independent source reviews at alpha.2 head 950c0440ad793dc6c34664f591383a5e6bba14dd found no actionable findings. GitHub Codex attempts did not complete and the local CLI failed before review. The independent source reviews are separate evidence and do not turn those failed attempts into completed automated reviews.

Six LLVM smoke continuity comparisons passed against the qualified compiler sources; historical timings remain historical. Raw report inputs and hashes are retained.

The full post-repair Lean censuses and all publication/artifact checks remain pending at this checkpoint. This bundle is not a publication receipt.
