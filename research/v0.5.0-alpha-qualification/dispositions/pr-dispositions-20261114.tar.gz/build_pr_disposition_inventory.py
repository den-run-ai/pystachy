#!/usr/bin/env python3
"""Scope-only PR inventory from captured metadata; no network or repository edits."""
import collections, datetime, hashlib, json, pathlib, re, subprocess

R=pathlib.Path('/workspace/scratch/7dd0519bc14a/release-bookkeeping')
REPO='/workspace/scratch/7dd0519bc14a/alpha2'
A1='a73c56c92f3aad4b490307a5d1b882e487a57f55'
A2='80490143498d149d407343ba1cb7aedb1db2d2c5'
CANDIDATE='950c0440ad793dc6c34664f591383a5e6bba14dd'
A1_IDS={1470,1440,1443,1293,1278,1386,1387,1410,1428,1429,1339,1492}
A2_IDS={1277,1415,1280,1281,1282,1298,1274,1377,1488}
ORIGINAL19=(A1_IDS-{1492})|(A2_IDS-{1488})
read=lambda n:json.loads((R/n).read_text())
opens=read('open-prs-final-metadata-snapshot.json')
closed=read('selected-closed-prs-final-metadata-snapshot.json')
independent=read('later-alpha-roadmap-independent.json')
closures=read('alpha1-closed-included-prs.json')
prs={p['number']:p for p in opens['prs']+closed['prs']}
supplement=prs.pop(1481)
assert len(prs)==180 and len(opens['prs'])==162 and len(ORIGINAL19)==19

def git(*a):
    return subprocess.check_output(['git','-C',REPO,*a],text=True).strip()
assert git('rev-parse','--is-shallow-repository')=='false'
trees={s:git('rev-parse',s+'^{tree}') for s in [A1,A2,CANDIDATE]}
assert trees[A2]==trees[CANDIDATE]=='717a8c9386ae9f5f6545cc3686a9e22282fc560c'
reachable={s:set(git('rev-list',s).splitlines()) for s in [A1,A2,CANDIDATE]}
assert all(prs[n]['head']['sha'] in reachable[A1] for n in A1_IDS)
assert all(prs[n]['head']['sha'] in reachable[A2] for n in A2_IDS)
assert all(prs[n]['head']['sha'] in reachable[CANDIDATE] for n in A2_IDS)

c={}
for r in independent['rows']:
    assert prs[r['number']]['head']['sha']==r['head']
    c[r['number']]={'disposition':r['category'],'horizon':r['future_horizon'],
        'rationale':r['rationale'],'dependencies_or_overlap':r['dependencies_or_overlap'],
        'evidence_basis':['user-approved roadmap','captured PR metadata/body','independent roadmap mapping']}

def conditional(n,horizon,reason,deps=()):
    c[n]={'disposition':'conditional','horizon':horizon,'rationale':reason,
          'dependencies_or_overlap':list(deps),
          'evidence_basis':['user-approved roadmap','captured PR metadata/body; planning inference, not fresh code review']}

for n,dep in [(1244,None),(1245,1244),(1246,1245),(1248,1246),(1250,1249),(1251,1250)]:
    conditional(n,'later compatibility batch: composition extraction',
        'Part of the older composition stack named for refresh/extraction. Refresh against main and extract useful changes after reconciling shipped behavior and dependent layers; preserve original histories by merging main into branches, with no complete current head promised for merge.',
        [] if dep is None else [dep])
values={
1292:('Object-bearing runtime-length tuples match alpha.3 values scope; qualify representation, lifetime and proof interactions.',[]),
1294:('Tuple-length joins build on #1292; evaluate conversion-identity limits and combined tuple behavior before selecting the alpha.3 subset.',[1292]),
1297:('Class-union tuple storage builds on #1292 and includes proof work from #1293; reconcile with the shipped proof layer before qualification.',[1292,1293]),
1315:('Class objects are explicit alpha.3 scope; qualify bounded type[C] representation before selecting dependent extensions.',[]),
1340:('Numeric/reflected protocols are embedded in Decimal #1341; reconcile NotImplemented strategies first and qualify mixed operand behavior.',[1341,1249,1472]),
1361:('Attribute/method dispatch through type[C] extends #1315; select coherently with that alpha.3 class-object subset.',[1315]),
1367:('Object __index__ in subscripts/slices/range is a numeric-protocol candidate; require combined evaluation-order and representation qualification.',[]),
1369:('Objects beside scalars and sum() fit mixed-union scope but are stacked on Decimal #1341; choose a coherent subset after operator reconciliation.',[1341]),
1370:('Additional Decimal operations are optional extensions of #1341/#1369; their presence does not commit the release to complete Decimal compatibility.',[1369,1341]),
1372:('type[object] extends #1315/#1361; preserve bounded construction and attribute rules during combined qualification.',[1361]),
1380:('Frozenset hashing and keys are related alpha.3 values; select only with a coherent key-representation subset.',[]),
1396:('Index-protocol objects at Any/typed sequence boundaries are a related alpha.3 candidate; validate #1367 interactions and preserve accepted programs.',[1367]),
1406:('Builtin class objects extend #1372; qualify dispatch, keys and identity with the selected class-object chain.',[1372]),
1407:('Attributes/methods through type[object] depend on #1406; conditional alpha.3 scope, not an alpha.2 addition.',[1406]),
1409:('Complex members in scalar unions extend #1408; reconcile shared numeric/union changes before combined proof and GC checks.',[1408]),
1412:('None and optional keys are explicit alpha.3 scope; qualify lookup/hash/widening across sets and dicts on the combined tree.',[]),
1421:('Dynamic Any complex values extend #1408; select with a coherent complex subset and reconcile reflected/declining operators.',[1408,1472,1249]),
1423:('Class-object reflection through Any is related alpha.3 scope; compare typed/dynamic behavior and documented unsupported operations.',[1315,1361]),
1425:('Any values/index objects in integer parameters are a related numeric-boundary candidate; require a coherent protocol subset and combined checks.',[1367,1396]),
1426:('Reflected IntEnum/IntFlag operations extend #1340; reconcile fallback and result types with the selected numeric subset.',[1340]),
1467:('Runtime-length tuple keys fit alpha.3 values; object elements need #1292 and cannot be inferred from the bounded scalar-key subset.',[1292]),
1475:('Identity-hashed class unions as keys fit mixed-union scope; preserve declared hash/equality and tuple/container restrictions.',[]),
}
for n,(reason,deps) in values.items():
    conditional(n,'alpha.3 candidate',reason,deps)
for n,reason,deps in [
(1355,'NewType is the base of #1399. Consider only required coherent import/typing dependencies or extraction; no whole-head commitment.',[1399]),
(1359,'Circular re-export reads belong to coherent import work. Reconcile binding order, failures and retries; a leaf change is not complete readiness.',[1420]),
(1399,'Alias-read checks are stacked on #1355; reconcile circular from-import handling in a complete qualified import batch.',[1355,1420]),
(1400,'Evaluated-annotation reads extend #1399; qualify import evaluation and lazy/unreachable behavior with the complete circular-import fix.',[1399,1420]),
(1424,'Related optional missing-module handlers do not prove #1420 handler/retry limitations solved; qualify a complete coherent import fix.',[1420]),
]:
    conditional(n,'future coherent import batch',reason,deps)
for n,horizon,reason,deps in [
(1275,'alpha.4 dependency if selected','Identity decorators/mypy_extensions are the base of #1276. Consider only for a selected parser/librt consumer chain; full native mypy remains outside commitment.',[1276]),
(1276,'alpha.4 dependency if selected','librt.internal is the base of optional parser #1435 and librt.base64 #1434. Select only for a useful bounded consumer; it does not qualify native mypy.',[1275,1435,1434]),
(1287,'alpha.4 native-test candidate','Native unittest/package/fixture support fits prioritized native pytest work. Qualify real suites and honest partial reporting; capture features require #1405.',[1264,1405]),
(1296,'alpha.4 optional upstream-consumer candidate','JSON repair is a concrete candidate for selected upstream workflows. Workload selection, adaptation limits and combined qualification remain required; no automatic intake is promised.',[1487]),
(1405,'alpha.4 native-test dependency if selected','This compiler/runtime batch explicitly enables output capture and directory behavior for #1287. Select coherently with useful native test workloads.',[1287]),
(1444,'optional alpha.5 application PGO','Executable/application PGO differs from compiler prototype #1218. Keep optional, reconcile the driver overlap with shipped #1377, and measure compile/startup/runtime costs.',[1377]),
(1471,'alpha.4 optional library dependency','cached_property is bundled by dependent #1473. Consider only for a selected useful library workload or coherent total_ordering integration, retaining descriptor limits.',[1473]),
(1473,'alpha.3/4 optional protocol/library candidate','total_ordering depends on #1471/#1472. Consider after #1249/#1472 reconciliation and only for selected useful library workflows.',[1471,1472,1249]),
(1474,'alpha.4 optional importlib companion','Constant-name import_module is stacked on #1438. Select only for a concrete consumer, preserving lazy validation and dynamic-name limits.',[1438]),
(1477,'alpha.5 optional refinement of #1468','The #1468 follow-up limits inlining to repeatedly executed calls. Its captured body says the timing matrix has not run; measure startup/code-size benefit before selection.',[1468]),
(1487,'alpha.4 optional upstream-consumer candidate','This evidence/schema-anchor follow-up is stacked on #1296. It may qualify a selected JSON repair workflow; historical branch benchmarks are not release qualification.',[1296]),
]:
    conditional(n,horizon,reason,deps)
research={784,796,816,1063,1088,1089,1090,1091,1105,1110,1111,1126,1307}
classes={1243,1286,1295,1317,1321,1335,1338,1342,1346,1348,1350,1352,1362,1364,1368,1373,1374,1375,1376,1378,1379,1384,1388,1390,1391,1401,1402,1413,1431,1448,1453,1454,1457,1463,1466,1480}
optimization={1134,1266,1284,1285,1436,1437,1441,1442,1445,1447,1449}
followups={1482,1483,1484,1485,1486,1489,1490,1491,1493}
for n,p in prs.items():
    if n in A1_IDS:
        reason='Selected alpha.1 feature/proof head is an ancestor of the published release source.'
        if n==1492: reason='Strict promoting-storage repair merged before publication and is an ancestor of both exact release sources.'
        if n in {1387,1410,1428,1429}: reason='Entire current head is in published alpha.1 ancestry; root added release provenance and closed the previously open stacked PR.'
        c[n]={'disposition':'included','horizon':'alpha.1 published','rationale':reason,'dependencies_or_overlap':[],
              'evidence_basis':['selected release scope','exact Git ancestry','captured GitHub state','published alpha.1 provenance']}
    elif n in A2_IDS:
        reason='Selected alpha.2 dependency head is in merged source 8049014; publication remains pending at this snapshot.'
        if n==1488: reason='Integration PR merged at 8049014 with the exact qualified candidate tree; publication remains pending.'
        if n in {1415,1281,1282}: reason+=' Stacked PR remains open; close only after published-tag and live-head ancestry recheck.'
        c[n]={'disposition':'included','horizon':'alpha.2 merged, unpublished','rationale':reason,'dependencies_or_overlap':[],
              'evidence_basis':['selected release scope','exact Git ancestry and candidate/main tree identity','captured GitHub state']}
    elif n not in c:
        deps=[]
        if n in followups:
            reason='Constructor/numeric/Any-boundary follow-up integrated by #1493 after #1488. Not selected for the cleared alpha.2 source; evaluate a later coherent batch.'
            deps=[] if n==1493 else [1493]
        elif n in classes:
            reason='Additional class, typing, protocol or validation work beyond the eight selected alpha.2 dependency heads. Deferred from these two alphas; later selection must preserve accepted programs and lazy validation.'
        elif n in optimization:
            reason='Additional optimization/proof infrastructure not selected for alpha.1/2. Later selection requires combined correctness/proof checks and measured build/runtime costs; no automatic alpha.5 inclusion.'
        elif n in research:
            reason='Research/prototype work outside selected alpha.1/2 sources. No production-readiness or whole-head-supersession conclusion; future extraction or separate goals remain possible.'
        else:
            reason='Not selected in completed alpha.1/alpha.2 source scope. Later v0.5 selection remains open and requires a useful workload, dependency review and combined-tree qualification.'
        c[n]={'disposition':'deferred','horizon':'later v0.5 selection remains open','rationale':reason,
              'dependencies_or_overlap':deps,'evidence_basis':['absence from selected alpha.1/alpha.2 heads','captured PR metadata; scope decision only']}

now=datetime.datetime.now(datetime.timezone.utc).isoformat()
rows=[]
for n,p in sorted(prs.items()):
    d=c[n]
    assert d['disposition'] in {'included','conditional','deferred','superseded'}
    assert all(re.fullmatch('[0-9a-f]{40}',p[side]['sha']) for side in ['head','base'])
    anc={'alpha1_published':p['head']['sha'] in reachable[A1],
         'alpha2_merged_source':p['head']['sha'] in reachable[A2],
         'alpha2_qualified_candidate':p['head']['sha'] in reachable[CANDIDATE]}
    assert d['disposition']=='included' or not any(anc.values())
    row={k:v for k,v in p.items() if k!='body'}
    row.update(d)
    row.update(alpha1_alpha2_scope='included' if d['disposition']=='included' else 'not selected; deferred from alpha.1/alpha.2',
        future_v050_excluded=False,ancestry=anc,body_sha256=hashlib.sha256(p['body'].encode()).hexdigest(),
        evidence_urls=[p['url'],'https://github.com/den-run-ai/pystachy/issues/1476']+
            [f'https://github.com/den-run-ai/pystachy/pull/{n}' for n in d['dependencies_or_overlap']],
        review_depth='Scope/metadata and release ancestry only; no fresh per-PR code or CI review')
    if n in A1_IDS: row['release_source_sha']=A1
    if n in A2_IDS: row['release_source_sha']=A2
    rows.append(row)
counts=collections.Counter(r['disposition'] for r in rows)
assert counts['included']==21 and counts['superseded']==0
source_names=['open-prs-metadata-snapshot.json','selected-closed-prs-metadata-snapshot.json',
'open-prs-final-metadata-snapshot.json','selected-closed-prs-final-metadata-snapshot.json',
'alpha1-closed-included-prs.json','later-alpha-roadmap-independent.json','native-mypy-issue-1322-snapshot.json']
sources=[{'path':n,'sha256':hashlib.sha256((R/n).read_bytes()).hexdigest()} for n in source_names]
notes=[
'Scope inventory, not fresh code/CI review of every PR. Historical PR validation is not present release evidence.',
'Every conditional and deferred row is outside alpha.1/2; neither is a blanket exclusion from later v0.5.',
'Full native mypy #1322 is an issue, not a PR, and is outside the release commitment.',
'Async/core asyncio is deferred by default; inclusion would need a dedicated alpha and broader qualification.',
'Broad concurrency, libuv/process-worker research, collector experiments and native-wheel prototypes are outside commitment. Synchronous futures #1416 and gc API #1351 are distinct compatibility work.',
'NotImplemented #1472/#1249 need reconciliation. Bounded matching #1272 shipped, but that does not prove whole-head supersession of #1252.',
'Circular imports need a complete fix; #1420 readiness changes must not land alone. Related handler PRs do not prove the issue resolved.',
'Lean sum proof #1455 must precede loop optimization #1450. JIT O2 #1456 and application PGO #1444 are optional; compiler PGO prototype #1218 is separate.',
'Related importlib #1365, librt.base64 #1434 and upstream-consumer candidates require concrete selected workflows; no automatic scope expansion.',
'#1493 and its constructor/numeric boundary stack remain after the cleared alpha.2 candidate and deferred from these two releases.']
data={
'kind':'Read-only release PR disposition inventory','repository':'den-run-ai/pystachy',
'snapshot_period':{'initial_utc':'2026-11-14 17:53:38 UTC','final_open_utc':opens['retrieved_at_utc'],'generated_utc':now,
'note':'Bounded interval, not an atomic GitHub transaction. One final refresh followed the known alpha.2 merge.'},
'authority':'User-approved alpha.1/alpha.2 scope and later v0.5 roadmap; tracker #1476; PR metadata; exact Git ancestry.',
'metadata_field_semantics':{'base.sha':'Exact value returned by the PR metadata snapshot; not necessarily the current main tip. Older or merged PR metadata can report pre-alpha base commits.','head.sha':'Exact current head value returned by the recorded PR metadata snapshot; inclusion is independently checked by Git ancestry.'},
'coverage':{'current_open_prs':162,'original_selected_feature_prs':19,'additional_repair_pr':1492,
'closed_selected_feature_or_repair_prs':17,'additional_merged_integration_pr':1488,'inventory_rows':180,
'supplemental_integration_provenance_pr':1481,'initial_open_prs_before_known_merge':168,
'count_cross_check':'Two final REST pages and independent complete GitHub search both counted 162 open PRs.'},
'definitions':{
'included':'Only entire selected heads verified in published alpha.1 or merged alpha.2 source; alpha.2 is not yet published.',
'conditional':'Outside alpha.1/2. Later roadmap-aligned candidate, optional dependency or extraction, requiring scope selection and fresh combined qualification. No whole-head merge promise.',
'deferred':'Outside alpha.1/2. Default if not included or concretely linked to later roadmap selection. Future v0.5 eligibility remains open; explicit separate goals stay outside commitment.',
'superseded':'Requires evidence that the entire current head is redundant. No row meets that threshold.'},
'release_sources':{
'alpha1':{'version':'v0.5.0-alpha.1','status':'published and verified by root','sha':A1,'tree':trees[A1],
'release_url':'https://github.com/den-run-ai/pystachy/releases/tag/v0.5.0-alpha.1','integration_pr':1481,'repair_pr':1492},
'alpha2':{'version':'v0.5.0-alpha.2','status':'merged; exact-main/distribution gates and publication pending at snapshot',
'sha':A2,'tree':trees[A2],'integration_pr':1488,'qualified_candidate_sha':CANDIDATE,
'qualified_candidate_tree':trees[CANDIDATE],'candidate_and_main_trees_identical':True}},
'counts':{k:counts[k] for k in ['included','conditional','deferred','superseded']},
'ancestry_method':'git rev-list reachability in a non-shallow local repository; candidate/main tree hashes compared. No fetch, builds, tests, GitHub mutation or dispatch by this inventory.',
'scope_caveats':notes,
'issue_level_deferrals':[{'number':1322,'type':'issue','url':'https://github.com/den-run-ai/pystachy/issues/1322',
'goal':'Full native mypy','disposition':'outside release commitment; selected compatibility improvements do not qualify the full checker'}],
'bookkeeping':{'alpha1_closed_with_provenance':closures,
'alpha2_automatically_marked_merged_after_integration':[1274,1277,1280,1298,1377],
'alpha2_still_open_stacked_dependencies':[1415,1281,1282],
'alpha2_close_condition':'After publication, re-read current heads and prove full ancestry in the exact published tag before closure.',
'tracker_followup':'Update #1476 and release PR summaries after alpha.2 publication with exact-source/gate/artifact evidence; keep umbrella open for later alphas and retain historical evidence.'},
'integration_provenance':[supplement],'source_files':sources,'prs':rows}
(R/'pr-disposition-inventory.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')

def esc(x): return str(x).replace('|','\\|').replace('\n',' ')
def lp(n): return f'[#{n}](https://github.com/den-run-ai/pystachy/pull/{n})'
def ls(s): return f'[{s[:12]}](https://github.com/den-run-ai/pystachy/commit/{s})'
def code(s): return chr(96)+str(s)+chr(96)
md=['# v0.5.0 alpha.1/alpha.2 PR disposition inventory','',
f'Generated {now}. Final open-PR snapshot: {opens["retrieved_at_utc"]}.','',
'This inventory covers **180 PRs**: all **162 currently open PRs**, **17 closed selected feature/repair PRs**, and merged integration #1488. It includes the original 19 selected feature PRs plus repair #1492. Alpha.1 integration #1481 is supplemental provenance. Before the known alpha.2 merge there were 168 open PRs; the final bounded refresh observed six closures. Full REST pages and an independent complete search count agree.','',
'**Alpha.1 is published. Alpha.2 is merged and unpublished at this snapshot.** Conditional/deferred rows add nothing to either source.','',
'## Exact release sources','',
'| Release | Status | Source | Tree | Integration |','| --- | --- | --- | --- | --- |',
f'| v0.5.0-alpha.1 | Published and verified by release owner | {ls(A1)} | {code(trees[A1])} | {lp(1481)} plus {lp(1492)} |',
f'| v0.5.0-alpha.2 | Merged; final gates/publication pending | {ls(A2)} | {code(trees[A2])} | {lp(1488)} |','',
f'Alpha.2 has the identical tree to qualified candidate {ls(CANDIDATE)}. Entire selected heads have verified ancestry in the recorded release source.','',
'## Dispositions','',
'| Category | Count | Meaning |','| --- | ---: | --- |',
f'| Included | {counts["included"]} | 12 alpha.1 feature/repair heads and nine alpha.2 dependency/integration heads, verified in exact source ancestry. |',
f'| Conditional | {counts["conditional"]} | Outside alpha.1/2; later roadmap candidates, dependencies or extraction. Requires selection and fresh qualification; no whole-head merge pledge. |',
f'| Deferred | {counts["deferred"]} | Outside alpha.1/2; future v0.5 selection remains open except explicit separate goals. No code rejection/readiness judgment. |',
f'| Superseded | {counts["superseded"]} | No complete current head has enough evidence for this claim. |','',
'The JSON preserves each full head SHA, full base SHA/ref, title, state, draft/merged flags, dates, rationale, dependencies and evidence URLs. Each base SHA is the exact value returned by the PR metadata snapshot, not necessarily the current main tip; older or merged PR metadata can report pre-alpha base commits. Abbreviated table hashes link to exact complete commits. Raw snapshots retain PR bodies and have recorded SHA-256 identities.','',
'## Scope decisions','']
md += ['- '+n for n in notes]
md += ['','## Included heads','',
'| PR | Title | State | Release status | Head | Base ref | Rationale |',
'| --- | --- | --- | --- | --- | --- | --- |']
for r in rows:
    if r['disposition']!='included': continue
    state=('open'+(' draft' if r['draft'] else '')) if r['state']=='open' else ('closed / merged' if r['merged'] else 'closed / integrated')
    md.append(f'| {lp(r["number"])} | {esc(r["title"])} | {state} | {esc(r["horizon"])} | {ls(r["head"]["sha"])} | {code(esc(r["base"]["ref"]))} | {esc(r["rationale"])} |')
for cat,heading in [('conditional','Conditional later candidates'),('deferred','Deferred from alpha.1/alpha.2')]:
    md += ['',f'## {heading}','','All rows are outside these two alphas. Future scope and qualification decisions remain separate.','',
    '| PR | Title | State | Horizon | Head | Base ref | Reason / dependency |','| --- | --- | --- | --- | --- | --- | --- |']
    for r in rows:
        if r['disposition']!=cat: continue
        state=r['state']+(' draft' if r['draft'] else '')
        md.append(f'| {lp(r["number"])} | {esc(r["title"])} | {state} | {esc(r["horizon"])} | {ls(r["head"]["sha"])} | {code(esc(r["base"]["ref"]))} | {esc(r["rationale"])} |')
md += ['','## Bookkeeping','',
'Root already closed four alpha.1 dependency PRs after checking complete live-head ancestry in the published source. This inventory performed no closures.','',
'| PR | Included head | Release-provenance comment |','| --- | --- | --- |']
for x in closures:
    n=x['number']; cid=x['comment']['id']
    md.append(f'| {lp(n)} | {ls(x["head"])} | [Comment](https://github.com/den-run-ai/pystachy/pull/{n}#issuecomment-{cid}) |')
md += ['',
'After alpha.2 integration GitHub marks #1274, #1277, #1280, #1298 and #1377 merged/closed. Stacked #1415, #1281 and #1282 remain open. After publication, re-read their current heads and verify ancestry in the exact published tag before closure.','',
'After both publications, update [tracker #1476](https://github.com/den-run-ai/pystachy/issues/1476) and release PR summaries with exact-source/gate/artifact evidence. Preserve historical context and keep the umbrella open for later alphas/RCs. Failed automated Codex attempts remain incomplete reviews.','',
'## Method and limits','',
'- Read-only GitHub metadata, two complete final open-PR pages, independent total-count check, selected closed-PR metadata and issue #1322 metadata. This is a bounded interval, not an atomic GitHub transaction.',
'- Selected heads were checked by '+code('git rev-list')+' in a non-shallow repository. Candidate/main trees match. No other complete current PR head appears in either release ancestry; partial overlap does not establish supersession.',
'- Scope inventory only, not fresh code/CI review of 180 PRs. Historical validation is not promoted to current release evidence. A separate independent roadmap mapping covered a bounded 33-row subset.',
'- No GitHub mutations, workflow dispatch, builds, heavy tests or monitoring for this inventory.',
'- JSON records source paths and SHA-256 identities; adjacent raw JSON files preserve complete captured metadata.','',
'Supplemental alpha.1 integration: '+lp(1481)+', head '+ls(supplement['head']['sha'])+'.','']
(R/'pr-disposition-inventory.md').write_text('\n'.join(md))
receipt={'created_utc':now,'inventory_rows':len(rows),'open_rows':sum(r['state']=='open' for r in rows),
'selected_feature_prs':len(ORIGINAL19),'counts':data['counts'],'valid_full_head_and_base_shas':True,
'selected_heads_in_expected_ancestry':True,'candidate_main_tree_identity':True,'unselected_whole_heads_in_release_ancestry':[],
'current_open_snapshot_complete':True,'scope_only_no_fresh_per_pr_code_review':True,
'files':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['pr-disposition-inventory.json','pr-disposition-inventory.md']}}
(R/'pr-disposition-inventory-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))

