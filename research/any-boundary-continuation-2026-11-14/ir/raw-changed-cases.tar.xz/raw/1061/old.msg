tests/programs/inference/dynany_identity_generator_optional_protocol.py:40: error: widened() yields float | None, but yield from delegates to a generator that yields float
