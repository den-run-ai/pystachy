#!/usr/bin/env python3
"""Freeze a completed exact-head CI capture for immutable research publication."""
import argparse
import collections
import gzip
import hashlib
import io
import json
import pathlib
import stat
import tarfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def gitsha(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def frozen(path):
    assert path.is_file() and not path.is_symlink(), path
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    assert (before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns), path
    assert not data.startswith(b"\x7fELF"), path
    return data, stat.S_IMODE(after.st_mode)


def verify(bundle):
    manifest = json.loads((bundle / "manifest.json").read_text())
    assert manifest["schema"] == 1 and manifest["immutable"] is True
    assert all(manifest["completion"][key] is True for key in ("ci", "lint", "submission_format"))
    summary = json.loads((bundle / "summary.json").read_text())
    assert summary["complete"] is True and not summary["pending"] and not summary["failures"]
    assert summary["head"] == manifest["head"] and summary["snapshot"] == manifest["final_snapshot"]
    actual = {p.name for p in bundle.iterdir()}
    assert actual == {"README.md", "summary.json", "captures.tar.gz", "manifest.json", "SHA256SUMS"}, actual
    for entry in manifest["artifacts"]:
        path = bundle / entry["path"]
        data, mode = frozen(path)
        assert len(data) == entry["bytes"] and sha(data) == entry["sha256"]
        assert gitsha(data) == entry["git_blob_sha"] and mode == entry["mode"]
    archive = (bundle / "captures.tar.gz").read_bytes()
    unpacked = gzip.decompress(archive)
    assert gzip.compress(unpacked, compresslevel=9, mtime=0) == archive
    expected = {row["path"]: row for row in manifest["capture_files"]}
    with tarfile.open(fileobj=io.BytesIO(unpacked), mode="r:") as tar:
        members = tar.getmembers()
        assert len(members) == len(expected)
        assert {m.name for m in members} == set(expected)
        archived_audit = None
        for member in members:
            assert member.isfile() and not member.issym() and not member.islnk()
            path = pathlib.PurePosixPath(member.name)
            assert not path.is_absolute() and ".." not in path.parts
            row = expected[member.name]
            data = tar.extractfile(member).read()
            assert len(data) == row["bytes"] and sha(data) == row["sha256"]
            assert member.mode == row["mode"]
            if member.name == manifest["final_snapshot"] + "/audit.json":
                archived_audit = data
        assert archived_audit == (bundle / "summary.json").read_bytes(), "published summary differs from archived final audit"
    sums = {}
    for line in (bundle / "SHA256SUMS").read_text().splitlines():
        digest, name = line.split("  ", 1)
        assert name not in sums
        sums[name] = digest
    assert set(sums) == actual - {"SHA256SUMS"}
    for name, digest in sums.items():
        assert sha((bundle / name).read_bytes()) == digest
    return {"verified": True, "head": manifest["head"], "capture_files": len(expected),
            "capture_archive_sha256": sha(archive), "manifest_sha256": sha((bundle / "manifest.json").read_bytes())}


def readme(summary):
    format_runs = sum(run["name"] == "Submission format" for run in summary["runs"])
    lines = ["# Final CI qualification for PR #1495", "",
        f"**CI, Lint and Submission format passed for exact head `{summary['head']}`.**",
        f"This immutable capture was completed at {summary['observed_at']}, before the PR was marked ready for review. Later body/ready metadata is recorded separately.", "",
        f"Base: `{summary['base']}`. Head tree: `{summary['tree']}`. GitHub's synthetic merge commit `{summary['merge_commit']}` has that same tree and exactly the base/head parents, so the pull-request CI checkout has the final source tree.", "",
        "The final commit changes only `tools/lean_boundary/REPORT.md` relative to the published source parent. The retrieved workflow files also match both the base commit and the locally qualified source byte for byte. Raw compare, commit and workflow records are included.", "",
        "## Workflow outcomes", "",
        "| Workflow | Run | Event | Result | Created (UTC) | Last updated (UTC) |",
        "|---|---|---|---|---|---|"]
    for run in sorted(summary["runs"], key=lambda r: (r["name"], r["id"])):
        lines.append(f"| {run['name']} | [{run['id']}]({run['html_url']}) | {run['event']} | {run['conclusion']} | {run['created_at']} | {run['updated_at']} |")
    lines += ["", f"The capture includes {summary['check_count']} check runs: " + ", ".join(f"{value} {key}" for key, value in sorted(summary["check_conclusions"].items())) + ". The combined commit status is success.", "",
        "The two expected skipped jobs are the CI qualification job, whose condition excludes pull requests, and the legacy DCO job, whose condition excludes `pull_request_target`. Every applicable CI/Lint job and declared step passed; conditional steps outside this PR's selected matrix were checked as skipped.", "",
        "## Jobs, durations and limits", "",
        "Durations below are GitHub job timestamps, not benchmark measurements. No benchmark timing was repeated for this qualification.", "",
        "| Job | Run | Result | Seconds | Configured timeout (minutes) |",
        "|---|---|---|---:|---:|"]
    for job in sorted(summary["jobs"], key=lambda j: (j["workflow"], j["name"], j["run_id"])):
        duration = "—" if job["duration_seconds"] is None else f"{job['duration_seconds']:g}"
        lines.append(f"| [{job['name']}]({job['html_url']}) | {job['run_id']} | {job['conclusion']} | {duration} | {job['timeout_minutes']} |")
    steps = collections.Counter(s["expected"] for j in summary["jobs"] for s in j["step_checks"])
    lines += ["",
        f"The pinned workflows configure {summary['configured_pr_job_rows']} PR job rows against a budget of {summary['configured_pr_job_row_budget']}. CI has 16 rows: bootstrap, 11 verification groups, two native JIT/configuration workers, the expected skipped qualification row, and the aggregate Verification gate. Lint, Submission format and legacy DCO add one row each. The {summary['observed_jobs_including_metadata_retriggers']} observed jobs include {format_runs} Submission format runs ({max(0, format_runs - 1)} metadata retriggers); these are separate metadata events rather than additional matrix expansion.", "",
        f"The native AOT group permits four shards; other matrix groups permit at most two workers. The workflow sets `PYSTACHY_JOBS={summary['local_process_limit']}`. No matrix `max-parallel` is configured. Observed peak overlap was {summary['observed_peak_ci_jobs']} CI jobs and {summary['observed_peak_concurrent_jobs']} jobs across the captured workflows. Workflow concurrency groups cancel superseded runs for the same PR; they do not impose a global running-job cap.", "",
        f"The saved audit checks {steps['success']} required successful steps and {steps['skipped']} expected conditional skips against the exact pinned definitions. It covers compiler/runtime fixed points, all native AOT and JIT partitions, configuration samples, Lean build/audit and CI guard proofs, FFI, sanitizer controls, cache/GC/runtime contracts, workload checks, recordings and final report aggregation. Complete names, conditions, timestamps and status records are in `summary.json` and the raw captures.", "",
        "## Evidence and reproduction", "",
        "`captures.tar.gz` preserves every selected raw API response, all observed progress snapshots, the pinned workflow sources, correspondence checks, and the read-only audit script. `manifest.json` lists each archived file's exact byte length, mode and SHA-256; it also records the published artifacts' hashes. `SHA256SUMS` covers all other package files. Progress snapshots are historical observations; only the named final snapshot establishes completion.", "",
        "All pages were followed until collection counts matched (or the historical-status collection returned its terminal short page). The final audit rejects changed head/base, an unexpected merge tree, missing jobs, unobserved required steps, unexpected skips/failures, incomplete pagination or non-success final statuses.", "",
        "```sh", "sha256sum -c SHA256SUMS", "mkdir captured", "tar -xzf captures.tar.gz -C captured",
        f"python3 captured/summarize_snapshot.py captured/{summary['snapshot']} --final --output re-audit.json", "```", "",
        "These are read-only observations. No workflow was retried, cancelled or modified, and this package contains no PR/ref/tree mutation.", ""]
    return "\n".join(lines)


def build(source, snapshot, output):
    assert not output.exists(), output
    summary = json.loads((source / snapshot / "audit.json").read_text())
    assert summary["complete"] and not summary["pending"] and not summary["failures"]
    paths = sorted({*source.glob("snapshot-*/*.json"), *source.glob("workflow-responses/*.json"),
                    *source.glob("workflows/*.yml"), source / "workflow-expectations.json",
                    source / "workflow-base-correspondence.json", source / "final-head-source-diff.json",
                    source / "pull-request-merge-commit.json", source / "summarize_snapshot.py",
                    source / "package_ci.py", source / "auditor-independent-review.json",
                    source / "audit-negative-controls.json", *source.glob("packaging-independent-review.json")})
    files = []
    contents = {}
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode="w", format=tarfile.USTAR_FORMAT) as tar:
        for path in paths:
            data, mode = frozen(path)
            rel = str(path.relative_to(source))
            contents[rel] = data
            files.append({"path": rel, "bytes": len(data), "mode": mode, "sha256": sha(data)})
            info = tarfile.TarInfo(rel)
            info.size, info.mode, info.mtime = len(data), mode, 0
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            tar.addfile(info, io.BytesIO(data))
    output.mkdir(parents=True)
    (output / "captures.tar.gz").write_bytes(gzip.compress(stream.getvalue(), compresslevel=9, mtime=0))
    (output / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    (output / "README.md").write_text(readme(summary))
    artifacts = []
    for path in sorted(output.iterdir()):
        data, mode = frozen(path)
        artifacts.append({"path": path.name, "bytes": len(data), "mode": mode,
                          "sha256": sha(data), "git_blob_sha": gitsha(data)})
    manifest = {"schema": 1, "immutable": True, "head": summary["head"], "base": summary["base"],
        "tree": summary["tree"], "final_snapshot": snapshot, "observed_at": summary["observed_at"],
        "completion": {"ci": True, "lint": True, "submission_format": True,
                       "post_ready_metadata_included": False},
        "capture_files": files, "artifacts": artifacts,
        "archive": {"encoding": "gzip of USTAR tar", "gzip_mtime": 0, "tar_mtime": 0,
                    "compression_level": 9, "source_root": str(source)},
        "packager_sha256": sha(pathlib.Path(__file__).read_bytes())}
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    (output / "SHA256SUMS").write_text("".join(sha(p.read_bytes()) + "  " + p.name + "\n" for p in sorted(output.iterdir())))
    for row in files:
        data, mode = frozen(source / row["path"])
        assert data == contents[row["path"]] and mode == row["mode"]
    return verify(output)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=pathlib.Path)
    parser.add_argument("--snapshot")
    parser.add_argument("--output", type=pathlib.Path)
    parser.add_argument("--verify", type=pathlib.Path)
    args = parser.parse_args()
    result = verify(args.verify) if args.verify else build(args.source, args.snapshot, args.output)
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
