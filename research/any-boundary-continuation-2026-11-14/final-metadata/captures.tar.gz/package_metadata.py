#!/usr/bin/env python3
"""Package the final ready-event readback without changing the frozen CI bundle."""
import gzip
import hashlib
import io
import json
import pathlib
import re
import stat
import tarfile

ROOT = pathlib.Path('/workspace/scratch/1a96cd11db0d')
SOURCE = ROOT / 'qualification/ci-final-metadata'
BUNDLE = ROOT / 'research-final-metadata-upload/bundle'
HEAD = '1f9309a0b6db9598ea16ff2b5195bd3e1aa30504'
BASE = 'adac7f4c88fd86ddaecbb889042b778c701b29ed'
CORE = 'e613a0b2607aa4007cb3d37592ceb4d2b022cd66'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def gitsha(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def frozen(path):
    assert path.is_file() and not path.is_symlink(), path
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    assert (before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns)
    assert not data.startswith(b'\x7fELF')
    return data, stat.S_IMODE(after.st_mode)


def comments(value, result):
    if isinstance(value, dict):
        if value.get('id') in (6886418592, 6886418892):
            result[value['id']] = value
        for item in value.values():
            comments(item, result)
    elif isinstance(value, list):
        for item in value:
            comments(item, result)


def main():
    assert not BUNDLE.exists()
    audit = read(SOURCE / 'ready-001/audit.json')
    body_audit = read(SOURCE / 'body-001/audit.json')
    assert audit['complete'] and not audit['failures'] and not audit['pending']
    assert body_audit['complete'] and not body_audit['failures'] and not body_audit['pending']
    pr = read(SOURCE / 'ready-001/pr.json')['data']
    body_pr = read(SOURCE / 'body-001/pr.json')['data']
    assert pr['head']['sha'] == HEAD and pr['base']['sha'] == BASE
    assert pr['state'] == 'open' and pr['draft'] is False and pr['merged'] is False and pr['mergeable'] is True
    assert body_pr['draft'] is True and body_pr['body'] == pr['body'] and CORE in pr['body']
    found = {}
    comments(read(SOURCE / 'codex-review-after-ready.json'), found)
    assert set(found) == {6886418592, 6886418892}
    reported = json.loads(re.search(r'codex-review-state:v1 (.*?) -->', found[6886418592]['body']).group(1))
    assert reported['code_review']['commit_sha'] == HEAD and reported['code_review']['status'] == 'failed'
    assert 'usage limits' in found[6886418892]['body'].lower()
    runs = {row['id']: row for row in audit['runs']}
    for run_id in [43657035332, 43657104879, 43654295644, 43654295641]:
        assert runs[run_id]['conclusion'] == 'success' and runs[run_id]['head_sha'] == HEAD
    summary = {
        'schema': 1, 'observed_at': audit['observed_at'], 'repository': 'den-run-ai/pystachy',
        'pr': 1495, 'url': pr['html_url'], 'head': HEAD, 'base': BASE, 'tree': audit['tree'],
        'state': pr['state'], 'draft': pr['draft'], 'merged': pr['merged'], 'mergeable': pr['mergeable'],
        'core_evidence_commit': CORE, 'body_unchanged_after_ready': True,
        'body_sha256': sha(pr['body'].encode()), 'current_checks': audit['current_check_count'],
        'current_check_conclusions': audit['current_check_conclusions'],
        'historical_check_conclusions': audit['historical_check_conclusions'],
        'body_edit_format_run': runs[43657035332], 'ready_format_run': runs[43657104879],
        'ci_run': runs[43654295644], 'lint_run': runs[43654295641],
        'combined_status': audit['combined_status'], 'latest_statuses': audit['latest_statuses'],
        'ready_snapshot': 'ready-001', 'body_snapshot': 'body-001',
        'automated_codex_review': {
            'status': 'failed_to_complete', 'cause': 'usage_quota_exhausted', 'clean_review_claimed': False,
            'reported_state': reported,
            'comments': [{k: found[key][k] for k in ('id', 'url', 'created_at', 'updated_at')} for key in sorted(found)],
            'original_response': 'codex-review-after-ready.json',
            'original_response_sha256': sha((SOURCE / 'codex-review-after-ready.json').read_bytes()),
            'separate_failed_check_observed': False,
            'note': 'The failed service review is preserved separately from passing CI/Lint/format checks. No completed clean automated review is asserted, and no retry was requested after the quota notice.'}}
    files = sorted({*SOURCE.glob('*.json'), *SOURCE.glob('*.py'),
                    *SOURCE.glob('body-001/*.json'), *SOURCE.glob('ready-001/*.json')})
    files.append(pathlib.Path(__file__))
    records, original = [], {}
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w', format=tarfile.USTAR_FORMAT) as tar:
        for path in files:
            name = 'package_metadata.py' if path == pathlib.Path(__file__) else str(path.relative_to(SOURCE))
            assert name not in original
            data, mode = frozen(path)
            original[name] = (path, data, mode)
            records.append({'path': name, 'bytes': len(data), 'mode': mode, 'sha256': sha(data)})
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), mode, 0
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            tar.addfile(info, io.BytesIO(data))
    archive = gzip.compress(stream.getvalue(), compresslevel=9, mtime=0)
    readme = f'''# Final PR ready status and automated-review limit

[PR #1495]({pr['html_url']}) is **open, ready for review, unmerged and mergeable** at the recorded observation, {audit['observed_at']}.

Head `{HEAD}` and base `{BASE}` are unchanged. The final PR body is byte-identical before and after the ready event and still links to the pinned [complete core qualification]({pr['html_url'].split('/pull/')[0]}/tree/{CORE}/research/any-boundary-continuation-2026-11-14).

| Event or gate | Run | Result |
|---|---|---|
| Final body edit: Submission format | [43657035332](https://github.com/den-run-ai/pystachy/actions/runs/43657035332) | Success |
| Mark ready: Submission format | [43657104879](https://github.com/den-run-ai/pystachy/actions/runs/43657104879) | Success |
| CI at the final head | [43654295644](https://github.com/den-run-ai/pystachy/actions/runs/43654295644) | Success |
| Lint at the final head, attempt 2 | [43654295641](https://github.com/den-run-ai/pystachy/actions/runs/43654295641) | Success |

All 23 current check runs are accounted for: 21 successes and the two expected qualification/DCO skips. The earlier cancelled Lint check remains in the full history, bringing the captured total to 24. The latest Submission format status agrees with the complete per-context status history. The unchanged strict capture auditor accepts the final metadata; no current check is pending or failed.

## Automated Codex review did not complete

The ready event triggered the automated review service. Its [summary comment](https://github.com/den-run-ai/pystachy/pull/1495#issuecomment-6886418592) reports failure for this exact head. Its [explicit quota comment](https://github.com/den-run-ai/pystachy/pull/1495#issuecomment-6886418892) states that the account's code-review usage limit was reached.

**This is not a clean completed automated review.** The original tool response, including the service's reported state fields, is preserved verbatim. This service failure was observed as comments; no separate failed check was present in the final captured check collection. CI, Lint and format success do not substitute for the unavailable automated review. No review retry, source edit, timeout relaxation or PR edit was performed during this final readback.

The independent compiler/proof reviews and complete tests remain in the pinned core evidence. This small supplement records the later metadata events and the automated-review limitation without changing that evidence or the PR's pinned link.

## Verification and raw records

`summary.json` contains the exact identifiers, timestamps, body hash, status accounting and review limitation. `captures.tar.gz` preserves all raw API pages for the body-edit and ready-event snapshots, the exact Codex response, the frozen read-only auditor and this packaging script. `manifest.json` records every archived file's byte count, mode and SHA-256. `SHA256SUMS` covers the other published files.

```sh
sha256sum -c SHA256SUMS
mkdir captured
tar -xzf captures.tar.gz -C captured
python3 captured/summarize_snapshot.py captured/ready-001 --final --output re-audit.json
```
'''
    BUNDLE.mkdir(parents=True)
    (BUNDLE / 'README.md').write_text(readme)
    (BUNDLE / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    (BUNDLE / 'captures.tar.gz').write_bytes(archive)
    artifacts = []
    for path in sorted(BUNDLE.iterdir()):
        data, mode = frozen(path)
        artifacts.append({'path': path.name, 'bytes': len(data), 'mode': mode,
                          'sha256': sha(data), 'git_blob_sha': gitsha(data)})
    manifest = {'schema': 1, 'immutable': True, 'head': HEAD, 'base': BASE,
                'core_evidence_commit': CORE, 'ready_format_complete': True,
                'automated_review_completed': False, 'automated_review_quota_exhausted': True,
                'files': records, 'artifacts': artifacts, 'packager_sha256': sha(pathlib.Path(__file__).read_bytes())}
    (BUNDLE / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    (BUNDLE / 'SHA256SUMS').write_text(''.join(sha(p.read_bytes()) + '  ' + p.name + '\n' for p in sorted(BUNDLE.iterdir())))
    assert gzip.compress(gzip.decompress(archive), compresslevel=9, mtime=0) == archive
    with tarfile.open(fileobj=io.BytesIO(gzip.decompress(archive)), mode='r:') as tar:
        assert len(tar.getmembers()) == len(original)
        assert {m.name for m in tar.getmembers()} == set(original)
        for member in tar.getmembers():
            path, data, mode = original[member.name]
            assert member.isfile() and member.mode == mode
            assert tar.extractfile(member).read() == data
            assert frozen(path) == (data, mode)
    assert read(BUNDLE / 'summary.json')['automated_codex_review']['clean_review_claimed'] is False
    print(json.dumps({'verified': True, 'files': len(records), 'archive_bytes': len(archive),
                      'archive_sha256': sha(archive), 'manifest_sha256': sha((BUNDLE / 'manifest.json').read_bytes())}))


if __name__ == '__main__':
    main()
