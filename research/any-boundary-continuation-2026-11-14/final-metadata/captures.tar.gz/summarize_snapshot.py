#!/usr/bin/env python3
"""Audit saved GitHub metadata for one exact PR head; never writes to GitHub."""
import argparse
import ast
import collections
import datetime as dt
import hashlib
import json
import pathlib
import re

HEAD = "1f9309a0b6db9598ea16ff2b5195bd3e1aa30504"
BASE = "adac7f4c88fd86ddaecbb889042b778c701b29ed"
TREE = "3960ae03b0cacfeaa71b8b2c32ced798562fc68b"


def read(path):
    return json.loads(path.read_text())


def pages(snapshot, stem, key=None):
    paths = sorted(snapshot.glob(stem + "-page*.json"),
                   key=lambda p: int(p.stem.rsplit("page", 1)[1]))
    assert paths, stem
    rows = []
    total = None
    evidence = []
    for number, path in enumerate(paths, 1):
        assert path.name == f"{stem}-page{number}.json", path
        wrapper = read(path)
        data = wrapper["data"]
        part = data[key] if key else data
        assert isinstance(part, list), path
        if key:
            assert total in (None, data["total_count"]), path
            total = data["total_count"]
        rows.extend(part)
        evidence.append({"file": path.name, "count": len(part),
                         "observed_at": wrapper["observed_at"],
                         "url": wrapper["request_url"],
                         "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    if key:
        assert len(rows) == total, (stem, len(rows), total)
    else:
        assert len(part) < 100, (stem, "terminal page not captured")
    assert len({row["id"] for row in rows}) == len(rows), stem
    return rows, {"total": len(rows), "complete": True, "pages": evidence}


def stamp(value):
    return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))


def condition(expression, matrix, event):
    if not expression:
        return True
    value = expression.strip()
    if value.startswith("${{"):
        value = value[3:-2].strip()
    substitutions = {
        "github.event_name": event,
        "steps.plan.outputs.kind": "code",
        "needs.bootstrap.outputs.plan_x86_64": "code",
        "needs.bootstrap.outputs.plan_aarch64": "not-selected-on-PR",
        "steps.lean-boundary.outputs.run": "true",
    }
    for key, item in matrix.items():
        substitutions["matrix." + key] = int(item) if key == "worker" else item
    for key, item in sorted(substitutions.items(), key=lambda p: -len(p[0])):
        value = value.replace(key, repr(item))
    value = value.replace("&&", " and ").replace("||", " or ")
    value = re.sub(r"!(?!=)", " not ", value).strip()
    tree = ast.parse(value, mode="eval")

    def visit(node):
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.BoolOp):
            values = [bool(visit(child)) for child in node.values]
            return all(values) if isinstance(node.op, ast.And) else any(values)
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
            return not visit(node.operand)
        if isinstance(node, ast.Compare) and len(node.ops) == 1:
            left, right = visit(node.left), visit(node.comparators[0])
            if isinstance(node.ops[0], ast.Eq):
                return left == right
            if isinstance(node.ops[0], ast.NotEq):
                return left != right
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id == "always" and not node.args:
                return True
            if node.func.id == "cancelled" and not node.args:
                return False
            if node.func.id == "startsWith" and len(node.args) == 2:
                return visit(node.args[0]).startswith(visit(node.args[1]))
        raise ValueError((expression, ast.dump(node)))

    return bool(visit(tree.body))


def job_name(workflow, key, job, matrix):
    if workflow == "ci.yml" and key == "verify":
        return "Verification"
    name = job["name"] or key
    for key, value in matrix.items():
        name = name.replace("${{ matrix." + key + " }}", str(value))
    assert "${{" not in name, name
    return name


def step_name(step):
    if step["name"]:
        return step["name"]
    if step["uses"]:
        return "Run " + step["uses"]
    return "Run " + step["run"].splitlines()[0]


def peak(jobs, observed_at):
    events = []
    for job in jobs:
        if job["conclusion"] != "skipped" and job["started_at"]:
            events.extend([(stamp(job["started_at"]), 1),
                           (stamp(job["completed_at"] or observed_at), -1)])
    current = maximum = 0
    for _, change in sorted(events):
        current += change
        maximum = max(maximum, current)
    return maximum


def audit(snapshot, final):
    root = snapshot.parent
    expectations = read(root / "workflow-expectations.json")
    pr = read(snapshot / "pr.json")["data"]
    assert pr["head"]["sha"] == HEAD and pr["base"]["sha"] == BASE
    merge = read(root / "pull-request-merge-commit.json")["data"]
    assert merge["sha"] == pr["merge_commit_sha"]
    assert merge["tree"]["sha"] == TREE
    assert [p["sha"] for p in merge["parents"]] == [BASE, HEAD]
    runs, run_pages = pages(snapshot, "runs", "workflow_runs")
    checks, check_pages = pages(snapshot, "checks", "check_runs")
    statuses, status_pages = pages(snapshot, "statuses")
    combined = read(snapshot / "status-page1.json")["data"]
    assert combined["sha"] == HEAD
    assert combined["total_count"] == len(combined["statuses"]) < 100
    assert len({r["name"] for r in runs}) == 4
    failures, pending, jobs_out, run_out, pagination = [], [], [], [], {
        "runs": run_pages, "checks": check_pages, "status_history": status_pages,
        "combined_status": {"total": combined["total_count"], "complete": True}}
    all_jobs = []
    historical_jobs = []
    superseded_checks = {}
    for run in runs:
        assert run["head_sha"] == HEAD, run["id"]
        workflow = pathlib.PurePosixPath(run["path"]).name
        definition = expectations["workflow_definitions"][workflow]
        jobs, job_pages = pages(snapshot, f"jobs-{run['id']}", "jobs")
        pagination[f"jobs-{run['id']}"] = job_pages
        current_jobs = [j for j in jobs if j["run_attempt"] == run["run_attempt"]]
        current_by_name = {j["name"]: j for j in current_jobs}
        assert len(current_by_name) == len(current_jobs), "duplicate current job name"
        expected = {}
        for key, job in definition["jobs"].items():
            for matrix in job["matrix_rows"]:
                expected[job_name(workflow, key, job, matrix)] = (key, job, matrix)
        if final:
            assert set(expected) == {j["name"] for j in current_jobs}, (run["id"], set(expected) - {j["name"] for j in current_jobs})
        for old in jobs:
            assert old["head_sha"] == HEAD and old["run_id"] == run["id"]
            if old["run_attempt"] == run["run_attempt"]:
                continue
            assert old["run_attempt"] < run["run_attempt"], "job attempt exceeds workflow attempt"
            assert old["name"] in expected, "unrecognized historical job"
            replacement = current_by_name.get(old["name"])
            if replacement is None:
                pending.append(f"historical job {old['id']} has no observed latest-attempt replacement")
                continue
            if old["status"] != "completed":
                pending.append(f"historical job {old['id']} remains {old['status']}")
            _, definition_old, _ = expected[old["name"]]
            duration = ((stamp(old["completed_at"]) - stamp(old["started_at"])).total_seconds()
                        if old["completed_at"] and old["started_at"] else None)
            historical = dict(old)
            historical.update(superseded_by_job_id=replacement["id"],
                              latest_run_attempt=run["run_attempt"],
                              duration_seconds=duration,
                              timeout_minutes=definition_old["timeout_minutes"],
                              accounting="historical attempt retained; current replacement must independently pass every required step")
            historical_jobs.append(historical)
            superseded_checks[old["id"]] = historical
        for actual in current_jobs:
            assert actual["head_sha"] == HEAD
            assert actual["run_id"] == run["id"]
            key, job, matrix = expected[actual["name"]]
            selected = condition(job["if"], matrix, run["event"])
            expected_conclusion = "success" if selected else "skipped"
            duration = ((stamp(actual["completed_at"]) - stamp(actual["started_at"])).total_seconds()
                        if actual["completed_at"] and actual["started_at"] else None)
            result = {k: actual[k] for k in ("id", "run_id", "run_attempt", "head_sha", "name", "html_url", "status", "conclusion", "created_at", "started_at", "completed_at")}
            result.update(workflow=workflow, job_key=key, matrix=matrix,
                          duration_seconds=duration, timeout_minutes=job["timeout_minutes"],
                          strategy_max_parallel=job["strategy_max_parallel"],
                          expected_conclusion=expected_conclusion, condition=job["if"],
                          step_checks=[])
            if actual["status"] != "completed":
                pending.append(actual["name"])
            elif actual["conclusion"] != expected_conclusion:
                failures.append(f"{actual['name']}: {actual['conclusion']} != {expected_conclusion}")
            if selected:
                actual_steps = {s["name"]: s for s in actual["steps"]}
                for step in job["steps"]:
                    name = step_name(step)
                    chosen = condition(step["if"], matrix, run["event"])
                    step_actual = actual_steps.get(name)
                    expected_step = "success" if chosen else "skipped"
                    check = {"name": name, "condition": step["if"], "expected": expected_step,
                             "status": step_actual["status"] if step_actual else "missing",
                             "conclusion": step_actual["conclusion"] if step_actual else None}
                    result["step_checks"].append(check)
                    if actual["status"] == "completed" and check["conclusion"] != expected_step:
                        failures.append(f"{actual['name']} / {name}: {check['conclusion']} != {expected_step}")
                for step in actual["steps"]:
                    if step["conclusion"] not in (None, "success", "skipped"):
                        failures.append(f"{actual['name']} / {step['name']}: {step['conclusion']}")
            if duration is not None and duration > job["timeout_minutes"] * 60:
                failures.append(f"{actual['name']}: duration {duration} exceeds configured timeout")
            jobs_out.append(result)
            all_jobs.append(actual)
        expected_run = "skipped" if workflow == "dco.yml" else "success"
        if run["status"] != "completed":
            pending.append(run["name"])
        elif run["conclusion"] != expected_run:
            failures.append(f"run {run['id']}: {run['conclusion']} != {expected_run}")
        run_out.append({k: run[k] for k in ("id", "name", "event", "head_sha", "run_attempt", "html_url", "status", "conclusion", "created_at", "run_started_at", "updated_at")})
    assert {j["id"] for j in all_jobs + historical_jobs} <= {c["id"] for c in checks}
    expected_skipped_checks = {j["id"] for j in jobs_out if j["expected_conclusion"] == "skipped"}
    for check in checks:
        assert check["head_sha"] == HEAD
        if check["status"] != "completed":
            pending.append(f"check {check['id']} ({check['name']}): {check['status']}")
        elif check["id"] in superseded_checks:
            historical = superseded_checks[check["id"]]
            if (check["name"], check["status"], check["conclusion"]) != (historical["name"], historical["status"], historical["conclusion"]):
                pending.append(f"historical check {check['id']} and job observations differ; recapture required")
        elif check["conclusion"] == "skipped" and check["id"] not in expected_skipped_checks:
            failures.append(f"check {check['id']} ({check['name']}): unexpected skip")
        elif check["conclusion"] not in ("success", "skipped"):
            failures.append(f"check {check['id']}: {check['conclusion']}")
    combined_by_context = {s["context"]: s for s in combined["statuses"]}
    assert len(combined_by_context) == len(combined["statuses"]), "duplicate combined status context"
    latest_statuses = {}
    for status in sorted(statuses, key=lambda s: (s["created_at"], s["id"]), reverse=True):
        latest_statuses.setdefault(status["context"], status)
    if "Submission format" not in combined_by_context or "Submission format" not in latest_statuses:
        failures.append("required Submission format status context is missing")
    if set(combined_by_context) != set(latest_statuses):
        pending.append("combined and historical status contexts differ; recapture required")
    for context, status in latest_statuses.items():
        combined_status = combined_by_context.get(context)
        if not combined_status or (combined_status["id"], combined_status["state"]) != (status["id"], status["state"]):
            pending.append(f"status {context}: combined/history observations differ; recapture required")
        if status["state"] == "pending":
            pending.append(f"status {context}: pending")
        elif status["state"] != "success":
            failures.append(f"status {context}: {status['state']}")
    if combined["state"] == "pending":
        pending.append("combined commit status: pending")
    elif combined["state"] != "success":
        failures.append("combined commit status: " + combined["state"])
    assert len([r for r in runs if r["name"] == "CI"]) == 1
    assert len([r for r in runs if r["name"] == "Lint"]) == 1
    if final:
        assert not pending, pending
        assert not failures, failures
    observed_at = max(page["observed_at"] for receipt in pagination.values()
                      for page in receipt.get("pages", []))
    return {"schema": 1, "head": HEAD, "base": BASE, "tree": TREE,
            "observed_at": observed_at,
            "merge_commit": merge["sha"], "merge_tree_identical_to_head": True,
            "pr_url": pr["html_url"], "draft_at_capture": pr["draft"],
            "pr_updated_at": pr["updated_at"], "snapshot": snapshot.name,
            "complete": not pending and not failures, "failures": failures,
            "pending": pending, "runs": run_out, "jobs": jobs_out,
            "historical_jobs": historical_jobs,
            "check_conclusions": dict(collections.Counter(c["conclusion"] or c["status"] for c in checks)),
            "current_check_conclusions": dict(collections.Counter(c["conclusion"] or c["status"] for c in checks if c["id"] not in superseded_checks)),
            "historical_check_conclusions": dict(collections.Counter(c["conclusion"] or c["status"] for c in checks if c["id"] in superseded_checks)),
            "current_check_count": len(checks) - len(superseded_checks),
            "historical_check_count": len(superseded_checks),
            "check_count": len(checks), "combined_status": combined["state"],
            "latest_statuses": {context: {key: status[key] for key in ("id", "state", "created_at", "updated_at", "target_url")}
                                for context, status in latest_statuses.items()},
            "status_history_reconciled_with_combined": not any("recapture required" in item for item in pending),
            "pagination": pagination,
            "configured_pr_job_rows": expectations["configured_pr_job_rows"],
            "configured_pr_job_row_budget": expectations["job_row_budget"],
            "observed_jobs_including_metadata_retriggers": len(all_jobs) + len(historical_jobs),
            "current_attempt_job_count": len(all_jobs),
            "historical_attempt_job_count": len(historical_jobs),
            "observed_peak_concurrent_jobs": peak(all_jobs + historical_jobs, observed_at),
            "observed_peak_ci_jobs": peak([j for j in all_jobs + historical_jobs if j["workflow_name"] == "CI"], observed_at),
            "local_process_limit": expectations["local_process_limit"],
            "aot_shard_limit": expectations["aot_shard_limit"],
            "other_group_worker_limit": expectations["other_group_worker_limit"],
            "global_matrix_max_parallel": None,
            "concurrency_note": "Workflow concurrency cancels superseded runs for the same PR; no matrix max-parallel is configured. Repeated metadata events add separate format jobs without expanding the configured per-event job matrix.",
            "condition_assumptions": {"event_plan": "code", "lean_boundary_validation": True,
                "evidence": "Code-plan bootstrap executed; Lint built/audited Lean. All pinned workflows match the locally qualified source byte for byte."}}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("snapshot", type=pathlib.Path)
    parser.add_argument("--final", action="store_true")
    parser.add_argument("--output", type=pathlib.Path, required=True)
    args = parser.parse_args()
    result = audit(args.snapshot, args.final)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({key: result[key] for key in ("head", "snapshot", "complete", "failures", "pending", "check_count", "check_conclusions", "configured_pr_job_rows", "observed_jobs_including_metadata_retriggers", "observed_peak_concurrent_jobs")}))


if __name__ == "__main__":
    main()
