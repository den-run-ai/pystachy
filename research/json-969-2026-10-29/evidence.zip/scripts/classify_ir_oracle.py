from pathlib import Path
import sys
import collections, difflib, hashlib, json
P=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/scratch/c494f0e17282/combined-ir-oracle')
OUT=P/'classification';OUT.mkdir(exist_ok=True)
manifest=json.loads((P/'manifest.json').read_text());results=json.loads((P/'results.json').read_text())
roots=[manifest['baseline'],manifest['candidate']]
def read_output(p):
 return p.read_text() if p.exists() else ''
def normalize(s):
 for root in roots:s=s.replace(root,'<REPO>')
 return s
rows=[]
for r in results:
 row={'index':r['index'],'case':r['case'],'mode':r['mode']}
 o,n=r['results']['old'],r['results']['new'];p=P/f"{r['index']:04d}"
 row['exit_status']=[o['exit_status'],n['exit_status']]
 row['raw_equal']=o['ir_sha256']==n['ir_sha256'] and o['messages_sha256']==n['messages_sha256'] and row['exit_status'][0]==row['exit_status'][1]
 row['original_harness_differences']=r['differences']
 row['normalized_differences']=[]
 if row['raw_equal']:row['bucket']='raw_identical'
 else:
  for ext in ['ll','msg']:
   old=normalize(read_output(p/f'old.{ext}'));new=normalize(read_output(p/f'new.{ext}'))
   if old!=new:
    row['normalized_differences'].append(ext)
    (OUT/f"{r['index']:04d}.{ext}.diff").write_text(''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='old',tofile='new',n=3)))
  row['bucket']='pending' if row['normalized_differences'] else 'path_only'
 rows.append(row)
report={'roots_normalized_symmetrically':roots,'normalization':'Replace both known repository roots with <REPO> in each raw output. Raw-equal outputs use fast path. Original raw and normalized files untouched.','manifest_candidate_head':manifest['candidate_head'],'manifest_candidate_tree':manifest['candidate_tree'],'count':len(rows),'counts':dict(collections.Counter(r['bucket'] for r in rows)),'cases':rows}
(OUT/'classification.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['counts'])
for r in rows:
 if r['bucket']=='pending':print(r['index'],r['case'],r['normalized_differences'],[(ext,(OUT/f"{r['index']:04d}.{ext}.diff").stat().st_size) for ext in r['normalized_differences']])
