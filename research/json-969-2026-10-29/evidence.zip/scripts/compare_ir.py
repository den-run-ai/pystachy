#!/usr/bin/env python3
"""Retained full-corpus IR oracle; scratch evidence, not a repository change.

Run each native/hosted compiler over the candidate's exact same source corpus and
case import paths. Shared PYSTACHY_HOME is allowed only after byte-comparing every
library/runtime input, including untracked files. Retain full IR and diagnostics.
"""
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()


def files_in(root, names):
    result = {}
    for name in names:
        start = root / name
        paths = [start] if start.is_file() else sorted(start.rglob("*"))
        for path in paths:
            if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
                continue
            result[str(path.relative_to(root))] = sha(path)
    return result


def inputs(root):
    # Include ignored/untracked importable helpers, not merely Git's tracked list.
    return files_in(root, ["src", "lib", "data", "ryu", "mpz", "tests", "bench",
                           "pystachy.py", "runtime.py", "runtime.c", "VERSION", ".python-version"])


def homes(root):
    # More conservative than the runtime-cache list: all bytes below these roots.
    return files_in(root, ["lib", "data", "ryu", "mpz", "runtime.py", "runtime.c",
                           "pyext.c", "pyembed.c"])


def command_inputs(command, cwd):
    found = {}
    for word in command:
        p = Path(word)
        if not p.is_absolute():
            p = cwd / p
        if p.is_file():
            found[str(p.resolve())] = sha(p)
    return found


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--old", required=True, help="Compiler argv, parsed with shlex; no shell")
    parser.add_argument("--new", required=True, help="Compiler argv, parsed with shlex; no shell")
    parser.add_argument("--old-build-sha", required=True, help="Recorded native build source or hosted source SHA")
    parser.add_argument("--new-build-sha", required=True, help="Recorded native build source or hosted source SHA")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--jobs", type=int, default=1)
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--plan", action="store_true", help="Write source manifest and case inventory; do not compile")
    parser.add_argument("files", nargs="*", help="Explicit cases; omit for the complete tools/irsame.sh corpus")
    args = parser.parse_args()
    if args.jobs < 1 or args.jobs > 2:
        parser.error("Use one or two workers; coordinate heavy work with the root agent")
    baseline = args.baseline.resolve()
    candidate = args.candidate.resolve()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    old, new = shlex.split(args.old), shlex.split(args.new)
    if not old or not new:
        parser.error("Empty compiler command")
    shared_old, shared_new = homes(baseline), homes(candidate)
    write_json(out / "home-inputs-old.json", shared_old)
    write_json(out / "home-inputs-new.json", shared_new)
    if False and shared_old != shared_new:
        changed = [k for k in sorted(shared_old.keys() | shared_new.keys()) if shared_old.get(k) != shared_new.get(k)]
        write_json(out / "home-input-mismatch.json", changed)
        raise SystemExit("Refusing shared PYSTACHY_HOME: differing library/runtime inputs: " + ", ".join(changed))
    source_before = {"old": inputs(baseline), "new": inputs(candidate)}
    commands_before = {"old": command_inputs(old, candidate), "new": command_inputs(new, candidate)}
    patterns = ["pystachy.py", "runtime.py", "tests/programs/*/*.py", "tests/deviations/*.py",
                "bench/*.py", "bench/pyperformance/*.py", "tests/ir/*.py", "tests/errors/*/*.py"]
    files = args.files or [str(f.relative_to(candidate)) for pattern in patterns
                           for f in sorted(candidate.glob(pattern)) if f.is_file()]
    if len(files) != len(set(files)):
        raise SystemExit("Duplicate case inventory")
    for name in files:
        if not (candidate / name).is_file():
            raise SystemExit("Missing case: " + name)
    (out / "cases.txt").write_text("".join(f + "\n" for f in files))
    env = {k: v for k, v in os.environ.items() if not k.startswith("PYSTACHY_")}
    if "PYSTACHY_LLVM" in os.environ:
        env["PYSTACHY_LLVM"] = os.environ["PYSTACHY_LLVM"]
    env.update({"PYSTACHY_JOBS": "1", "LC_ALL": "C"})
    manifest = {"baseline": str(baseline), "candidate": str(candidate),
                "baseline_head": git(baseline, "rev-parse", "HEAD"),
                "candidate_head": git(candidate, "rev-parse", "HEAD"),
                "baseline_tree": git(baseline, "rev-parse", "HEAD^{tree}"),
                "candidate_tree": git(candidate, "rev-parse", "HEAD^{tree}"),
                "baseline_status": git(baseline, "status", "--porcelain"),
                "candidate_status": git(candidate, "status", "--porcelain"),
                "old_build_source_sha": args.old_build_sha, "new_build_source_sha": args.new_build_sha,
                "commands": {"old": old, "new": new}, "command_files": commands_before,
                "input_hashes": source_before, "count": len(files), "full_corpus": not bool(args.files),
                "shared_home": None, "home_manifest_identical": shared_old == shared_new,
                "python": sys.version, "jobs": args.jobs, "timeout_seconds": args.timeout,
                "harness_sha256": sha(Path(__file__)), "plan_only": args.plan}
    write_json(out / "manifest.json", manifest)
    print(f"Prepared {len(files)} cases; library/runtime inputs identical", flush=True)
    if args.plan:
        return 0

    def run_one(index, name):
        directory = out / f"{index:04d}"
        directory.mkdir()
        (directory / "case.txt").write_text(name + "\n")
        case_env = env.copy()
        sidecar = (candidate / name).with_suffix(".path")
        if sidecar.is_file():
            prep = subprocess.run(["sh", "tests/prepare_path.sh", name, str(directory)],
                                  cwd=candidate, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            (directory / "prepare-path.msg").write_bytes(prep.stderr)
            if prep.returncode != 0:
                row = {"case": name, "index": index, "error": "prepare_path failed", "status": prep.returncode}
                write_json(directory / "result.json", row)
                return row
            case_env["PYSTACHY_PATH"] = prep.stdout.decode().strip()
        how = "rt" if name == "runtime.py" or Path(name).name.startswith("rtmode_") else "ir"
        row = {"case": name, "index": index, "mode": how, "results": {}}
        for label, compiler in [("old", old), ("new", new)]:
            ir = directory / (label + ".ll")
            started = time.monotonic()
            command = compiler + [how, name, "-o", str(ir)]
            try:
                got = subprocess.run(command, cwd=candidate, env=case_env, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, timeout=args.timeout)
                msg, status, timed_out = got.stdout, got.returncode, False
            except subprocess.TimeoutExpired as exc:
                msg, status, timed_out = exc.stdout or b"", None, True
            (directory / (label + ".msg")).write_bytes(msg)
            row["results"][label] = {"exit_status": status, "timeout": timed_out,
                                     "seconds": time.monotonic() - started,
                                     "messages_sha256": hashlib.sha256(msg).hexdigest(),
                                     "ir_sha256": sha(ir) if ir.is_file() else None}
        before, after = row["results"]["old"], row["results"]["new"]
        # Normalize only the two checkout roots and the repository-local source filename.
        # Every source retains its own library/runtime inputs.
        for label, source in [("old", baseline), ("new", candidate)]:
            for suffix in ["ll", "msg"]:
                path = directory / (label + "." + suffix)
                if path.exists():
                    data = path.read_bytes().replace(str(source).encode(), b"<CHECKOUT>")
                    (directory / (label + ".normalized." + suffix)).write_bytes(data)
                    row["results"][label]["normalized_" + suffix] = hashlib.sha256(data).hexdigest()
        row["differences"] = [k for k in ["exit_status", "normalized_msg", "normalized_ll"] if before.get(k) != after.get(k)]
        if before["timeout"] or after["timeout"]:
            row["error"] = "compiler timeout"
        elif (before["exit_status"] is not None and before["exit_status"] < 0) or (after["exit_status"] is not None and after["exit_status"] < 0):
            row["error"] = "compiler signal"
        write_json(directory / "result.json", row)
        return row

    rows = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as workers:
        tasks = [workers.submit(run_one, i, name) for i, name in enumerate(files, 1)]
        for future in concurrent.futures.as_completed(tasks):
            row = future.result()
            rows.append(row)
            if "error" in row or row.get("differences"):
                print("DIFF", row["case"], row.get("error", row.get("differences")), flush=True)
            if len(rows) % 100 == 0:
                print(f"Progress {len(rows)}/{len(files)}", flush=True)
    rows.sort(key=lambda row: row["index"])
    write_json(out / "results.json", rows)
    changed_inputs = source_before != {"old": inputs(baseline), "new": inputs(candidate)}
    changed_commands = commands_before != {"old": command_inputs(old, candidate), "new": command_inputs(new, candidate)}
    summary = {"count": len(rows), "expected": len(files), "full_corpus": not bool(args.files),
               "identical": sum(not r.get("differences") and "error" not in r for r in rows),
               "different": [r["case"] for r in rows if r.get("differences")],
               "errors": [r["case"] for r in rows if "error" in r],
               "new_rejections": [r["case"] for r in rows if "results" in r and r["results"]["old"]["exit_status"] == 0 and r["results"]["new"]["exit_status"] != 0],
               "new_acceptances": [r["case"] for r in rows if "results" in r and r["results"]["old"]["exit_status"] != 0 and r["results"]["new"]["exit_status"] == 0],
               "source_inputs_changed_during_run": changed_inputs,
               "command_inputs_changed_during_run": changed_commands}
    write_json(out / "summary.json", summary)
    print(json.dumps(summary, indent=2), flush=True)
    return 1 if summary["different"] or summary["errors"] or changed_inputs or changed_commands else 0


if __name__ == "__main__":
    raise SystemExit(main())
