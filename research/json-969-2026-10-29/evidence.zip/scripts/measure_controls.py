import hashlib, importlib.util, json, os, re, statistics, subprocess, sys, time
from pathlib import Path
ROOT=Path('/workspace/scratch/c494f0e17282')
OUT=ROOT/'control-evidence'; OUT.mkdir(exist_ok=True)
variants={'alpha3':Path('/workspace/scratch/d7d6ff7f2910/alpha3'),'main':ROOT/'pystachy','combined':ROOT/'combined'}
inputs={'typed':ROOT/'combined/bench/smoke/json_decode.py','any':ROOT/'combined/bench/smoke/json_decode_any.py'}
settings={k:v for k,v in os.environ.items() if not k.startswith('PYSTACHY_') and k not in ('PYTHONPATH','PYTHONHOME')}
settings['PYSTACHY_LLVM']=os.environ['PYSTACHY_LLVM']; settings['PYTHONHASHSEED']='0'
cpu=min(os.sched_getaffinity(0)); rows={}
def run(args, cwd, env, label):
 r=subprocess.run(args,cwd=cwd,env=env,capture_output=True,timeout=180,preexec_fn=lambda:os.sched_setaffinity(0,{cpu}))
 (OUT/(label+'.out')).write_bytes(r.stdout); (OUT/(label+'.log')).write_bytes(r.stderr)
 if r.returncode: raise RuntimeError((label,r.returncode,r.stderr[-1500:]))
 return r
spec=importlib.util.spec_from_file_location('oldh', '/workspace/scratch/d7d6ff7f2910/json_acceptance.py'); oldh=importlib.util.module_from_spec(spec); spec.loader.exec_module(oldh)
meta={'variants':{k:oldh.source_identity(v) for k,v in variants.items()},'inputs':{k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in inputs.items()},'python':sys.version,'llvm':subprocess.check_output([settings['PYSTACHY_LLVM']+'/clang','--version'],text=True),'cpu':cpu,'settings':{'PYTHONHASHSEED':'0','private_caches':True}}
(OUT/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
for kind,src in inputs.items():
 for name,home in variants.items():
  env=settings|{'PYSTACHY_CACHE':str(OUT/('cache-'+name))}
  binary=OUT/(kind+'-'+name)
  run([sys.executable,str(home/'pystachy.py'),'build',str(src),'-o',str(binary)],home,env,kind+'-'+name+'-build')
  tests=[('any',['2000'])] if kind=='any' else [(x,[x,'3000']) for x in ['numeric','strings','mixed']]
  for case,args in tests:
   oracle=run([sys.executable,str(src),*args],home,env,case+'-'+name+'-oracle').stdout
   path=OUT/(case+'-'+name+'.callgrind')
   r=run(['valgrind','--tool=callgrind','--error-exitcode=99','--callgrind-out-file='+str(path),str(binary),*args],home,env,case+'-'+name)
   if r.stdout!=oracle: raise RuntimeError('output mismatch '+case+' '+name)
   count=int(re.search(r'^summary: (\d+)',path.read_text(),re.M)[1])
   rows.setdefault(case,{})[name]={'instructions':count,'stdout_sha256':hashlib.sha256(oracle).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
   (OUT/'profiles.json').write_text(json.dumps(rows,indent=2)+'\n'); print(case,name,count,flush=True)
# Interleaved steady-state timings; loop timers exclude compiler startup.
timings={}
for kind,src in inputs.items():
 tests=[('any',['20000'])] if kind=='any' else [(x,[x,'30000']) for x in ['numeric','strings','mixed']]
 for case,args in tests:
  for mode in ['aot','jit']:
   samples={n:[] for n in variants}
   for i in range(9):
    order=list(variants) if i%2==0 else list(reversed(variants))
    for name in order:
     home=variants[name]; env=settings|{'PYSTACHY_CACHE':str(OUT/('cache-'+name))}
     cmd=[str(OUT/(kind+'-'+name))] if mode=='aot' else [sys.executable,str(home/'pystachy.py'),'run',str(src)]
     r=run(cmd+args,home,env,f'{case}-{mode}-{i}-{name}')
     oracle=run([sys.executable,str(src),*args],home,env,f'{case}-{mode}-{i}-{name}-oracle').stdout if i==0 else None
     if oracle is not None and r.stdout!=oracle: raise RuntimeError('timing output mismatch')
     seconds=float(r.stderr.decode().strip().removeprefix('seconds '))
     if i>=2:samples[name].append(seconds)
   timings[case+'-'+mode]={'samples':samples,'medians':{n:statistics.median(v) for n,v in samples.items()},'paired_combined_main':statistics.median([a/b for a,b in zip(samples['combined'],samples['main'],strict=True)]),'paired_combined_alpha3':statistics.median([a/b for a,b in zip(samples['combined'],samples['alpha3'],strict=True)])}
   (OUT/'timings.json').write_text(json.dumps(timings,indent=2)+'\n');print(case,mode,timings[case+'-'+mode]['paired_combined_main'],flush=True)
assert {k:oldh.source_identity(v) for k,v in variants.items()}==meta['variants']
