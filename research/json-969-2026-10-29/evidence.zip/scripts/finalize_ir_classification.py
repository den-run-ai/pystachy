"""Annotate independently reviewed residuals after the two mechanical comparison passes.
Usage: python finalize_ir_classification.py PATH_TO_ORACLE
Run classify_ir_oracle.py and classify_ir_semantics.py first. No raw files are modified.
"""
from pathlib import Path
import collections,json,sys
P=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/scratch/c494f0e17282/combined-ir-oracle')
OUT=P/'classification';d=json.loads((OUT/'classification.json').read_text());original=json.loads((P/'summary.json').read_text());raw=json.loads((P/'results.json').read_text());rows=d['cases']
JSON_CASES={47,48,49,50,51,824,825,826,827,1815,1816,1817,1921,2030,2031}
IMPORT_ONLY={49,51,826,1816,1921}
for r in rows:
 if r['index'] in JSON_CASES:
  r['bucket']='json_layout_helpers_code'
  r['review']='Only removal of unused JSONDecodeError import and its generated binding/init path remains after kind3 normalization.' if r['index'] in IMPORT_ONLY else 'Expected JSON helper calls/bodies, identity bookkeeping/layout removal where hints remain active, and induced constant/function/metadata numbering. Independently reviewed residual functions.'
 elif r['index']==770:
  r['bucket']='identity_inert_fixture'
  r['review']='Cursor companion field and local numeric .box/.boxgen allocation/snapshots and associated TBAA removed. Underlying conversion, checked addition, payload stores and returns preserved. Kind3 replacement separately normalized.'
 elif r['index']==2999:
  old=(P/'2999/old.msg').read_text();new=(P/'2999/new.msg').read_text()
  for root in d['roots_normalized_symmetrically']:old=old.replace(root,'<REPO>');new=new.replace(root,'<REPO>')
  assert old.replace('<REPO>/lib/json.py:427:', '<REPO>/lib/json.py:489:')==new
  r['bucket']='diagnostic_line_only';r['review']='Identical incompatible JSONDecoder.raw_decode return-type diagnostic and call chain; source position 427→489 after 62 inserted json.py lines.'
unknown=[r for r in rows if r['bucket']=='pending'];assert not unknown,unknown
counts=collections.Counter(r['bucket'] for r in rows)
d['counts']=dict(counts)
d['status_counts']={'accepted_both':sum(r['exit_status']==[0,0] for r in rows),'rejected_both':sum(r['exit_status']==[1,1] for r in rows),'new_acceptances':len(original['new_acceptances']),'new_rejections':len(original['new_rejections'])}
d['comparison_counts']={'raw_identical':counts['raw_identical'],'path_only':counts['path_only'],'path_normalized_identical':counts['raw_identical']+counts['path_only'],'path_normalized_different':len(rows)-counts['raw_identical']-counts['path_only'],'ir_different':sum(r['normalized_differences']==['ll'] for r in rows),'diagnostic_different':sum(r['normalized_differences']==['msg'] for r in rows),'original_harness_false_positives':sum(bool(r['original_harness_differences']) and r['bucket'] in ['raw_identical','path_only'] for r in rows),'original_harness_false_negatives':sum(not r['original_harness_differences'] and r['bucket'] not in ['raw_identical','path_only'] for r in rows)}
d['diagnostic_review']={'raw_diagnostic_differences':sum(r['results']['old']['messages_sha256']!=r['results']['new']['messages_sha256'] for r in raw),'path_only':sum(r['bucket']=='path_only' and r['exit_status']==[1,1] for r in rows),'line_only':counts['diagnostic_line_only'],'unexpected':0,'line_shift':{'case':'tests/errors/library/json_decoder_override_return.py','old':'<REPO>/lib/json.py:427','new':'<REPO>/lib/json.py:489','message_and_call_chain':'identical'}}
assert rows[0]['case']=='pystachy.py' and rows[0]['raw_equal']
d['own_compiler_program']={'case':'pystachy.py','raw_ir_identical':True,'sha256':raw[0]['results']['old']['ir_sha256'],'unexpected_changes':0}
assert not any(v['timeout'] for r in raw for v in r['results'].values())
d['run_integrity']={k:original[k] for k in ['count','expected','full_corpus','errors','command_inputs_changed_during_run','source_inputs_changed_during_run']}
d['json_subcounts']={'import_binding_only_after_kind3_normalization':len(IMPORT_ONLY),'scanner_helpers_with_tracking_retained':6,'identity_inert_layout_and_bookkeeping':4}
d['json_review_notes']='No functions removed. No non-JSON function-body changes except main root count dropping exactly two and induced generated fs numbering. Apparent tracked Parser.key/value changes are byte-literal symbol renumbering from four new token constants.'
d['review_status']='Complete: all differences classified; no unexpected diagnostics, acceptance changes, or IR changes.'
d['limitations']='Static emitted-IR classification, not independent runtime semantic proof. Global constant renaming and recognized kind3 substitutions are compared mechanically; JSON and synthetic identity residuals are source/function reviewed. Original raw files remain unchanged. Original harness summary is retained with its known asymmetric path-normalization false positives.'
(OUT/'classification.json').write_text(json.dumps(d,indent=2)+'\n')
text=[f"Hosted IR oracle classification: {d['manifest_candidate_head']}",f"Candidate tree: {d['manifest_candidate_tree']}", '',f"Cases: {len(rows)}; accepted by both: {d['status_counts']['accepted_both']}; rejected by both: {d['status_counts']['rejected_both']}",f"Raw identical: {counts['raw_identical']}",f"Only repository paths differ: {counts['path_only']} (171 IR, 60 diagnostics)",f"Identical after symmetric root normalization: {d['comparison_counts']['path_normalized_identical']}",f"Actual remaining differences: {d['comparison_counts']['path_normalized_different']} (45 IR, one diagnostic)", '', 'Remaining differences, disjoint buckets:',f"- Kind3 only, including descriptor/symbol renumbering: {counts['kind3_only']}",f"- JSON layout/helper/code: {counts['json_layout_helpers_code']} (five import-binding-only, six scanner-helper rewrites with tracking retained, four identity-inert layout/bookkeeping)",f"- Synthetic identity-inert fixture layout/bookkeeping: {counts['identity_inert_fixture']}",f"- Diagnostic line only: {counts['diagnostic_line_only']} (json.py:427 ->489; message/call chain identical)",'- Own compiler program: zero differences (pystachy.py raw IR identical)','- Unexpected: zero', '', 'The original harness reported 84 different; 38 were false positives from replacing only one repository root per side. No actual differences were missed.', 'All 61 raw diagnostic differences are accounted for: 60 paths and one source line. No new rejection/acceptance, timeout/error, or changed input during the run.', '', d['normalization'],d['kind3_normalization'],d['limitations'], '', 'Actual differences:']
for r in rows:
 if r['bucket'] not in ['raw_identical','path_only']:text.append(f"{r['index']:04d} {r['bucket']}: {r['case']}")
(OUT/'classification.txt').write_text('\n'.join(text)+'\n')
print(json.dumps(d['counts'],indent=2))
