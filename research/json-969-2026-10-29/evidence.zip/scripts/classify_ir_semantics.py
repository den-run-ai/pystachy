from pathlib import Path
import sys
import collections,difflib,hashlib,json,re
P=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/scratch/c494f0e17282/combined-ir-oracle');OUT=P/'classification';report=json.loads((OUT/'classification.json').read_text())
roots=report['roots_normalized_symmetrically']
def canonical(s):
 for root in roots:s=s.replace(root,'<REPO>')
 smap={m.group(1):'@S.'+hashlib.sha256(m.group(2).encode()).hexdigest()[:16] for m in re.finditer(r'^(@s\.\d+) = (.+)$',s,re.M)}
 stringdefs={m.group(1):m.group(2) for m in re.finditer(r'^(@s\.\d+) = (.+)$',s,re.M)}
 marked=[smap[k] for k,v in stringdefs.items() if 'c"!s\\00"' in v]
 s=re.sub(r'@s\.\d+\b',lambda m:smap.get(m[0],m[0]),s)
 bytesmap={m.group(1):'@B.'+hashlib.sha256(m.group(2).encode()).hexdigest()[:16] for m in re.finditer(r'^(@b\.\d+) = (.+)$',s,re.M)}
 s=re.sub(r'@b\.\d+\b',lambda m:bytesmap.get(m[0],m[0]),s)
 bmap={m.group(1):'@DBS.'+hashlib.sha256(m.group(2).encode()).hexdigest()[:16] for m in re.finditer(r'^(@dbs\.\d+) = (.+)$',s,re.M)}
 s=re.sub(r'@dbs\.\d+\b',lambda m:bmap.get(m[0],m[0]),s)
 changes=0
 for sym in marked:
  pat=r'(@pys_dict_(?:new(?:_atomic)?|fromkeys)\()i64 ptrtoint \(ptr '+re.escape(sym)+r' to i64\)'
  s,n=re.subn(pat,r'\g<1>i64 3',s);changes+=n
  pat=r'(store i64 )ptrtoint \(ptr getelementptr \(i8, ptr '+re.escape(sym)+r', i64 2\) to i64\)'
  s,n=re.subn(pat,r'\g<1>3',s);changes+=n
  # Only discard this known obsolete descriptor constant when it has no uses.
  if s.count(sym)==1:s=re.sub(r'^'+re.escape(sym)+r' = .*\n','',s,flags=re.M)
 return s,changes
for r in report['cases']:
 if r['bucket']!='pending' or r['normalized_differences']!=['ll']:continue
 p=P/f"{r['index']:04d}";old,n=canonical((p/'old.ll').read_text());new,k=canonical((p/'new.ll').read_text())
 r['kind3_constructor_replacements']=n
 r['kind3_new_legacy_constructors']=k
 if old==new:
  r['bucket']='kind3_only'
  (OUT/(str(r['index']).zfill(4)+'.reduced.diff')).unlink(missing_ok=True)
 else:
  diff=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='old.canonical',tofile='new.canonical',n=3))
  (OUT/f"{r['index']:04d}.reduced.diff").write_text(diff)
  r['reduced_diff_bytes']=len(diff)
report['counts']=dict(collections.Counter(r['bucket'] for r in report['cases']))
report['kind3_normalization']='Content-address @s, @b and @dbs symbols, replace only !s descriptor arguments of pys_dict_new/pys_dict_new_atomic/pys_dict_fromkeys and marked !s kind-field stores with immediate 3, discard the !s constant only when unused.'
(OUT/'classification.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['counts'])
for r in report['cases']:
 if r['bucket']=='pending':print(r['index'],r['case'],r.get('kind3_constructor_replacements'),r.get('reduced_diff_bytes'))
