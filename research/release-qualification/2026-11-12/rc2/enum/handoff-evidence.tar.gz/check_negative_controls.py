"""Native before/after controls, including the explicitly deferred formatting boundary."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

ROOT = Path(__file__).resolve().parent
PYTHON = ROOT.parent / "toolchains/python/cpython-3.13.16-linux-x86_64-gnu/bin/python3.13"
ROOTS = {"baseline": ROOT.parent / "pystachy-rc", "corrected": ROOT.parent / "rc-exit-intenum"}
EXPECT = {"baseline": "7c75948747090c7d6a0a0bf76f9aecee8de90a15",
          "corrected": "395227b75bb777401627c0296a18fe71388070e7"}
environment = {k: v for k, v in os.environ.items()
               if not k.startswith("PYSTACHY_") and k not in ("PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV")}
llvm = ROOT.parent / "toolchains/debian/root/usr/lib/llvm-19/bin"
environment.update(PYSTACHY_LLVM=str(llvm), PYSTACHY_IRCHECK="1",
                   LD_LIBRARY_PATH=str(ROOT.parent / "toolchains/debian/root/usr/lib/x86_64-linux-gnu"))
environment["PATH"] = str(llvm) + ":" + str(PYTHON.parent) + ":" + environment["PATH"]


def run(command, env):
    p = subprocess.run(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                       capture_output=True, text=True, timeout=180)
    return {"status": p.returncode, "stdout": p.stdout, "stderr": p.stderr}


rows = []
for name in ("index_override", "stored_value_mutation", "str_override_finally"):
    path = ROOT / (name + ".py")
    expected = run([str(PYTHON), str(path)], {"PATH": environment["PATH"]})
    for label, repo in ROOTS.items():
        commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
        assert commit == EXPECT[label]
        assert subprocess.check_output(["git", "status", "--porcelain"], cwd=repo, text=True) == ""
        current = dict(environment, PYSTACHY_HOME=str(repo),
                       PYSTACHY_CACHE=str(ROOT / ("controls-cache-" + label)))
        binary = ROOT / (name + ".native-" + label)
        build = run([str(repo / "pystachy"), "build", str(path), "-o", str(binary)], current)
        assert build == {"status": 0, "stdout": "", "stderr": ""}, build
        for mode, command in (("jit", [str(repo / "pystachy"), "run", str(path)]),
                              ("aot", [str(binary)])):
            actual = run(command, current)
            row = {"case": name, "compiler": label, "source_commit": commit,
                   "compiler_sha256": hashlib.sha256((repo / "pystachy").read_bytes()).hexdigest(),
                   "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                   "mode": mode, "expected_cpython": expected, "actual": actual,
                   "matches_cpython": actual == expected,
                   "known_formatting_deviation": name == "str_override_finally"}
            if label == "corrected" and name != "str_override_finally":
                assert row["matches_cpython"], row
            if label == "corrected" and name == "str_override_finally":
                assert actual == {"status": 0, "stdout": "str called\nfinally\n", "stderr": ""}, row
            rows.append(row)
report = {"python": "3.13.16", "llvm": "19.1.7", "runs": rows,
          "scope_note": "Side-effecting __str__ still runs eagerly when constructing SystemExit; this documented pre-existing behavior is outside the accepted exit-status correction."}
(ROOT / "native-negative-controls.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
