"""Compare native exit status, complete stdout and complete stderr with pinned CPython."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'rc-exit-intenum'
PYTHON = ROOT.parent / 'toolchains/python/cpython-3.13.16-linux-x86_64-gnu/bin/python3.13'
LLVM = ROOT.parent / 'toolchains/debian/root/usr/lib/llvm-19/bin'
SOURCE = '395227b75bb777401627c0296a18fe71388070e7'
controls = [
    'exit_none', 'exit_bool', 'exit_message', 'exit_tuple_status', 'exit_systemexit',
    'exc_exit_optional', 'exit_none_object', 'exc_class_exit', 'exit_optional_code',
]
cases = sorted({p for pattern in ('*enum*.py', 'exit_intflag_stored_*.py', 'exit_object_nonint_protocol.py')
                for p in (REPO / 'tests/programs/exceptions').glob(pattern)} |
               {REPO / 'tests/programs/exceptions' / (name + '.py') for name in controls})
env = {k: v for k, v in os.environ.items()
       if not k.startswith('PYSTACHY_') and k not in ('PYTHONPATH', 'PYTHONHOME', 'VIRTUAL_ENV')}
env.update(PYSTACHY_LLVM=str(LLVM),
           LD_LIBRARY_PATH=str(ROOT.parent / 'toolchains/debian/root/usr/lib/x86_64-linux-gnu'),
           PYSTACHY_CACHE=str(ROOT / 'native-cache'), PYSTACHY_IRCHECK='1')
env['PATH'] = str(LLVM) + ':' + str(PYTHON.parent) + ':' + env['PATH']
(ROOT / 'matrix-binaries').mkdir(exist_ok=True)


def run(command, environment):
    started = time.monotonic()
    r = subprocess.run(command, cwd=REPO, env=environment, stdin=subprocess.DEVNULL,
                       capture_output=True, timeout=180)
    return {'status': r.returncode, 'stdout': r.stdout.decode(), 'stderr': r.stderr.decode()}, time.monotonic() - started


def check(path):
    expected, _ = run([str(PYTHON), str(path), 'a1', 'a2'], {'PATH': env['PATH']})
    rows = []
    binary = ROOT / 'matrix-binaries' / path.stem
    build, build_seconds = run([str(REPO / 'pystachy'), 'build', str(path), '-o', str(binary)], env)
    if build != {'status': 0, 'stdout': '', 'stderr': ''}:
        return {'case': str(path.relative_to(REPO)), 'build': build, 'passed': False}
    for stress in (False, True):
        for mode in ('jit', 'aot'):
            current = dict(env)
            if mode == 'jit':
                if stress:
                    current['PYSTACHY_GC_STRESS_PROGRAM'] = '1'
                command = [str(REPO / 'pystachy'), 'run', str(path), 'a1', 'a2']
            else:
                if stress:
                    current['PYSTACHY_GC_STRESS'] = '1'
                command = [str(binary), 'a1', 'a2']
            actual, seconds = run(command, current)
            rows.append({'mode': mode, 'gc_stress': stress, 'actual': actual,
                         'seconds': seconds, 'matches_cpython': actual == expected})
    return {'case': str(path.relative_to(REPO)), 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'expected_cpython': expected, 'build': build, 'build_seconds': build_seconds,
            'aot_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'runs': rows,
            'passed': all(row['matches_cpython'] for row in rows)}


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == SOURCE
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True) == ''
with ThreadPoolExecutor(max_workers=2) as pool:
    results = list(pool.map(check, cases))
report = {'source_commit': SOURCE, 'python': 'CPython 3.13.16', 'llvm': '19.1.7',
          'compiler_sha256': hashlib.sha256((REPO / 'pystachy').read_bytes()).hexdigest(),
          'case_count': len(results), 'run_count': sum(len(x.get('runs', [])) for x in results),
          'passed': all(x['passed'] for x in results), 'cases': results}
(ROOT / 'native-exit-matrix.json').write_text(json.dumps(report, indent=2) + '\n')
for result in results:
    print(('PASS ' if result['passed'] else 'FAIL ') + result['case'])
print(json.dumps({key: report[key] for key in ('source_commit', 'case_count', 'run_count', 'passed')}))
raise SystemExit(0 if report['passed'] else 1)
