import sys
from enum import IntEnum
class Status(IntEnum):
    OK = 0
Status.OK._value_ = 7
print(Status.OK.value, flush=True)
sys.exit(Status.OK)
