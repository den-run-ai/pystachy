import sys
from enum import IntEnum

class Status(IntEnum):
    OK = 0
    def __index__(self) -> int:
        print("index called", flush=True)
        return 7

print("bye", flush=True)
sys.exit(Status.OK)
