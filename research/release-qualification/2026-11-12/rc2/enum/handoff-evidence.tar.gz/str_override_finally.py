import sys
from enum import IntEnum
class Status(IntEnum):
    OK = 0
    def __str__(self) -> str:
        print("str called", flush=True)
        return "custom"
try:
    sys.exit(Status.OK)
finally:
    print("finally", flush=True)
