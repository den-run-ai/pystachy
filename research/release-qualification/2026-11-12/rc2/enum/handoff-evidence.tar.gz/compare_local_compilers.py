"""Retain a local, source-pinned version of the repository's compiler IR oracle.

This is local development evidence, not a sealed CI verification bundle. It uses
the same corpus and exact diagnostic normalization functions as tools/irsame.sh.
Raw IR is never normalized and is retained losslessly as gzip files.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import gzip
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "pystachy-rc"
NEW = ROOT.parent / "rc-exit-intenum"
OUTPUT = ROOT / "ir-comparison"
EXPECTED = {
    "old": "7c75948747090c7d6a0a0bf76f9aecee8de90a15",
    "new": "395227b75bb777401627c0296a18fe71388070e7",
}
ROOTS = {"old": OLD, "new": NEW}
PATTERNS = (
    "tests/programs/*/*.py", "tests/deviations/*.py", "bench/*.py",
    "bench/pyperformance/*.py", "tests/ir/*.py", "tests/errors/*/*.py",
)


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def git(root, *args):
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()


def identity(root):
    return {"commit": git(root, "rev-parse", "HEAD"),
            "tree": git(root, "rev-parse", "HEAD^{tree}"),
            "worktree_status": git(root, "status", "--porcelain"),
            "compiler_sha256": digest(root / "pystachy")}


def env():
    e = {k: v for k, v in os.environ.items()
         if not k.startswith("PYSTACHY_") and k not in ("PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV")}
    llvm = ROOT.parent / "toolchains/debian/root/usr/lib/llvm-19/bin"
    python = ROOT.parent / "toolchains/python/cpython-3.13.16-linux-x86_64-gnu/bin"
    e.update(PYSTACHY_LLVM=str(llvm), PYSTACHY_IRCHECK="1", PYSTACHY_JOBS="2",
             LD_LIBRARY_PATH=str(ROOT.parent / "toolchains/debian/root/usr/lib/x86_64-linux-gnu"))
    e["PATH"] = str(llvm) + ":" + str(python) + ":" + e["PATH"]
    return e


def run(command, environment, log, timeout=180):
    started = time.monotonic()
    timed_out = False
    with log.open("wb") as output:
        process = subprocess.Popen(command, cwd=NEW, env=environment,
                                   stdin=subprocess.DEVNULL, stdout=output,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait()
    return {"returncode": code, "timed_out": timed_out,
            "seconds": time.monotonic() - started,
            "log_sha256": digest(log), "log_bytes": log.stat().st_size}


def file_info(path):
    return ({"exists": True, "bytes": path.stat().st_size, "sha256": digest(path)}
            if path.exists() else {"exists": False})


def compress(path):
    if path.exists():
        target = path.with_name(path.name + ".gz")
        with path.open("rb") as src, target.open("wb") as dst:
            with gzip.GzipFile(filename="", fileobj=dst, mode="wb", mtime=0, compresslevel=1) as gz:
                shutil.copyfileobj(src, gz)
        path.unlink()


def compare(entry):
    directory = OUTPUT / "cases" / f"{entry['index']:05d}"
    directory.mkdir(parents=True)
    result = {"input": entry, "runs": {}, "error": None}
    try:
        environment = env()
        module_path = ""
        if (NEW / entry["path"]).with_suffix(".path").exists():
            setup = run(["sh", "tests/prepare_path.sh", entry["path"], str(directory)],
                        environment, directory / "setup.msg", timeout=30)
            result["setup"] = setup
            if setup["returncode"] != 0 or setup["timed_out"]:
                raise ValueError("import-path setup failed")
            module_path = (directory / "setup.msg").read_text().rstrip("\n")
        mode = "rt" if entry["path"] == "runtime.py" or Path(entry["path"]).name.startswith("rtmode_") else "ir"
        for side, root in ROOTS.items():
            current = dict(environment, PYSTACHY_HOME=str(root), PYSTACHY_PATH=module_path,
                           PYSTACHY_CACHE=str(OUTPUT / "cache" / side))
            ir = directory / (side + ".ll")
            log = directory / (side + ".msg")
            record = run([str(root / "pystachy"), mode, entry["path"], "-o", str(ir)], current, log)
            record["ir"] = file_info(ir)
            message = log.read_bytes()
            record["accepted"] = record["returncode"] == 0 and record["ir"].get("bytes", 0) > 0
            diagnostic = (record["returncode"] == 1 and len(message.splitlines()) == 1
                          and re.fullmatch(rb".+\.py:[0-9]+: error: .+\n", message) is not None)
            record["valid"] = (not record["timed_out"]
                               and ((record["accepted"] and not message) or diagnostic)
                               and b"error: internal error" not in message)
            result["runs"][side] = record
        raw_equal = result["runs"]["old"]["log_sha256"] == result["runs"]["new"]["log_sha256"]
        result["raw_messages_equal"] = raw_equal
        for side, root in ROOTS.items():
            raw = directory / (side + ".msg")
            normalized = directory / (side + ".normal.msg")
            if raw_equal:
                shutil.copyfile(raw, normalized)
            else:
                normalization = run(["sh", str(OUTPUT / "normalize.sh"), str(root / "lib") + "/", str(raw)],
                                    environment, normalized, timeout=30)
                if normalization["returncode"] != 0 or normalization["timed_out"]:
                    raise ValueError("diagnostic normalization failed")
        a, b = result["runs"]["old"], result["runs"]["new"]
        result["new_rejection"] = a["accepted"] and b["valid"] and b["returncode"] == 1
        result["new_acceptance"] = not a["accepted"] and b["accepted"]
        result["differences"] = [key for key, different in (
            ("status", a["returncode"] != b["returncode"]),
            ("ir", a["ir"] != b["ir"]),
            ("messages", digest(directory / "old.normal.msg") != digest(directory / "new.normal.msg")),
        ) if different]
        if a["ir"]["exists"] and b["ir"]["exists"] and a["ir"] != b["ir"]:
            diff = run(["diff", "-u", str(directory / "old.ll"), str(directory / "new.ll")],
                       environment, directory / "ir.diff", timeout=30)
            if diff["returncode"] not in (0, 1) or diff["timed_out"]:
                raise ValueError("IR difference retention failed")
        result["valid"] = a["valid"] and b["valid"]
    except Exception as error:
        result["error"] = repr(error)
        result["valid"] = False
    finally:
        for side in ROOTS:
            compress(directory / (side + ".ll"))
        write_json(directory / "result.json", result)
    return result


def main():
    OUTPUT.mkdir(exist_ok=False)
    before = {side: identity(root) for side, root in ROOTS.items()}
    receipt = json.loads((ROOT.parent / "rc-native-checks/compiler-receipt.json").read_text())
    fresh = json.loads((ROOT / "native-bootstrap.json").read_text())
    assert before["old"]["compiler_sha256"] == receipt["sha256"]["pystachy"]
    assert before["new"]["compiler_sha256"] == fresh["sha256"]["pystachy"]
    assert fresh["exit_code"] == 0 and fresh["status_after"] == ""
    for side in ROOTS:
        assert before[side]["commit"] == EXPECTED[side] and before[side]["worktree_status"] == ""
    write_json(OUTPUT / "inputs-before.json", before)
    names = ["pystachy.py", "runtime.py"]
    for pattern in PATTERNS:
        names.extend(sorted(str(path.relative_to(NEW)) for path in NEW.glob(pattern)))
    entries = [{"index": i, "path": name, "sha256": digest(NEW / name)}
               for i, name in enumerate(names, 1)]
    assert len(names) == len(set(names))
    write_json(OUTPUT / "inventory.json", entries)
    original = (NEW / "tools/irsame.sh").read_text()
    assert original == (OLD / "tools/irsame.sh").read_text()
    start = original.index("quoted_library_path() (")
    end = original.index("\nRT=0 ", start)
    normalizer = OUTPUT / "normalize.sh"
    normalizer.write_text("#!/bin/sh\n" + original[start:end] + '\nnormalize_messages "$1" "$2"\n')
    write_json(OUTPUT / "normalization.json", {
        "source": "tools/irsame.sh", "source_sha256": digest(NEW / "tools/irsame.sh"),
        "extracted_sha256": digest(normalizer), "ir_normalized": False,
    })
    for side, root in ROOTS.items():
        usage = OUTPUT / (side + "-usage.msg")
        run([str(root / "pystachy")], dict(env(), PYSTACHY_HOME=str(root)), usage, timeout=10)
        assert b"pystachy rt " in usage.read_bytes()
    started = time.monotonic()
    results = []
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(compare, entry) for entry in entries]
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            if len(results) % 100 == 0 or not result["valid"]:
                print(json.dumps({"completed": len(results), "total": len(entries),
                                  "case": result["input"]["path"], "valid": result["valid"]}), flush=True)
    results.sort(key=lambda value: value["input"]["index"])
    after = {side: identity(root) for side, root in ROOTS.items()}
    write_json(OUTPUT / "inputs-after.json", after)
    summary = {
        "kind": "local source-pinned differential audit; not a sealed CI bundle",
        "workers": 2, "seconds": time.monotonic() - started,
        "inputs_unchanged": before == after, "case_count": len(entries),
        "completed": len(results), "invalid": sum(not r["valid"] for r in results),
        "new_rejections": sum(r.get("new_rejection", False) for r in results),
        "new_acceptances": sum(r.get("new_acceptance", False) for r in results),
        "different": sum(bool(r.get("differences")) for r in results),
        "raw_diagnostic_differences": sum(not r.get("raw_messages_equal", True) for r in results),
        "inputs": before, "harness_sha256": digest(Path(__file__)),
        "results": results,
    }
    write_json(OUTPUT / "summary.json", summary)
    print(json.dumps({k: v for k, v in summary.items() if k != "results"}), flush=True)
    return 0 if before == after and summary["invalid"] == summary["new_rejections"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
