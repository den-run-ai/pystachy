"""Check the specific representation transformation in non-exit enum IR cases.

This post-comparison explanation retains every raw oracle difference. It accepts
only one scalar slot, adjusted field indices/TBAA, duplicate initial-value stores
to that slot, and SSA/block renumbering. It does not change the comparison result.
"""
from pathlib import Path
import difflib
import gzip
import json
import re
from adjudicate_ir import path_literal

ROOT = Path(__file__).resolve().parent
AUDIT = ROOT / "ir-comparison"
OUTPUT = ROOT / "layout-review"
OUTPUT.mkdir(exist_ok=True)
CASES = [1429, 1430, 1431, 1433, 1434, 1435, 1436, 1437, 1438, 1439, 1440, 1441, 1442, 1443]
TYPE = re.compile(r'(%C\.[^ ]+) = type \{([^{}]*)\}')
GEP = re.compile(r'^(  (%[^ ]+) = getelementptr )(%C\.[^,]+)(, ptr (%[^,]+), i32 0, i32 )([0-9]+)$')
META = re.compile(r'!([0-9]+) = !\{(.*)\}')


def fields(text):
    return {m[1]: m[2].split(", ") if m[2] else [] for line in text.splitlines()
            if (m := TYPE.fullmatch(line))}


def offsets(types):
    result, position = [], 0
    for t in types:
        size = {"i1": 1, "i8": 1, "i16": 2, "i32": 4, "i64": 8, "ptr": 8, "double": 8}[t]
        position = (position + size - 1) // size * size
        result.append(position)
        position += size
    return result


def types_changed(old, new):
    changes = {}
    assert old.keys() == new.keys()
    for name in old:
        if old[name] == new[name]:
            continue
        positions = [i for i, t in enumerate(new[name])
                     if t == "i64" and new[name][:i] + new[name][i + 1:] == old[name]]
        assert positions, (name, old[name], new[name])
        # IntEnum owns the scalar before _value_; IntFlag appends it after its
        # complete Flag prefix, including a companion box where one is present.
        position = 3 if 3 in positions else positions[0]
        changes[name] = position
    return changes


def metadata(text, side, oldtypes, newtypes, changes):
    raw = {m[1]: m[2] for line in text.splitlines() if (m := META.fullmatch(line))}
    named = {key: re.match(r'!"([^"]*)"', value)[1]
             for key, value in raw.items() if value.startswith('!"')}
    result = {}
    for key, value in raw.items():
        tag = re.fullmatch(r'!([0-9]+), !([0-9]+), i64 ([0-9]+)', value)
        if tag:
            base, scalar, offset = named[tag[1]], named[tag[2]], int(tag[3])
            cname = "%C." + base
            if side == "new" and cname in changes:
                new_offsets = offsets(newtypes[cname])
                index = new_offsets.index(offset)
                if index == changes[cname]:
                    result[key] = ("payload", base, scalar)
                    assert scalar == "int"
                    continue
                old_index = index - (index > changes[cname])
                offset = offsets(oldtypes[cname])[old_index]
            result[key] = ("tag", base, scalar, offset)
            continue
        name = named.get(key)
        if name is not None:
            body = value[value.find('"', 2) + 1:]
            pairs = re.findall(r'!([0-9]+), i64 ([0-9]+)', body)
            cname = "%C." + name
            if pairs and cname in newtypes:
                members = [(named[t], int(o)) for t, o in pairs]
                if side == "new" and cname in changes:
                    expected_offsets = offsets(newtypes[cname])
                    assert [o for _, o in members] == expected_offsets, (name, members, expected_offsets)
                    removed = members.pop(changes[cname])
                    assert removed[0] == "int"
                    members = [(kind, off) for (kind, _), off in zip(members, offsets(oldtypes[cname]), strict=True)]
                result[key] = ("struct", name, tuple(members))
            else:
                result[key] = ("named", name, re.sub(r'!([0-9]+)', lambda m: "!" + named[m[1]], body))
        else:
            raise AssertionError((key, value))
    return result


def functions(text):
    result, name, body = {}, None, []
    for line in text.splitlines():
        if line.startswith("define "):
            assert name is None
            name = line[line.find("@"):line.find("(")]
            body = [line]
        elif name is not None:
            body.append(line)
            if line == "}":
                result[name] = body
                name = None
    assert name is None
    return result


def outside_functions(text):
    result, inside = [], False
    for line in text.splitlines():
        if line.startswith("define "):
            inside = True
        elif inside and line == "}":
            inside = False
        elif not inside and not line.startswith("!"):
            result.append(line)
    return result


def canonical(body, side, tags, changes):
    kept = []
    stores, geps = {}, {}
    payload_stores = []
    i = 0
    while i < len(body):
        line = body[i]
        match = GEP.fullmatch(line)
        if match:
            cname, obj, index = match[3], match[5], int(match[6])
            geps[match[2]] = (cname, obj, index)
            if side == "new" and cname in changes:
                slot = changes[cname]
                if index == slot:
                    store = re.fullmatch(r'  store i64 ([^,]+), ptr ' + re.escape(match[2]) + r', !tbaa !([0-9]+)', body[i + 1])
                    assert store is not None, (cname, line, body[i + 1])
                    assert tags[store[2]][0] == "payload"
                    value_slot = 4 if slot == 3 else 3
                    assert stores.get((cname, obj, value_slot)) == store[1], (cname, obj, value_slot, store[1], stores)
                    payload_stores.append({"class": cname, "object": obj, "value": store[1]})
                    i += 2
                    continue
                if index > slot:
                    line = match[1] + cname + match[4] + str(index - 1)
        store = re.fullmatch(r'  store i64 ([^,]+), ptr (%[^,]+)(?:,.*)?', body[i])
        if store and store[2] in geps:
            stores[geps[store[2]]] = store[1]
        line = re.sub(r'!tbaa !([0-9]+)', lambda m: "!tbaa " + repr(tags[m[1]]), line)
        line = re.sub(r'!prof !([0-9]+)', lambda m: "!prof " + repr(tags[m[1]]), line)
        kept.append(line)
        i += 1
    names = {}
    for line in kept:
        m = re.match(r'  (%[^ ]+) = ', line)
        if m:
            names[m[1]] = "%v" + str(len(names))
    labels = {line[:-1]: "block" + str(i) for i, line in enumerate(kept)
              if re.fullmatch(r'[A-Za-z][A-Za-z0-9_.]*:', line)}
    out = []
    for line in kept:
        if line.endswith(":") and line[:-1] in labels:
            line = labels[line[:-1]] + ":"
        line = re.sub(r'%[A-Za-z_.$][A-Za-z0-9_.$-]*', lambda m: "%" + labels[m[0][1:]] if m[0][1:] in labels else names.get(m[0], m[0]), line)
        out.append(line)
    return out, payload_stores


rows = []
for index in CASES:
    directory = AUDIT / "cases" / f"{index:05d}"
    result = json.loads((directory / "result.json").read_text())
    text = {side: gzip.open(directory / (side + ".ll.gz"), "rt").read() for side in ("old", "new")}
    types = {side: fields(value) for side, value in text.items()}
    changes = types_changed(types["old"], types["new"])
    old_global, new_global = outside_functions(text["old"]), outside_functions(text["new"])
    assert len(old_global) == len(new_global)
    path_changes = 0
    for old_line, new_line in zip(old_global, new_global, strict=True):
        if old_line == new_line:
            continue
        if path_literal(old_line, new_line):
            path_changes += 1
            continue
        before_type, after_type = TYPE.fullmatch(old_line), TYPE.fullmatch(new_line)
        assert before_type is not None and after_type is not None, (index, old_line, new_line)
        assert before_type[1] == after_type[1] and before_type[1] in changes
    metas = {side: metadata(value, side, types["old"], types["new"], changes) for side, value in text.items()}
    oldmeta = set(metas["old"].values())
    newmeta = {v for v in metas["new"].values() if v[0] != "payload"}
    assert oldmeta <= newmeta
    added_metadata = newmeta - oldmeta
    payload_bases = {v[1] for v in metas["new"].values() if v[0] == "payload"}
    for extra in added_metadata:
        assert extra[0] == "struct" and extra[1] in payload_bases
        cname = "%C." + extra[1]
        assert cname in changes
        expected = tuple(({'i64': 'int', 'ptr': 'pointer', 'i1': 'bool', 'double': 'float'}[t], offset)
                         for t, offset in zip(types["old"][cname], offsets(types["old"][cname]), strict=True))
        assert extra[2] == expected
    funcs = {side: functions(value) for side, value in text.items()}
    assert funcs["old"].keys() == funcs["new"].keys()
    different, initialized, unchanged = [], [], 0
    for name in funcs["old"]:
        old, _ = canonical(funcs["old"][name], "old", metas["old"], changes)
        new, payloads = canonical(funcs["new"][name], "new", metas["new"], changes)
        if payloads:
            initialized.append({"function": name, "payloads": payloads})
        if old == new:
            unchanged += 1
        else:
            different.append(name)
            target = OUTPUT / (str(index) + "-" + name.replace("@", "").replace("/", "_") + ".diff")
            target.write_text("\n".join(difflib.unified_diff(old, new, fromfile="old accounted layout", tofile="new accounted layout")) + "\n")
    row = {"index": index, "path": result["input"]["path"], "changed_types": changes,
           "metadata_accounted": True, "globals_accounted": True, "path_literal_changes": path_changes,
           "new_payload_metadata_bases": sorted(payload_bases),
           "new_struct_metadata": sorted(extra[1] for extra in added_metadata),
           "total_functions": len(funcs["old"]),
           "functions_accounted": unchanged, "unaccounted_functions": different,
           "payload_initializations": initialized}
    rows.append(row)
    print(index, "functions", unchanged, "/", len(funcs["old"]), "unaccounted", different)
(ROOT / "layout-function-review.json").write_text(json.dumps(rows, indent=2) + "\n")
