import sys
from enum import IntEnum
class Status(IntEnum):
    OK = 0
print(hasattr(Status.OK, " enum int"), flush=True)
setattr(Status.OK, " enum int", 7)
print(getattr(Status.OK, " enum int"), flush=True)
sys.exit(Status.OK)
