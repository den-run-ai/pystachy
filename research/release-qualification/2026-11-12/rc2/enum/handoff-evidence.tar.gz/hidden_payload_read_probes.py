from enum import IntEnum, IntFlag, Enum
class Status(IntEnum):
    OK = 0
class Perm(IntFlag):
    READ = 1
print(hasattr(Status.OK, " enum int"))
print(getattr(Status.OK, " enum int", 42))
print(hasattr(Perm(0), " enum int"))
print(getattr(Perm(0), " enum int", 42))
def probe(value: Enum):
    print(hasattr(value, " enum int"))
    print(getattr(value, " enum int", 42))
probe(Status.OK)
