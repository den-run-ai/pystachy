"""Classify retained raw differences without altering the IR comparison oracle."""
from pathlib import Path
import collections
import gzip
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
AUDIT = ROOT / "ir-comparison"
OLD_HOME = str(ROOT.parent / "pystachy-rc") + "/"
NEW_HOME = str(ROOT.parent / "rc-exit-intenum") + "/"
STRING = re.compile(
    r'(?P<name>@[^ ]+) = private unnamed_addr global '
    r'\{i64, i64, i64, \[(?P<array1>[0-9]+) x i8\]\} '
    r'\{i64 (?P<chars>[0-9]+), i64 (?P<hash>-?[0-9]+), i64 (?P<bytes>[0-9]+), '
    r'\[(?P<array2>[0-9]+) x i8\] c"(?P<payload>.*)"\}, align 8'
)
TYPE = re.compile(r'(?P<name>%C\.[^ ]+) = type \{(?P<fields>[^{}]*)\}')


def llvm_bytes(value):
    out = bytearray()
    i = 0
    while i < len(value):
        if value[i] == "\\":
            out.append(int(value[i + 1:i + 3], 16))
            i += 3
        else:
            out.extend(value[i].encode())
            i += 1
    return bytes(out)


def path_literal(a, b):
    left, right = STRING.fullmatch(a), STRING.fullmatch(b)
    if left is None or right is None:
        return False
    old, new = left.groupdict(), right.groupdict()
    if old["name"] != new["name"] or old["hash"] != new["hash"]:
        return False
    before, after = llvm_bytes(old["payload"]), llvm_bytes(new["payload"])
    replaced = (OLD_HOME.encode() in before and before.replace(OLD_HOME.encode(), NEW_HOME.encode()) == after)
    bare_home = before == OLD_HOME[:-1].encode() + b"\0" and after == NEW_HOME[:-1].encode() + b"\0"
    if not replaced and not bare_home:
        return False
    for fields, data in ((old, before), (new, after)):
        if not data.endswith(b"\0"):
            return False
        if any(int(fields[key]) != len(data) for key in ("array1", "array2", "bytes")):
            return False
        if int(fields["chars"]) != len(data[:-1].decode()):
            return False
    return True


def base_type(a, b):
    left, right = TYPE.fullmatch(a), TYPE.fullmatch(b)
    if left is None or right is None or left["name"] != right["name"]:
        return False
    before, after = left["fields"], right["fields"]
    if left["name"] in ("%C.enum$IntEnum", "%C.enum$_IntMixin"):
        return before == "i64, ptr, i1, i64, i1" and after == "i64, ptr, i1, i64, i64, i1"
    if left["name"] == "%C.enum$IntFlag":
        return before == "i64, ptr, i1, i64, i1" and after == "i64, ptr, i1, i64, i1, i64"
    return False



def main():
    summary = json.loads((AUDIT / "summary.json").read_text())
    rows = []
    for result in summary["results"]:
        if not result.get("differences") and result.get("raw_messages_equal", True):
            continue
        directory = AUDIT / "cases" / f"{result['input']['index']:05d}"
        row = {"index": result["input"]["index"], "path": result["input"]["path"],
               "oracle_differences": result["differences"], "diagnostic_paths_only": False}
        if not result["raw_messages_equal"]:
            old_message = (directory / "old.msg").read_bytes()
            new_message = (directory / "new.msg").read_bytes()
            assert OLD_HOME.encode() in old_message
            assert old_message.replace(OLD_HOME.encode(), NEW_HOME.encode()) == new_message
            row["diagnostic_paths_only"] = True
        if "ir" in result["differences"]:
            old_lines = gzip.open(directory / "old.ll.gz", "rt").read().splitlines()
            new_lines = gzip.open(directory / "new.ll.gz", "rt").read().splitlines()
            paired = list(zip(old_lines, new_lines))
            if len(old_lines) == len(new_lines) and all(a == b or path_literal(a, b) for a, b in paired):
                row["category"] = "checkout_path_literals_only"
                row["path_literal_changes"] = sum(a != b for a, b in paired)
            elif len(old_lines) == len(new_lines) and all(a == b or path_literal(a, b) or base_type(a, b) for a, b in paired):
                row["category"] = "base_enum_type_declarations_and_checkout_paths_only"
                row["path_literal_changes"] = sum(path_literal(a, b) for a, b in paired if a != b)
                row["base_type_changes"] = sum(base_type(a, b) for a, b in paired if a != b)
            else:
                row["category"] = "requires_semantic_layout_review"
                old_defs = [line for line in old_lines if line.startswith("define ")]
                new_defs = [line for line in new_lines if line.startswith("define ")]
                row["definition_count"] = {"old": len(old_defs), "new": len(new_defs)}
            row["ir_diff_sha256"] = hashlib.sha256((directory / "ir.diff").read_bytes()).hexdigest()
        else:
            row["category"] = ("raw_diagnostic_checkout_paths_only" if result["differences"]
                               else "official_normalizer_accounts_for_diagnostic_paths")
        rows.append(row)
    report = {
        "oracle_summary": {key: value for key, value in summary.items() if key != "results"},
        "scope": "These are strict explanations of retained raw changes, not IR normalization: the original oracle differences and bytes remain intact.",
        "classification_rule": "A path-only LLVM string change must have an exact own-checkout-home substitution, identical symbol/hash, and independently correct UTF-8 character count, byte count and both array bounds. The type-only rule permits only the three exact reviewed base enum type declarations.",
        "categories": dict(collections.Counter(row["category"] for row in rows)),
        "cases": rows,
    }
    (ROOT / "ir-adjudication.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report["categories"], indent=2))
    for row in rows:
        if row["category"] == "requires_semantic_layout_review":
            print(row["index"], row["path"], row["definition_count"])


if __name__ == "__main__":
    main()
