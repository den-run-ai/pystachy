"""Verify the approved PyPI workflow identity and complete retained test/publish jobs."""
from datetime import datetime, timezone
import hashlib
import json

from audit_context import ROOT, load_context


def main():
    c = load_context("native_run_id", "pypi_run_id")
    run = json.loads((ROOT / "pypi-run.json").read_text())
    doc = json.loads((ROOT / "pypi-final-jobs.json").read_text())
    source = json.loads((ROOT / "pypi-report.json").read_text())["source_receipt"]
    assert run["id"] == c["pypi_run_id"] and run["head_sha"] == c["approved_pypi_workflow_commit"]
    assert run["head_branch"] == c["approved_pypi_workflow_ref"] and run["event"] == "workflow_dispatch"
    assert run["run_attempt"] == 1 and run["status"] == "completed" and run["conclusion"] == "success"
    assert source["SOURCE_COMMIT"] == c["source_commit"] and source["GITHUB_SHA"] == run["head_sha"]
    success = {"Verify PyPI source packages", "Publish verified packages to PyPI"}
    skipped = {"prepare", "Binary (" + "$" + "{{ matrix.target }})",
               "Container (linux/" + "$" + "{{ matrix.arch }})", "publish"}
    assert doc["total_count"] == len(doc["jobs"]) == 6
    assert {j["name"] for j in doc["jobs"]} == success | skipped
    assert len({j["id"] for j in doc["jobs"]}) == 6
    rows = []
    for j in doc["jobs"]:
        assert j["run_id"] == run["id"] and j["head_sha"] == run["head_sha"] and j["run_attempt"] == 1
        assert j["status"] == "completed" and j["conclusion"] == ("success" if j["name"] in success else "skipped")
        row = {k: j[k] for k in ("id", "name", "conclusion", "started_at", "completed_at")}
        if j["name"] in success:
            wrapper = ROOT / "pypi-job-logs" / f"{j['id']}.json"
            raw = json.loads(wrapper.read_text())["content"].encode()
            wrapper.with_suffix(".log").write_bytes(raw)
            row["decoded_log_path"] = str(wrapper.with_suffix(".log").relative_to(ROOT))
            row["decoded_log_sha256"] = hashlib.sha256(raw).hexdigest()
            row["steps"] = j["steps"]
            assert all(s["status"] == "completed" and s["conclusion"] in ("success", "skipped")
                       for s in j["steps"])
            steps = {s["name"]: s["conclusion"] for s in j["steps"]}
            if j["name"] == "Verify PyPI source packages":
                for name in ("Require the published tag and its exact successful main checks",
                             "Build wheel from the release source distribution",
                             "Check distribution identity and PyPI metadata",
                             "Verify clean pip and uv installs, JIT and standalone AOT",
                             "Record source and distribution checksums"):
                    assert steps[name] == "success"
                assert c["source_commit"].encode() in raw
            else:
                assert steps["Verify the exact distributions tested by this run"] == "success"
                assert steps["Publish with PyPI Trusted Publishing"] == "success"
        rows.append(row)
    result = {
        "complete": True, "status": "passed", "source_commit": c["source_commit"],
        "source_tree": c["source_tree"], "pypi_run": run["id"], "workflow_commit": run["head_sha"],
        "workflow_ref": run["head_branch"], "attempt": 1, "success_jobs": 2, "expected_skips": 4,
        "audited_utc": datetime.now(timezone.utc).isoformat(), "jobs": rows,
        "source_receipt": source, "scope": "Approved publishing workflow and exact released-source binding, including hosted pip/uv execution checks and the publishing job. Public distribution bytes and fresh local installation are separate receipts.",
    }
    out = ROOT / "pypi-workflow-report.json"
    out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": "passed", "success_jobs": 2, "expected_skips": 4,
                      "sha256": hashlib.sha256(out.read_bytes()).hexdigest()}))


if __name__ == "__main__":
    main()
