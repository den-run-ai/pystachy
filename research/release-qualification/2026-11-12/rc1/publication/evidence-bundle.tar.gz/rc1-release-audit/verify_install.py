"""Exercise the verified public wheel in fresh pip and uv installations."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess

from audit_context import ROOT, TAG, VERSION, load_context


def require(value, message):
    if not value:
        raise ValueError(message)


def main():
    context = load_context("native_run_id", "pypi_run_id", "python", "llvm_bin", "uv")
    pypi = json.loads((ROOT / "pypi-report.json").read_text())
    require(pypi["complete"] and pypi["status"] == "passed", "Public PyPI bytes are not verified")
    require(pypi["source_commit"] == context["source_commit"] and
            pypi["pypi_run"] == context["pypi_run_id"], "PyPI receipt source/run mismatch")
    wheels = [x for x in pypi["distributions"] if x["filename"].endswith(".whl")]
    require(len(wheels) == 1, "Expected one verified public wheel")
    wheel = ROOT / "pypi-public-dist" / wheels[0]["filename"]
    require(hashlib.sha256(wheel.read_bytes()).hexdigest() == wheels[0]["sha256"],
            "Public wheel changed after byte verification")
    checkout = Path(context["source_checkout"])
    helper = checkout / "tools/compiler_install_smoke.py"
    helper_sha = hashlib.sha256(helper.read_bytes()).hexdigest()
    environment = dict(os.environ, PYSTACHY_LLVM=context["llvm_bin"])
    environment["PATH"] = str(Path(context["uv"]).parent) + os.pathsep + environment["PATH"]
    command = [context["python"], str(helper), "--source", str(wheel)]
    versions = {}
    for name, cmd in (("python", [context["python"], "--version"]),
                      ("llvm", [str(Path(context["llvm_bin"]) / "clang"), "--version"]),
                      ("uv", [context["uv"], "--version"])):
        versions[name] = subprocess.check_output(cmd, env=environment, text=True, timeout=15).splitlines()[0]
    log = ROOT / "pypi-public-install.log"
    with log.open("w") as stream:
        result = subprocess.run(command, cwd=ROOT, env=environment, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=900)
    text = log.read_text()
    require(result.returncode == 0, "Fresh pip/uv public-wheel installation smoke failed")
    require(text.count("version, JIT, standalone AOT and external cache passed") == 2,
            "Missing pip or uv compiler execution evidence")
    require("Successfully uninstalled pystachy-" + VERSION in text and
            "Uninstalled 1 executable: pystachy" in text, "Missing uninstall evidence")
    report = {
        "complete": True, "status": "passed", "source_commit": context["source_commit"],
        "tag": TAG, "version": VERSION, "pypi_run": context["pypi_run_id"],
        "observed_at": datetime.now(timezone.utc).isoformat(), "toolchain": versions,
        "command": command, "exit_code": result.returncode,
        "public_wheel_sha256": wheels[0]["sha256"],
        "helper_source_commit": context["source_commit"], "helper_sha256": helper_sha,
        "raw_log_sha256": hashlib.sha256(log.read_bytes()).hexdigest(),
        "fresh_environment_per_manager": True, "outside_checkout": True,
        "checks": ["version with LLVM unavailable", "JIT equals pinned CPython",
                   "standalone AOT equals pinned CPython with empty PATH",
                   "external runtime and JIT-runner caches", "pip and uv uninstall cleanup"],
        "source_binding": "Public wheel equals the tested publishing artifact; SOURCE.json binds its source. Installed version text alone does not embed that source commit.",
        "scope": "Local Linux x86_64 installation smoke using the recorded toolchain; other platforms rely on separately retained hosted evidence.",
    }
    (ROOT / "pypi-public-install-evidence.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": "passed", "version": VERSION, "toolchain": versions}))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        report = {"complete": False, "status": "failed", "error": str(error) if isinstance(error, ValueError) else type(error).__name__}
        (ROOT / "pypi-public-install-evidence.json").write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps(report))
        raise SystemExit(1)
