"""Retain connector-provided artifact bytes, verify ZIP digests, extract text evidence."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = '30822255ee7ee704e0e780e01cd8c23357ba13ab'
RUN = 43314381943


def main():
    records_path = ROOT / 'downloads.json'
    records = json.loads(records_path.read_text()) if records_path.exists() else {}
    for item in json.loads(sys.argv[1]):
        artifact = item['artifact']
        ident = str(artifact['id'])
        assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == SOURCE
        assert not artifact['expired']
        path = ROOT / 'zips' / (ident + '.zip')
        path.parent.mkdir(exist_ok=True)
        if not path.exists():
            request = urllib.request.Request(item['url'], headers={'Accept-Encoding': 'identity'})
            partial = path.with_suffix('.part')
            count = 0
            with urllib.request.urlopen(request, timeout=60) as response, partial.open('wb') as out:
                while block := response.read(1024 * 1024):
                    count += len(block)
                    assert count <= artifact['size_in_bytes']
                    out.write(block)
            partial.rename(path)
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        assert len(data) == artifact['size_in_bytes']
        assert 'sha256:' + digest == artifact['digest']
        text_files = []
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            names = [x.filename for x in archive.infolist()]
            assert len(names) == len(set(names))
            for member in archive.infolist():
                name = PurePosixPath(member.filename)
                assert not name.is_absolute() and '..' not in name.parts
                if member.is_dir() or name.suffix not in ('.log', '.json', '.txt'):
                    continue
                assert member.file_size <= 16 * 1024 * 1024
                dest = ROOT / 'raw' / ident / Path(*name.parts)
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(archive.read(member))
                text_files.append(str(dest.relative_to(ROOT)))
        records[ident] = {'name': artifact['name'], 'source_commit': SOURCE, 'run_id': RUN,
                          'zip_path': str(path.relative_to(ROOT)), 'zip_sha256': digest,
                          'zip_bytes': len(data), 'text_files': text_files,
                          'zip_inventory': names}
    records_path.write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps({'artifacts_retained': len(records), 'new_requests': len(json.loads(sys.argv[1]))}))


if __name__ == '__main__':
    main()
