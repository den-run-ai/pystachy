"""Read-only audit of retained RC1 merged-main Variants evidence."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import itertools
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
CHECKOUT = ROOT.parents[1] / "pystachy-rc"
SOURCE = "30822255ee7ee704e0e780e01cd8c23357ba13ab"
TREE = "64f1fb7295efd25401052d61a22823681e5669ab"
RUN = 43314381943
sys.path[:0] = [str(CHECKOUT), str(CHECKOUT / "tools")]
from src.pystachy_compiler.specs import OPTS
import ci_sample
import verification_bootstrap


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    return json.loads((ROOT / name).read_text())


def command(*args):
    return subprocess.check_output(args, cwd=CHECKOUT, text=True, timeout=30).strip()


def seconds(start, end):
    if start is None or end is None:
        return None
    return (datetime.fromisoformat(end.replace("Z", "+00:00")) -
            datetime.fromisoformat(start.replace("Z", "+00:00"))).total_seconds()


def main():
    assert command("git", "rev-parse", "HEAD^{tree}") == TREE
    assert command("git", "status", "--porcelain", "--untracked-files=no") == ""
    run, jobsdoc, adoc = read("run-final.json"), read("jobs-final.json"), read("artifacts-final.json")
    jobs, artifacts = jobsdoc["jobs"], adoc["artifacts"]
    assert run["id"] == RUN and run["head_sha"] == SOURCE and run["run_attempt"] == 1
    assert run["event"] == "push" and run["status"] == "completed" and run["conclusion"] == "success"
    assert jobsdoc["total_count"] == len(jobs) == 25
    assert adoc["total_count"] == len(artifacts) == 25
    assert len({j["id"] for j in jobs}) == 25
    assert all(j["run_id"] == RUN and j["head_sha"] == SOURCE and j["conclusion"] == "success"
               and j["run_attempt"] == 1 for j in jobs)
    assert all(a["workflow_run"]["id"] == RUN and a["workflow_run"]["head_sha"] == SOURCE
               and not a["expired"] for a in artifacts)
    downloads = read("downloads.json")
    assert set(downloads) == {str(a["id"]) for a in artifacts}
    for a in artifacts:
        b = (ROOT / downloads[str(a["id"])]["zip_path"]).read_bytes()
        assert len(b) == a["size_in_bytes"] and "sha256:" + digest(b) == a["digest"]
        with zipfile.ZipFile(ROOT / downloads[str(a["id"])]["zip_path"]) as z:
            assert z.testzip() is None

    producer = next(a for a in artifacts if a["name"] == "verified-bootstrap-x86_64")
    with zipfile.ZipFile(ROOT / downloads[str(producer["id"])]["zip_path"]) as z:
        manifest_bytes = z.read("manifest.json")
        manifest = json.loads(manifest_bytes)
        assert manifest["schema"] == 1
        assert manifest["identity"]["commit"] == SOURCE
        assert manifest["identity"]["github_run_id"] == str(RUN)
        payload = {name: z.read(name) for name in manifest["sha256"]}
        assert all(digest(b) == manifest["sha256"][name] for name, b in payload.items())
        report = json.loads(payload["verification.json"])
        verification_bootstrap.validate_producer(report, manifest["identity"], CHECKOUT)
        verification_bootstrap.validate_payload(report, payload)
    source_hash = hashlib.sha256()
    tracked = subprocess.check_output(["git", "ls-files", "-z"], cwd=CHECKOUT).split(b"\0")
    for name in sorted(n for n in tracked if n):
        path = CHECKOUT / os.fsdecode(name)
        mode = path.lstat().st_mode
        if stat.S_ISLNK(mode):
            data, kind = os.fsencode(os.readlink(path)), b"120000"
        else:
            data, kind = path.read_bytes(), b"100755" if mode & 0o111 else b"100644"
        source_hash.update(name + b"\0" + kind + b"\0" + digest(data).encode() + b"\0")
    assert source_hash.hexdigest() == manifest["identity"]["tracked_sources_sha256"]
    bundle_id = digest(manifest_bytes)

    inventory = {}
    all_cases = command("sh", "-c", ". tests/corpus.sh; LC_ALL=C; export LC_ALL; corpus").splitlines()
    for shard in range(4):
        cases = command("tools/shard_cases.sh", f"{shard}/4").splitlines()
        assert cases and len(cases) == len(set(cases))
        inventory[str(shard)] = {
            "shard": f"{shard}/4", "cases": cases, "case_count": len(cases),
            "case_list_sha256": digest(("\n".join(cases) + "\n").encode()),
            "expected_checks": ci_sample.expected_checks(cases, ["jit", "aot"], root=CHECKOUT),
        }
    assert Counter(x for row in inventory.values() for x in row["cases"]) == Counter(all_cases)
    corpus_checks = ci_sample.expected_checks(all_cases, ["jit", "aot"], root=CHECKOUT)
    assert sum(row["expected_checks"] for row in inventory.values()) == corpus_checks
    (ROOT / "expected-inventory.json").write_text(json.dumps({
        "source_commit": SOURCE, "source_tree": TREE, "modes": ["jit", "aot"],
        "corpus_count": len(all_cases), "full_checks": corpus_checks, "shards": inventory,
    }, indent=2) + "\n")

    cols = [c for c in itertools.combinations(range(7), 3) if 0 in c]
    assert len(OPTS) <= len(cols)
    rows = [[r in cols[j] for j in range(len(OPTS))] for r in range(7)]
    assert all(len({(row[a], row[b]) for row in rows}) == 4
               for a, b in itertools.combinations(range(len(OPTS)), 2))
    settings = {f"opt-{r}": "PYSTACHY_OPT=" + ",".join(
        "-" + OPTS[j] for j in range(len(OPTS)) if not rows[r][j]) for r in range(1, 7)}
    settings["cflags-O0"] = "PYSTACHY_CFLAGS=-O0 PYSTACHY_JIT_LAUNCHER=lli"
    parsed, timing, consumed = [], [], []
    for j in jobs:
        text = (ROOT / "job-logs" / f"{j['id']}.log").read_text()
        wrapper = read(f"job-logs/{j['id']}.json")
        assert (ROOT / "job-logs" / f"{j['id']}.log").read_bytes() == wrapper["content"].encode()
        assert re.search(r"\[command\]/usr/bin/git log -1 --format=%H\n\S+ " + SOURCE, text)
        assert "PYSTACHY_JOBS: 4" in text and "PYSTACHY_LLVM: /usr/lib/llvm-18/bin" in text
        assert "Successfully set up CPython (3.13.16)" in text
        assert "Ubuntu LLVM version 18.1.3" in text
        step_times = [{"name": s["name"], "status": s["status"], "conclusion": s["conclusion"],
                       "seconds": seconds(s.get("started_at"), s.get("completed_at"))} for s in j["steps"]]
        assert all(s["conclusion"] in ("success", "skipped") for s in step_times)
        timing.append({"job_id": j["id"], "name": j["name"],
                       "job_seconds": seconds(j["started_at"], j["completed_at"]),
                       "started_at": j["started_at"], "completed_at": j["completed_at"],
                       "runner_name": j["runner_name"], "runner_id": j["runner_id"],
                       "labels": j["labels"], "cpu": None, "steps": step_times})
        if j["name"] == "verified compiler producer":
            continue
        match = re.fullmatch(r"variant (.+) \(shard ([0-3])/4, JIT and AOT\)", j["name"])
        assert match
        variants, shard = match[1].split(), int(match[2])
        assert f"VARIANTS_SHARD: {shard}/4" in text
        assert f"SHA256 digest of downloaded artifact is {producer['digest'][7:]}" in text
        restored = [json.loads(line[line.index("{"):]) for line in text.splitlines()
                    if '{"bootstrap_bundle_id":' in line]
        assert len(restored) == 1
        b = restored[0]
        assert b["bootstrap_bundle_id"] == bundle_id and b["bootstrap_reused"] is True
        assert b["ir_identical"] is True and b["runtime_ir_identical"] is True
        assert b["ir_sha256"] == manifest["sha256"]["stage1.ll"]
        assert b["runtime_ir_sha256"] == manifest["sha256"]["rt1.ll"]
        uploaded = re.findall(r"Artifact (variant-[^\n]+?) successfully finalized\. Artifact ID (\d+)", text)
        assert len(uploaded) == 1
        artifact_name, artifact_id = uploaded[0]
        art = next(a for a in artifacts if a["id"] == int(artifact_id))
        assert art["name"] == artifact_name
        assert f"SHA256 digest of uploaded artifact is {art['digest'][7:]}" in text
        consumed.append(art["id"])
        with zipfile.ZipFile(ROOT / downloads[artifact_id]["zip_path"]) as archive:
            assert sorted(archive.namelist()) == sorted(v + ".log" for v in variants)
            for v in variants:
                expected = inventory[str(shard)]
                body = archive.read(v + ".log").decode()
                assert body == (f"selected {expected['case_count']} cases\n"
                                f"{expected['expected_checks']} passed, 0 failed\n")
                rx = (re.escape(v + " (" + settings[v] + f"; jit aot; shard {shard}/4): ") +
                      r"(\d+) passed, 0 failed in (\d+) s")
                matches = re.findall(rx, text)
                assert len(matches) == 1 and int(matches[0][0]) == expected["expected_checks"]
                parsed.append({"variant": v, "shard": shard, "case_count": expected["case_count"],
                               "checks": expected["expected_checks"], "modes": ["jit", "aot"],
                               "settings": settings[v], "execution_seconds": int(matches[0][1]),
                               "job_id": j["id"], "artifact_id": art["id"], "log_sha256": digest(body.encode()),
                               "bootstrap_bundle_id": bundle_id, "cpu": None})
    assert len(parsed) == 28 and len(consumed) == len(set(consumed)) == 24
    assert {(r["variant"], r["shard"]) for r in parsed} == {(v, i) for v in settings for i in range(4)}
    assert all(sum(r["checks"] for r in parsed if r["variant"] == v) == corpus_checks for v in settings)
    assert all(t["job_seconds"] <= 900 for t in timing)
    audit = {
        "schema_version": 1, "audited_utc": datetime.now(timezone.utc).isoformat(),
        "source_commit": SOURCE, "source_tree": TREE, "run_id": RUN, "run_attempt": 1,
        "result": "passed", "event": "push", "jobs": {"producer": 1, "workers": 24, "successful": 25},
        "artifacts_retained": 25, "decoded_job_logs_retained": 25,
        "configurations": 7, "logical_config_shards": 28, "corpus_cases": len(all_cases),
        "checks_per_configuration": corpus_checks, "total_configuration_checks": sum(r["checks"] for r in parsed),
        "max_job": max(timing, key=lambda r: r["job_seconds"]),
        "max_variant_execution": max(parsed, key=lambda r: r["execution_seconds"]),
        "bootstrap": {"artifact_id": producer["id"], "zip_digest": producer["digest"],
                      "bundle_id": bundle_id, "manifest_source_hash": source_hash.hexdigest(),
                      "producer_platform": report["platform"], "toolchain": report["toolchain"]},
        "settings": settings, "logical_shards": sorted(parsed, key=lambda r: (r["variant"], r["shard"])),
        "job_timings": sorted(timing, key=lambda r: r["job_id"]),
        "limits": {"timeout_minutes": 15, "PYSTACHY_JOBS": 4},
        "inventory_method": "Recomputed the four deterministic shards and exact checks from the clean source tree; each retained log and job summary matches the selected-case/check counts, modes, flags and shard. Artifacts do not contain individual case execution records.",
        "cpu_evidence": "All 25 decoded job logs were scanned; no consumer CPU marker is available. Producer platform.cpu is '(unknown)' and is not attributed to consumers.",
        "nonclaims": [
            "One exact-main supplemental run, not a three-run znver3 headroom acceptance set.",
            "Configuration completeness is bound by same-run source/restore plus deterministic inventory and exact retained counts, not per-case result JSON.",
            "This supplemental run does not replace the full exact-main CI release gate or GC source-size scaling qualification.",
            "The max job excludes queue waiting; complete created/start/completion metadata is retained separately.",
        ],
    }
    out = ROOT / "variants-audit.json"
    out.write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps({"result": "passed", "audit_sha256": digest(out.read_bytes()),
                      "cases": len(all_cases), "checks_per_configuration": corpus_checks,
                      "total_checks": sum(r["checks"] for r in parsed),
                      "max_job_seconds": audit["max_job"]["job_seconds"],
                      "max_variant_seconds": audit["max_variant_execution"]["execution_seconds"]}))


if __name__ == "__main__":
    main()
