"""Exact-source parameters for RC.1 artifact readback; unbound parameters fail closed."""
from pathlib import Path
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
TAG = "v0.4.0-rc.1"
VERSION = "0.4.0rc1"


def load_context(*required):
    data = json.loads((ROOT / "context.json").read_text())
    if data.get("tag") != TAG or data.get("package_version") != VERSION:
        raise ValueError("Unexpected RC.1 version context")
    for key in ("source_commit", "source_tree", "source_checkout", *required):
        if not data.get(key):
            raise ValueError("Audit context not yet bound: " + key)
    for key in ("source_commit", "source_tree"):
        if not re.fullmatch(r"[0-9a-f]{40}", data[key]):
            raise ValueError("Invalid exact-source identity: " + key)
    source = json.loads((ROOT / "source-commit.json").read_text())
    if source.get("sha") != data["source_commit"] or source.get("tree", {}).get("sha") != data["source_tree"]:
        raise ValueError("Source commit metadata does not bind the qualified tree")
    checkout = Path(data["source_checkout"])
    head_tree = subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=checkout, text=True).strip()
    if head_tree != data["source_tree"]:
        raise ValueError("Verifier checkout does not match the qualified source tree")
    dirty = subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"], cwd=checkout, text=True)
    if dirty:
        raise ValueError("Verifier checkout has modified tracked files")
    for key in ("native_run_id", "pypi_run_id"):
        if key in required and (type(data[key]) is not int or data[key] <= 0):
            raise ValueError("Invalid workflow run ID: " + key)
    return data


def source_tools(data):
    return str(Path(data["source_checkout"]) / "tools")
