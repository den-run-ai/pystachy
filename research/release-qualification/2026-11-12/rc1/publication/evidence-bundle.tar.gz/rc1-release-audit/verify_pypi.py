"""Compare public PyPI distributions with the exact approved publishing run."""
from pathlib import Path
import hashlib
import json
import sys
import urllib.request
import zipfile

from audit_context import ROOT, TAG, VERSION, load_context, source_tools
CONTEXT = load_context('native_run_id', 'pypi_run_id', 'approved_pypi_workflow_commit', 'approved_pypi_workflow_ref')
SOURCE = CONTEXT['source_commit']
RUN = CONTEXT['native_run_id']
sys.path.insert(0, source_tools(CONTEXT))
from pypi_release import audit_dist


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        while data := stream.read(1024 * 1024):
            h.update(data)
    return h.hexdigest()


def main():
    run = json.loads((ROOT / 'pypi-run.json').read_text())
    require(run['status'] == 'completed' and run['conclusion'] == 'success' and run['head_branch'] == CONTEXT['approved_pypi_workflow_ref'] and run['head_sha'] == CONTEXT['approved_pypi_workflow_commit'] and run['id'] == CONTEXT['pypi_run_id'] and run['path'] == '.github/workflows/release.yml', 'PyPI publication workflow identity mismatch')
    artifacts = json.loads((ROOT / 'pypi-artifacts.json').read_text())['artifacts']
    matches = [a for a in artifacts if a['name'] == 'pypi-' + VERSION]
    require(len(matches) == 1, 'Missing tested PyPI artifact')
    a = matches[0]
    require(a['workflow_run']['id'] == run['id'] and a['workflow_run']['head_sha'] == run['head_sha'] and not a['expired'], 'Tested PyPI artifact source mismatch')
    archive = ROOT / 'tested-zips' / (a['name'] + '.zip')
    require('sha256:' + sha(archive) == a['digest'], 'PyPI artifact ZIP digest mismatch')
    tested = {}
    with zipfile.ZipFile(archive) as z:
        require('SOURCE.json' in z.namelist() and 'SHA256SUMS' in z.namelist(), 'Missing PyPI artifact provenance')
        source = json.loads(z.read('SOURCE.json'))
        require(source['RELEASE_VERSION'] == TAG and source['PACKAGE_VERSION'] == VERSION and source['SOURCE_COMMIT'] == SOURCE and source['GITHUB_SHA'] == run['head_sha'], 'PyPI source provenance mismatch')
        sums = {name: digest for digest, name in (line.split() for line in z.read('SHA256SUMS').decode().splitlines())}
        for name, digest in sums.items():
            require(name.startswith('dist/') and Path(name).name in ('pystachy-' + VERSION + '.tar.gz', 'pystachy-' + VERSION + '-py3-none-any.whl'), 'Unexpected tested distribution')
            data = z.read(name)
            require(hashlib.sha256(data).hexdigest() == digest, 'Tested distribution checksum mismatch')
            tested[Path(name).name] = {'sha256': digest, 'size': len(data)}
    require(len(tested) == 2, 'Expected wheel and source distribution')
    with urllib.request.urlopen('https://pypi.org/pypi/pystachy/' + VERSION + '/json', timeout=45) as response:
        public = json.load(response)
    (ROOT / 'pypi-public.json').write_text(json.dumps(public, indent=2) + '\n')
    require(public['info']['name'] == 'pystachy' and public['info']['version'] == VERSION, 'Public PyPI metadata mismatch')
    require({x['filename'] for x in public['urls']} == set(tested), 'Public PyPI file inventory mismatch')
    out = ROOT / 'pypi-public-dist'
    out.mkdir(exist_ok=True)
    report = []
    for item in public['urls']:
        name = item['filename']
        require(item['url'].startswith('https://files.pythonhosted.org/') and not item['yanked'], 'Unexpected PyPI download URL or yanked artifact')
        dest = out / name
        if not dest.exists():
            with urllib.request.urlopen(item['url'], timeout=60) as response, dest.open('wb') as target:
                while data := response.read(1024 * 1024):
                    target.write(data)
        digest = sha(dest)
        require(digest == item['digests']['sha256'] == tested[name]['sha256'] and dest.stat().st_size == item['size'] == tested[name]['size'], 'Public PyPI distribution differs from tested bytes')
        report.append({'filename': name, 'url': item['url'], 'size': item['size'], 'sha256': digest, 'byte_for_byte_equal': True})
    audit_dist(out, VERSION)
    result = {'complete': True, 'status': 'passed', 'source_commit': SOURCE, 'native_run': RUN, 'pypi_run': run['id'], 'artifact_id': a['id'], 'version': VERSION, 'source_receipt': source, 'distributions': report}
    (ROOT / 'pypi-report.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        report = {'complete': False, 'status': 'failed', 'error': str(error) if isinstance(error, ValueError) else type(error).__name__}
        (ROOT / 'pypi-report.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report))
        raise SystemExit(1)
