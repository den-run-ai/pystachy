"""Assemble only completed RC.1 readback receipts; missing evidence fails closed."""
from datetime import datetime, timezone
import hashlib
import json

from audit_context import ROOT, TAG, VERSION, load_context


def require(value, message):
    if not value:
        raise ValueError(message)


def read(name):
    return json.loads((ROOT / name).read_text())


def main():
    context = load_context("native_run_id", "pypi_run_id", "approved_pypi_workflow_commit")
    receipts = {}
    names = ("native-report.json", "docker-amd64-report.json", "docker-arm64-report.json",
             "pypi-report.json", "pypi-public-install-evidence.json", "stable-aliases-after-pypi-report.json")
    for name in names:
        receipt = read(name)
        require(receipt.get("complete") is True and receipt.get("status") == "passed",
                "Incomplete public artifact evidence: " + name)
        require(receipt["source_commit"] == context["source_commit"], "Receipt source mismatch: " + name)
        receipts[name] = receipt
    require(len(receipts["native-report.json"]["assets"]) == 11, "Expected eleven native assets")
    require(set(receipts["native-report.json"]["manifests"]) ==
            {"linux-x86_64", "linux-aarch64", "macos-arm64", "macos-x86_64"}, "Incomplete native targets")
    require(receipts["docker-amd64-report.json"]["index_digest"] ==
            receipts["docker-arm64-report.json"]["index_digest"], "Docker index changed between architecture audits")
    workflows = {}
    for phase, expected_id, expected_sha in (
        ("native", context["native_run_id"], context["source_commit"]),
        ("pypi", context["pypi_run_id"], context["approved_pypi_workflow_commit"]),
    ):
        run = read(phase + "-run.json")
        jobs = read(phase + "-final-jobs.json")
        require(run["id"] == expected_id and run["head_sha"] == expected_sha and
                run["status"] == "completed" and run["conclusion"] == "success", "Workflow identity/result mismatch")
        require(jobs["total_count"] == len(jobs["jobs"]), "Incomplete workflow job pagination")
        require(all(j["status"] == "completed" and j["conclusion"] in ("success", "skipped")
                    for j in jobs["jobs"]), "Unsuccessful publication workflow job")
        workflow_audit_name = phase + "-workflow-report.json"
        workflow_audit = read(workflow_audit_name)
        require(workflow_audit.get("complete") is True and workflow_audit.get("status") == "passed" and
                workflow_audit["source_commit"] == context["source_commit"] and
                workflow_audit[phase + "_run"] == expected_id, "Incomplete independent workflow audit")
        workflows[phase] = {
            "id": run["id"], "url": run["html_url"], "attempt": run["run_attempt"],
            "workflow_commit": run["head_sha"], "workflow_ref": run["head_branch"],
            "audit_report": workflow_audit_name,
            "audit_report_sha256": hashlib.sha256((ROOT / workflow_audit_name).read_bytes()).hexdigest(),
            "jobs": [{k: j[k] for k in ("id", "name", "conclusion", "started_at", "completed_at")}
                     for j in jobs["jobs"]],
        }
    public = read("release.json")
    require(public["tag_name"] == TAG and public["target_commitish"] == context["source_commit"] and
            public["prerelease"] and not public["draft"], "Unexpected final GitHub prerelease")
    result = {
        "schema_version": 1, "complete": True, "status": "passed",
        "observed_at": datetime.now(timezone.utc).isoformat(), "repository": context["repository"],
        "tag": TAG, "package_version": VERSION, "source_commit": context["source_commit"],
        "source_tree": context["source_tree"],
        "scope": "Public artifact identity/readback and fresh local installation. Source qualification, CI headroom and stable-release acceptance are recorded separately.",
        "release": {k: public[k] for k in ("id", "html_url", "tag_name", "target_commitish", "prerelease", "draft", "published_at")},
        "workflows": workflows, "receipts": receipts,
        "method_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.glob("*.py"))},
        "receipt_sha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in names},
        "nonclaims": ["No local Docker execution is claimed by config/layer readback.",
                      "Local wheel installation uses its recorded toolchain, not every supported platform.",
                      "RC publication does not close repeated CI headroom or source-size scaling requirements."],
    }
    (ROOT / "audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"complete": True, "status": "passed", "source_commit": context["source_commit"],
                      "tag": TAG, "receipts": len(receipts)}))


if __name__ == "__main__":
    main()
