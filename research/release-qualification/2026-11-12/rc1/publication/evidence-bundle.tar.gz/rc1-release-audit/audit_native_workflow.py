"""Audit the complete retained native/Docker publication workflow and test steps."""
from datetime import datetime, timezone
import hashlib
import json
import re

from audit_context import ROOT, TAG, load_context


def main():
    c = load_context("native_run_id")
    run = json.loads((ROOT / "native-run.json").read_text())
    doc = json.loads((ROOT / "native-final-jobs.json").read_text())
    artifacts = json.loads((ROOT / "artifacts.json").read_text())["artifacts"]
    assert run["id"] == c["native_run_id"] and run["head_sha"] == c["source_commit"]
    assert run["status"] == "completed" and run["conclusion"] == "success"
    assert run["event"] == "workflow_dispatch" and run["head_branch"] == "main" and run["run_attempt"] == 1
    targets = ("linux-x86_64", "linux-aarch64", "macos-arm64", "macos-x86_64")
    successful = {"prepare", "publish"} | {f"Binary ({t})" for t in targets}
    successful |= {"Container (linux/amd64)", "Container (linux/arm64)"}
    skipped = {"Verify PyPI source packages", "Publish verified packages to PyPI"}
    assert doc["total_count"] == len(doc["jobs"]) == len(successful | skipped)
    assert {j["name"] for j in doc["jobs"]} == successful | skipped
    assert len({j["id"] for j in doc["jobs"]}) == len(doc["jobs"])
    assert len(artifacts) == 6 and len({a["name"] for a in artifacts}) == 6
    rows = []
    for j in doc["jobs"]:
        assert j["run_id"] == run["id"] and j["head_sha"] == c["source_commit"] and j["run_attempt"] == 1
        assert j["status"] == "completed"
        assert j["conclusion"] == ("success" if j["name"] in successful else "skipped")
        record = {k: j[k] for k in ("id", "name", "conclusion", "started_at", "completed_at")}
        if j["name"] in skipped:
            rows.append(record)
            continue
        wrapper = ROOT / "native-job-logs" / f"{j['id']}.json"
        raw = json.loads(wrapper.read_text())["content"]
        data = raw.encode()
        wrapper.with_suffix(".log").write_bytes(data)
        record["decoded_log_sha256"] = hashlib.sha256(data).hexdigest()
        record["decoded_log_path"] = str(wrapper.with_suffix(".log").relative_to(ROOT))
        record["steps"] = [{k: s[k] for k in ("name", "status", "conclusion", "started_at", "completed_at")}
                           for s in j["steps"]]
        assert all(s["status"] == "completed" and s["conclusion"] in ("success", "skipped")
                   for s in j["steps"])
        steps = {s["name"]: s["conclusion"] for s in j["steps"]}
        assert c["source_commit"] in raw
        if j["name"] == "prepare":
            assert steps["Require green CI on the release commit"] == "success"
            assert "CI: success, Installation: success, Lint: success, Packages: success" in raw
        elif j["name"].startswith("Binary ("):
            target = j["name"][8:-1]
            assert steps["Bootstrap, package, and test relocation without Python"] == "success"
            assert f"release {TAG} {target}: Python-free PATH, read-only resources, external cache" in raw
            assert f"pystachy {TAG} (commit {c['source_commit']})" in raw
            assert re.search(r"fixed point: stage1 == stage2 == stage3 \(\s*914514 lines of IR\)", raw)
            assert re.search(r"fixed point: runtime.py's IR, rt1 == rt2 == rt3 \(\s*21214 lines\)", raw)
            if target.startswith("linux-"):
                assert steps["Audit the complete Linux archive payload"] == "success"
            art = next(a for a in artifacts if a["name"] == "binary-" + target)
            assert "SHA256 digest of uploaded artifact is " + art["digest"][7:] in raw
        elif j["name"].startswith("Container ("):
            arch = j["name"].removeprefix("Container (linux/").removesuffix(")")
            assert steps["Verify and stage the tested native archive"] == "success"
            assert steps["Test JIT/AOT and bind mounts as an unprivileged user"] == "success"
            assert steps["Save the tested image for publication"] == "success"
            art = next(a for a in artifacts if a["name"] == "container-linux-" + arch)
            assert "SHA256 digest of uploaded artifact is " + art["digest"][7:] in raw
        elif j["name"] == "publish":
            for name in ("Recheck version and exact commit immediately before publishing",
                         "Verify downloads and load both tested native images",
                         "Push both tested images and their versioned manifest to Docker Hub",
                         "Publish GitHub release binaries and checksums"):
                assert steps[name] == "success"
            assert steps["Determine whether to advance latest"] == "skipped"
            assert steps["Update latest for newer stable releases"] == "skipped"
        if j["started_at"] and j["completed_at"]:
            record["job_seconds"] = (datetime.fromisoformat(j["completed_at"].replace("Z", "+00:00")) -
                                     datetime.fromisoformat(j["started_at"].replace("Z", "+00:00"))).total_seconds()
        rows.append(record)
    result = {
        "complete": True, "status": "passed", "source_commit": c["source_commit"], "source_tree": c["source_tree"],
        "native_run": run["id"], "attempt": 1, "tag": TAG, "audited_utc": datetime.now(timezone.utc).isoformat(),
        "success_jobs": len(successful), "expected_skips": len(skipped), "jobs": rows,
        "scope": "Complete publication workflow identity, required test/publish steps and retained decoded logs. Public bytes are verified by separate native, Docker and stable-alias receipts.",
    }
    out = ROOT / "native-workflow-report.json"
    out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": "passed", "success_jobs": len(successful), "expected_skips": len(skipped),
                      "sha256": hashlib.sha256(out.read_bytes()).hexdigest()}))


if __name__ == "__main__":
    main()
