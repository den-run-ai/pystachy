"""Compare public release bytes with the artifacts tested by the native workflow."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import urllib.request
import zipfile

from audit_context import ROOT, TAG, VERSION, load_context, source_tools
CONTEXT = load_context('native_run_id')
SOURCE = CONTEXT['source_commit']
RUN = CONTEXT['native_run_id']
TARGETS = ('linux-x86_64', 'linux-aarch64', 'macos-arm64', 'macos-x86_64')
sys.path.insert(0, source_tools(CONTEXT))
from release_smoke import extract, verify_manifest


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            h.update(block)
    return h.hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def download(asset):
    name = asset['name']
    require(name == Path(name).name, 'Unexpected asset path')
    url = 'https://github.com/den-run-ai/pystachy/releases/download/' + TAG + '/' + name
    require(asset['browser_download_url'] == url, 'Unexpected public asset URL')
    destination = ROOT / 'public' / name
    destination.parent.mkdir(exist_ok=True)
    if not destination.exists():
        request = urllib.request.Request(url, headers={'Accept-Encoding': 'identity'})
        with urllib.request.urlopen(request, timeout=60) as response, destination.with_suffix(destination.suffix + '.part').open('wb') as stream:
            count = 0
            while block := response.read(1024 * 1024):
                count += len(block)
                require(count <= asset['size'], 'Public download exceeded advertised size')
                stream.write(block)
        destination.with_suffix(destination.suffix + '.part').rename(destination)
    require(destination.stat().st_size == asset['size'], 'Public asset size mismatch: ' + name)
    digest = sha(destination)
    if asset.get('digest'):
        require(asset['digest'] == 'sha256:' + digest, 'GitHub asset digest mismatch: ' + name)
    return destination, digest


def main():
    metadata = json.loads((ROOT / 'release.json').read_text())
    run = json.loads((ROOT / 'native-run.json').read_text())
    require(run['id'] == RUN and run['head_sha'] == SOURCE and run['status'] == 'completed' and run['conclusion'] == 'success', 'Native publication workflow mismatch')
    require(run['path'] == '.github/workflows/release.yml', 'Unexpected native workflow path')
    tag = json.loads((ROOT / 'native-tag.json').read_text())
    require(tag['ref'] == 'refs/tags/' + TAG and tag['object']['type'] == 'commit' and tag['object']['sha'] == SOURCE, 'Native tag identity mismatch')
    artifacts = json.loads((ROOT / 'artifacts.json').read_text())['artifacts']
    require(metadata['tag_name'] == TAG and metadata['prerelease'] is True and metadata['draft'] is False, 'Unexpected release flags')
    require(metadata['target_commitish'] == SOURCE, 'Unexpected source commit')
    require(len(metadata['assets']) == 11, 'Expected eleven native release assets')
    tested = {}
    for target in TARGETS:
        matches = [a for a in artifacts if a['name'] == 'binary-' + target]
        require(len(matches) == 1, 'Missing or duplicate tested native artifact')
        artifact = matches[0]
        require(not artifact['expired'] and artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == SOURCE, 'Tested native artifact provenance mismatch')
        archive = ROOT / 'tested-zips' / (artifact['name'] + '.zip')
        if artifact.get('digest'):
            require('sha256:' + sha(archive) == artifact['digest'], 'Tested ZIP digest mismatch')
        with zipfile.ZipFile(archive) as z:
            for entry in z.infolist():
                if entry.is_dir():
                    continue
                name = Path(entry.filename).name
                require(name not in tested, 'Duplicate tested filename')
                data = z.read(entry)
                tested[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'size': len(data), 'artifact_id': artifact['id']}
    assets = {}
    for asset in metadata['assets']:
        path, digest = download(asset)
        entry = {'url': asset['browser_download_url'], 'size': path.stat().st_size, 'sha256': digest}
        if path.name != 'SHA256SUMS':
            require(path.name in tested, 'Public asset absent from tested artifacts')
            require(tested[path.name]['sha256'] == digest and tested[path.name]['size'] == path.stat().st_size, 'Public asset differs from tested bytes: ' + path.name)
            entry.update(tested_artifact_id=tested[path.name]['artifact_id'], byte_for_byte_equal=True)
        assets[path.name] = entry
    require(set(assets) == set(tested) | {'SHA256SUMS'}, 'Public and tested asset inventories differ')
    sums = {}
    for line in (ROOT / 'public/SHA256SUMS').read_text().splitlines():
        digest, name = line.split()
        if name.startswith('./'):
            name = name[2:]
        require(name not in sums, 'Duplicate checksum entry')
        sums[name] = digest
    expected_archives = {f'pystachy-{TAG}-{target}.tar.gz' for target in TARGETS}
    require(set(sums) == expected_archives, 'Checksum inventory mismatch')
    manifests = {}
    for target in TARGETS:
        name = f'pystachy-{TAG}-{target}.tar.gz'
        require(sums[name] == assets[name]['sha256'], 'SHA256SUMS mismatch')
        single = (ROOT / 'public' / (name + '.sha256')).read_text().split()
        require(single == [sums[name], name], 'Individual archive checksum mismatch')
        stage = ROOT / 'extracted' / target
        stage.mkdir(parents=True, exist_ok=True)
        directory = extract(ROOT / 'public' / name, stage)
        manifest = verify_manifest(directory)
        require((manifest['version'], manifest['target'], manifest['commit']) == (TAG, target, SOURCE), 'Native manifest provenance mismatch')
        manifests[target] = {'identity': {k: manifest[k] for k in ('version', 'target', 'commit')}, 'payload_files': len(manifest['files_sha256']), 'directory': str(directory)}
        if target == 'linux-x86_64':
            environment = {k: v for k, v in os.environ.items() if not k.startswith('PYSTACHY_')}
            environment.update(PYSTACHY_LLVM='/unavailable')
            r = subprocess.run([str(directory / 'bin/pystachy'), '--version'], capture_output=True, text=True, env=environment, timeout=30)
            require(r.returncode == 0 and r.stderr == '' and r.stdout == f'pystachy {TAG} (commit {SOURCE})\n', 'Public native version mismatch')
            manifests[target]['version_stdout'] = r.stdout
    report = {'complete': True, 'status': 'passed', 'repository': 'den-run-ai/pystachy', 'tag': TAG, 'source_commit': SOURCE, 'native_run': RUN, 'assets': assets, 'manifests': manifests}
    (ROOT / 'native-report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        report = {'complete': False, 'status': 'failed', 'error': str(error) if isinstance(error, ValueError) else type(error).__name__}
        (ROOT / 'native-report.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report))
        raise SystemExit(1)
