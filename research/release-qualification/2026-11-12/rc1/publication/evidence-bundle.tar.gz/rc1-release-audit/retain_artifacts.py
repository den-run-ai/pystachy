"""Retain exact publication-run artifact ZIPs supplied by the GitHub connector."""
from pathlib import Path
import hashlib
import json
import sys
import urllib.request
import zipfile

from audit_context import ROOT, load_context


def main():
    phase = sys.argv[1]
    if phase not in ("native", "pypi"):
        raise ValueError("Unexpected publication phase")
    context = load_context(phase + "_run_id")
    expected_sha = context["source_commit"] if phase == "native" else context["approved_pypi_workflow_commit"]
    expected_run = context[phase + "_run_id"]
    receipt = ROOT / (phase + "-downloads.json")
    records = json.loads(receipt.read_text()) if receipt.exists() else {}
    items = json.loads(sys.argv[2])
    for item in items:
        a = item["artifact"]
        name = a["name"]
        if a["workflow_run"]["id"] != expected_run or a["workflow_run"]["head_sha"] != expected_sha or a["expired"]:
            raise ValueError("Artifact source/run/expiry mismatch")
        allowed = {f"binary-{x}" for x in ("linux-x86_64", "linux-aarch64", "macos-arm64", "macos-x86_64")}
        allowed |= {"container-linux-amd64", "container-linux-arm64"}
        if phase == "pypi":
            allowed = {"pypi-" + context["package_version"]}
        if name not in allowed:
            raise ValueError("Unexpected publication artifact")
        out = ROOT / "tested-zips" / (name + ".zip")
        out.parent.mkdir(exist_ok=True)
        if not out.exists():
            request = urllib.request.Request(item["url"], headers={"Accept-Encoding": "identity"})
            part = out.with_suffix(".part")
            count = 0
            with urllib.request.urlopen(request, timeout=60) as response, part.open("wb") as dest:
                while block := response.read(1024 * 1024):
                    count += len(block)
                    if count > a["size_in_bytes"]:
                        raise ValueError("Artifact exceeds declared size")
                    dest.write(block)
            part.rename(out)
        digest = hashlib.sha256(out.read_bytes()).hexdigest()
        if out.stat().st_size != a["size_in_bytes"] or "sha256:" + digest != a["digest"]:
            raise ValueError("Retained artifact digest/size mismatch")
        with zipfile.ZipFile(out) as z:
            if z.testzip() is not None:
                raise ValueError("ZIP member CRC mismatch")
            files = [{"path": f.filename, "bytes": f.file_size, "crc32": f.CRC} for f in z.infolist()]
        records[str(a["id"])] = {
            "artifact_id": a["id"], "name": name, "run_id": expected_run,
            "workflow_commit": expected_sha, "release_source_commit": context["source_commit"],
            "zip_path": str(out.relative_to(ROOT)), "zip_sha256": digest,
            "zip_bytes": out.stat().st_size, "inventory": files,
        }
        receipt.write_text(json.dumps(records, indent=2) + "\n")
        print(json.dumps({"retained_artifact": name, "bytes": out.stat().st_size,
                          "sha256": digest}), flush=True)
    print(json.dumps({"phase": phase, "retained_artifacts": len(records)}))


if __name__ == "__main__":
    main()
