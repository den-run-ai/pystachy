"""Bind published OCI image configs and layers to same-run tested Docker images."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import sys
import tarfile
import urllib.request
import zipfile
import zlib

from registry_read import ROOT as REGISTRY, token

from audit_context import ROOT, TAG, VERSION, load_context, source_tools
CONTEXT = load_context('native_run_id')
SOURCE = CONTEXT['source_commit']
RUN = CONTEXT['native_run_id']


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        while data := stream.read(1024 * 1024):
            h.update(data)
    return h.hexdigest()


def tested_image(artifact, arch):
    require(artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == SOURCE and not artifact['expired'], 'Tested image provenance mismatch')
    archive = ROOT / 'tested-zips' / (artifact['name'] + '.zip')
    require('sha256:' + sha(archive) == artifact['digest'], 'Tested container ZIP digest mismatch')
    name = 'pystachy-image-' + arch + '.tar.gz'
    dest = ROOT / 'tested-images' / name
    dest.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        names = {Path(n).name: n for n in z.namelist()}
        require(set(names) == {name, name + '.sha256'}, 'Unexpected tested-image artifact inventory')
        expected = z.read(names[name + '.sha256']).decode().split()
        if not dest.exists():
            with z.open(names[name]) as source, dest.open('wb') as target:
                while data := source.read(1024 * 1024):
                    target.write(data)
        require(expected == [sha(dest), name], 'Tested container archive checksum mismatch')
    small = {}
    hashes = {}
    with tarfile.open(dest, 'r|gz') as t:
        for member in t:
            if not member.isfile():
                continue
            source = t.extractfile(member)
            raw = hashlib.sha256()
            unpacked = hashlib.sha256()
            count = 0
            chunks = [] if member.size < 1024 * 1024 else None
            decoder = None
            first = True
            while data := source.read(1024 * 1024):
                if first:
                    decoder = zlib.decompressobj(16 + zlib.MAX_WBITS) if data.startswith(b'\x1f\x8b') else None
                    first = False
                count += len(data)
                raw.update(data)
                unpacked.update(decoder.decompress(data) if decoder is not None else data)
                if chunks is not None:
                    chunks.append(data)
            if decoder is not None:
                unpacked.update(decoder.flush())
                require(decoder.eof, 'Truncated saved layer')
            hashes[member.name] = {'raw': 'sha256:' + raw.hexdigest(), 'unpacked': 'sha256:' + unpacked.hexdigest(), 'size': count}
            if chunks is not None:
                small[member.name] = b''.join(chunks)
    manifest = json.loads(small['manifest.json'])
    require(len(manifest) == 1, 'Expected one saved tested image')
    entry = manifest[0]
    config_data = small[entry['Config']]
    config = json.loads(config_data)
    diff_ids = [hashes[path]['unpacked'] for path in entry['Layers']]
    require(diff_ids == config['rootfs']['diff_ids'], 'Saved image layer chain differs from config')
    require(config['architecture'] == arch and config['os'] == 'linux', 'Saved image architecture mismatch')
    require(config['config']['Labels']['org.opencontainers.image.revision'] == SOURCE and config['config']['Labels']['org.opencontainers.image.version'] == TAG, 'Saved image release labels mismatch')
    return {'artifact_id': artifact['id'], 'archive_sha256': expected[0], 'config_digest': 'sha256:' + hashlib.sha256(config_data).hexdigest(), 'config': config, 'config_bytes': config_data, 'diff_ids': diff_ids}


def public_layer(descriptor, credential, expected_diff):
    digest = descriptor['digest']
    request = urllib.request.Request(REGISTRY + '/blobs/' + digest, headers={'Authorization': 'Bearer ' + credential, 'Accept-Encoding': 'identity'})
    compressed = hashlib.sha256()
    unpacked = hashlib.sha256()
    decoder = zlib.decompressobj(16 + zlib.MAX_WBITS)
    count = 0
    with urllib.request.urlopen(request, timeout=60) as response:
        while data := response.read(1024 * 1024):
            count += len(data)
            require(count <= descriptor['size'], 'Registry layer exceeded declared size')
            compressed.update(data)
            unpacked.update(decoder.decompress(data))
    unpacked.update(decoder.flush())
    require(decoder.eof, 'Truncated public compressed layer')
    require(count == descriptor['size'] and 'sha256:' + compressed.hexdigest() == digest, 'Public layer digest or size mismatch')
    require('sha256:' + unpacked.hexdigest() == expected_diff, 'Public layer differs from tested uncompressed layer')
    return {'digest': digest, 'size': count, 'diff_id': expected_diff, 'bytes_verified': True}


def main():
    arch = sys.argv[1]
    require(arch in ('amd64', 'arm64'), 'Unexpected architecture')
    artifacts = json.loads((ROOT / 'artifacts.json').read_text())['artifacts']
    matches = [a for a in artifacts if a['name'] == 'container-linux-' + arch]
    require(len(matches) == 1, 'Missing tested container artifact')
    saved = tested_image(matches[0], arch)
    public = json.loads((ROOT / 'docker-public/report.json').read_text())
    require(public['image'] == 'dta67/pystachy' and public['tag'] == TAG, 'Public Docker reference mismatch')
    p = public['platforms'][arch]
    public_config = (ROOT / 'docker-public' / (arch + '-config.json')).read_bytes()
    require(public_config == saved.pop('config_bytes') and p['config_digest'] == saved['config_digest'], 'Published config differs from tested config')
    require(p['diff_ids'] == saved['diff_ids'], 'Published layer chain differs from tested layer chain')
    require(len(p['layers']) == len(saved['diff_ids']), 'Layer count mismatch')
    credential = token()
    layers = [public_layer(d, credential, diff) for d, diff in zip(p['layers'], saved['diff_ids'])]
    report = {'complete': True, 'status': 'passed', 'source_commit': SOURCE, 'native_run': RUN, 'tag': TAG, 'architecture': arch, 'index_digest': public['index_digest'], 'manifest_digest': p['manifest_digest'], 'tested': saved, 'public_layers': layers}
    (ROOT / ('docker-' + arch + '-report.json')).write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'architecture': arch, 'status': 'passed', 'config_digest': p['config_digest'], 'layers_verified': len(layers), 'public_bytes_verified': sum(x['size'] for x in layers)}))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        report = {'complete': False, 'status': 'failed', 'error': str(error) if isinstance(error, ValueError) else type(error).__name__}
        (ROOT / ('docker-' + sys.argv[1] + '-report.json')).write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report))
        raise SystemExit(1)
