"""Read public OCI distribution metadata without retaining bearer credentials."""
from pathlib import Path
import hashlib
import json
import sys
import urllib.parse
import urllib.request

IMAGE = 'dta67/pystachy'
ROOT = 'https://registry-1.docker.io/v2/' + IMAGE
ACCEPT = ', '.join(['application/vnd.oci.image.index.v1+json', 'application/vnd.docker.distribution.manifest.list.v2+json', 'application/vnd.oci.image.manifest.v1+json', 'application/vnd.docker.distribution.manifest.v2+json'])


def token():
    query = urllib.parse.urlencode({'service': 'registry.docker.io', 'scope': 'repository:' + IMAGE + ':pull'})
    with urllib.request.urlopen('https://auth.docker.io/token?' + query, timeout=45) as response:
        return json.load(response)['token']


def fetch(path, credential):
    request = urllib.request.Request(ROOT + path, headers={'Authorization': 'Bearer ' + credential, 'Accept': ACCEPT, 'Accept-Encoding': 'identity'})
    with urllib.request.urlopen(request, timeout=45) as response:
        data = response.read(16 * 1024 * 1024 + 1)
        if len(data) > 16 * 1024 * 1024:
            raise ValueError('Oversized metadata')
        digest = 'sha256:' + hashlib.sha256(data).hexdigest()
        declared = response.headers.get('Docker-Content-Digest')
        if declared and declared != digest:
            raise ValueError('Registry content digest mismatch')
        return json.loads(data), digest, data


def main():
    tag, output = sys.argv[1:]
    out = Path(output)
    out.mkdir(parents=True, exist_ok=True)
    credential = token()
    manifest, digest, data = fetch('/manifests/' + tag, credential)
    (out / 'index.json').write_bytes(data)
    report = {'image': IMAGE, 'tag': tag, 'index_digest': digest, 'platforms': {}}
    if 'manifests' not in manifest:
        raise ValueError('Expected a multi-platform index')
    for item in manifest['manifests']:
        p = item.get('platform', {})
        if p.get('os') != 'linux' or p.get('architecture') not in ('amd64', 'arm64'):
            continue
        arch = p['architecture']
        if arch in report['platforms']:
            raise ValueError('Duplicate public image architecture')
        platform, platform_digest, raw = fetch('/manifests/' + item['digest'], credential)
        if platform_digest != item['digest']:
            raise ValueError('Platform digest mismatch')
        config, config_digest, config_raw = fetch('/blobs/' + platform['config']['digest'], credential)
        if config_digest != platform['config']['digest']:
            raise ValueError('Config digest mismatch')
        (out / (arch + '-manifest.json')).write_bytes(raw)
        (out / (arch + '-config.json')).write_bytes(config_raw)
        report['platforms'][arch] = {'manifest_digest': platform_digest, 'config_digest': config_digest, 'os': config['os'], 'architecture': config['architecture'], 'labels': config['config'].get('Labels', {}), 'diff_ids': config['rootfs']['diff_ids'], 'layers': platform.get('layers', [])}
    if set(report['platforms']) != {'amd64', 'arm64'}:
        raise ValueError('Incomplete public image architecture inventory')
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print(type(error).__name__ + (': ' + str(error.code) if hasattr(error, 'code') else ''))
        raise SystemExit(1)
