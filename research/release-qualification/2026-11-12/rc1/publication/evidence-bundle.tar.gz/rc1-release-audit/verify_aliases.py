"""Compare fresh stable-alias observations before and after RC.1 publication."""
from datetime import datetime, timezone
import json
import sys

from audit_context import ROOT, TAG, load_context


def require(value, message):
    if not value:
        raise ValueError(message)


def read(name):
    return json.loads((ROOT / name).read_text())


def main():
    context = load_context("native_run_id")
    phase = sys.argv[1] if len(sys.argv) > 1 else "native"
    require(phase in ("native", "pypi"), "Unexpected alias observation phase")
    suffix = "-pypi" if phase == "pypi" else ""
    before = read("latest-github-before.json")
    after = read("latest-github-after" + suffix + ".json")
    keys = ("id", "tag_name", "target_commitish")
    require({k: before[k] for k in keys} == {k: after[k] for k in keys},
            "GitHub stable latest release changed during RC publication")
    require(not before["prerelease"] and not before["draft"] and not after["prerelease"] and
            not after["draft"] and before["tag_name"] != TAG, "Unexpected GitHub stable alias")
    docker_before = read("docker-latest-before/report.json")
    docker_after = read("docker-latest-after" + suffix + "/report.json")
    require(docker_before == docker_after, "Docker latest changed during RC publication")
    require(docker_after["image"] == "dta67/pystachy" and docker_after["tag"] == "latest" and
            set(docker_after["platforms"]) == {"amd64", "arm64"}, "Unexpected Docker stable alias")
    for platform in docker_after["platforms"].values():
        require(platform["labels"]["org.opencontainers.image.version"] == before["tag_name"],
                "Docker stable image version differs from the stable GitHub release")
    report = {
        "complete": True, "status": "passed", "source_commit": context["source_commit"],
        "native_run": context["native_run_id"], "tag": TAG,
        "observation_phase": phase,
        "observed_at": datetime.now(timezone.utc).isoformat(), "unchanged": True,
        "github_latest": {k: after[k] for k in (*keys, "html_url")},
        "docker_latest": docker_after,
        "scope": "Fresh before/after public alias observations for this publication; no prior release report is reused.",
    }
    name = "stable-aliases-after-pypi-report.json" if phase == "pypi" else "stable-aliases-report.json"
    (ROOT / name).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": "passed", "stable_tag": after["tag_name"]}))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        report = {"complete": False, "status": "failed", "error": str(error) if isinstance(error, ValueError) else type(error).__name__}
        name = "stable-aliases-after-pypi-report.json" if len(sys.argv) > 1 and sys.argv[1] == "pypi" else "stable-aliases-report.json"
        (ROOT / name).write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps(report))
        raise SystemExit(1)
