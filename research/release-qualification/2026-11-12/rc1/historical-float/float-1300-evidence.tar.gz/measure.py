"""One fixed set of 15 alternating, pinned pairs for #1300; retain every sample."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import platform
import re
import resource
import statistics
import subprocess
import time

HERE = Path(__file__).resolve().parent
CPU = 3
REPETITIONS = 15
OUTPUT = HERE / "timing.json"
assert not OUTPUT.exists(), "A retained measurement already exists; do not silently resample"
assert CPU in os.sched_getaffinity(0)
EXPECTED = (HERE / "output.cpython.txt").read_text()
BUILDS = json.loads((HERE / "builds.json").read_text())
ENV = {k: v for k, v in os.environ.items() if not k.startswith("PYSTACHY_")}
for build in BUILDS:
    assert hashlib.sha256((HERE / ("float." + build["label"])).read_bytes()).hexdigest() == build["binary_sha256"]


def read(path):
    try:
        return Path(path).read_text()
    except (OSError, PermissionError):
        return None


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def snapshot():
    paths = ["/proc/loadavg", "/proc/stat", "/sys/fs/cgroup/cpu.stat", "/sys/fs/cgroup/cpu.max",
             f"/sys/devices/system/cpu/cpu{CPU}/cpufreq/scaling_governor",
             f"/sys/devices/system/cpu/cpu{CPU}/cpufreq/scaling_cur_freq",
             f"/sys/devices/system/cpu/cpu{CPU}/topology/thread_siblings_list",
             f"/sys/devices/system/cpu/cpu{CPU}/topology/core_id"]
    return {path: read(path) for path in paths}


def save(report):
    OUTPUT.write_text(json.dumps(report, indent=2) + "\n")


def run(label, repetition, warmup):
    args = ["taskset", "-c", str(CPU), str(HERE / ("float." + label)), "10"]
    started = now()
    ru0 = resource.getrusage(resource.RUSAGE_CHILDREN)
    t0 = time.perf_counter_ns()
    result = subprocess.run(args, cwd=HERE, env=ENV, capture_output=True, text=True, timeout=30)
    wall = (time.perf_counter_ns() - t0) / 1e9
    ru1 = resource.getrusage(resource.RUSAGE_CHILDREN)
    times = re.findall(r"^seconds (\S+)$", result.stderr, re.M)
    row = {"label": label, "repetition": repetition, "warmup": warmup, "command": args,
           "started": started, "finished": now(), "wall_seconds": wall,
           "timed_seconds": float(times[0]) if len(times) == 1 else None,
           "user_seconds": ru1.ru_utime - ru0.ru_utime, "system_seconds": ru1.ru_stime - ru0.ru_stime,
           "voluntary_context_switches": ru1.ru_nvcsw - ru0.ru_nvcsw,
           "involuntary_context_switches": ru1.ru_nivcsw - ru0.ru_nivcsw,
           "status": result.returncode, "stdout": result.stdout, "stderr": result.stderr,
           "stdout_sha256": hashlib.sha256(result.stdout.encode()).hexdigest()}
    return row


report = {"started": now(), "cpu": CPU, "allowed_cpus": sorted(os.sched_getaffinity(0)),
          "repetitions": REPETITIONS, "warmup_pairs": 2, "sources": json.loads((HERE / "sources.json").read_text()),
          "builds_sha256": hashlib.sha256((HERE / "builds.json").read_bytes()).hexdigest(),
          "toolchain_sha256": hashlib.sha256((HERE / "toolchain.json").read_bytes()).hexdigest(),
          "measurement_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "metric": "float benchmark stderr seconds line; internal loop-region elapsed time",
          "workload": {"source": "bench/pyperformance/float.py", "args": ["10"], "points_per_loop": 100000},
          "acceptance": {"maximum_rc1_over_old_median_ratio": 1.05, "discarded_samples": 0,
                         "method": "Median of all 15 RC1 samples divided by the median of all 15 baseline samples; no outlier removal or additional sampling"},
          "platform": platform.platform(), "machine": platform.machine(), "cpuinfo": read("/proc/cpuinfo"),
          "before": snapshot(), "warmups": [], "samples": []}
save(report)
for warmup, count in [(True, 2), (False, REPETITIONS)]:
    for repetition in range(count):
        for label in (["old", "rc1"] if repetition % 2 == 0 else ["rc1", "old"]):
            row = run(label, repetition, warmup)
            report["warmups" if warmup else "samples"].append(row)
            save(report)
            assert row["status"] == 0 and row["stdout"] == EXPECTED and row["timed_seconds"] is not None, row
report["after"] = snapshot()
report["finished"] = now()
report["results"] = {}
for label in ["old", "rc1"]:
    values = [row["timed_seconds"] * 1000 for row in report["samples"] if row["label"] == label]
    median = statistics.median(values)
    report["results"][label] = {"median_ms": median, "min_ms": min(values), "max_ms": max(values),
                                "mad_ms": statistics.median(abs(value - median) for value in values),
                                "mean_ms": statistics.mean(values), "stdev_ms": statistics.stdev(values),
                                "samples_ms": values}
ratio = report["results"]["rc1"]["median_ms"] / report["results"]["old"]["median_ms"]
report["acceptance"].update(rc1_over_old_median_ratio=ratio, rc1_change_percent=(ratio - 1) * 100,
                            within_five_percent=ratio <= 1.05)
paired = []
for repetition in range(REPETITIONS):
    values = {row["label"]: row["timed_seconds"] for row in report["samples"] if row["repetition"] == repetition}
    paired.append(values["rc1"] / values["old"])
report["paired_rc1_over_old_ratios"] = paired
save(report)
print(json.dumps({"results": report["results"], "acceptance": report["acceptance"],
                  "paired_rc1_over_old_ratios": paired}, indent=2))
