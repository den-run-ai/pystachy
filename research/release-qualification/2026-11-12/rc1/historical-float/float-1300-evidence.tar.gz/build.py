"""Prepare the exact #1300 old/RC1 AOT comparison after local workers are idle."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parent
PYTHON = WORKSPACE / "toolchains/python/cpython-3.13.16-linux-x86_64-gnu/bin/python3.13"
LLVM = WORKSPACE / "toolchains/debian/root/usr/lib/llvm-19/bin"
LIBRARIES = WORKSPACE / "toolchains/debian/root/usr/lib/x86_64-linux-gnu"
SOURCES = json.loads((HERE / "sources.json").read_text())
ENV = {k: v for k, v in os.environ.items() if not k.startswith("PYSTACHY_")
       and k not in {"PYTHONPATH", "PYTHONHOME", "CC", "CXX", "CFLAGS", "CPPFLAGS", "LDFLAGS"}}
ENV["LD_LIBRARY_PATH"] = str(LIBRARIES)
ENV["PATH"] = str(LLVM) + ":" + str(PYTHON.parent) + ":" + ENV.get("PATH", "/usr/bin:/bin")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + "\n")


def command(args, cwd=HERE, env=ENV, timeout=60):
    result = subprocess.run([str(a) for a in args], cwd=cwd, env=env,
                            capture_output=True, text=True, timeout=timeout)
    return {"command": [str(a) for a in args], "cwd": str(cwd), "status": result.returncode,
            "stdout": result.stdout, "stderr": result.stderr}


assert not (HERE / "builds.json").exists(), "Preserve any earlier build record before a new attempt"
tools = {}
for path in [PYTHON, LLVM / "clang", LLVM / "opt", LLVM / "llvm-link", LLVM / "llvm-as",
             LLVM / "llvm-nm", LLVM / "llvm-objdump"]:
    result = command([path, "--version"])
    assert result["status"] == 0, result
    tools[path.name] = {"path": str(path), "sha256": sha(path), "version": result["stdout"]}
write("toolchain.json", tools)

builds = []
inlining = {}
for source in SOURCES:
    label = source["label"]
    checkout = Path(source["path"])
    identity = command(["git", "show", "-s", "--format=%H %T", "HEAD"], cwd=checkout)
    assert identity["stdout"].split() == [source["local_commit"], source["source_tree"]], identity
    clean = command(["git", "status", "--porcelain", "--untracked-files=no"], cwd=checkout)
    assert clean["status"] == 0 and not clean["stdout"].strip(), clean
    assert sha(checkout / source["input"]) == source["input_sha256"]
    env = ENV | {"PYSTACHY_HOME": str(checkout), "PYSTACHY_CACHE": str(HERE / (label + "-cache")),
                 "PYSTACHY_LLVM": str(LLVM), "PYSTACHY_AOT_OPT": "2", "PYSTACHY_OPT": "",
                 "PYSTACHY_CFLAGS": "", "PYSTACHY_IRCHECK": "1", "PYSTACHY_TIMING": "1"}
    binary = HERE / ("float." + label)
    ir = HERE / ("float." + label + ".ll")
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = command([PYTHON, "pystachy.py", "build", source["input"], "-o", binary,
                      "--emit-ir", ir], cwd=checkout, env=env, timeout=120)
    (HERE / ("build." + label + ".log")).write_text(result["stdout"] + result["stderr"])
    row = source | result | {"started": started,
                             "finished": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                             "environment": {k: v for k, v in env.items()
                                             if k.startswith("PYSTACHY_") or k == "LD_LIBRARY_PATH"},
                             "hosted_driver_sha256": sha(checkout / "pystachy.py"),
                             "driver_module_sha256": sha(checkout / "src/pystachy_compiler/driver.py")}
    builds.append(row)
    write("builds.json", builds)
    assert result["status"] == 0, result
    row["binary_sha256"] = sha(binary)
    row["raw_emitted_ir_sha256"] = sha(ir)
    symbols = command([LLVM / "llvm-nm", "-C", binary])
    assembly = command([LLVM / "llvm-objdump", "-d", binary])
    assert symbols["status"] == 0 and assembly["status"] == 0
    (HERE / ("symbols." + label + ".txt")).write_text(symbols["stdout"])
    (HERE / ("disassembly." + label + ".txt")).write_text(assembly["stdout"])
    inlining[label] = {
        "constructor_symbol_lines": [line for line in symbols["stdout"].splitlines() if "Point.__init__" in line],
        "constructor_disassembly_mentions": [line for line in assembly["stdout"].splitlines() if "Point.__init__" in line],
        "raw_ir_constructor_lines": [line for line in ir.read_text().splitlines() if "Point.__init__" in line],
    }
    write("builds.json", builds)
    write("inlining.json", inlining)

outputs = []
for label, args in [("cpython", [PYTHON, Path(SOURCES[0]["path"]) / SOURCES[0]["input"], "10"]),
                    ("old", [HERE / "float.old", "10"]), ("rc1", [HERE / "float.rc1", "10"])]:
    result = command(args)
    outputs.append({"label": label} | result)
    (HERE / ("output." + label + ".txt")).write_text(result["stdout"])
    write("outputs.json", outputs)
    assert result["status"] == 0, result
    assert result["stdout"] == outputs[0]["stdout"], outputs
print(json.dumps({"builds": [{k: row[k] for k in ["label", "source_tree", "status", "binary_sha256",
                                                          "raw_emitted_ir_sha256"]} for row in builds],
                  "full_stdout_matches_cpython": True, "inlining": inlining}, indent=2))
