from pathlib import Path
import json, os, shutil, subprocess, time
w=Path('/tmp/pystachy-bytescan-sanitize')
llvm=Path('/usr/lib/llvm-18/bin')
resource=w/'compiler-rt/usr/lib/llvm-18/lib/clang/18'
clang=[str(llvm/'clang'),f'-resource-dir={resource}','-isystem','/usr/lib/llvm-18/lib/clang/18/include']
records=[]
def run(label,args,env=None,expect=0):
    before=time.monotonic()
    result=subprocess.run(args,cwd=w,env=env,capture_output=True,text=True,timeout=180)
    row={'label':label,'argv':list(map(str,args)),'returncode':result.returncode,'seconds':round(time.monotonic()-before,3),'stdout':result.stdout,'stderr':result.stderr}
    if env:
        row['environment']={k:env[k] for k in ['ASAN_OPTIONS','UBSAN_OPTIONS','PYSTACHY_GC_STRESS'] if k in env}
    records.append(row)
    (w/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    (w/(label+'.log')).write_text(result.stdout+result.stderr)
    print(label, 'exit',result.returncode,'seconds',row['seconds'],flush=True)
    if result.stdout: print(result.stdout,end='',flush=True)
    if result.stderr: print(result.stderr,end='',flush=True)
    if result.returncode!=expect: raise SystemExit(f'{label}: expected exit {expect}')
    return result
run('probe-asan-ubsan-compile',clang+['-O2','-g','-fno-omit-frame-pointer','-fsanitize=address,undefined','-fno-sanitize-recover=all','-c','snapshot/tools/bytescanprobe.c','-o','probe-sanitized.o'])
run('runtime-asan-compile',clang+['-O2','-g','-fno-omit-frame-pointer','-fsanitize=address','-fno-sanitize-recover=all','-c','runtime-address.ll','-o','runtime-asan.o'])
run('combined-link',clang+['-O2','-fsanitize=address,undefined','-fno-sanitize-recover=all','probe-sanitized.o','runtime-asan.o','-lm','-o','bytescanprobe-sanitized'])
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:detect_stack_use_after_return=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
env.pop('PYSTACHY_GC_STRESS',None)
run('asan-ubsan-normal',[str(w/'bytescanprobe-sanitized')],env)
run('asan-ubsan-gc-stress',[str(w/'bytescanprobe-sanitized')],dict(env,PYSTACHY_GC_STRESS='1'))
control=w/'scalar-control'
shutil.copytree(w/'snapshot',control,dirs_exist_ok=True)
p=control/'runtime.c'
s=p.read_text(); needle='if (below <= 128 && end - i >= 8) {'
assert s.count(needle)==1
p.write_text(s.replace(needle,'if (0 && below <= 128 && end - i >= 8) {'))
p=control/'tools/bytescanprobe.c'
s=p.read_text();needle='wrapper(); errors(); guarded(); bulk_work();'
assert s.count(needle)==1
p.write_text(s.replace(needle,'wrapper(); errors(); guarded(); printf("scalar-control: %lld correctness/bounds checks passed before the bulk gate\\n", checks); bulk_work();'))
run('scalar-control-compile',clang+['-O2','-c',str(control/'tools/bytescanprobe.c'),'-o','scalar-control.o'])
run('runtime-plain-compile',clang+['-O2','-c','runtime-plain.ll','-o','runtime-plain.o'])
run('scalar-control-link',clang+['-O2','scalar-control.o','runtime-plain.o','-lm','-o','bytescanprobe-scalar'])
result=run('scalar-negative-control',[str(w/'bytescanprobe-scalar')],expect=1)
assert result.stderr=='bytescanprobe: long span did not skip words\n',result.stderr
assert 'correctness/bounds checks passed before the bulk gate' in result.stdout,result.stdout
print('All sanitizer runs passed; scalar-only control failed only the deterministic bulk-work gate.',flush=True)
