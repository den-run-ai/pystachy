import datetime
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import time

ROOT = Path('/workspace/scratch/7d119a0ee86b')
PLAN = {r['name']: r for r in json.loads((ROOT / 'final-plan.json').read_text())}
OUT = ROOT / 'focused-repeat-results.json'
CASES = [
    {'id': 'jit_repair_short', 'variants': ['base_jit', 'candidate_jit'], 'api': 'repair', 'case': 'short', 'size': 8192, 'count': 1000000, 'per_call': 8},
    {'id': 'jit_repair_mixed', 'variants': ['base_jit', 'candidate_jit'], 'api': 'repair', 'case': 'mixed', 'size': 8192, 'count': 200000, 'per_call': 5},
    {'id': 'integrated_aot_direct_dense', 'variants': ['integer_fix_aot', 'integrated_aot'], 'api': 'direct', 'case': 'dense', 'size': 8192, 'count': 1500, 'per_call': 8192},
]
WARMUPS = 4
SAMPLES = 9
PROCESSES = 7
runs = []
files = [ROOT / 'pystachy/bench/extended/json_scan.py']
for name in {n for c in CASES for n in c['variants']}:
    files.append(Path(PLAN[name]['command'][0]))
report = {
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'description': 'Targeted repeats of three flagged regressions; same final-plan binaries, source, homes and private caches; 5x batch lengths, 4 warmups, 9 samples; seven rotated paired fresh processes.',
    'cpu': 0, 'warmups': WARMUPS, 'samples': SAMPLES, 'processes': PROCESSES,
    'cases': CASES, 'sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
    'source_commits': {d: subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT/d, text=True).strip() for d in ('pystachy', 'pystachy-base')},
    'runs': runs, 'status': 'running',
}

def save():
    OUT.write_text(json.dumps(report, indent=2) + '\n')


def parse_output(output, case):
    lines = output.splitlines()
    expected_tags = ['case', 'first'] + ['warmup'] * WARMUPS + ['sample'] * SAMPLES + ['verified']
    assert [x.split()[0] for x in lines] == expected_tags, 'unexpected output structure'
    header = lines[0].split()
    assert header[1:4] == [case['api'], case['case'], str(case['size'])], header
    assert int(header[-1]) == case['count']
    checksum = case['count'] * case['per_call']
    for line in lines[1:-1]:
        assert int(line.split()[1]) == checksum, line
    assert lines[-1] == 'verified ' + str(case['per_call'])
    samples = [int(line.split()[2]) for line in lines if line.startswith('sample ')]
    assert len(samples) == SAMPLES and min(samples) > 0
    return samples

save()
for rep in range(PROCESSES):
    ordered = CASES[rep % len(CASES):] + CASES[:rep % len(CASES)]
    for case in ordered:
        variants = case['variants'] if rep % 2 == 0 else list(reversed(case['variants']))
        for variant in variants:
            plan = PLAN[variant]
            prefix = plan['command'][:-6]
            command = ['taskset', '-c', '0'] + prefix + [case['api'], case['case'], str(case['size']), str(case['count']), str(WARMUPS), str(SAMPLES)]
            env = {k: v for k, v in os.environ.items() if not k.startswith('PYSTACHY_')}
            env.update(plan.get('env', {}))
            start = time.perf_counter()
            r = subprocess.run(command, cwd=plan.get('cwd', str(ROOT/'pystachy')), env=env, text=True, capture_output=True, timeout=120)
            row = {'id': case['id'], 'variant': variant, 'process': rep, 'command': command, 'env': plan.get('env', {}), 'cwd': plan.get('cwd', str(ROOT/'pystachy')), 'wall_s':time.perf_counter()-start, 'returncode':r.returncode, 'stdout':r.stdout, 'stderr':r.stderr}
            runs.append(row)
            if r.returncode:
                report['status']='failed'; save(); raise RuntimeError(row)
            row['samples_ns'] = parse_output(r.stdout, case)
            row['median_ns'] = statistics.median(row['samples_ns'])
            save()
            print(f"{rep + 1}/{PROCESSES} {case['id']} {variant}: {row['median_ns']/1e6:.3f} ms, wall {row['wall_s']:.2f}s", flush=True)

summary = []
for case in CASES:
    bname,cname = case['variants']
    base = [next(r['median_ns'] for r in runs if r['id']==case['id'] and r['variant']==bname and r['process']==i) for i in range(PROCESSES)]
    candidate = [next(r['median_ns'] for r in runs if r['id']==case['id'] and r['variant']==cname and r['process']==i) for i in range(PROCESSES)]
    paired = [c/b-1 for b,c in zip(base,candidate)]
    row = {'id':case['id'], 'base':bname, 'candidate':cname, 'base_process_medians_ns':base, 'candidate_process_medians_ns':candidate, 'base_median_ns':statistics.median(base), 'candidate_median_ns':statistics.median(candidate), 'ratio_of_medians':statistics.median(candidate)/statistics.median(base), 'paired_deltas':paired, 'median_paired_delta':statistics.median(paired), 'pairs_slower':sum(d>0 for d in paired)}
    summary.append(row)
report['summary']=summary
report['status']='complete'
save()
print(json.dumps(summary,indent=2), flush=True)
