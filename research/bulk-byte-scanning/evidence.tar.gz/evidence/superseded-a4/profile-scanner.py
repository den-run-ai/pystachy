"""Separate instruction and GC/RSS diagnostics; never use their wall times."""
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "scanner-profile"
BINARIES = {
    "base": ROOT / "scan-base-final",
    "candidate": ROOT / "scan-candidate-final",
    "integer_fix": ROOT / "scan-integer-base",
    "integrated": ROOT / "scan-integrated",
}


def clean_env():
    env = {k: v for k, v in os.environ.items()
           if not k.startswith("PYSTACHY_") and k != "PYTHONPATH"}
    env["PYSTACHY_GC"] = "stats"
    return env


def child():
    # Each child wrapper starts with fresh RUSAGE_CHILDREN counters.
    variant, mode, name, size, count = sys.argv[2:]
    command = [str(BINARIES[variant]), mode, name, size, count, "0", "1"]
    run = subprocess.run(command, env=clean_env(), text=True, capture_output=True,
                         check=True)
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    print(json.dumps({"variant": variant, "mode": mode, "case": name,
                      "size": int(size), "count": int(count), "command": command,
                      "stdout": run.stdout, "stderr": run.stderr,
                      "max_rss_kib": usage.ru_maxrss, "returncode": run.returncode}))


def main():
    OUT.mkdir(exist_ok=True)
    records = {"created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               "memory": [], "instructions": [],
               "note": "Separate instrumented diagnostics. Wall times are not performance evidence."}
    for variant in BINARIES:
        for mode, name, size, count in [
            ("direct", "long", 4096, 2000),
            ("direct", "long", 16384, 2000),
            ("repair", "long", 8192, 2000),
            ("direct", "dense", 8192, 300),
        ]:
            command = [sys.executable, __file__, "child", variant, mode, name,
                       str(size), str(count)]
            run = subprocess.run(command, text=True, capture_output=True, check=True)
            records["memory"].append(json.loads(run.stdout))
    for variant, mode, name, count in [
        (variant, mode, name, count)
        for variant in ("base", "candidate")
        for mode, name, count in [("direct", "long", 1000),
                                  ("repair", "long", 1000),
                                  ("direct", "short", 20000),
                                  ("repair", "mixed", 4000)]
    ] + [("integer_fix", "direct", "dense", 100),
         ("integrated", "direct", "dense", 100)]:
        tag = f"{variant}-{mode}-{name}"
        output = OUT / (tag + ".callgrind")
        command = ["valgrind", "--tool=callgrind", "--collect-atstart=no",
                   "--toggle-collect=f.batch", "--callgrind-out-file=" + str(output),
                   str(BINARIES[variant]), mode, name, "8192", str(count), "0", "1"]
        env = clean_env()
        env.pop("PYSTACHY_GC")
        run = subprocess.run(command, env=env, text=True, capture_output=True,
                             timeout=180, check=True)
        (OUT / (tag + ".stdout")).write_text(run.stdout)
        (OUT / (tag + ".stderr")).write_text(run.stderr)
        totals = [int(line.split()[1]) for line in output.read_text().splitlines()
                  if line.startswith("totals:")]
        if not totals:
            raise RuntimeError("callgrind omitted instruction totals")
        records["instructions"].append({"variant": variant, "mode": mode, "case": name,
                                         "size": 8192, "calls_per_batch": count,
                                         "collected_batches": 2,
                                         "instructions": sum(totals), "command": command,
                                         "raw_file": output.name})
        print(tag, sum(totals), flush=True)
    records["status"] = "complete"
    (OUT / "results.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "child":
        child()
    else:
        main()
