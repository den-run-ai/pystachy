import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import statistics
import subprocess
import time

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--plan', required=True)
parser.add_argument('--output', required=True)
parser.add_argument('--processes', type=int, default=5)
args = parser.parse_args()
plan = json.loads(Path(args.plan).read_text())
report = {'plan': plan, 'processes': args.processes, 'cpu': 0,
          'created_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'runs': []}
for process in range(args.processes):
    variants = plan[process % len(plan):] + plan[:process % len(plan)]
    for variant in variants:
        env = os.environ.copy()
        for key in list(env):
            if key.startswith('PYSTACHY_') or key == 'PYTHONPATH':
                env.pop(key)
        env.update(variant.get('env', {}))
        command = ['taskset', '-c', '0'] + variant['command']
        start = time.perf_counter()
        run = subprocess.run(command, cwd=variant.get('cwd', str(ROOT)), env=env,
                             text=True, capture_output=True, timeout=180)
        record = {'variant': variant['name'], 'process': process, 'command': command,
                  'wall_s': time.perf_counter() - start, 'returncode': run.returncode,
                  'stdout': run.stdout, 'stderr': run.stderr, 'cases': []}
        report['runs'].append(record)
        Path(args.output).write_text(json.dumps(report, indent=2) + '\n')
        if run.returncode:
            raise RuntimeError(f"{variant['name']}: {run.stderr[-2000:]}")
        case = None
        for line in run.stdout.splitlines():
            row = line.split()
            if row[0] == 'case':
                case = {'api': row[1], 'name': row[2], 'size': int(row[3]),
                        'characters': int(row[4]), 'bytes': int(row[5]), 'calls': int(row[6]),
                        'samples_ns': [], 'verified': False}
                record['cases'].append(case)
            elif row[0] == 'first':
                case['first_ns'] = int(row[2])
                case['checksum'] = int(row[1])
            elif row[0] == 'sample':
                assert int(row[1]) == case['checksum']
                case['samples_ns'].append(int(row[2]))
            elif row[0] == 'verified':
                assert int(row[1]) * case['calls'] == case['checksum']
                case['verified'] = True
        assert len(record['cases']) == variant.get('cases', 18)
        for case in record['cases']:
            assert case['verified'] and len(case['samples_ns']) == 7
            case['median_ns'] = statistics.median(case['samples_ns'])
        Path(args.output).write_text(json.dumps(report, indent=2) + '\n')
        print(variant['name'], process, f"{record['wall_s']:.3f}s", flush=True)
summary = []
for variant in plan:
    runs = [r for r in report['runs'] if r['variant'] == variant['name']]
    for index, case in enumerate(runs[0]['cases']):
        medians = [r['cases'][index]['median_ns'] for r in runs]
        summary.append({'variant': variant['name'], 'api': case['api'], 'name': case['name'],
                        'size': case['size'], 'calls': case['calls'],
                        'median_ns': statistics.median(medians),
                        'min_process_ns': min(medians), 'max_process_ns': max(medians),
                        'process_medians_ns': medians})
report['summary'] = summary
report['status'] = 'complete'
Path(args.output).write_text(json.dumps(report, indent=2) + '\n')
