from pathlib import Path
import collections,json,re,sys
out=Path('/tmp/scanner-irsame')
t=Path(sys.argv[1]) if len(sys.argv)>1 else Path((out/'output-directory').read_text().strip())
old_prefix='/workspace/scratch/7d119a0ee86b/pystachy-base'
new_prefix='/workspace/scratch/7d119a0ee86b/pystachy'
canonical='/PYSTACHY_HOME'
string=re.compile(r'^(.*\{i64, i64, i64, \[)(\d+)( x i8\]\} \{i64 )(\d+)(, i64 )(\d+)(, i64 )(\d+)(, \[)(\d+)( x i8\] c".*)$')
def normline(line,prefix):
    count=line.count(prefix)
    if not count:return line
    delta=count*(len(canonical)-len(prefix))
    line=line.replace(prefix,canonical)
    match=string.match(line)
    if match:
        g=list(match.groups())
        for index in [1,3,7,9]:
            value=int(g[index])
            if index==7 and value==0:continue
            g[index]=str(value+delta)
        return ''.join(g)
    return line
counts=collections.Counter();rows=[]
for case in sorted(t.iterdir(),key=lambda p:int(p.name) if p.name.isdecimal() else -1):
    if not (case/'statuses').exists():continue
    old,new=map(int,(case/'statuses').read_text().split())
    source=(case/'source').read_text().strip()
    row={'case':case.name,'source':source,'old_status':old,'new_status':new}
    counts[f'status_{old}_{new}']+=1
    a=(case/'old.msg').read_text();b=(case/'new.msg').read_text()
    if a==b:row['messages']='identical'
    elif a.replace(old_prefix+'/lib/',canonical+'/lib/')==b.replace(new_prefix+'/lib/',canonical+'/lib/'):row['messages']='installation-prefix-only'
    else:row['messages']='changed'
    counts['messages_'+row['messages']]+=1
    if (case/'ir.diff').exists():
        lines=(case/'ir.diff').read_text().splitlines()
        removed=[x[1:] for x in lines if x.startswith('-') and not x.startswith('---')]
        added=[x[1:] for x in lines if x.startswith('+') and not x.startswith('+++')]
        path_only=(len(removed)==len(added) and bool(removed)
                   and all(old_prefix in x for x in removed) and all(new_prefix in x for x in added)
                   and [normline(x,old_prefix) for x in removed]==[normline(x,new_prefix) for x in added])
        row['ir']='installation-prefix-and-string-length-only' if path_only else 'changed'
        row['scanner_in_diff']=any('pys_bytes_scan' in x or '_pystachy_bytescan' in x for x in lines)
    else:row['ir']='no-diff-retained'
    counts['ir_'+row['ir']]+=1
    if old==0 and new!=0:row['new_rejection']=True
    rows.append(row)
summary={'directory':str(t),'completed':len(rows),'counts':dict(counts),'new_rejections':[r for r in rows if r.get('new_rejection')],'newly_accepted':[r for r in rows if r['old_status']!=0 and r['new_status']==0],'changed_messages':[r for r in rows if r['messages']=='changed'],'meaningful_ir_changes':[r for r in rows if r['ir']=='changed'],'classification':'Only demonstrated old/new lib installation prefixes and the sys.prefix installation-home constants are normalized. For changed IR globals containing those prefixes, array lengths, byte length and populated character-count cache lengths are adjusted by the exact ASCII prefix byte difference; no other IR or diagnostics are normalized.'}
(t/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(t/'cases.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['changed_messages','meaningful_ir_changes','newly_accepted']},indent=2))
print('Meaningful IR:',[r['source'] for r in summary['meaningful_ir_changes']])
print('Changed diagnostics:',[r['source'] for r in summary['changed_messages']])
print('Newly accepted:',[r['source'] for r in summary['newly_accepted']])
