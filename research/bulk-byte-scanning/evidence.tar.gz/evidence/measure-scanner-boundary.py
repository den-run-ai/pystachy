"""Run only with explicit timing clearance: --execute. No source/build mutations."""
import argparse
import datetime
import hashlib
import json
import os
import platform
import statistics
import subprocess
import time
from pathlib import Path

ROOT = Path('/workspace/scratch/7d119a0ee86b')
GROUPS = [('base_aot', 'candidate_aot'), ('base_jit', 'candidate_jit'),
          ('integer_fix_aot', 'integrated_aot'), ('cpython', 'pypy')]
FOCUSED = [
    ('jit_repair_short', ('base_jit', 'candidate_jit'), ['repair', 'short', '8192', '1000000', '4', '9']),
    ('jit_repair_mixed', ('base_jit', 'candidate_jit'), ['repair', 'mixed', '8192', '200000', '4', '9']),
    ('integrated_aot_direct_dense', ('integer_fix_aot', 'integrated_aot'), ['direct', 'dense', '8192', '1500', '4', '9']),
]
SOURCE_DIRS = ['src', 'lib', 'ports', 'bench', 'ryu', 'mpz']
ROOT_SOURCES = ['runtime.c', 'runtime.py', 'pystachy.py', 'pyembed.c', 'pyext.c',
                'Makefile', 'VERSION', '.python-version']
SUFFIXES = {'.py', '.c', '.h', '.inc'}
EXPECTED_DRIVER = 'ac0342aa4d8a779c2b14d49184bebb542337dab69cbeb98aebf3d5f0a3da009e'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(root, *args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()


def source_manifest(root):
    root = Path(root)
    paths = subprocess.check_output(['rg', '--files', '--hidden', '--no-ignore', *SOURCE_DIRS],
                                    cwd=root, text=True).splitlines()
    paths = [p for p in paths if Path(p).suffix in SUFFIXES]
    paths += [p for p in ROOT_SOURCES if (root / p).is_file()]
    hashes = {p: digest(root / p) for p in sorted(set(paths))}
    encoded = json.dumps(hashes, sort_keys=True, separators=(',', ':')).encode()
    return {'root': str(root), 'commit': git(root, 'rev-parse', 'HEAD'),
            'tree': git(root, 'rev-parse', 'HEAD^{tree}'),
            'status': git(root, 'status', '--porcelain=v1', '--untracked-files=all'),
            'hashes': hashes, 'manifest_sha256': hashlib.sha256(encoded).hexdigest()}


def cache_manifest(plan):
    records = {}
    for variant in plan:
        cache = variant.get('env', {}).get('PYSTACHY_CACHE')
        if cache and Path(cache).is_dir():
            records[cache] = {p.name: digest(p) for p in sorted(Path(cache).iterdir())
                              if p.is_file()}
    return records


def expected_cases(command):
    api, name, size, count, warmups, samples = command[-6:]
    size, count, warmups, samples = map(int, (size, count, warmups, samples))
    if api != 'suite':
        return [(api, name, size, count)], warmups, samples
    if name not in ('all', 'no-direct-control'):
        raise ValueError('unrecognized suite selection')
    result = []
    for mode in ('direct', 'repair'):
        result.extend((mode, 'long', size * factor, count * 2000) for factor in (1, 2, 4))
        for case, calls in [('short', 200000), ('mixed', 40000), ('sparse', 3000),
                            ('dense', 300), ('unicode', 300), ('control', 300)]:
            if mode == 'direct' and case == 'control' and name == 'no-direct-control':
                continue
            if mode == 'repair' and case == 'control':
                calls = 100
            result.append((mode, case, 8192, count * calls))
    return result, warmups, samples


def shape(api, name, size):
    if name == 'long':
        return size + 8, size + 8, size
    if name == 'short':
        return 16, 16, 8
    if name == 'mixed':
        return 64, 64, 5
    if name == 'sparse':
        return size // 4 * 4 + 20, size // 4 * 4 + 20, size // 4 * 4 + 8
    if name == 'dense':
        return size + size // 3 + 8, size + size // 3 + 8, size
    if name == 'unicode':
        return size + 8, (size // 4) * 10 + (size % 4) * 2 + 8, size
    if name == 'control':
        return size + 8, size + 8, size + 5 if api == 'direct' else size
    raise ValueError(name)


def parse_output(stdout, command):
    expected, warmups, samples = expected_cases(command)
    rows = stdout.splitlines()
    tags = ['case', 'first'] + ['warmup'] * warmups + ['sample'] * samples + ['verified']
    if len(rows) != len(expected) * len(tags):
        raise ValueError('missing/extra benchmark output rows')
    cases = []
    for index, (api, name, size, count) in enumerate(expected):
        chunk = [line.split() for line in rows[index * len(tags):(index + 1) * len(tags)]]
        if [r[0] for r in chunk] != tags:
            raise ValueError('benchmark output order mismatch')
        chars, encoded_bytes, per_call = shape(api, name, size)
        header = ['case', api, name, str(size), str(chars), str(encoded_bytes), str(count)]
        if chunk[0] != header or chunk[-1] != ['verified', str(per_call)]:
            raise ValueError(f'case/oracle mismatch: {chunk[0]}')
        checksum = count * per_call
        for row in chunk[1:-1]:
            if len(row) != (2 if row[0] == 'warmup' else 3) or int(row[1]) != checksum:
                raise ValueError('checksum/row shape mismatch')
            if row[0] != 'warmup' and int(row[2]) <= 0:
                raise ValueError('nonpositive timing')
        sample_times = [int(row[2]) for row in chunk if row[0] == 'sample']
        cases.append({'api': api, 'name': name, 'size': size, 'calls': count,
                      'characters': chars, 'bytes': encoded_bytes, 'checksum': checksum,
                      'first_ns': int(chunk[1][2]), 'samples_ns': sample_times,
                      'median_ns': statistics.median(sample_times), 'verified': True})
    return cases


def summary(runs):
    grouped = {}
    for run in runs:
        for case in run['cases']:
            key = (run['variant'], case['api'], case['name'], case['size'], case['calls'])
            grouped.setdefault(key, []).append((run['process'], case['median_ns']))
    rows = []
    for (variant, api, name, size, calls), values in grouped.items():
        medians = [value for _, value in sorted(values)]
        rows.append({'variant': variant, 'api': api, 'name': name, 'size': size,
                     'calls': calls, 'median_ns': statistics.median(medians),
                     'min_process_ns': min(medians), 'max_process_ns': max(medians),
                     'process_medians_ns': medians})
    comparisons = []
    for base, candidate in GROUPS[:3]:
        for before in [r for r in rows if r['variant'] == base]:
            key = tuple(before[k] for k in ('api', 'name', 'size', 'calls'))
            after = next(r for r in rows if r['variant'] == candidate and
                         tuple(r[k] for k in ('api', 'name', 'size', 'calls')) == key)
            deltas = [c / b - 1 for b, c in zip(before['process_medians_ns'], after['process_medians_ns'], strict=True)]
            comparisons.append({'base': base, 'candidate': candidate,
                                **{k: before[k] for k in ('api', 'name', 'size', 'calls')},
                                'ratio_of_medians': after['median_ns'] / before['median_ns'],
                                'median_paired_delta': statistics.median(deltas),
                                'paired_deltas': deltas, 'pairs_slower': sum(x > 0 for x in deltas)})
    return rows, comparisons


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--campaign', choices=('full', 'focused'), default='full')
    parser.add_argument('--processes', type=int)
    parser.add_argument('--cpu', type=int, default=0)
    parser.add_argument('--published-head', required=True)
    parser.add_argument('--expected-tree', required=True)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    plan = json.loads(Path(args.plan).read_text())
    variants = {r['name']: r for r in plan}
    if set(variants) != {n for group in GROUPS for n in group}:
        raise ValueError('plan must contain all eight distinct variants')
    if not args.execute:
        print('Plan parsed. No benchmark executed; timing clearance requires --execute.')
        return
    output = Path(args.output)
    if output.exists():
        raise FileExistsError('refusing to overwrite retained evidence: ' + str(output))
    candidate_root = Path(variants['candidate_jit']['source_root'])
    if git(candidate_root, 'rev-parse', 'HEAD^{tree}') != args.expected_tree:
        raise ValueError('candidate tree differs from the published tree')
    driver = candidate_root / 'bench/extended/json_scan.py'
    if digest(driver) != EXPECTED_DRIVER:
        raise ValueError('benchmark source differs from the reviewed driver')
    processes = args.processes or (5 if args.campaign == 'full' else 7)
    roots = sorted({r['source_root'] for r in plan})
    before_sources = {root: source_manifest(root) for root in roots}
    for root, manifest in before_sources.items():
        if root == str(candidate_root) and git(root, 'diff', '--name-only', 'HEAD', '--', *manifest['hashes']):
            raise ValueError('candidate sources differ from their published tree')
    binaries = {r['command'][0]: digest(r['command'][0]) for r in plan}
    report = {'created_utc': datetime.datetime.now(datetime.UTC).isoformat(),
              'published_head': args.published_head, 'expected_tree': args.expected_tree,
              'plan': plan, 'campaign': args.campaign, 'processes': processes,
              'cpu': args.cpu, 'controller_sha256': digest(__file__),
              'platform': platform.uname()._asdict(), 'logical_cpus': os.cpu_count(),
              'parent_affinity': sorted(os.sched_getaffinity(0)),
              'environment': {k: os.environ.get(k) for k in ('LANG', 'LC_ALL', 'PYTHONHASHSEED')},
              'versions': {name: subprocess.check_output([variants[name]['command'][0], '--version'], text=True).strip()
                           for name in ('cpython', 'pypy')},
              'llvm_versions': {name: subprocess.check_output(['/usr/lib/llvm-18/bin/' + name, '--version'], text=True).strip()
                                for name in ('clang', 'opt', 'lli', 'llvm-link', 'llvm-as')},
              'driver_sha256': EXPECTED_DRIVER, 'executable_sha256': binaries,
              'sources_before': before_sources, 'cache_before': cache_manifest(plan),
              'runs': [], 'status': 'running'}

    def save():
        temporary = output.with_suffix('.writing')
        temporary.write_text(json.dumps(report, indent=2) + '\n')
        temporary.replace(output)

    jobs = []
    for process in range(processes):
        if args.campaign == 'full':
            ordered = GROUPS[process % len(GROUPS):] + GROUPS[:process % len(GROUPS)]
            for group in ordered:
                for name in group if process % 2 == 0 else reversed(group):
                    jobs.append((process, name, variants[name]['command'], 'full'))
        else:
            ordered = FOCUSED[process % len(FOCUSED):] + FOCUSED[:process % len(FOCUSED)]
            for case_id, group, suffix in ordered:
                for name in group if process % 2 == 0 else reversed(group):
                    jobs.append((process, name, variants[name]['command'][:-6] + suffix, case_id))
    save()
    campaign_start = time.perf_counter()
    try:
        for index, (process, name, command, case_id) in enumerate(jobs, 1):
            variant = variants[name]
            env = {k: v for k, v in os.environ.items()
                   if not k.startswith('PYSTACHY_') and k != 'PYTHONPATH'}
            env.update(variant.get('env', {}))
            command = ['taskset', '-c', str(args.cpu)] + command
            cwd = variant.get('cwd', str(ROOT))
            print(f'START {index}/{len(jobs)} round={process + 1}/{processes} {name} {case_id}', flush=True)
            start = time.perf_counter()
            run = subprocess.run(command, cwd=cwd, env=env, text=True,
                                 capture_output=True, timeout=180, check=False)
            record = {'variant': name, 'process': process, 'case_group': case_id,
                      'command': command, 'cwd': cwd, 'env': variant.get('env', {}),
                      'wall_s': time.perf_counter() - start, 'returncode': run.returncode,
                      'stdout': run.stdout, 'stderr': run.stderr, 'cases': []}
            report['runs'].append(record)
            save()
            if run.returncode:
                raise RuntimeError(f'{name}: exit {run.returncode}: {run.stderr[-2000:]}')
            record['cases'] = parse_output(run.stdout, command)
            save()
            print(f'PASS {index}/{len(jobs)} {name}: {len(record["cases"])} verified cases, '
                  f'{record["wall_s"]:.2f}s wall, campaign {time.perf_counter()-campaign_start:.1f}s', flush=True)
        report['sources_after'] = {root: source_manifest(root) for root in roots}
        report['cache_after'] = cache_manifest(plan)
        report['executable_sha256_after'] = {p: digest(p) for p in binaries}
        if report['executable_sha256_after'] != binaries:
            raise RuntimeError('a measured executable changed during the campaign')
        for root in roots:
            if report['sources_after'][root]['hashes'] != before_sources[root]['hashes']:
                raise RuntimeError('source files changed during the campaign: ' + root)
        report['summary'], report['comparisons'] = summary(report['runs'])
        report['wall_s'] = time.perf_counter() - campaign_start
        report['status'] = 'complete'
        save()
        print(f'COMPLETE: {len(jobs)} runs, {len(report["summary"])} summaries, {report["wall_s"]:.1f}s', flush=True)
    except BaseException as exc:
        report['status'] = 'failed'
        report['failure'] = repr(exc)
        save()
        raise


if __name__ == '__main__':
    main()
