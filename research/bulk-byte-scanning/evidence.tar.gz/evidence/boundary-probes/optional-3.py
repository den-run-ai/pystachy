# pystachy: dynamic-any
from _pystachy_bytescan import scan
def maybe(ok: bool) -> int | None:
    return 0 if ok else None
print(scan(b"abc", 0, maybe(False), 34, 92, 32))
