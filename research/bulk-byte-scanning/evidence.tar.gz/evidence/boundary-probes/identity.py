# pystachy: dynamic-any
from _pystachy_bytescan import scan
from typing import Any, Callable


def run() -> None:
    end = int("1000")
    start = int("1000")
    data = b"x" * 1000
    direct: Any = scan(data, 0, end, 34, 92, 32)
    keyword: Any = scan(data=data, start=0, end=end, first=34, second=92, below=32)
    through: Callable[[bytes, int, int, int, int, int], int] = scan
    called: Any = through(data, 0, end, 34, 92, 32)
    print("end", direct, direct is end, keyword is end, called is end)
    data = data + b'"'
    direct = scan(data, start, 1001, 34, 92, 32)
    keyword = scan(data=data, start=start, end=1001, first=34, second=92, below=32)
    called = through(data, start, 1001, 34, 92, 32)
    print("start", direct, direct is start, keyword is start, called is start)
    middle = int("500")
    direct = scan(b"x" * 500 + b'"' + b"x" * 499, 0, end, 34, 92, 32)
    print("middle", direct, direct is middle, direct is end)


run()
