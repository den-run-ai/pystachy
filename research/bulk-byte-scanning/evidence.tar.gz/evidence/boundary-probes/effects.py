# pystachy: dynamic-any
from _pystachy_bytescan import scan
from typing import Any

events: list[str] = []
global_start = int("1000")


class Positions:
    def __init__(self, start: int) -> None:
        self.start = start


def number(name: str, value: int) -> int:
    events.append(name)
    return value


def data_arg() -> bytes:
    events.append("data")
    return b"x" * 1000 + b'"'


def reset_global() -> int:
    global global_start
    events.append("global")
    global_start = 0
    return 1001


def reset_field(positions: Positions) -> int:
    events.append("field")
    positions.start = 0
    return 1001


def reset_list(positions: list[int]) -> int:
    events.append("list")
    positions[0] = 0
    return 1001


def throwing(name: str) -> int:
    events.append(name)
    raise RuntimeError("argument failed")


def run() -> None:
    data = b"x" * 1000 + b'"'
    start = int("1000")
    saved: Any = None
    result = scan(data, (saved := start), 1001, 34, 92, 32)
    print("walrus", result, saved is start)
    original: Any = start
    result = scan(data, start, 1001, 34, 92, 32)
    print("local-alias", result, original is start)

    result = scan(data, global_start, reset_global(), 34, 92, 32)
    print("global-snapshot", result, global_start)
    positions = Positions(start)
    field_alias: Any = positions.start
    result = scan(data, positions.start, reset_field(positions), 34, 92, 32)
    print("field-snapshot", result, positions.start, field_alias is start)
    items = [start]
    item_alias: Any = items[0]
    result = scan(data, items[0], reset_list(items), 34, 92, 32)
    print("list-snapshot", result, items[0], item_alias is start)

    events.clear()
    result = scan(data_arg(), number("start", 0), number("end", 1001),
                  number("first", 34), number("second", 92), number("below", 32))
    print("argument-order", result, events)
    events.clear()
    try:
        scan(data_arg(), number("start", -1), number("end", 1001),
             number("first", -1), throwing("second"), number("below", 257))
        print("missed-argument-error")
    except RuntimeError as exc:
        print("argument-before-validation", exc, events)
    events.clear()
    try:
        scan(data_arg(), number("start", -1), number("end", 1001),
             number("first", -1), number("second", 92), number("below", 257))
        print("missed-bounds-error")
    except IndexError as exc:
        print("validation-after-arguments", exc, events)


run()
