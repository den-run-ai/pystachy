# pystachy: dynamic-any
from _pystachy_bytescan import scan
def maybe(ok: bool) -> bytes | None:
    return b"abc" if ok else None
print(scan(maybe(False), 0, 3, 34, 92, 32))
