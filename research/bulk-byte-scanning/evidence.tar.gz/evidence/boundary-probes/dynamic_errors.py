# pystachy: dynamic-any
from _pystachy_bytescan import scan
from typing import Any

events: list[str] = []


def dynamic_number(value: int) -> Any:
    if value < 0:
        return None
    return value


def later() -> int:
    events.append("later")
    return 3


def run() -> None:
    for item in [2, -1]:
        events.clear()
        try:
            value = scan(b"abc", dynamic_number(item), later(), 34, 92, 32)
            print("dynamic-start", value, events)
        except TypeError as exc:
            print("dynamic-start", exc, events)
    for item in [3, -1]:
        events.clear()
        try:
            value = scan(b"abc", 0, dynamic_number(item), later(), 92, 32)
            print("dynamic-end", value, events)
        except TypeError as exc:
            print("dynamic-end", exc, events)


run()
