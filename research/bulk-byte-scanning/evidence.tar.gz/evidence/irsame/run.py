from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

OUT = Path(__file__).parent
ROOT = Path('/workspace/scratch/7d119a0ee86b/pystachy')
BASE = Path('/workspace/scratch/7d119a0ee86b/pystachy-base')
EXPECTED_TREE = 'd8391c0c9af4e189634bb6d495de85c5b23cc167'
OLD_CANDIDATE_BINARY = '9d070842664c9bb228b4598772d6161d83d0e2926dc41a35948f9acf2d860fd6'


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identities():
    files = [ROOT/'pystachy', BASE/'pystachy', ROOT/'lib/json.py',
             ROOT/'lib/_pystachy_bytescan.py', ROOT/'runtime.c',
             ROOT/'src/pystachy_compiler/calls.py', ROOT/'src/pystachy_compiler/specs.py',
             ROOT/'tests/programs/inference/dynany_bytescan.py',
             ROOT/'tests/programs/inference/dynany_bytescan.out',
             ROOT/'tests/programs/inference/dynany_bytescan.path']
    return {str(path): digest(path) for path in files}


tree = git(ROOT, 'rev-parse', 'HEAD^{tree}')
assert tree == EXPECTED_TREE, (tree, EXPECTED_TREE)
before = identities()
assert before[str(ROOT/'pystachy')] != OLD_CANDIDATE_BINARY, 'Native compiler is still the previous c46 build'
corpus = ['pystachy.py', 'runtime.py']
for pattern in ['tests/programs/*/*.py', 'tests/deviations/*.py', 'bench/*.py',
                'bench/pyperformance/*.py', 'tests/ir/*.py', 'tests/errors/*/*.py']:
    corpus.extend(str(path.relative_to(ROOT)) for path in sorted(ROOT.glob(pattern)))
assert len(corpus) == 3909, len(corpus)
(OUT/'corpus.txt').write_text('\n'.join(corpus) + '\n')
metadata = {'started_epoch': time.time(), 'candidate_commit': git(ROOT, 'rev-parse', 'HEAD'),
            'candidate_tree': tree, 'published_head': 'd056aafe2f0c09d72ca23bf14b18123d1e439170',
            'base_commit': git(BASE, 'rev-parse', 'HEAD'), 'case_count': len(corpus),
            'workers': 8, 'source_hashes': before}
(OUT/'source-identity.json').write_text(json.dumps(metadata, indent=2) + '\n')
command = [str(OUT/'irsame.sh'), '/tmp/scanner-irsame/old-compiler', '/tmp/scanner-irsame/new-compiler']
env = dict(os.environ, PYSTACHY_JOBS='8', PYSTACHY_LLVM='/usr/lib/llvm-18/bin', TMPDIR=str(OUT))
start = time.monotonic()
with (OUT/'run.log').open('w') as log:
    proc = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    (OUT/'process.json').write_text(json.dumps({'pid': proc.pid, 'pgid': proc.pid, 'command': command}) + '\n')
    print('irsame process', proc.pid, flush=True)
    status = proc.wait()
after = identities()
metadata.update({'elapsed_seconds': time.monotonic() - start, 'harness_exit': status,
                 'finished_epoch': time.time(), 'source_and_binary_hashes_unchanged': before == after,
                 'after_hashes': after})
(OUT/'source-identity.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps({k: metadata[k] for k in ['elapsed_seconds', 'harness_exit', 'source_and_binary_hashes_unchanged']}, indent=2), flush=True)
assert before == after, 'Inputs changed during comparison'
directory = Path((OUT/'output-directory').read_text().strip())
subprocess.run(['python3', '/tmp/scanner-irsame/summarize.py', str(directory)], check=True)
