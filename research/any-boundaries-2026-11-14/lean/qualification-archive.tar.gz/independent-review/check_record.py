import json,sys
from pathlib import Path
sys.path.insert(0,sys.argv[1])
import check_lean_storage as s
snapshot=json.load(open(sys.argv[2]))
report,status=s.check_all(snapshot,Path(sys.argv[3]))
print(json.dumps({'status_code':status,'report':report},indent=2))
