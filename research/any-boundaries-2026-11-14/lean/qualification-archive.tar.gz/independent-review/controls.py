"""Independent mutations of the actual failing numeric-generator IR record."""
import copy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, "/workspace/scratch/6e931c3f8732/lean-combined/tools")
import check_lean_storage as storage
import check_lean_boundary as boundary

identity = json.loads((ROOT / "identity.json").read_text())
snapshot = json.loads(Path(identity["snapshot"]).read_text())
fresh = next(fn for fn in snapshot["functions"] if fn["symbol"] == "@f.fresh.1")


def checked(fn):
    candidate, metadata = storage.Normalize(fn).build()
    ok = boundary.run_checker(Path(identity["checker"]), boundary.encode(candidate), metadata)
    return {"accepted": ok, "obligations": metadata["obligations"]}


def first_yield(fn):
    return next(op for block in fn["blocks"] for op in block["operations"] if op["op"] == "gen.yield")


results = {"actual_fresh": checked(fresh)}
assert results["actual_fresh"] == {"accepted": True, "obligations": 0}
for kind in ("null_high", "wrong_first_type", "wrong_second_type", "wrong_third_type", "extra_fourth", "tainted_third", "third_on_return"):
    fn = copy.deepcopy(fresh)
    op = first_yield(fn)
    if kind == "null_high":
        op["operands"][1]["value"] = "null"
    elif kind.startswith("wrong_"):
        index = {"wrong_first_type": 0, "wrong_second_type": 1, "wrong_third_type": 2}[kind]
        op["operands"][index]["type"] = "int"
    elif kind == "extra_fourth":
        op["operands"].append({"value": "null", "type": "dyn"})
    elif kind == "tainted_third":
        block = next(b for b in fn["blocks"] if op in b["operations"])
        cast = {"op": "scalar.cast", "type": "dyn", "text": "inttoptr", "immediate": 0, "descriptor": "",
                "results": [16], "operands": [{"value": op["operands"][0]["value"], "type": "int"}], "targets": []}
        block["operations"].insert(block["operations"].index(op), cast)
        op["operands"][2]["value"] = "%t16"
    else:
        lastyield = [o for b in fn["blocks"] for o in b["operations"] if o["op"] == "gen.yield"][-1]
        ret = next(o for b in fn["blocks"] for o in b["operations"] if o["op"] == "gen.ret")
        ret["operands"] = copy.deepcopy(lastyield["operands"])
    results[kind] = checked(fn)
    assert results[kind] == {"accepted": False, "obligations": 1}, (kind, results[kind])
(ROOT / "controls.json").write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(results, indent=2))
