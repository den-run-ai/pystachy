from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

ROOT = Path('/workspace/scratch/6e931c3f8732/lean-combined')
OUT = Path('/workspace/scratch/6e931c3f8732/lean-evidence-final')
PREVIOUS = OUT.parent / 'lean-evidence'
PY = '/workspace/scratch/c2b093657c17/dev-venv/bin/python'
ENV = os.environ.copy()
ENV['PATH'] = '/workspace/scratch/c2b093657c17/dev-venv/bin:/workspace/scratch/c2b093657c17/toolchains/lean-4.35.0-linux/bin:' + ENV['PATH']
ENV['PYSTACHY_LLVM'] = '/workspace/scratch/c2b093657c17/toolchains/llvm18/payload/usr/lib/llvm-18/bin'
ENV['LEAN_NUM_THREADS'] = '1'
ENV['MAKEFLAGS'] = '-j1'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


assert not git('status', '--porcelain'), 'Qualification requires a clean source checkout'
source = git('rev-parse', 'HEAD')
tree = git('rev-parse', 'HEAD^{tree}')
inputs = json.loads((PREVIOUS / 'inputs.json').read_text())
inputs.update(commit=source, tree=tree)
assert all(sha(Path(p)) == digest for p, digest in inputs['external_inputs'].items())
write('inputs.json', inputs)
tracked = git('ls-files', '-z').split('\0')
files = {}
for p in tracked:
    if p in ('AGENTS.md', 'Makefile', '.python-version') or p.startswith(('src/', 'lib/')) or (p.startswith('tools/') and Path(p).suffix in ('.py', '.lean', '.toml', '.json')) or (p.startswith('tests/') and Path(p).suffix in ('.py', '.path')):
        if (ROOT / p).is_file():
            files[p] = sha(ROOT / p)
checkers = {str(p.relative_to(ROOT)): sha(p) for p in sorted((ROOT / 'tools/lean_boundary/.lake/build/bin').glob('*')) if p.is_file() and os.access(p, os.X_OK)}
write('source-manifest.json', {'source_commit': source, 'source_tree': tree, 'files_sha256': files, 'native_checker_sha256': checkers})
inventory_command = [PY, 'tools/check_lean_storage_corpus.py', '--list']
inventory = subprocess.check_output(inventory_command, cwd=ROOT, env=ENV, text=True)
(OUT / 'storage-programs.txt').write_text(inventory)
storage_programs = inventory.splitlines()
assert len(storage_programs) == 178, len(storage_programs)
summary = {'source_commit': source, 'source_tree': tree, 'status': 'running', 'toolchain': {'python': PY, 'lean': '4.35.0', 'llvm': '18.1.3'}, 'units': {'status': 'pending'}, 'focused_report': {'status': 'pending', 'programs': len(inputs['programs'])}, 'storage_corpus': {'status': 'pending', 'programs': len(storage_programs), 'inventory_command': inventory_command}, 'prior_rejection': str(PREVIOUS / 'storage-report.json'), 'scope': 'Full native Lean unit gate; explicit selected 14-case report; full strict 178-program promoting-int storage corpus. Does not replace the exhaustive all-program report.'}
write('run-summary.json', summary)


def run(key, command, log):
    summary[key].update(status='running', command=command, log=log)
    write('run-summary.json', summary)
    started = time.monotonic()
    with (OUT / log).open('w') as handle:
        result = subprocess.run(command, cwd=ROOT, env=ENV, stdout=handle, stderr=subprocess.STDOUT)
    summary[key].update(status='passed' if result.returncode == 0 else 'failed', exit_code=result.returncode, seconds=round(time.monotonic() - started, 2))
    write('run-summary.json', summary)
    print(f'{key}: exit {result.returncode}, {summary[key]["seconds"]} s', flush=True)
    if result.returncode:
        summary['status'] = 'failed'
        write('run-summary.json', summary)
        raise SystemExit(result.returncode)


run('units', ['make', 'check-lean-boundary', 'PY=' + PY], 'units.log')
unit_log = (OUT / 'units.log').read_text()
counts = [int(n) for n in re.findall(r'^Ran (\d+) tests?', unit_log, flags=re.MULTILINE)]
summary['units'].update(groups=len(counts), group_counts=counts, tests=sum(counts), skipped=unit_log.count('skipped='))
assert len(counts) == 17 and sum(counts) == 383 and 'skipped=' not in unit_log, counts
write('run-summary.json', summary)

flags = '--jobs 1 --timeout 120 --progress --output ' + str(OUT / 'selected-report.md') + ' --records ' + str(OUT / 'selected-records.jsonl') + ' ' + ' '.join(inputs['programs'])
run('focused_report', ['make', 'lean-report', 'PY=' + PY, 'LEAN_REPORT_FLAGS=' + flags], 'selected-report.log')
summary['focused_report'].update(report='selected-report.md', records='selected-records.jsonl', external_input_provenance='External consumer inputs are independently SHA256-pinned. The report correctly flags this explicit selected corpus as external and does not claim canonical exhaustive coverage.')
write('run-summary.json', summary)

run('storage_corpus', [PY, 'tools/check_lean_storage_corpus.py', '--jobs', '1', '--timeout', '120', '--progress', '--report', str(OUT / 'storage-report.json')], 'storage.log')
storage = json.loads((OUT / 'storage-report.json').read_text())
summary['storage_corpus'].update(status=storage['status'], totals=storage['totals'], report='storage-report.json')
assert storage['status'] == 'accepted' and storage['totals']['programs'] == 178
assert storage['totals']['obligations'] == storage['totals']['proved_obligations'] and storage['totals']['unclassified_functions'] == 0
assert git('rev-parse', 'HEAD') == source and not git('status', '--porcelain')
assert all(sha(Path(p)) == digest for p, digest in inputs['external_inputs'].items())
summary.update(status='passed', inputs_unchanged_after_run=True)
write('run-summary.json', summary)
print('Final combined Lean qualification passed.', flush=True)
