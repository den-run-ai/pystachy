"""Run the frozen full census; only resume with the maintained identity checks."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
prepared = json.loads((OUT / "prepared.json").read_text())
REPO = Path(prepared["repo"])
PY = Path("/workspace/scratch/c2b093657c17/dev-venv/bin/python")
LLVM = Path("/workspace/scratch/c2b093657c17/toolchains/llvm18/payload/usr/lib/llvm-18")
LEAN = Path("/workspace/scratch/c2b093657c17/toolchains/lean-4.35.0-linux/bin")
resume = "--resume" in sys.argv[1:]
records = OUT / "records.jsonl"
report = OUT / "report.md"
env = {key: value for key, value in os.environ.items()
       if not key.startswith("PYSTACHY_") and key not in ("PYTHONPATH", "PYTHONOPTIMIZE")}
env.update(PATH=":".join([str(PY.parent), str(LLVM / "bin"), str(LEAN), "/usr/local/bin", "/usr/bin", "/bin"]),
           PYSTACHY_LLVM=str(LLVM / "bin"), LD_LIBRARY_PATH=str(LLVM / "lib"),
           PYTHON=str(PY), PYSTACHY_JOBS="1")

def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args], text=True).strip()

def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}

def resource_sample(pid):
    # Read only the maintained report process we started. A sample can inform
    # later diagnosis but does not establish why any process was killed.
    sample = {"utc": datetime.now(timezone.utc).isoformat(), "report_pid": pid}
    try:
        status = Path(f"/proc/{pid}/status").read_text()
        sample["status"] = {line.split(":", 1)[0]: line.split(":", 1)[1].strip()
                            for line in status.splitlines()
                            if line.split(":", 1)[0] in {"State", "VmRSS", "VmHWM", "VmPeak", "Threads"}}
    except OSError as error:
        sample["unavailable"] = str(error)
    return sample

assert git("rev-parse", "HEAD") == prepared["commit"]
assert git("rev-parse", "HEAD^{tree}") == prepared["tree"]
assert not git("status", "--porcelain")
assert records.exists() if resume else not records.exists()
command = [str(PY), "tools/lean_report.py", "--jobs", "1", "--start-method", "spawn", "--timeout", "300",
           "--progress", "--output", str(report), "--records", str(records)]
if resume:
    command.append("--resume")
receipt = {"started_utc": datetime.now(timezone.utc).isoformat(), "commit": prepared["commit"],
           "tree": prepared["tree"], "command": command, "resume": resume, "cwd": str(REPO),
           "source_before": git("status", "--porcelain"), "jobs": 1,
           "runner": identity(Path(__file__)), "preparation": identity(OUT / "prepared.json"),
           "audit_script": identity(OUT / "audit.py")}
stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
receipt_path = OUT / ("run-" + stamp + ".json")
log = OUT / ("run-" + stamp + ".log")
receipt["log"] = str(log)
resource_log = OUT / ("run-" + stamp + "-resources.jsonl")
receipt["resource_samples"] = str(resource_log)
if resume:
    prefix_path = OUT / ("run-" + stamp + "-preserved-prefix.jsonl")
    with prefix_path.open("xb") as prefix:
        prefix.write(records.read_bytes())
    receipt["preserved_prefix"] = identity(prefix_path)
    receipt["preserved_records"] = len(prefix_path.read_bytes().splitlines()) - 1
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt), flush=True)
started = time.monotonic()
with log.open("x") as stream, resource_log.open("x") as samples:
    result = subprocess.Popen(command, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT)
    receipt["report_pid"] = result.pid
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
    while result.poll() is None:
        samples.write(json.dumps(resource_sample(result.pid), sort_keys=True) + "\n")
        samples.flush()
        try:
            result.wait(timeout=30)
        except subprocess.TimeoutExpired:
            pass
    receipt["report_exit"] = result.returncode
    if report.is_file():
        status = subprocess.run([str(PY), "tools/lean_report.py", "--status", "--output", str(report)],
                                cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT)
        receipt["status_exit"] = status.returncode
        audit = subprocess.run([str(PY), str(OUT / "audit.py")], cwd=REPO, env=env,
                               stdout=stream, stderr=subprocess.STDOUT)
        receipt["audit_exit"] = audit.returncode
    else:
        receipt.update(status_exit=None, audit_exit=None,
                       postprocessing_skipped="The primary report process wrote no completed report; preserve its primary exit status without secondary missing-file exceptions.")
receipt.update(seconds=round(time.monotonic() - started, 3),
               child_peak_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
               commit_after=git("rev-parse", "HEAD"), tree_after=git("rev-parse", "HEAD^{tree}"),
               source_after=git("status", "--porcelain"))
receipt["resources"] = identity(resource_log)
receipt["resource_diagnosis_limit"] = "Read-only RSS samples do not attribute a signal or prove an OOM event."
if resume:
    receipt["preserved_prefix_unchanged"] = records.read_bytes().startswith(prefix_path.read_bytes())
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt), flush=True)
success = (receipt.get("report_exit") == receipt.get("status_exit") == receipt.get("audit_exit") == 0
           and receipt["commit_after"] == prepared["commit"] and receipt["tree_after"] == prepared["tree"]
           and not receipt["source_after"] and (not resume or receipt["preserved_prefix_unchanged"]))
raise SystemExit(0 if success else 1)
