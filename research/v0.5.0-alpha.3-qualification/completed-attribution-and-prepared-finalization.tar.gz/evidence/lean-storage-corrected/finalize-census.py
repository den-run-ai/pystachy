"""Freeze the completed final-source census and every same-source attempt receipt."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
prepared = json.loads((OUT / "prepared.json").read_text())
repo = Path(prepared["repo"])
acceptance = json.loads((OUT / "acceptance.json").read_text())
delta = json.loads((OUT / "delta-alpha2.json").read_text())


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def git(*args):
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()


raw = (OUT / "records.jsonl").read_bytes()
lines = [json.loads(line) for line in raw.splitlines()]
header, records = lines[0]["header"], lines[1:]
attempt_paths = sorted(OUT.glob("run-????????T??????Z.json"))
assert attempt_paths, "No owned execution receipt."
attempts = []
prefix_checks = []
for path in attempt_paths:
    attempt = json.loads(path.read_text())
    artifacts = {"receipt": identity(path), "log": identity(Path(attempt["log"]))}
    if attempt.get("resources"):
        artifacts["resources"] = identity(Path(attempt["resources"]["path"]))
        assert artifacts["resources"] == attempt["resources"]
    if attempt.get("resume"):
        prefix = Path(attempt["preserved_prefix"]["path"])
        prefix_raw = prefix.read_bytes()
        prefix_lines = [json.loads(line) for line in prefix_raw.splitlines()]
        prefix_records = prefix_lines[1:]
        passed = (identity(prefix) == attempt["preserved_prefix"]
                  and raw.startswith(prefix_raw) and prefix_raw.endswith(b"\n")
                  and prefix_lines[0]["header"] == header
                  and len(prefix_records) == attempt["preserved_records"]
                  and len({row["program"] for row in prefix_records}) == len(prefix_records)
                  and attempt.get("preserved_prefix_unchanged") is True)
        prefix_checks.append({"receipt": str(path), "prefix": identity(prefix),
                              "records": len(prefix_records), "exact_prefix_preserved": passed})
    attempts.append({"result": attempt, "artifacts": artifacts})
last = attempts[-1]["result"]
checks = {
    "all_final_acceptance_checks_passed": bool(acceptance["checks"]) and all(acceptance["checks"].values()),
    "records_match_acceptance_hash": identity(OUT / "records.jsonl")["sha256"] == acceptance["records_sha256"],
    "report_matches_acceptance_hash": identity(OUT / "report.md")["sha256"] == acceptance["report_sha256"],
    "exact_unique_complete_records": len(records) == len({row["program"] for row in records})
        == prepared["expected_programs"] == 2699,
    "exact_full_corpus_names": {row["program"] for row in records} == set(prepared["programs"]),
    "complete_record_lines": raw.endswith(b"\n"),
    "exact_storage_selection": set(header["promoting"]) == set(prepared["promoting"])
        and len(header["promoting"]) == prepared["expected_promoting"] == 196,
    "source_commit_matches": git("rev-parse", "HEAD") == prepared["commit"] == acceptance["commit"],
    "source_tree_matches": git("rev-parse", "HEAD^{tree}") == prepared["tree"] == acceptance["tree"],
    "source_clean": not git("status", "--porcelain"),
    "first_attempt_fresh": attempts[0]["result"].get("resume") is False,
    "later_attempts_maintained_resume_only": all(a["result"].get("resume") is True for a in attempts[1:]),
    "all_attempts_same_frozen_clean_source": all(
        a["result"].get("commit") == a["result"].get("commit_after") == prepared["commit"]
        and a["result"].get("tree") == a["result"].get("tree_after") == prepared["tree"]
        and a["result"].get("source_before") == a["result"].get("source_after") == ""
        for a in attempts),
    "maintained_one_worker_commands": all(
        a["result"]["command"][1] == "tools/lean_report.py"
        and a["result"]["jobs"] == 1
        and a["result"]["command"][a["result"]["command"].index("--timeout") + 1] == "300"
        for a in attempts),
    "all_same_source_prefixes_preserved": all(p["exact_prefix_preserved"] for p in prefix_checks),
    "last_report_status_and_audit_succeeded": last.get("report_exit") == last.get("status_exit")
        == last.get("audit_exit") == 0,
    "baseline_names_and_storage_selection_retained": delta["missing_programs"] == []
        and delta["storage_selection_delta"]["removed"] == [],
}
result = {
    "schema_version": 1,
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "status": "complete_and_strict_storage_accepted" if all(checks.values()) else "census_or_storage_gate_failed",
    "candidate_commit": prepared["commit"], "candidate_tree": prepared["tree"],
    "checks": checks,
    "programs": len(records), "strict_storage_selections": len(header["promoting"]),
    "known_storage_counts": {key: acceptance["full_proof_totals"]["storage"][key]
                             for key in ("programs", "functions", "obligations", "proved")},
    "storage_gaps": acceptance["storage_gaps"],
    "attempts": attempts, "same_source_prefixes": prefix_checks,
    "prior_checker_records_reused": False,
    "semantic_approval_granted": False,
    "limits": [
        "This receipt attests complete source-bound execution and strict storage. It does not declare all other proof categories fully accepted.",
        "Any rejected or unsupported function remains in the report and separate semantic disposition.",
        "Read-only resource samples do not establish an OOM event or explain any process kill without direct evidence.",
        "Final exact denominator binding and independent semantic review remain separate artifacts/gates.",
    ],
    "evidence": {name: identity(OUT / name) for name in (
        "records.jsonl", "report.md", "acceptance.json", "delta-alpha2.json", "prepared.json",
        "attribution-config.json", "prepare.py", "run.py", "audit.py", "finalize-census.py")},
    "historical_failed_censuses": {
        "original_b0_partial": identity(OUT.parent / "lean/interrupted-partial-census.json"),
        "complete_94f4_strict_storage_failure": identity(OUT.parent / "lean-corrected/complete-blocked-census.json"),
        "94f4_historical_failure_comparison": identity(OUT.parent / "lean-corrected/historical-attempt-comparison.json"),
    },
}
(OUT / "final-census-receipt.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"status": result["status"], "checks": checks,
                  "attempts": len(attempts), "known_storage_counts": result["known_storage_counts"]}))
raise SystemExit(0 if all(checks.values()) else 1)
