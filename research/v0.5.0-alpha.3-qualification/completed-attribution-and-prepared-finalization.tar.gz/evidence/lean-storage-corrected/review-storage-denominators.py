"""Describe both storage denominator drops from frozen, side-specific inventories.

This is a pure-data/source/retained-IR review. Final fresh-census binding remains
a separate mandatory check; no new proof verdict is produced here.
"""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
DEST = OUT / "storage-denominator-review"
DEST.mkdir(exist_ok=True)
INVENTORY = OUT / "count-attribution/inventory.json"
inventory = json.loads(INVENTORY.read_text())
rows = {row["program"]: row for row in inventory["rows"]}


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def side_data(row, side):
    extracted = json.loads(Path(row["sides"][side]["extraction"]["path"]).read_text())
    excerpt = json.loads(Path(row["site_excerpts"]["path"]).read_text())
    return extracted, {fn["symbol"]: fn for fn in excerpt["sides"][side]["functions"]}


def producers(fn):
    return {f"%t{result}": {"block": block["label"], "offset": i, "operation": op}
            for block in fn["blocks"] for i, op in enumerate(block["operations"]) for result in op["results"]}


def low_word_context(fn, sites):
    defs = producers(fn)
    result = []
    for site in sites:
        if site["kind"] != "low-word":
            continue
        value = site["source"]
        definition = defs[value]
        assert definition["operation"]["op"] == "big.lo"
        parent = definition["operation"]["operands"][0]["value"]
        users = [{"block": block["label"], "offset": i, "operation": op}
                 for block in fn["blocks"] for i, op in enumerate(block["operations"])
                 if any(arg["value"] == value for arg in op["operands"])]
        result.append({"site": site, "definition": definition, "parent": defs.get(parent), "uses": users})
    return result


boundary_name = "tests/deviations/dynany_identity_boundary.py"
boundary = rows[boundary_name]
boundary_sides = {}
for side in ("baseline", "candidate"):
    extracted, functions = side_data(boundary, side)
    fn = functions["@main.init"]
    storage = extracted["checks"]["storage"]["functions"]
    assert len(storage) == 1 and storage[0]["function"] == "@main.init"
    gc = extracted["checks"]["gc"]["functions"]
    assert len(gc) == 1 and gc[0]["function"] == "@main.init"
    blocks = {block["label"]: block for block in fn["blocks"]}
    gc_sites = [{"normalized_node": node, "origin": origin,
                 "operation": blocks[origin[0]]["operations"][origin[1]]}
                for node, origin in gc[0]["sites"].items()]
    source_path = Path(boundary["sides"][side]["source"]["path"])
    source_copy = DEST / ("identity-boundary-" + side + ".py")
    source_copy.write_bytes(source_path.read_bytes())
    boundary_sides[side] = {"source": identity(source_path), "source_copy": identity(source_copy),
                            "storage": storage[0], "low_word_context": low_word_context(fn, storage[0]["sites"]),
                            "gc": gc[0], "gc_site_operations": gc_sites}
assert boundary_sides["baseline"]["storage"]["obligations"] == 2
assert boundary_sides["candidate"]["storage"]["obligations"] == 1
old_optional_gc = [site for site in boundary_sides["baseline"]["gc_site_operations"]
                   if any("list[opt[float]]" in a["type"] for a in site["operation"]["operands"])]
assert len(old_optional_gc) == 4
assert all(any("list[union[float,int]]" in a["type"] for a in site["operation"]["operands"])
           for site in boundary_sides["candidate"]["gc_site_operations"])

materialization_name = "tests/programs/numbers/python_int_vtuple_materialization.py"
materialization = rows[materialization_name]
materialization_sides = {}
for side in ("baseline", "candidate"):
    extracted, functions = side_data(materialization, side)
    checks = extracted["checks"]["storage"]
    details = []
    for function in checks["functions"]:
        if function["function"] not in ("@f.optional", "@f.small"):
            continue
        details.append({**function, "site_kinds": dict(Counter(site["kind"] for site in function["sites"])),
                        "low_word_context": low_word_context(functions[function["function"]], function["sites"])})
    materialization_sides[side] = {"source": materialization["sides"][side]["source"],
                                  "totals": checks["totals"],
                                  "all_function_counts": {f["function"]: f["obligations"] for f in checks["functions"]},
                                  "changed_functions": details}
assert materialization_sides["baseline"]["source"]["sha256"] == materialization_sides["candidate"]["source"]["sha256"]
assert materialization_sides["baseline"]["all_function_counts"] == {
    "@main.init": 8, "@f.small": 6, "@f.optional": 18, "@f.dynamic": 6, "@f.converted": 8}
assert materialization_sides["candidate"]["all_function_counts"] == {
    "@main.init": 8, "@f.small": 8, "@f.optional": 7, "@f.dynamic": 6, "@f.converted": 8}
old_optional = next(f for f in materialization_sides["baseline"]["changed_functions"] if f["function"] == "@f.optional")
new_optional = next(f for f in materialization_sides["candidate"]["changed_functions"] if f["function"] == "@f.optional")
assert old_optional["site_kinds"] == {"low-word": 6, "tail-marker": 2, "narrowing": 6, "tuple-decode": 4}
assert new_optional["site_kinds"] == {"low-word": 7}
ir_files = {}
for side, name in (("baseline", "old"), ("candidate", "new")):
    path = ROOT / "ir-audit/cases/1994" / (name + ".ll")
    text = path.read_text()
    bodies = [m.group(0) for m in re.finditer(
        r"^define[^\n]*@f\.(?:small|optional)\([^\n]*\)[^\n]*\{\n.*?^\}", text, re.M | re.S)]
    assert len(bodies) == 2
    excerpt_path = DEST / ("materialization-" + name + ".ll")
    excerpt_path.write_text("\n\n".join(bodies) + "\n")
    ir_files[side] = {"full_ir": identity(path), "function_excerpts": identity(excerpt_path)}

result = {
    "reviewed_utc": datetime.now(timezone.utc).isoformat(),
    "status": "exact_inventory_semantic_review_pending_final_fresh_census_binding",
    "baseline_commit": inventory["source_commits"]["baseline"],
    "candidate_commit": inventory["source_commits"]["candidate"],
    "final_binding_required": str(OUT / "count-attribution/final-census-binding.json"),
    "identity_boundary": {
        "program": boundary_name, "sides": boundary_sides,
        "site_excerpts": boundary["site_excerpts"],
        "removed_optional_gc_sites": old_optional_gc,
        "disposition": [
            "The source deliberately removes the formerly documented failing typed-VTuple and optional-float-list identity observations after those cases become supported. The remaining union-list and wide-integer observations stay in this deviation fixture.",
            "The removed storage site is baseline node 9, source t9: big.lo of t2, the big.from_str result for int('1000') used in the removed typed tuple. The remaining wide-integer big.op low-word extraction is baseline t252 and candidate t130.",
            "The four removed GC sites are list.append, the global optional-list store, and two list.get operations for list[opt[float]]. The four retained sites belong to the separate list[union[float,int]] observation.",
            "Positive coverage is explicit: python_int_vtuple_identity.py has both dynamic-any/python-int directives and int('1000'), repeated VTuple entries, list conversion and checked helper boundaries. python_int_optional_container_identity.py is also promoting-int selected; dynany_identity_optional_lists.py supplies the ordinary dynamic optional-list case. Generic dynany_identity_vtuples.py is not claimed as storage proof coverage.",
            "The original changed fixture was separately recompiled/audited against the release candidate in original-input-disposition.json; changing the source corpus denominator is not presented as unchanged input coverage.",
        ],
    },
    "vtuple_materialization": {
        "program": materialization_name, "sides": materialization_sides,
        "site_excerpts": materialization["site_excerpts"], "retained_ir": ir_files,
        "net_change": {"before": 46, "after": 37, "delta": -9},
        "disposition": [
            "The source is unchanged. The net nine-obligation drop is not nine simply deleted sites: optional falls from 18 to 7 (-11), small rises from 6 to 8 (+2), and main.init/dynamic/converted remain at 8/6/8.",
            "Optional no longer allocates an intermediate fixed tuple t85, packs marker/tail words, decodes it, then converts it to the final optional-item VTuple. Its 12 tuple-specific sites disappear: 2 tail-marker, 6 narrowing and 4 tuple-decode. Its low-word sites rise from 6 to 7 because the direct path also captures an item identity; the final integer fit checks remain before boxing/materialization.",
            "Small adds two low-word obligations when capturing the identities of its two item-call results, before the final VTuple allocation. The final materialization low-word checks remain. This accounts for the offsetting increase of two.",
            "The emitted old/new optional and small bodies retain item evaluation order, checked numeric conversion and the raising overflow path. Current VTuple storage additionally writes identity companions. The independent IR review already classifies case 1994 as the intended numeric-container identity change.",
        ],
    },
    "evidence": {name: identity(path) for name, path in {
        "inventory": INVENTORY,
        "reference_delta": OUT.parent / "lean-corrected/delta-alpha2.json",
        "accepted_ir_review": OUT.parent / "ir-review/accepted-ir-review.json",
        "original_input_review": OUT.parent / "ir-review/original-input-disposition.json",
        "final_production_equivalence": OUT.parent / "lean/optional-storage-repair/final-source-equivalence-b0-to-0a2f.json",
        "script": Path(__file__),
    }.items()},
    "limits": [
        "Historical snapshot hashes/counts match the alpha2 census exactly; candidate inventories match the prior 94f4 reference counts. Candidate proof validity is not inferred from that reference.",
        "The final fresh 0a2f census must independently produce these exact candidate snapshot hashes/counts and pass strict storage; the separate binder enforces that requirement.",
        "No compiler, runtime or Lean checker was executed by this review script. It explains denominator changes and preserves existing/future verdicts.",
    ],
}
(DEST / "review.json").write_text(json.dumps(result, indent=2) + "\n")
(DEST / "review.md").write_text("""# Storage denominator changes

Two shared fixtures account for the ten-obligation net storage decrease in the comparison selection. The historical snapshot/count bindings are exact. These inventories come from frozen final source `0a2fe77a`; its fresh census must still match every candidate snapshot and count and pass the strict-storage gate.

## Identity boundary: 2 → 1 storage, 8 → 4 GC

The deviation fixture removes two formerly failing observations after support is added: identity through a typed VTuple holding `int("1000")`, and identity through an optional float list. The remaining union-list and wide-integer observations stay.

The one removed storage obligation is the low word extracted from the `big.from_str` result for the typed tuple's `int("1000")`. The surviving wide-integer low word comes from `big.op` (old `%t252`, new `%t130`). The four removed GC sites are the optional list's append, global store and two reads. All four surviving GC sites belong to the separate union-list observation.

The precise promoting-int positive replacement is `python_int_vtuple_identity.py`, which includes both directives, `int("1000")`, repeated VTuple entries, list conversion and checked helper boundaries. `python_int_optional_container_identity.py` also has storage coverage; the ordinary optional-list identity test adds separate dynamic coverage. The generic VTuple identity test is not being called a storage-proof replacement. The original edited fixture was independently compiled and audited in the retained original-input review.

## VTuple materialization: 46 → 37 storage

This source is unchanged. The net decrease consists of two different changes:

| Function | Alpha2 | Candidate inventory | Change |
|---|---:|---:|---:|
| `main.init` | 8 | 8 | 0 |
| `small` | 6 | 8 | +2 |
| `optional` | 18 | 7 | −11 |
| `dynamic` | 6 | 6 | 0 |
| `converted` | 8 | 8 | 0 |
| Total | 46 | 37 | −9 |

`optional` no longer allocates, fills, narrows and decodes an intermediate fixed tuple before creating the final VTuple. That removes twelve tuple-specific obligations: two tail-marker, six narrowing and four tuple-decode sites. Its direct low-word checks rise from six to seven, including identity capture. Both final integer fit checks and the overflow-raising path remain.

`small` adds two low-word uses for identity capture of its two item-call results. Its final VTuple materialization checks remain. These two new obligations offset part of `optional`'s reduction. This is not a claim that exactly nine old sites were simply deleted.

`review.json` retains every exact old/new site and low-word producer/use context, complete relevant typed functions, both emitted function bodies, raw source/IR hashes and the independent IR disposition. This read-only review ran no compiler, runtime or Lean checker. Final fresh-census binding remains mandatory.
""")
print(json.dumps(identity(DEST / "review.json")))
