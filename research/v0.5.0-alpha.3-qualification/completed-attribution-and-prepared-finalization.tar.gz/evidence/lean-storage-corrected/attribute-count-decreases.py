"""Before the final census, inventory exact null/GC/storage denominator changes.

This serial diagnostic exports snapshots and inventories obligations. It does not
change the maintained report, invoke a Lean checker, or turn residuals into proofs.
The preceding complete census supplies a selection/reference only. Candidate
snapshots and counts must later match the fresh final-source census exactly.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
DEST = OUT / "count-attribution"
BASE = Path("/workspace/scratch/7dd0519bc14a/lean-reports/alpha2-source")
CONFIG_PATH = OUT / "attribution-config.json"
CONFIG = json.loads(CONFIG_PATH.read_text())
NEW = Path(CONFIG["candidate_repo"])
REFERENCE = Path(CONFIG["selection_reference"])
PY = Path("/workspace/scratch/c2b093657c17/dev-venv/bin/python")
EXPECTED = {"baseline": "950c0440ad793dc6c34664f591383a5e6bba14dd",
            "candidate": CONFIG["candidate_commit"]}

def identity(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "bytes": path.stat().st_size}

def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()

def null_inventory(snapshot, guards):
    result = []
    for pass_index, record in enumerate(snapshot["nullcheck_evidence"]):
        sites = guards.removed_checks(record)
        assert len(sites) == record["reported_rewrites"]
        if sites:
            blocks = {block["label"]: block for block in record["before"]["blocks"]}
            result.append({"function": record["before"]["symbol"], "pass_index": pass_index,
                           "obligations": len(sites),
                           "removed_sites": [{"block": block, "offset": offset,
                                              "operation": blocks[block]["operations"][offset]}
                                             for block, offset in sorted(sites)]})
    return result

def gc_inventory(snapshot, boundary, collector, guards):
    declared = {fn["symbol"]: [fn["parameters"][i]["representation"]
                               for i in guards.argument_parameters(fn["parameters"])]
                for fn in snapshot["functions"]}
    words, opened = collector.memory_types(snapshot)
    typed = collector.signatures(snapshot)
    invariants = collector.infer_invariants(snapshot, words, opened, declared=typed)
    context = {"classes": snapshot.get("classes") or {}, "layouts": snapshot.get("class_layouts") or {}}
    result = []
    for fn in snapshot["functions"]:
        producers = {f"%t{n}": op for block in fn["blocks"] for op in block["operations"]
                     for n in op["results"]}
        stored = {op["operands"][0]["value"] for block in fn["blocks"] for op in block["operations"]
                  if op["op"] in ("mem.store", "mach.store") and op["operands"] and guards.direct_access(op)
                  and (guards.memory_key(context, producers, op["operands"][0]["value"]) in words
                       or invariants.get(guards.memory_key(context, producers, op["operands"][0]["value"])))}
        if not collector.relevant(fn, declared, stored):
            continue
        candidate, meta = collector.normalize(snapshot, fn, (words, invariants), typed)
        encoded = boundary.encode(candidate)
        result.append({"function": fn["symbol"], "obligations": meta["obligations"],
                       "candidate_sha256": hashlib.sha256(encoded.encode()).hexdigest(),
                       "sites": meta["origins"]})
    return result

def storage_inventory(snapshot, storage):
    result = []
    for fn in snapshot["functions"]:
        ops = [op for block in fn["blocks"] for op in block["operations"]]
        if not any(op["op"] == "big.lo" or storage.is_tuple(storage.unopt(op["type"]))
                   or any(storage.is_tuple(storage.unopt(arg["type"])) for arg in op["operands"])
                   for op in ops):
            continue
        candidate, meta = storage.Normalize(fn).build(infer=False)
        result.append({"function": fn["symbol"], "obligations": meta["obligations"],
                       "sites": meta["sites"],
                       "graph_sha256": hashlib.sha256(json.dumps(candidate["program"], sort_keys=True).encode()).hexdigest(),
                       "proof_executed": False})
    return result

if len(sys.argv) > 1 and sys.argv[1] == "--extract":
    # Each side imports its own historical adapter in a separate process. In
    # particular, the alpha3 boundary validator requires layout inventory that
    # an alpha2 snapshot does not export. Do not interpret old snapshots through
    # a replacement normalizer or make their totals fit the candidate.
    repo, snapshot_path, output_path = map(Path, sys.argv[2:5])
    checks = sys.argv[5:]
    sys.path.insert(0, str(repo / "tools"))
    sys.path.insert(1, str(repo))
    import check_lean_boundary as boundary
    import check_lean_gc as collector
    import check_lean_guards as guards
    if "storage" in checks:
        import check_lean_storage as storage
    snapshot, digest = boundary.read_snapshot(snapshot_path, boundary.MAX_PROGRAM_BYTES)
    boundary.check_header(snapshot)
    extracted = {"repo": str(repo), "commit": git(repo, "rev-parse", "HEAD"),
                 "snapshot_sha256": digest, "checks": {},
                 "function_symbols": [fn["symbol"] for fn in snapshot["functions"]],
                 "adapter_choice": "Side-specific historical modules; no candidate imports on the baseline side."}
    for check in checks:
        functions = (null_inventory(snapshot, guards) if check == "null" else
                     storage_inventory(snapshot, storage) if check == "storage" else
                     gc_inventory(snapshot, boundary, collector, guards))
        extracted["checks"][check] = {
            "totals": {"functions": len(functions), "obligations": sum(f["obligations"] for f in functions)},
            "functions": functions,
        }
    extracted["adapter_modules"] = {
        name: identity(Path(module.__file__)) for name, module in sorted(sys.modules.items())
        if name.startswith("check_lean_") and getattr(module, "__file__", None)
    }
    assert all(Path(row["path"]).resolve().is_relative_to((repo / "tools").resolve())
               for row in extracted["adapter_modules"].values()), "adapter import escaped its frozen side"
    extracted["compiler_support_modules"] = {
        name: identity(Path(module.__file__)) for name, module in sorted(sys.modules.items())
        if name.startswith("src.pystachy_compiler") and getattr(module, "__file__", None)
    }
    assert all(Path(row["path"]).resolve().is_relative_to((repo / "src").resolve())
               for row in extracted["compiler_support_modules"].values()), "compiler utility import escaped its frozen side"
    output_path.write_text(json.dumps(extracted, indent=2) + "\n")
    raise SystemExit(0)

assert (REFERENCE / "acceptance.json").is_file(), "Selection must come from a completed prior census."
acceptance = json.loads((REFERENCE / "acceptance.json").read_text())
assert acceptance["programs"] == 2699, "No attribution from an incomplete census."
assert all(value for name, value in acceptance["checks"].items()
           if name != "strict_storage_all_accepted")
delta = json.loads((REFERENCE / "delta-alpha2.json").read_text())
record_paths = {"baseline": Path(delta["baseline_records"]), "candidate": REFERENCE / "records.jsonl"}
census_records = {side: {row["program"]: row for row in
                        map(json.loads, path.read_text().splitlines()[1:])}
                  for side, path in record_paths.items()}
wanted = {(row["program"], row["check"]) for row in delta["obligation_decreases"]
          if row["check"] in ("null", "gc", "storage")}
changes = {(row["program"], row["check"]): row for row in delta["shared_changes"]}
for side, repo in (("baseline", BASE), ("candidate", NEW)):
    assert git(repo, "rev-parse", "HEAD") == EXPECTED[side]
    assert not git(repo, "status", "--porcelain")
assert not DEST.exists(), "Keep each attempt separate."
DEST.mkdir()
env = {k: v for k, v in os.environ.items()
       if not k.startswith("PYSTACHY_") and k not in ("PYTHONPATH", "PYTHONOPTIMIZE")}
env.update(PATH=f"{PY.parent}:/usr/local/bin:/usr/bin:/bin")
results = []
receipt = {"started_utc": datetime.now(timezone.utc).isoformat(), "jobs": 1,
           "source_commits": EXPECTED, "script": identity(Path(__file__)),
           "configuration": identity(CONFIG_PATH),
           "selection_reference": {name: identity(REFERENCE / name)
                                   for name in ("acceptance.json", "delta-alpha2.json", "records.jsonl")},
           "selection_pairs": [{"program": p, "check": c} for p, c in sorted(wanted)],
           "candidate_census_binding": "pending fresh complete final-source census",
           "purpose": "Exact per-function denominator attribution; no new Lean verdicts.",
           "adapter_choice": "Each side uses its own frozen compiler, inspector, and adapter modules in a separate process; exact module hashes are recorded per extraction.",
           "rows": results}
for index, program in enumerate(sorted({program for program, _ in wanted}), 1):
    row = {"program": program, "sides": {}}
    checks = sorted(check for p, check in wanted if p == program)
    for side, repo in (("baseline", BASE), ("candidate", NEW)):
        output = DEST / f"{index:02d}-{Path(program).stem}" / side
        output.parent.mkdir(parents=True, exist_ok=True)
        # The inspector reserves its output atomically after the staged compile;
        # do not create that directory beforehand.
        command = [str(PY), "tools/inspect_compiler.py", str(repo / program), "--output", str(output),
                   "--typed-after-only", "--guard-evidence", "--timeout", "300"]
        side_env = dict(env, PYSTACHY_HOME=str(repo), PYSTACHY_IRCHECK="1")
        sidecar = (repo / program).with_suffix(".path")
        if sidecar.is_file():
            side_env["PYSTACHY_PATH"] = sidecar.read_text().strip()
        started = time.monotonic()
        with (output.parent / f"{side}.inspection.log").open("w") as log:
            completed = subprocess.run(command, cwd=repo, env=side_env, stdout=log, stderr=subprocess.STDOUT)
        side_row = {"command": command, "cwd": str(repo), "exit": completed.returncode,
                    "seconds": round(time.monotonic() - started, 3), "source": identity(repo / program)}
        row["sides"][side] = side_row
        if completed.returncode:
            side_row["error"] = "snapshot inspection did not complete"
            continue
        snapshot_path = output / "typed-after.json"
        side_row["snapshot"] = identity(snapshot_path)
        extracted_path = output / "extracted-inventory.json"
        extraction_command = [str(PY), str(Path(__file__).resolve()), "--extract", str(repo),
                              str(snapshot_path), str(extracted_path), *checks]
        with (output / "extraction.log").open("w") as log:
            extraction = subprocess.run(extraction_command, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT)
        side_row.update(extraction_command=extraction_command, extraction_exit=extraction.returncode)
        if extraction.returncode:
            side_row["error"] = "side-specific obligation extraction did not complete"
            continue
        extracted = json.loads(extracted_path.read_text())
        assert extracted["commit"] == EXPECTED[side]
        side_row["reference_snapshot_sha256"] = census_records[side][program]["snapshot_sha256"]
        side_row["snapshot_matches_reference"] = extracted["snapshot_sha256"] == side_row["reference_snapshot_sha256"]
        side_row["reference_is_same_source_census"] = side == "baseline"
        side_row["extraction"] = identity(extracted_path)
        side_row["function_symbols"] = extracted["function_symbols"]
        side_row["checks"] = extracted["checks"]
        side_row["adapter_modules"] = extracted["adapter_modules"]
        side_row["compiler_support_modules"] = extracted["compiler_support_modules"]
        for check in checks:
            totals = side_row["checks"][check]["totals"]
            previous = changes[(program, check)]["before" if side == "baseline" else "after"]
            side_row["checks"][check]["matches_reference_counts"] = all(totals[k] == previous[k] for k in totals)
    row["attribution"] = {}
    if all("checks" in row["sides"][side] for side in ("baseline", "candidate")):
        for check in checks:
            old, new = {}, {}
            for side, grouped in (("baseline", old), ("candidate", new)):
                for fn in row["sides"][side]["checks"][check]["functions"]:
                    grouped.setdefault(fn["function"], []).append(fn)
            candidate_symbols = set(row["sides"]["candidate"]["function_symbols"])
            row["attribution"][check] = [
                {"function": name, "before_records": old.get(name, []), "after_records": new.get(name, []),
                 "before_obligations": sum(fn["obligations"] for fn in old.get(name, [])),
                 "after_obligations": sum(fn["obligations"] for fn in new.get(name, [])),
                 "function_absent_in_candidate": name not in candidate_symbols}
                for name in sorted(old.keys() | new.keys())
                if sum(fn["obligations"] for fn in old.get(name, []))
                   != sum(fn["obligations"] for fn in new.get(name, []))]
        excerpt = {"program": program, "source_commits": EXPECTED,
                   "purpose": "Exact typed function and before/after null-pass context for every changed per-function denominator; raw snapshots are retained separately.",
                   "sides": {}}
        changed_functions = {item["function"] for items in row["attribution"].values() for item in items}
        for side in ("baseline", "candidate"):
            snapshot_file = Path(row["sides"][side]["snapshot"]["path"])
            snapshot = json.loads(snapshot_file.read_text())
            excerpt["sides"][side] = {
                "snapshot": identity(snapshot_file),
                "functions": [fn for fn in snapshot["functions"] if fn["symbol"] in changed_functions],
                "nullcheck_evidence": [{"pass_index": i, "record": record}
                                       for i, record in enumerate(snapshot.get("nullcheck_evidence", []))
                                       if "null" in checks and record["before"]["symbol"] in changed_functions],
                "absent_changed_functions": sorted(changed_functions - {fn["symbol"] for fn in snapshot["functions"]}),
            }
        excerpt_path = DEST / f"{index:02d}-{Path(program).stem}" / "site-excerpts.json"
        excerpt_path.write_text(json.dumps(excerpt, indent=2) + "\n")
        row["site_excerpts"] = identity(excerpt_path)
    results.append(row)
    (DEST / "inventory.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(f"{index}: {program}", flush=True)
receipt["finished_utc"] = datetime.now(timezone.utc).isoformat()
receipt["all_extractions_completed"] = all("checks" in row["sides"][side]
                                             for row in results for side in ("baseline", "candidate"))
receipt["all_baseline_snapshot_inventories_match_census"] = all(
    "checks" in row["sides"]["baseline"] and row["sides"]["baseline"]["snapshot_matches_reference"]
    and all(c["matches_reference_counts"] for c in row["sides"]["baseline"]["checks"].values())
    for row in results)
receipt["candidate_reference_count_changes"] = [
    {"program": row["program"], "check": name, "current_totals": check["totals"]}
    for row in results for name, check in row["sides"]["candidate"].get("checks", {}).items()
    if not check["matches_reference_counts"]]
receipt["source_clean_after"] = {side: not git(repo, "status", "--porcelain")
                                  for side, repo in (("baseline", BASE), ("candidate", NEW))}
(DEST / "inventory.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({k: v for k, v in receipt.items() if k != "rows"}), flush=True)
raise SystemExit(0 if receipt["all_extractions_completed"]
                 and receipt["all_baseline_snapshot_inventories_match_census"]
                 and all(receipt["source_clean_after"].values()) else 1)
