"""Bind early, side-specific site inventories to the complete fresh final census.

This pure-data check cannot grant a semantic proof-delta approval. It requires
exact selected-pair coverage, snapshot hashes, source identities and counts.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
CONFIG_PATH = OUT / "attribution-config.json"
config = json.loads(CONFIG_PATH.read_text())
repo = Path(config["candidate_repo"])
inventory_path = OUT / "count-attribution/inventory.json"
inventory = json.loads(inventory_path.read_text())
acceptance = json.loads((OUT / "acceptance.json").read_text())
delta = json.loads((OUT / "delta-alpha2.json").read_text())
reference = Path(config["selection_reference"])
reference_delta = json.loads((reference / "delta-alpha2.json").read_text())
SUPPORTED = {"null", "gc", "storage"}


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def git(*args):
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()


def records(path):
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    assert len({row["program"] for row in rows[1:]}) == len(rows) - 1
    return rows[0]["header"], {row["program"]: row for row in rows[1:]}


base_path = Path(delta["baseline_records"])
base_header, base_records = records(base_path)
header, current_records = records(OUT / "records.jsonl")
expected_pairs = {(row["program"], row["check"]) for row in delta["obligation_decreases"]
                  if row["check"] in SUPPORTED}
selected_pairs = {(row["program"], row["check"]) for row in inventory["selection_pairs"]}
observed_pair_rows = [(row["program"], check) for row in inventory["rows"]
                      for check in row["sides"]["candidate"].get("checks", {})]
observed_pairs = set(observed_pair_rows)
excluded_final = [row for row in delta["obligation_decreases"] if row["check"] not in SUPPORTED]
excluded_reference = [row for row in reference_delta["obligation_decreases"] if row["check"] not in SUPPORTED]
checks = {
    "all_final_acceptance_checks_passed": bool(acceptance["checks"]) and all(acceptance["checks"].values()),
    "final_records_match_acceptance_hash": identity(OUT / "records.jsonl")["sha256"] == acceptance["records_sha256"],
    "final_report_matches_acceptance_hash": identity(OUT / "report.md")["sha256"] == acceptance["report_sha256"],
    "unique_inventory_program_rows": len({row["program"] for row in inventory["rows"]}) == len(inventory["rows"]),
    "unique_inventory_selected_pairs": len(selected_pairs) == len(inventory["selection_pairs"]),
    "unique_inventory_observed_pairs": len(observed_pairs) == len(observed_pair_rows),
    "complete_fresh_census": acceptance["programs"] == 2699
        and acceptance["checks"]["exact_corpus_census"]
        and acceptance["checks"]["completion_valid"]
        and acceptance["checks"]["no_incomplete_or_failed_records"],
    "strict_storage_gate_passed": acceptance["checks"]["strict_storage_all_accepted"],
    "frozen_source_commit_matches": git("rev-parse", "HEAD") == config["candidate_commit"]
        == inventory["source_commits"]["candidate"] == acceptance["commit"],
    "frozen_source_tree_matches": git("rev-parse", "HEAD^{tree}") == config["candidate_tree"]
        == acceptance["tree"],
    "frozen_source_clean": not git("status", "--porcelain"),
    "configuration_unchanged": identity(CONFIG_PATH) == inventory["configuration"],
    "attribution_script_unchanged": identity(OUT / "attribute-count-decreases.py") == inventory["script"],
    "reference_files_unchanged": all(identity(Path(row["path"])) == row
                                     for row in inventory["selection_reference"].values()),
    "baseline_records_unchanged": identity(base_path)["sha256"] == delta["baseline_sha256"],
    "all_early_extractions_completed": inventory["all_extractions_completed"],
    "baseline_bindings_passed": inventory["all_baseline_snapshot_inventories_match_census"],
    "extraction_sources_clean_after": all(inventory["source_clean_after"].values()),
    "exact_final_supported_decrease_set": expected_pairs == selected_pairs == observed_pairs,
    "other_final_decreases_equal_previously_reviewed_reference": excluded_final == excluded_reference,
}
rows = []
for program in inventory["rows"]:
    name = program["program"]
    for side, all_records in (("baseline", base_records), ("candidate", current_records)):
        extracted = program["sides"][side]
        census = all_records[name]
        row_checks = {
            "compact_site_excerpts_unchanged": identity(Path(program["site_excerpts"]["path"])) == program["site_excerpts"],
            "snapshot_bytes_unchanged": identity(Path(extracted["snapshot"]["path"])) == extracted["snapshot"],
            "snapshot_matches_final_census": extracted["snapshot"]["sha256"] == census["snapshot_sha256"],
            "extraction_bytes_unchanged": identity(Path(extracted["extraction"]["path"])) == extracted["extraction"],
            "fixture_source_unchanged": identity(Path(extracted["source"]["path"])) == extracted["source"],
            "adapter_sources_unchanged": all(identity(Path(item["path"])) == item
                                              for item in extracted["adapter_modules"].values()),
            "compiler_support_sources_unchanged": all(identity(Path(item["path"])) == item
                                                       for item in extracted["compiler_support_modules"].values()),
        }
        for category, extraction in extracted["checks"].items():
            row_checks[f"{category}_counts_match_final_census"] = all(
                census["checks"][category][key] == value
                for key, value in extraction["totals"].items())
        rows.append({"program": name, "side": side, "checks": row_checks,
                     "extracted_totals": {key: value["totals"] for key, value in extracted["checks"].items()},
                     "census_snapshot_sha256": census["snapshot_sha256"]})
checks["all_per_side_snapshot_source_and_count_bindings"] = all(all(row["checks"].values()) for row in rows)
access_review = OUT.parent / "lean/access-count-decrease-1158/review.json"
result = {
    "schema_version": 1,
    "checked_utc": datetime.now(timezone.utc).isoformat(),
    "candidate_commit": config["candidate_commit"],
    "candidate_tree": config["candidate_tree"],
    "baseline_commit": inventory["source_commits"]["baseline"],
    "status": "bound_to_complete_final_source_census" if all(checks.values()) else "binding_or_strict_gate_failed",
    "checks": checks, "rows": rows,
    "supported_decrease_pairs": [{"program": p, "check": c} for p, c in sorted(expected_pairs)],
    "other_decreases_requiring_existing_semantic_review": excluded_final,
    "existing_access_review": identity(access_review),
    "semantic_approval_granted": False,
    "limitation": "Exact provenance and count coverage are prerequisites; the final semantic disposition and independent review must separately explain every decreased denominator.",
    "evidence": {name: identity(path) for name, path in {
        "inventory": inventory_path, "candidate_records": OUT / "records.jsonl",
        "baseline_records": base_path, "acceptance": OUT / "acceptance.json",
        "delta": OUT / "delta-alpha2.json", "configuration": CONFIG_PATH,
        "binding_script": Path(__file__)}.items()},
}
(OUT / "count-attribution/final-census-binding.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"status": result["status"], "checks": checks,
                  "rows": len(rows), "supported_pairs": len(expected_pairs)}))
raise SystemExit(0 if all(checks.values()) else 1)
