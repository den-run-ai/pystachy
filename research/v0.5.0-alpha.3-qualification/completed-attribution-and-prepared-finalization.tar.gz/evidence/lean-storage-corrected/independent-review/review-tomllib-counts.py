"""Independently check all 21 retained Tomllib null-pass sites; read JSON only."""
from datetime import datetime, timezone
import json
from pathlib import Path
from raw_json_review import canonical_digest, identity, top_array, verify

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BASE = ROOT.parent
IPATH = ROOT / "count-attribution/inventory.json"
PPATH = BASE / "lean/tomllib-count-attribution-support/exact-null-site-confirmation.json"
assert identity(IPATH)["sha256"] == "7200136d2f198e297688a66aeceb60eb1e7ade0423e8f2dd27a286fb098ccb00"
inventory = json.loads(IPATH.read_text())
publication = json.loads(PPATH.read_text())
assert publication["programs"] == 7 and publication["site_confirmations"] == 21
assert publication["attribution_inventory"]["sha256"] == identity(IPATH)["sha256"]
entries = {row["program"]: row for row in inventory["rows"]}
expected_methods = {"@f.tomllib$_parser$create_dict_rule": "is_",
                    "@f.tomllib$_parser$create_list_rule": "unset_all",
                    "@f.tomllib$_parser$key_value_rule": "add_pending"}
rows = []
for pub in publication["rows"]:
    entry = entries[pub["program"]]
    verify(pub["excerpt"])
    excerpt = json.loads(Path(pub["excerpt"]["path"]).read_text())
    phases, removed = {}, {}
    snapshots = {}
    for side in ("baseline", "candidate"):
        se = entry["sides"][side]
        snapshots[side] = verify(se["snapshot"])
        assert snapshots[side] == pub["snapshot_references"][side]
        verify(se["extraction"])
        assert se["extraction"]["sha256"] == pub["extracted_inventory_hashes"][side]
        extraction = json.loads(Path(se["extraction"]["path"]).read_text())
        assert extraction["checks"]["null"]["totals"] == pub["null_totals"][side]
        removed[side] = {fn["function"]: fn for fn in extraction["checks"]["null"]["functions"]}
        wanted = {rec["pass_index"]: rec["record"] for rec in excerpt["sides"][side]["nullcheck_evidence"]
                  if rec["record"]["before"]["symbol"] in expected_methods}
        assert len(wanted) == 3
        text = Path(se["snapshot"]["path"]).read_text()
        matched = set()
        for index, record in enumerate(top_array(text, "nullcheck_evidence")):
            if index in wanted:
                assert record == wanted[index]
                matched.add(index)
        del text
        assert matched == set(wanted)
        phases[side] = {rec["before"]["symbol"]: rec for rec in wanted.values()}
    assert set(removed["baseline"]) == set(removed["candidate"])
    assert {name for name in removed["baseline"]
            if removed["baseline"][name]["obligations"] != removed["candidate"][name]["obligations"]} == set(expected_methods)
    site_rows = []
    for site in pub["sites"]:
        name = site["function"]
        method = expected_methods[name]
        old = removed["baseline"][name]
        new = removed["candidate"][name]
        assert old["obligations"] == 4 and new["obligations"] == 3
        old_sites = {json.dumps(s, sort_keys=True) for s in old["removed_sites"]}
        new_sites = {json.dumps(s, sort_keys=True) for s in new["removed_sites"]}
        assert not new_sites - old_sites
        assert old_sites - new_sites == {json.dumps(site["only_removed_inventory_difference"], sort_keys=True)}
        operation = site["only_removed_inventory_difference"]["operation"]
        assert operation["text"] == f"AttributeError: 'NoneType' object has no attribute '{method}'"
        verified_phases = {}
        for side in ("baseline", "candidate"):
            verified_phases[side] = {}
            for phase in ("before", "after"):
                fn = phases[side][name][phase]
                saved = site["phases"][side][phase]
                assert canonical_digest(fn) == saved["function_sha256"]
                operations = [(block["label"], offset, op) for block in fn["blocks"]
                              for offset, op in enumerate(block["operations"])]
                occurrences = [{"block": label, "offset": offset} for label, offset, op in operations if op == operation]
                assert occurrences == saved["check_occurrences"]
                if side == "baseline" and phase == "after":
                    assert not occurrences
                    verified_phases[side][phase] = {"function_sha256": canonical_digest(fn), "guard_absent": True}
                    continue
                assert len(occurrences) == 1
                definitions = {f"%t{value}": op for _, _, op in operations for value in op["results"]}
                comparison = definitions[operation["operands"][0]["value"]]
                assert comparison["op"] == "ptr.cmp" and comparison["text"] == "=="
                assert comparison["operands"][1]["value"] == "null"
                receiver = comparison["operands"][0]["value"]
                load = definitions[receiver]
                assert load["op"] == "mem.load" and load["type"] == "tomllib$_parser$Flags"
                address = definitions[load["operands"][0]["value"]]
                assert address["op"] == "field.addr" and address["immediate"] == 1
                assert address["operands"][0]["type"] == "tomllib$_parser$Output"
                calls = [op for _, _, op in operations if op["op"] == "call"
                         and op["text"] == "@m.tomllib$_parser$Flags." + method
                         and op["operands"][0]["value"] == receiver]
                assert len(calls) == 1
                assert saved["receiver"] == receiver
                for key, value in {"comparison": comparison, "load": load, "address": address,
                                   "check": operation, "method_call": calls[0]}.items():
                    assert value == saved[key]
                verified_phases[side][phase] = {"function_sha256": canonical_digest(fn),
                    "guard_location": occurrences[0], "receiver": receiver,
                    "receiver_field_index": 1, "method": method}
        site_rows.append({"function": name, "before_obligations": 4, "after_obligations": 3,
                          "old_removed_new_retained_operation": operation, "phases": verified_phases})
    rows.append({"program": pub["program"], "snapshots": snapshots,
                 "excerpt": identity(Path(pub["excerpt"]["path"])), "sites": site_rows,
                 "other_null_function_denominators_unchanged": True})

assert len(rows) == 7 and sum(len(row["sites"]) for row in rows) == 21
result = {"status": "independently_verified_exact_tomllib_sites_pending_final_census_binding",
          "observed_utc": datetime.now(timezone.utc).isoformat(),
          "source_commits": inventory["source_commits"], "inventory": identity(IPATH),
          "publication_review": identity(PPATH), "review_script": identity(Path(__file__)),
          "raw_json_helper": identity(HERE / "raw_json_review.py"),
          "programs": 7, "old_removed_new_retained_guards": 21, "rows": rows,
          "conclusion": "All 21 denominator losses are exact Output.flags receiver guards retained in the candidate. The unchanged before-pass check is absent after the old pass and present after the new pass; no tuple-pointer or TypeError interpretation applies.",
          "limits": ["Final-source census binding remains mandatory.",
                     "Per-function hashes include full location metadata; no path or IR normalization was used.",
                     "The earlier vtuple.slice effect/reaching-load mechanism is separately supported by source and LLVM review.",
                     "No compiler, normalizer, Lean checker or runtime was executed; no proof residual is reclassified."]}
(HERE / "tomllib-count-attribution-review.json").write_text(json.dumps(result, indent=2) + "\n")
(HERE / "tomllib-count-attribution-review.md").write_text("""# Independent verification of the exact Tomllib null sites

All **21 sites across seven fixtures** match the raw old/new null-pass snapshots. Each of the three parser functions has four old removed-check obligations and three new ones. The only changed removal is an `Output.flags` receiver check: `create_dict_rule` checks `is_`, `create_list_rule` checks `unset_all`, and `key_value_rule` checks `add_pending`.

The same check operation occurs in both before-pass inputs. It is absent after the old pass and retained exactly after the new pass. I traced every check through its `ptr.cmp` to the loaded `Flags` receiver, field index 1 on `Output`, and the downstream method call using that receiver. All raise `AttributeError` on null. These are separate from the VTuple layout change.

This review independently rehashed the large raw snapshots, matched all 42 selected before/after pass records to their compact excerpts, verified publication's canonical full-function hashes including location metadata, and checked all other per-function null denominators are unchanged. JSON records every exact phase/site and input hash. No compiler or theorem checker ran; final fresh-census binding remains mandatory, and this does not waive any model residual.
""")
print(json.dumps({"status": result["status"], "programs": 7, "sites": 21,
                  "review": identity(HERE / "tomllib-count-attribution-review.json")}))
