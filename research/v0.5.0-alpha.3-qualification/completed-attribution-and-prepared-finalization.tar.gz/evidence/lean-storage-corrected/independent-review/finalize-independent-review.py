"""Freeze final independent acceptance after completed data and manual review.

This is a pure evidence/hash/git-object check. It imports and executes no compiler,
normalizer, runtime or Lean checker. Do not execute against an incomplete census.
"""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
EVIDENCE = ROOT.parent
CANDIDATE = '0a2fe77a580106c197face4d2904be80e3f85dbc'
INTEGRATED = '328b945f02788b296d9981d1b44706a2a0092255'
TREE = '107460d5f89bdcf37f2741b233eac0568d82604a'
BASE_PROOF = '950c0440ad793dc6c34664f591383a5e6bba14dd'
BASE_RELEASE = '80490143498d149d407343ba1cb7aedb1db2d2c5'
BASE_TREE = '717a8c9386ae9f5f6545cc3686a9e22282fc560c'


def read(path):
    return json.loads(path.read_text())


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def verify_identity(info):
    actual = identity(Path(info['path']))
    assert actual['bytes'] == info['bytes'] and actual['sha256'] == info['sha256'], info['path']
    return actual


def exact_rows(rows):
    return Counter(json.dumps(row, sort_keys=True, separators=(',', ':')) for row in rows)


paths = {
    'records': ROOT / 'records.jsonl',
    'report': ROOT / 'report.md',
    'acceptance': ROOT / 'acceptance.json',
    'delta': ROOT / 'delta-alpha2.json',
    'census_receipt': ROOT / 'final-census-receipt.json',
    'count_binding': ROOT / 'count-attribution/final-census-binding.json',
    'semantic_disposition': ROOT / 'semantic-disposition.json',
    'semantic_markdown': ROOT / 'semantic-disposition.md',
    'structural_review': OUT / 'structural-audit.json',
    'prepared': ROOT / 'prepared.json',
    'equivalence': ROOT / 'qualification-source-equivalence.json',
    'inventory': ROOT / 'count-attribution/inventory.json',
    'provenance_review': OUT / 'provenance-preflight-review.json',
    'enum_review': OUT / 'enum-count-attribution-review.json',
    'gc_helper_review': OUT / 'gc-helper-count-attribution-review.json',
    'tomllib_review': OUT / 'tomllib-count-attribution-review.json',
    'storage_review': OUT / 'storage-count-attribution-review.json',
    'structural_verifier': OUT / 'verify-final-records.py',
    'final_reviewer': Path(__file__),
}
docs = {name: read(path) for name, path in paths.items() if path.suffix == '.json'}
a, d, r, b, s, v, p, eq = (docs[name] for name in (
    'acceptance', 'delta', 'census_receipt', 'count_binding',
    'semantic_disposition', 'structural_review', 'prepared', 'equivalence'))
assert s['status'] == 'reviewed_with_explicit_model_limits'
assert v['status'] == 'structural_census_and_exact_delta_verified_semantic_review_separate'
assert r['status'] == 'complete_and_strict_storage_accepted'
assert b['status'] == 'bound_to_complete_final_source_census'
for doc in (a, r, b, s):
    assert doc['checks'] and all(value is True for value in doc['checks'].values())
for field in ('evidence', 'review_evidence'):
    for info in s[field].values():
        verify_identity(info)
for doc in (r, b):
    for info in doc['evidence'].values():
        verify_identity(info)
for name, expected in {
    'semantic_builder': ('build-semantic-disposition.py', '50487306e00a1ef35a48bf5dfcfb94339941948a0c504b3c1c8da36c33446f12'),
    'census_finalizer': ('finalize-census.py', '21075e38f288d03892695443c21fccae32e929dc65f96d9d34797842651da7d3'),
}.items():
    assert identity(ROOT / expected[0])['sha256'] == expected[1], name
assert identity(paths['structural_verifier'])['sha256'] == v['review_script_sha256']
for name, expected in {
    'enum_review': '8421eee32a1e51e14df13b44e8dbcc93c95f9f323c1abca0d992934663a2dba4',
    'gc_helper_review': '9e8b0033d58ae422178c1527b8d86235354452eee9d7e871195ce4f02e1c7eff',
    'tomllib_review': 'aa4c3005e14b93855e7f1fc17dbfab228a06313c8e984f819654a815392eba9e',
    'storage_review': '6221476e41bb4663106c9b6437ab08dcb55d8501959e7727294392ba6c00e7b0',
    'provenance_review': '477bed231d576adee0899bc4fe9302fe0970878c7e0f9ea0f1c3f996aaa9aab7',
}.items():
    assert identity(paths[name])['sha256'] == expected, name
assert v['records_sha256'] == a['records_sha256'] == identity(paths['records'])['sha256']
assert v['report_sha256'] == a['report_sha256'] == identity(paths['report'])['sha256']
assert v['final_attribution_binding_sha256'] == identity(paths['count_binding'])['sha256']
assert identity(paths['inventory'])['sha256'] == '7200136d2f198e297688a66aeceb60eb1e7ade0423e8f2dd27a286fb098ccb00'
assert v['baseline_sha256'] == '98d2cd703064e39dbb14e41f3d13bb1b5df7bbcf4d30903966db4b427ecd09a6'
assert len(r['attempts']) == len(v['execution']['attempts']) == 1
assert r['attempts'][0]['result']['resume'] is False
assert not r['same_source_prefixes'] and r['prior_checker_records_reused'] is False
assert v['execution']['historical_records_reused'] is False
assert v['candidate_programs'] == a['programs'] == 2699
assert v['candidate_storage_programs'] == a['storage_programs'] == 196
assert v['baseline_programs'] == 2550 and v['baseline_storage_programs'] == 175
assert len(d['added_programs']) == 149 and not d['missing_programs']
assert len(d['storage_selection_delta']['added']) == 21 and not d['storage_selection_delta']['removed']
assert not a['storage_gaps'] and not v['storage_gaps']
assert v['new_totals']['storage']['obligations'] == v['new_totals']['storage']['proved'] == 25816
assert len(v['baseline_unknown_count_residuals']) == 443
assert len(v['candidate_unknown_count_residuals']) == 444
assert not any(row['check'] == 'storage' for row in v['candidate_unknown_count_residuals'])
assert len(v['obligation_decreases']) == len(v['proved_count_decreases']) == 38
assert not v['exact_raw_shared_residual_changes'] and not v['shared_gap_or_unknown_count_increases']
assert exact_rows(v['added_program_unproved']) == exact_rows(s['added_residual_functions'])
assert len(s['added_residual_functions']) == 23
assert Counter(row['check'] for row in s['added_residual_functions']) == {'union': 21, 'gc': 1, 'fields': 1}
assert sum(row['union_gap'] for row in s['complex_joint_verdict_counts']) == 542
assert sum(row['payload_gap'] for row in s['complex_joint_verdict_counts']) == 409
assert len(s['complex_joint_verdict_counts']) == 9
assert all(row['matches_review'] for row in s['complex_joint_verdict_counts'])
assert s['net_decreases_by_category'] == {'access': 1, 'gc': 106, 'null': 70, 'storage': 10}
assert exact_rows([{key: row[key] for key in ('program', 'check', 'before', 'after')}
                   for row in s['denominator_dispositions']]) == exact_rows(v['obligation_decreases'])
assert s['raw_shared_residual_changes_without_normalization'] == []
assert s['unknown_count_entries']['candidate'].get('storage', 0) == 0
assert s['storage_blocker_resolution']['final_fresh_record']['checks']['storage'] == {
    'functions': 7, 'obligations': 142, 'proved': 142, 'unproved': []}
assert s['coverage']['proof_counts']['storage']['candidate']['obligations'] == 25816

repo = Path(p['repo'])


def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()


assert git('rev-parse', 'HEAD') == CANDIDATE
assert git('rev-parse', 'HEAD^{tree}') == TREE and not git('status', '--porcelain')
for commit, expected_tree in ((CANDIDATE, TREE), (INTEGRATED, TREE), (BASE_PROOF, BASE_TREE), (BASE_RELEASE, BASE_TREE)):
    assert git('rev-parse', commit + '^{tree}') == expected_tree
assert p['commit'] == a['commit'] == v['commit'] == r['candidate_commit'] == b['candidate_commit'] == s['candidate_commit'] == CANDIDATE
assert p['tree'] == a['tree'] == v['tree'] == r['candidate_tree'] == b['candidate_tree'] == s['candidate_tree'] == TREE
assert s['observed_integrated_release_commit'] == INTEGRATED
assert s['baseline_proof_commit'] == BASE_PROOF and s['baseline_published_commit'] == BASE_RELEASE
assert eq['pairs']['alpha3_storage_repair']['release_or_integration_commit'] == INTEGRATED
assert eq['pairs']['alpha2']['release_or_integration_commit'] == BASE_RELEASE

checks = {
    'complete_fresh_single_attempt_and_all_2699_records': True,
    'all_2550_baseline_programs_and_175_storage_selections_retained': True,
    'exact_196_storage_selections_fully_proved_without_unknowns': True,
    'source_and_integrated_complete_trees_independently_equal': True,
    'published_alpha2_and_baseline_complete_trees_independently_equal': True,
    'clean_frozen_source_and_prepared_checker_identities_verified': True,
    'all_final_record_and_artifact_hashes_bound': True,
    'all_37_early_attribution_pairs_bound_to_final_snapshots_and_counts': True,
    'all_38_denominator_and_proved_decreases_independently_disposed': True,
    'enum_signature_reuse_and_renaming_accounted': True,
    'tomllib_exact_flags_receiver_guards_retained_at_runtime': True,
    'storage_net_decrease_includes_offsetting_added_low_word_sites': True,
    'shared_raw_residuals_unchanged_without_normalization': True,
    'all_added_counted_gaps_and_unknown_counts_explicit': True,
    'all_542_union_and_409_payload_residuals_remain_unproved': True,
    'native_execution_evidence_is_distinct_from_lean_proof': True,
    'handwritten_typeerror_deviation_is_not_cpython_parity': True,
    'historical_failed_censuses_preserved_without_reuse': True,
    'completed_semantic_json_and_markdown_independently_reviewed': True,
}
result = {
    'schema_version': 1,
    'status': 'accepted_with_explicit_model_limits',
    'reviewed_utc': datetime.now(timezone.utc).isoformat(),
    'candidate_commit': CANDIDATE, 'candidate_tree': TREE,
    'observed_integrated_release_commit': INTEGRATED,
    'baseline_proof_commit': BASE_PROOF, 'baseline_published_commit': BASE_RELEASE,
    'baseline_tree': BASE_TREE,
    'checks': checks,
    'coverage': {'baseline_programs': 2550, 'candidate_programs': 2699, 'added_programs': 149,
                 'baseline_storage_selections': 175, 'candidate_storage_selections': 196},
    'execution': {'fresh_attempts': 1, 'same_source_resumes': 0, 'prior_source_records_reused': False,
                  'mode': 'one worker, spawn, 300-second inspection timeout'},
    'proof_counts': s['coverage']['proof_counts'],
    'strict_storage': {'obligations': 25816, 'proved': 25816, 'unproved_function_entries': 0,
                       'unknown_count_functions': 0, 'repaired_target': {'obligations': 142, 'proved': 142}},
    'denominator_decrease_rows': 38,
    'net_decreases_by_category': s['net_decreases_by_category'],
    'new_residuals': {'union_functions': 21, 'union_fixtures': 9, 'union_obligations_rejected': 542,
                      'union_payload_obligations_unproved': 409, 'gc_obligations_rejected': 3,
                      'fields_unknown_count_functions': 1},
    'unknown_count_function_entries': {'baseline': 443, 'candidate': 444,
                                      'unit': 'program/check/function entries; unknown obligation counts are excluded from numerical denominators'},
    'evidence': {name: identity(path) for name, path in paths.items()},
    'limits': [
        'Acceptance is a source-bound release qualification with explicit model limits, not a claim that all obligations or compiler/runtime behavior are proved.',
        'All shared rejected/unsupported dictionaries remain exactly unchanged. Every added rejected or unsupported entry is retained; no blanket normalization or unknown-count waiver is used.',
        'The complex first-failure review does not prove later obligations in those functions. The payload model shares the union-function verdict and its additional 409 unproved obligations remain explicit.',
        'The Decimal field case has an unknown count. Native execution evidence and source/IR contracts do not create Lean theorems or a complete coverage percentage.',
        'Retained b0 native executions are bridged by exact production-source equivalence to the final proof-only repairs, not represented as new runs. complex_union_none uses a handwritten TypeError deviation oracle.',
        'Historical b0 and 94f4 failures remain failed/incomplete as recorded. Their process-kill causes are unproven; none of their records enters this fresh census.',
        'This receipt makes no current-branch or publication claim. The parent owns fresh GitHub checks, reviews, release-head/base validation, merge and publication.',
    ],
}
lines = [
    '# Independent final alpha3 qualification', '',
    '**Accepted with explicit model limits.** The complete fresh census is pinned to '
    f'`{CANDIDATE}`, tree `{TREE}`. I independently resolved the same complete tree for '
    f'integrated release head `{INTEGRATED}` and the published-alpha2/baseline proof tree pair.', '',
    'The fresh single attempt completed all **2,699 programs** and **196 strict-storage selections**. '
    'All 2,550 baseline programs and all 175 baseline selections remain. The completed report, records, '
    'acceptance, exact delta, source/checker identities, final snapshot/count binding and semantic '
    'disposition are hash-bound in the JSON companion. No prior-source records were reused.', '',
    'Strict storage proves **25,816/25,816** counted obligations with no rejected, unsupported or '
    'unknown-count storage function. The repaired optional-tuple target independently appears as '
    '**142/142** in the final fresh census. Its earlier 8/8 known subtotal with three unknown functions '
    'remains a historical gate failure.', '',
    '## Denominator and residual review', '',
    'All **38 decreases** are independently accounted for by exact source/IR sites and final counts. '
    'This includes enum specialization signatures and suffix reuse, 21 Output.flags checks now retained '
    'at runtime, omitted unreferenced GC helpers, moved identity observations, storage representation '
    'changes with offsetting new low-word sites, and one access moved to explicit runtime bounds checks. '
    'All 37 early null/GC/storage attribution pairs match the final census snapshots and counts; the '
    'remaining access pair retains its separate emitted-IR/runtime review.', '',
    'Shared residual dictionaries are exactly unchanged without normalization. The new coverage '
    'retains **542 rejected union reads and 409 unproved payload-bit obligations** across 21 functions '
    'in nine complex fixtures, **three rejected GC obligations**, and **one unknown-count Decimal '
    'field-initialization function**. Unknown-count program/check/function entries rise from 443 to '
    '444; these are not counts of missing obligations. Native JIT/AOT evidence supports the reviewed '
    'runtime behavior without granting Lean proofs. The complex-null TypeError oracle is a handwritten '
    'deviation, not a CPython-parity assertion.', '',
    '## Scope', '',
    'This accepts the recorded bounded-model qualification and explicit residual dispositions. '
    'It does not assert complete formal correctness, prove all later obligations after a first failure, '
    'or waive unsupported cases. The original b0 interruption and complete 94f4 strict-storage failure '
    'remain separate evidence, with unproven process-kill causes. The parent still owns live release '
    'head/base, CI/review checks, merge and publication.', '',
]
assert all(checks.values())
(OUT / 'final-acceptance.json').write_text(json.dumps(result, indent=2) + '\n')
(OUT / 'final-acceptance.md').write_text('\n'.join(lines))
print(json.dumps({'status': result['status'], 'checks': len(checks),
                  'acceptance': identity(OUT / 'final-acceptance.json'),
                  'markdown': identity(OUT / 'final-acceptance.md')}, indent=2))
