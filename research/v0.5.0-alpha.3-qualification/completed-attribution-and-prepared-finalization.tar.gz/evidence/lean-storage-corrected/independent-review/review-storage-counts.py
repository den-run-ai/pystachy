"""Independently verify the two storage denominator changes from retained data."""
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
from raw_json_review import canonical_digest, identity, top_array, verify

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
IPATH = ROOT / "count-attribution/inventory.json"
QPATH = ROOT / "storage-denominator-review/review.json"
PPATH = ROOT.parent / "lean/vtuple-count-attribution-support/review.json"
assert identity(IPATH)["sha256"] == "7200136d2f198e297688a66aeceb60eb1e7ade0423e8f2dd27a286fb098ccb00"
assert identity(QPATH)["sha256"] == "80452912146b9f9421d01888694ce47de54fa07dc4ebc6a6308460a7e0a41012"
inventory = json.loads(IPATH.read_text())
qualification = json.loads(QPATH.read_text())
publication = json.loads(PPATH.read_text())
rows = {row["program"]: row for row in inventory["rows"]}
program_names = {"identity_boundary": "tests/deviations/dynany_identity_boundary.py",
                 "vtuple_materialization": "tests/programs/numbers/python_int_vtuple_materialization.py"}
reports = {}
for kind, program in program_names.items():
    entry = rows[program]
    q = qualification[kind]
    verify(entry["site_excerpts"])
    excerpt = json.loads(Path(entry["site_excerpts"]["path"]).read_text())
    sides, typed, extracted = {}, {}, {}
    for side in ("baseline", "candidate"):
        se = entry["sides"][side]
        snapshot_info = verify(se["snapshot"])
        extraction_info = verify(se["extraction"])
        verify(se["source"])
        extracted[side] = json.loads(Path(extraction_info["path"]).read_text())
        text = Path(snapshot_info["path"]).read_text()
        all_functions = {fn["symbol"]: fn for fn in top_array(text, "functions")}
        del text
        typed[side] = {fn["symbol"]: fn for fn in excerpt["sides"][side]["functions"]}
        assert all(fn == all_functions[name] for name, fn in typed[side].items())
        counts = extracted[side]["checks"]["storage"]
        assert counts["totals"] == se["checks"]["storage"]["totals"]
        assert all(fn["proof_executed"] is False for fn in counts["functions"])
        details = []
        expected = ([q["sides"][side]["storage"]] if kind == "identity_boundary"
                    else q["sides"][side]["changed_functions"])
        for check in expected:
            raw = next(fn for fn in counts["functions"] if fn["function"] == check["function"])
            assert all(check[key] == value for key, value in raw.items())
            fn = typed[side][check["function"]]
            definitions = {f"%t{n}": {"block": b["label"], "offset": i, "operation": op}
                           for b in fn["blocks"] for i, op in enumerate(b["operations"]) for n in op["results"]}
            contexts = []
            for site in check["sites"]:
                if site["kind"] != "low-word":
                    continue
                definition = definitions[site["source"]]
                assert definition["operation"]["op"] == "big.lo"
                parent = definitions.get(definition["operation"]["operands"][0]["value"])
                uses = [{"block": b["label"], "offset": i, "operation": op}
                        for b in fn["blocks"] for i, op in enumerate(b["operations"])
                        if any(a["value"] == site["source"] for a in op["operands"])]
                contexts.append({"site": site, "definition": definition, "parent": parent, "uses": uses})
            expected_context = (q["sides"][side]["low_word_context"] if kind == "identity_boundary"
                                else check["low_word_context"])
            assert contexts == expected_context
            operations = [{"block": b["label"], "offset": i, "operation": op}
                          for b in fn["blocks"] for i, op in enumerate(b["operations"])]
            guards = [op for op in operations if op["operation"]["op"] == "check"
                      and op["operation"]["text"] == "OverflowError: Python int too large to convert to C long"]
            calls = [op for op in operations if op["operation"]["op"] == "call" and op["operation"]["text"] == "@f.item"]
            details.append({"function": fn["symbol"], "function_sha256": canonical_digest(fn),
                            "inventory": raw, "site_kinds": dict(Counter(s["kind"] for s in raw["sites"])),
                            "low_word_context": contexts, "overflow_guards": guards, "item_calls_in_export_order": calls,
                            "tuple_operations": [op for op in operations if op["operation"]["op"].startswith("tuple.")],
                            "vtuple_operations": [op for op in operations if op["operation"]["op"].startswith("vtuple.")]})
        sides[side] = {"snapshot": snapshot_info, "extraction": extraction_info,
                       "source": se["source"], "totals": counts["totals"], "functions": details}
    if kind == "identity_boundary":
        assert sides["baseline"]["totals"]["obligations"] == 2
        assert sides["candidate"]["totals"]["obligations"] == 1
        gc = {}
        for side in ("baseline", "candidate"):
            fn = typed[side]["@main.init"]
            check = extracted[side]["checks"]["gc"]["functions"][0]
            assert check == q["sides"][side]["gc"]
            blocks = {b["label"]: b for b in fn["blocks"]}
            sites = [{"normalized_node": node, "origin": origin,
                      "operation": blocks[origin[0]]["operations"][origin[1]]}
                     for node, origin in check["sites"].items()]
            assert sites == q["sides"][side]["gc_site_operations"]
            gc[side] = {"obligations": check["obligations"], "sites": sites}
            verify(q["sides"][side]["source_copy"])
        assert gc["baseline"]["obligations"] == 8 and gc["candidate"]["obligations"] == 4
        lost_gc = [s for s in gc["baseline"]["sites"] if any("list[opt[float]]" in a["type"] for a in s["operation"]["operands"])]
        assert lost_gc == q["removed_optional_gc_sites"] and len(lost_gc) == 4
        assert all(any("list[union[float,int]]" in a["type"] for a in s["operation"]["operands"])
                   for s in gc["candidate"]["sites"])
        old_low = sides["baseline"]["functions"][0]["low_word_context"]
        new_low = sides["candidate"]["functions"][0]["low_word_context"]
        assert [c["parent"]["operation"]["text"] for c in old_low] == ["big.from_str", "big.op"]
        assert [c["parent"]["operation"]["text"] for c in new_low] == ["big.op"]
        assert old_low[0]["uses"][0]["operation"]["op"] == "vtuple.make"
        reports[kind] = {"program": program, "sides": sides, "gc": gc,
                         "disposition": q["disposition"]}
    else:
        assert sides["baseline"]["source"]["sha256"] == sides["candidate"]["source"]["sha256"]
        checks = {side: {x["function"]: x for x in extracted[side]["checks"]["storage"]["functions"]}
                  for side in ("baseline", "candidate")}
        for name in ("@main.init", "@f.dynamic", "@f.converted"):
            assert checks["baseline"][name] == checks["candidate"][name]
        expected_counts = {"baseline": {"@main.init": 8, "@f.small": 6, "@f.optional": 18, "@f.dynamic": 6, "@f.converted": 8},
                           "candidate": {"@main.init": 8, "@f.small": 8, "@f.optional": 7, "@f.dynamic": 6, "@f.converted": 8}}
        for side in ("baseline", "candidate"):
            assert {k: v["obligations"] for k, v in checks[side].items()} == expected_counts[side]
            for fn in sides[side]["functions"]:
                assert len(fn["overflow_guards"]) == 2
                assert len(fn["item_calls_in_export_order"]) == (1 if fn["function"] == "@f.optional" else 2)
                assert len(fn["vtuple_operations"]) == 1
                if side == "candidate":
                    assert not fn["tuple_operations"]
        old_optional = next(x for x in sides["baseline"]["functions"] if x["function"] == "@f.optional")
        new_optional = next(x for x in sides["candidate"]["functions"] if x["function"] == "@f.optional")
        assert old_optional["site_kinds"] == {"low-word": 6, "tail-marker": 2, "narrowing": 6, "tuple-decode": 4}
        assert new_optional["site_kinds"] == {"low-word": 7}
        assert new_optional["vtuple_operations"][0]["operation"]["operands"][1] == {"value": "null", "type": "opt[int]"}
        for side in q["retained_ir"].values():
            for info in side.values():
                verify(info)
        reports[kind] = {"program": program, "sides": sides, "unchanged_function_inventories":
                         {name: checks["baseline"][name] for name in ("@main.init", "@f.dynamic", "@f.converted")},
                         "retained_ir": q["retained_ir"], "disposition": q["disposition"]}

for info in qualification["evidence"].values():
    verify(info)
source = publication["source_explanation"]
verify({"path": source["path"], "sha256": source["sha256"]})
result = {"schema_version": 1, "status": "independently_reviewed_storage_denominators_pending_final_census_binding",
          "observed_utc": datetime.now(timezone.utc).isoformat(), "source_commits": inventory["source_commits"],
          "inventory": identity(IPATH), "qualification_review": identity(QPATH), "publication_support": identity(PPATH),
          "script": identity(Path(__file__)), "raw_json_helper": identity(HERE / "raw_json_review.py"),
          "storage_decrease": 10, "identity_boundary_gc_decrease": 4,
          "checks": {"both_raw_snapshot_pairs_hashed": True, "all_selected_typed_functions_match_raw": True,
                     "all_site_and_low_word_context_matches": True, "materialization_source_unchanged": True,
                     "materialization_counts_reconciled_with_increase": True, "final_overflow_checks_remain": True,
                     "item_evaluation_calls_remain": True, "original_changed_input_review_retained": True},
          "programs": reports,
          "limits": ["Candidate snapshot/count binding to the fresh final census is still mandatory.",
                     "Existing or future Lean proof verdicts are not inferred from the extracted inventory; proof_executed remains false.",
                     "Native/original-input and promoting replacement coverage has its own bounded scope, retained by the linked source evidence.",
                     "No compiler, normalizer, theorem checker or runtime was executed by this review. No broad IR normalization was used."]}
(HERE / "storage-count-attribution-review.json").write_text(json.dumps(result, indent=2) + "\n")
(HERE / "storage-count-attribution-review.md").write_text("""# Independent storage denominator review

Both storage decreases and the associated identity-boundary GC decrease are accounted for in exact retained source and IR. All four raw snapshots were rehashed; complete selected typed functions match the compact excerpts, and every recorded low-word definition, producer and use matches the raw function.

The edited identity-boundary deviation loses one storage obligation for `int(\"1000\")` in the removed typed-VTuple observation. Its surviving low word comes from the wide `big.op` expression. The four removed GC sites are the optional-float-list append, global store and two reads. The remaining four sites all belong to the union-list observation. The original input audit and precise promoting-int replacements remain separate evidence; generic VTuple coverage is not relabeled as a storage proof.

The unchanged VTuple-materialization fixture changes **46 → 37**, with `optional` **18 → 7** and `small` **6 → 8**; the other three complete inventory records and graph hashes are unchanged. The intermediate fixed tuple disappears, removing two tail-marker, six narrowing and four tuple-decode obligations. Low-word uses rise by one in `optional` and two in `small`, yielding **−12 + 1 + 2 = −9**. Each function retains both explicit overflow checks. `item` is called once in `optional` and twice in `small`, in source order, before final VTuple materialization. The optional tuple retains its explicit null middle element and directly coerced endpoint values; identity companions account for the new low-word uses.

The full old/new LLVM bodies and qualification/publication support are hash-bound in JSON. This attributes the denominator and keeps the runtime checks distinct from theorem-checker verdicts. No compiler, normalizer, Lean checker or runtime was run. Final fresh-census snapshot/count binding and strict-storage acceptance remain mandatory.
""")
print(json.dumps({"status": result["status"], "review": identity(HERE / "storage-count-attribution-review.json")}))
