"""Read retained JSON only; independently map enum null-count changes by type.

No compiler, normalizer, runtime or theorem checker is imported or executed.
The numeric specialization suffix is matched only within five named enum
function families, with exact parameter and return representations retained.
This does not normalize IR or alter the final census.
"""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
INVENTORY = ROOT / "count-attribution/inventory.json"
EXPECTED = "7200136d2f198e297688a66aeceb60eb1e7ade0423e8f2dd27a286fb098ccb00"
FAMILIES = {"@f.enum$_int_of", "@f.enum$_str_of", "@m.enum$IntEnum.__eq__",
            "@m.enum$IntFlag.__eq__", "@m.enum$StrEnum.__eq__"}

def identity(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return {"path": str(path), "sha256": h.hexdigest(), "bytes": path.stat().st_size}

def verified(info):
    actual = identity(info["path"])
    assert actual == info, (actual, info)
    return json.loads(Path(info["path"]).read_text())

def family(fn):
    stem = re.sub(r"\.\d+$", "", fn["symbol"])
    return stem if stem in FAMILIES else None

def signature(fn):
    return (family(fn), tuple((p["name"], p["type"], p["representation"])
                             for p in fn["parameters"]),
            fn["return_type"], fn["return_representation"])

def describe(fn):
    return {k: fn[k] for k in ("symbol", "parameters", "return_type", "return_representation")}

assert identity(INVENTORY)["sha256"] == EXPECTED
inventory = json.loads(INVENTORY.read_text())
assert inventory["all_extractions_completed"]
assert inventory["all_baseline_snapshot_inventories_match_census"]
assert inventory["candidate_reference_count_changes"] == []
assert all(inventory["source_clean_after"].values())
rows = []
renamed_evidence = []
for entry in inventory["rows"]:
    if "null" not in entry["attribution"] or "tomllib" in entry["program"]:
        continue
    snapshots, by_signature, counts = {}, {}, {}
    excerpt = verified(entry["site_excerpts"])
    for side in ("baseline", "candidate"):
        side_entry = entry["sides"][side]
        snapshots[side] = snapshot = verified(side_entry["snapshot"])
        extraction = verified(side_entry["extraction"])
        assert extraction["checks"] == side_entry["checks"] or all(
            extraction["checks"][name] == {k: v for k, v in check.items() if k != "matches_reference_counts"}
            for name, check in side_entry["checks"].items())
        assert extraction["snapshot_sha256"] == side_entry["snapshot"]["sha256"]
        counts[side] = {}
        by_signature[side] = {}
        for fn in snapshot["functions"]:
            if family(fn):
                key = signature(fn)
                by_signature[side].setdefault(key, []).append(fn)
        raw_functions = {fn["symbol"]: fn for fn in snapshot["functions"]}
        for fn in excerpt["sides"][side]["functions"]:
            assert fn == raw_functions[fn["symbol"]]
        for record in excerpt["sides"][side]["nullcheck_evidence"]:
            assert record["record"] == snapshot["nullcheck_evidence"][record["pass_index"]]
        for fn in extraction["checks"]["null"]["functions"]:
            counts[side].setdefault(fn["function"], []).append(fn)
            rec = snapshot["nullcheck_evidence"][fn["pass_index"]]
            assert rec["before"]["symbol"] == fn["function"]
            assert rec["reported_rewrites"] == fn["obligations"] == len(fn["removed_sites"])
            before = {b["label"]: b for b in rec["before"]["blocks"]}
            after = {b["label"]: b for b in rec["after"]["blocks"]}
            for site in fn["removed_sites"]:
                assert before[site["block"]]["operations"][site["offset"]] == site["operation"]
                assert site["operation"] not in after.get(site["block"], {}).get("operations", [])
    losses, retained_renames, reused_names = [], [], []
    old_names = {fn["symbol"]: fn for fn in snapshots["baseline"]["functions"]}
    new_names = {fn["symbol"]: fn for fn in snapshots["candidate"]["functions"]}
    duplicate_signatures = {side: [{"functions": [describe(f) for f in functions],
                                   "null_obligations": [sum(r["obligations"] for r in counts[side].get(f["symbol"], []))
                                                        for f in functions]}
                                  for functions in by_signature[side].values() if len(functions) > 1]
                            for side in ("baseline", "candidate")}
    for old in (fn for functions in by_signature["baseline"].values() for fn in functions):
        key = signature(old)
        before = counts["baseline"].get(old["symbol"], [])
        if not before:
            continue
        matches = by_signature["candidate"].get(key, [])
        # Exports can contain distinct specializations with identical printed
        # argument types. Do not silently merge or pick one. A retained match
        # here must be unique on both sides; unmatched old functions stay raw.
        assert not matches or (len(matches) == 1 and len(by_signature["baseline"][key]) == 1)
        new = matches[0] if matches else None
        after = counts["candidate"].get(new["symbol"], []) if new else []
        nb = sum(r["obligations"] for r in before)
        na = sum(r["obligations"] for r in after)
        if nb != na:
            assert new is None and nb == 1 and na == 0
            assert all(s["operation"]["text"] == "AttributeError: 'NoneType' object has no attribute '_value_'"
                       for rec in before for s in rec["removed_sites"])
            losses.append({"old": describe(old), "new_same_typed_signature": None,
                           "before_obligations": nb, "after_obligations": na,
                           "exact_old_removed_sites": before})
        if new and old["symbol"] != new["symbol"]:
            assert nb == na
            retained_renames.append({"old": describe(old), "new": describe(new),
                                    "before_obligations": nb, "after_obligations": na,
                                    "old_removed_sites": before, "new_removed_sites": after})
            renamed_evidence.append({"program": entry["program"], "old": old, "new": new,
                "old_null_passes": [snapshots["baseline"]["nullcheck_evidence"][r["pass_index"]] for r in before],
                "new_null_passes": [snapshots["candidate"]["nullcheck_evidence"][r["pass_index"]] for r in after]})
        same_name = new_names.get(old["symbol"])
        if same_name and signature(old) != signature(same_name):
            reused_names.append({"old": describe(old), "new": describe(same_name),
                                 "old_removed_sites": before,
                                 "new_removed_sites": counts["candidate"].get(same_name["symbol"], [])})
    expected_drop = sum(x["before_obligations"] - x["after_obligations"]
                        for x in entry["attribution"]["null"])
    assert sum(x["before_obligations"] - x["after_obligations"] for x in losses) == expected_drop
    rows.append({"program": entry["program"], "decrease": expected_drop,
                 "snapshots": {side: entry["sides"][side]["snapshot"] for side in snapshots},
                 "site_excerpts": entry["site_excerpts"],
                 "exact_symbol_delta": entry["attribution"]["null"],
                 "duplicate_exported_signature_groups_retained_separately": duplicate_signatures,
                 "lost_typed_specializations": losses,
                 "retained_typed_specializations_with_renamed_symbol": retained_renames,
                 "same_symbol_reused_with_different_signature": reused_names})

assert len(rows) == 11 and sum(row["decrease"] for row in rows) == 49
assert len(renamed_evidence) == 1
assert renamed_evidence[0]["program"].endswith("lib_enum_intflag.py")
renamed_path = HERE / "enum-renamed-specialization-evidence.json"
renamed_path.write_text(json.dumps(renamed_evidence, indent=2) + "\n")
report = {"status": "reviewed_denominator_attribution_pending_final_census_binding",
          "observed_utc": datetime.now(timezone.utc).isoformat(),
          "baseline_commit": inventory["source_commits"]["baseline"],
          "candidate_commit": inventory["source_commits"]["candidate"],
          "inventory": identity(INVENTORY), "review_script": identity(Path(__file__)),
          "programs": len(rows), "net_null_obligations_decrease": 49,
          "exact_old_removal_message": "AttributeError: 'NoneType' object has no attribute '_value_'",
          "renamed_specialization_evidence": identity(renamed_path),
          "matching_scope": "Five explicit enum function families, exact parameter names/types/representations and return type/representation; raw symbols and records retained. No IR/global/constant normalization.",
          "limitations": ["The early candidate snapshots require exact matching to the fresh final-source census.",
                          "Removed denominator sites are not new proofs; this review attributes why their old typed functions are no longer selected.",
                          "Same symbol names do not establish same specialization; old _int_of.3 in lib_enum_intflag survives as new _int_of.2.",
                          "No compiler, runtime, Lean checker or normalizer was executed."],
          "rows": rows}
(HERE / "enum-count-attribution-review.json").write_text(json.dumps(report, indent=2) + "\n")
lines = ["# Independent enum null-denominator review", "", 
         f"Candidate: `{report['candidate_commit']}`. Baseline: `{report['baseline_commit']}`.", "",
         "All 49 fewer null-removal obligations across 11 enum fixtures have exact typed-specialization attribution. Their old sites all removed a `NoneType._value_` guard. This is a review of the retained diagnostic snapshots, pending exact binding to the fresh final-source census.", "",
         "## Symbol identity matters", "",
         "In `lib_enum_plain_isinstance`, seven old symbols disappear and five names are reused for different signatures: `StrEnum.__eq__.1/.2` change `other` to `Any/dyn`; `_str_of.1/.2` change `x` to `Any/dyn`; `_int_of.3` changes `(IntFlag, IntEnum, str) -> int` to `(Any, IntFlag, str) -> Any`. The 12 old typed specializations carrying one guard each are absent.", "",
         "In `lib_enum_intflag`, the raw symbol delta alone would be misleading. Old `_int_of.3` `(I, Number, str) -> int` survives as new `_int_of.2`, retaining its identical one-site null-removal obligation. The actual lost helper specialization is old `_int_of.2` `(I, I, str) -> int`, alongside `IntEnum.__eq__.1` `(Number, I)` and `IntFlag.__eq__.3` `(I, I)`. These account for the net decrease of three. Full old/new typed functions and null passes are retained separately.", "",
         "| Fixture | Fewer null-removal obligations |", "| --- | ---: |"]
lines += [f"| {Path(row['program']).name} | {row['decrease']} |" for row in rows]
lines += ["", "The review rehashed each raw snapshot and extraction, matched all compact function/null-pass excerpts to the raw snapshots, verified exact old removed operations and their absence after the recorded pass, and matched the per-program arithmetic. No broad normalization was used. No execution or theorem-checker verdict was produced; final census binding and semantic approval remain separate."]
(HERE / "enum-count-attribution-review.md").write_text("\n".join(lines) + "\n")
print(json.dumps({"status": report["status"], "programs": len(rows), "decrease": 49,
                  "review": identity(HERE / "enum-count-attribution-review.json")}))
