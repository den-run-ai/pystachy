"""Independent read-only arithmetic/coverage audit of the completed Lean evidence.

This imports no compiler or checker, executes no proof, and changes only its own
derived review artifact. Semantic dispositions remain a separate manual review.
"""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
BASE = Path('/workspace/scratch/7dd0519bc14a/lean-reports/alpha2-storage-lean-records.jsonl')
BASE_SHA = '98d2cd703064e39dbb14e41f3d13bb1b5df7bbcf4d30903966db4b427ecd09a6'
COMMON = {'payload', 'access', 'null', 'union', 'union_payload', 'fields', 'gc'}
CONDITIONAL = {'int', 'int_inline', 'storage'}

def read(path):
    return json.loads(path.read_text())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def inventory(names):
    return {'count': len(names), 'sha256': sha256(json.dumps(sorted(names, key=str.encode)).encode()).hexdigest()}

def load(path):
    raw = path.read_bytes()
    assert raw.endswith(b'\n'), 'Record stream is not complete at a line boundary'
    lines = [json.loads(line) for line in raw.splitlines()]
    assert set(lines[0]) == {'header'}
    header, rows = lines[0]['header'], lines[1:]
    names = [r['program'] for r in rows]
    assert len(names) == len(set(names))
    assert inventory(names) == header['inventory']
    assert len(header['promoting']) == len(set(header['promoting']))
    selected = set(header['promoting'])
    assert selected <= set(names)
    totals, unknown, numerical_gaps, residuals, storage_gaps = {}, [], [], [], []
    for row in rows:
        assert not row.get('error') and not row.get('failed'), row['program']
        assert re.fullmatch('[0-9a-f]{64}', row['snapshot_sha256'])
        assert set(row['checks']) == COMMON | (CONDITIONAL if row['program'] in selected else set())
        for key, value in row['checks'].items():
            for field in ('functions', 'obligations', 'proved'):
                assert type(value[field]) is int and value[field] >= 0
            assert value['proved'] <= value['obligations']
            total = totals.setdefault(key, dict(programs=0, functions=0, obligations=0, proved=0))
            total['programs'] += value['obligations'] > 0
            for field in ('functions', 'obligations', 'proved'):
                total[field] += value[field]
            for item in value['unproved']:
                assert item['status'] in ('rejected', 'unsupported')
                count = item['obligations']
                assert count is None or (type(count) is int and count >= 0)
                entry = dict(program=row['program'], check=key, **item)
                residuals.append(entry)
                if count is None:
                    unknown.append(entry)
            known_residual_count = sum(i['obligations'] or 0 for i in value['unproved'])
            counted_gap = value['obligations'] - value['proved']
            if counted_gap != known_residual_count:
                numerical_gaps.append({'program': row['program'], 'check': key,
                                       'counted_gap': counted_gap,
                                       'known_residual_count': known_residual_count,
                                       'residuals': value['unproved']})
            if row['program'] in selected and key == 'storage':
                if value['obligations'] != value['proved'] or value['unproved']:
                    storage_gaps.append({'program': row['program'], 'storage': value})
    return header, dict(zip(names, rows)), totals, unknown, numerical_gaps, residuals, storage_gaps

assert digest(BASE) == BASE_SHA
prepared, acceptance, delta = [read(ROOT / name) for name in ('prepared.json', 'acceptance.json', 'delta-alpha2.json')]
failed_acceptance_checks = [k for k, v in acceptance['checks'].items() if not v]
assert failed_acceptance_checks == [], failed_acceptance_checks
assert acceptance['programs'] == 2699 and acceptance['storage_programs'] == 196
assert acceptance['records_sha256'] == digest(ROOT / 'records.jsonl')
assert acceptance['report_sha256'] == digest(ROOT / 'report.md')
old_h, old, old_t, old_unknown, old_gaps, old_res, old_storage_gaps = load(BASE)
new_h, new, new_t, new_unknown, new_gaps, new_res, new_storage_gaps = load(ROOT / 'records.jsonl')
assert not old_storage_gaps and not new_storage_gaps
assert new_storage_gaps == acceptance['storage_gaps']
assert acceptance['checks']['strict_storage_all_accepted'] == (not new_storage_gaps)
assert len(old) == 2550 and len(old_h['promoting']) == 175
assert len(new) == 2699 and len(new_h['promoting']) == 196
assert set(old) <= set(new) and set(old_h['promoting']) <= set(new_h['promoting'])
assert set(new) == set(prepared['programs'])
assert set(new_h['promoting']) == set(prepared['promoting'])
assert new_h['inputs'] == prepared['inputs']
assert new_h['checker_executables'] == prepared['checker_executables']
assert prepared['commit'] == '0a2fe77a580106c197face4d2904be80e3f85dbc'
assert prepared['tree'] == '107460d5f89bdcf37f2741b233eac0568d82604a'
assert new_h['commit'] == prepared['commit'][:12]
assert new_h['python'] == prepared['python'] == '3.13.16'
assert new_h['platform'] == prepared['platform'] == 'linux'
assert new_h['lean'] == 'Lean 4.35.0'
assert acceptance['commit'] == prepared['commit'] and acceptance['tree'] == prepared['tree']
assert not acceptance['incomplete_records'] and not acceptance['invalid_records']
for totals, reference in [(old_t, acceptance['baseline_proof_totals']), (new_t, acceptance['full_proof_totals'])]:
    for key, counts in totals.items():
        assert counts == {field: reference[key][field] for field in counts}

changes, decreases, losses, gap_increases, raw_residual_changes = [], [], [], [], []
for program in sorted(old):
    before, after = old[program]['checks'], new[program]['checks']
    for key in sorted(set(before) | set(after)):
        a, b = before.get(key, {}), after.get(key, {})
        if a != b:
            changes.append(dict(program=program, check=key, before=a, after=b))
        if b.get('obligations', 0) < a.get('obligations', 0):
            decreases.append(dict(program=program, check=key, before=a.get('obligations', 0), after=b.get('obligations', 0)))
        if b.get('proved', 0) < a.get('proved', 0):
            losses.append(dict(program=program, check=key, before=a.get('proved', 0), after=b.get('proved', 0)))
        gap_a, gap_b = (a.get('obligations', 0) - a.get('proved', 0), b.get('obligations', 0) - b.get('proved', 0))
        ua, ub = (sum(i['obligations'] is None for i in v.get('unproved', [])) for v in (a, b))
        if gap_b > gap_a or ub > ua:
            gap_increases.append(dict(program=program, check=key, counted_gap_before=gap_a,
                                      counted_gap_after=gap_b, unknown_count_functions_before=ua,
                                      unknown_count_functions_after=ub,
                                      before_unproved=a.get('unproved', []), after_unproved=b.get('unproved', [])))
        if a.get('unproved', []) != b.get('unproved', []):
            raw_residual_changes.append(dict(program=program, check=key,
                                             before=a.get('unproved', []), after=b.get('unproved', [])))
added = sorted(set(new) - set(old))
added_unproved = [dict(program=p, check=k, **i) for p in added
                  for k, value in new[p]['checks'].items() for i in value['unproved']]
assert added == delta['added_programs']
assert changes == delta['shared_changes']
assert decreases == delta['obligation_decreases']
assert losses == delta['proved_count_decreases']
assert gap_increases == delta['shared_unproved_count_increases']
assert added_unproved == delta['added_program_unproved']
assert delta['missing_programs'] == []
markers = [line for line in (ROOT / 'report.md').read_text().splitlines()
           if line.startswith('<!-- lean-report-completion ')]
assert len(markers) == 1 and markers[0].endswith(' -->')
completion = json.loads(markers[0][len('<!-- lean-report-completion '):-len(' -->')])
assert completion == {'version': 1, 'expected': inventory(list(new)), 'evaluated': inventory(list(new)),
                      'promoting': inventory(new_h['promoting']), 'failed': 0}
# Any additional attempt requires a new explicit review of its frozen prefix,
# source/binary revalidation and primary status. Do not silently generalize it.
run_receipts = sorted(ROOT.glob('run-*.json'))
assert len(run_receipts) == 1, 'Review any interruption/resume explicitly before acceptance'
run_path = run_receipts[0]
run = read(run_path)
assert run['resume'] is False
assert run['report_exit'] == run['status_exit'] == run['audit_exit'] == 0
assert run['jobs'] == 1 and run['cwd'] == prepared['repo']
assert run['source_before'] == run['source_after'] == ''
assert run['commit'] == run['commit_after'] == prepared['commit']
assert run['tree'] == run['tree_after'] == prepared['tree']
assert run['command'] == ['/workspace/scratch/c2b093657c17/dev-venv/bin/python',
    'tools/lean_report.py', '--jobs', '1', '--start-method', 'spawn', '--timeout', '300',
    '--progress', '--output', str(ROOT / 'report.md'), '--records', str(ROOT / 'records.jsonl')]
for info in (run['runner'], run['preparation'], run['audit_script'], run['resources']):
    path = Path(info['path'])
    assert path.stat().st_size == info['bytes'] and digest(path) == info['sha256']
for row in prepared['source_correspondence']:
    assert digest(Path(prepared['repo']) / row['path']) == row['sha256']
for row in prepared['copied_executables'].values():
    assert digest(Path(row['destination'])) == row['sha256']

binding_path = ROOT / 'count-attribution/final-census-binding.json'
binding = read(binding_path)
assert binding['status'] == 'bound_to_complete_final_source_census'
assert binding['checks'] and all(binding['checks'].values())
assert binding['candidate_commit'] == prepared['commit'] and binding['candidate_tree'] == prepared['tree']
assert len(binding['rows']) == 58
assert len(binding['supported_decrease_pairs']) == 37
for info in binding['evidence'].values():
    path = Path(info['path'])
    assert path.stat().st_size == info['bytes'] and digest(path) == info['sha256']

prior_path = ROOT.parent / 'lean-corrected/records.jsonl'
assert digest(prior_path) == '396f4b02ede94afda93ecc796f1da3aa1d3cb022a78939c51c4fc34a22101bbe'
prior_h, prior, _, _, _, _, _ = load(prior_path)
assert set(prior) == set(new)
repair_changes = [dict(program=program, check=key, before=prior[program]['checks'].get(key), after=new[program]['checks'].get(key))
    for program in sorted(new) for key in sorted(set(prior[program]['checks']) | set(new[program]['checks']))
    if prior[program]['checks'].get(key) != new[program]['checks'].get(key)]
assert len(repair_changes) == 1
repair = repair_changes[0]
assert repair['program'] == 'tests/programs/numbers/python_int_optional_tuple_keys.py' and repair['check'] == 'storage'
assert repair['before']['functions'] == repair['after']['functions'] == 7
assert repair['before']['obligations'] == repair['before']['proved'] == 8
assert len(repair['before']['unproved']) == 3
assert all(x['status'] == 'unsupported' and x['obligations'] is None for x in repair['before']['unproved'])
assert repair['after'] == {'functions': 7, 'obligations': 142, 'proved': 142, 'unproved': []}

execution = dict(mode='one fresh immutable-source completed census attempt',
                 attempts=[dict(receipt=str(run_path), receipt_sha256=digest(run_path),
                                log_sha256=digest(Path(run['log'])), **run)],
                 historical_records_reused=False)
result = dict(schema_version=1, status='structural_census_and_exact_delta_verified_semantic_review_separate',
              failed_acceptance_checks=failed_acceptance_checks, storage_gaps=new_storage_gaps,
              commit=prepared['commit'], tree=prepared['tree'],
              baseline_sha256=BASE_SHA, records_sha256=acceptance['records_sha256'],
              report_sha256=acceptance['report_sha256'],
              baseline_programs=len(old), candidate_programs=len(new),
              baseline_storage_programs=len(old_h['promoting']), candidate_storage_programs=len(new_h['promoting']),
              old_totals=old_t, new_totals=new_t,
              obligation_decreases=decreases, proved_count_decreases=losses,
              shared_gap_or_unknown_count_increases=gap_increases,
              exact_raw_shared_residual_changes=raw_residual_changes,
              added_program_unproved=added_unproved,
              baseline_unknown_count_residuals=old_unknown, candidate_unknown_count_residuals=new_unknown,
              numerical_gap_inventory={'baseline': old_gaps, 'candidate': new_gaps},
              baseline_unproved_rows=len(old_res), candidate_unproved_rows=len(new_res),
              exact_changes_from_previous_complete_blocked_census=repair_changes,
              completion=completion, execution=execution,
              final_attribution_binding_sha256=digest(binding_path),
              review_script_sha256=digest(Path(__file__)),
              method='Pure JSON arithmetic, exact record dictionaries, hashes and completion marker; no compiler/checker import or execution. No residual normalization.',
              limits=['Structural acceptance does not establish that every obligation is proved.',
                      'Every raw residual change, count decrease and added residual requires the separate semantic disposition and independent final review.'])
(OUT / 'structural-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('status', 'baseline_programs', 'candidate_programs', 'candidate_storage_programs')}, indent=2))
print(json.dumps({'decreases': len(decreases), 'proved_count_decreases': len(losses),
                  'raw_residual_changes': len(raw_residual_changes), 'gap_increases': len(gap_increases),
                  'added_unproved': len(added_unproved), 'unknown_count_residuals': len(new_unknown)}, indent=2))
