"""Pure data-reading helpers for independent retained-evidence reviews."""
import hashlib
import json
from pathlib import Path


def identity(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return {"path": str(path), "sha256": h.hexdigest(), "bytes": path.stat().st_size}


def verify(info):
    actual = identity(info["path"])
    assert all(actual[key] == value for key, value in info.items()), (actual, info)
    return actual


def canonical_digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def top_array(text, name):
    """Read one item at a time from a pretty-printed top-level JSON array.

    Each retained compiler snapshot is hash checked first. The anchored marker
    is outside escaped JSON strings. raw_decode handles each full JSON item,
    so this avoids materializing all three copies of a large program's IR.
    """
    marker = '\n  "' + name + '": ['
    assert text.count(marker) == 1, name
    index = text.index(marker) + len(marker)
    decoder = json.JSONDecoder()
    while True:
        while text[index].isspace():
            index += 1
        if text[index] == "]":
            return
        item, index = decoder.raw_decode(text, index)
        yield item
        while text[index].isspace():
            index += 1
        if text[index] == "]":
            return
        assert text[index] == ",", (name, index)
        index += 1
