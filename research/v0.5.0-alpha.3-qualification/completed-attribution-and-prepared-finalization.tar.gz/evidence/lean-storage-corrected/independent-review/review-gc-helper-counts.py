"""Read-only attribution of the 16 mappingproxy GC-denominator decreases."""
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
from raw_json_review import canonical_digest, identity, top_array, verify

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
IPATH = ROOT / "count-attribution/inventory.json"
assert identity(IPATH)["sha256"] == "7200136d2f198e297688a66aeceb60eb1e7ade0423e8f2dd27a286fb098ccb00"
inventory = json.loads(IPATH.read_text())
repo = Path(json.loads((ROOT / "prepared.json").read_text())["repo"])
source = "lib/_pystachy_mappingproxy.py"
old_source = subprocess.check_output(["git", "-C", str(repo), "show", inventory["source_commits"]["baseline"] + ":" + source])
new_source = subprocess.check_output(["git", "-C", str(repo), "show", inventory["source_commits"]["candidate"] + ":" + source])
assert old_source == new_source
source_receipt = {"path": source, "unchanged_complete_bytes": True,
                  "sha256": __import__("hashlib").sha256(old_source).hexdigest(), "bytes": len(old_source)}
rows = []
for entry in inventory["rows"]:
    changes = [x for x in entry["attribution"].get("gc", []) if x["function"].endswith(".__ror__")]
    if not changes:
        continue
    assert all(x["function"].startswith("@m._pystachy_mappingproxy$mappingproxy-") for x in changes)
    excerpt_info = verify(entry["site_excerpts"])
    excerpt = json.loads(Path(excerpt_info["path"]).read_text())
    helpers = {}
    side_evidence = {}
    for side in ("baseline", "candidate"):
        se = entry["sides"][side]
        snapshot_info = verify(se["snapshot"])
        extraction_info = verify(se["extraction"])
        extraction = json.loads(Path(extraction_info["path"]).read_text())
        assert extraction["checks"]["gc"] == {k: v for k, v in se["checks"]["gc"].items() if k != "matches_reference_counts"}
        text = Path(snapshot_info["path"]).read_text()
        selected = {x["function"] for x in changes}
        found = {fn["symbol"]: fn for fn in top_array(text, "functions") if fn["symbol"] in selected}
        del text
        assert found == {fn["symbol"]: fn for fn in excerpt["sides"][side]["functions"]
                         if fn["symbol"] in selected}
        assert set(found) == (selected if side == "baseline" else set())
        helpers[side] = found
        llpath = Path(snapshot_info["path"]).with_name("llvm.ll")
        side_evidence[side] = {"snapshot": snapshot_info, "extraction": extraction_info,
                               "llvm": identity(llpath), "llvm_text": llpath.read_text()}
    detail = []
    for item in changes:
        symbol = item["function"]
        assert item["after_records"] == [] and item["after_obligations"] == 0
        assert item["function_absent_in_candidate"]
        assert sum(x["obligations"] for x in item["before_records"]) == item["before_obligations"]
        fn = helpers["baseline"][symbol]
        blocks = {block["label"]: block for block in fn["blocks"]}
        origins = []
        for record in item["before_records"]:
            for node, (block, offset, op, operand) in record["sites"].items():
                raw = blocks[block]["operations"][offset]
                assert raw["op"] == op and operand < len(raw["operands"])
                origins.append({"node": node, "block": block, "offset": offset,
                                "operand": operand, "operation": raw})
        pattern = re.escape(symbol) + r"(?![\w.$-])"
        references = [line for line in side_evidence["baseline"]["llvm_text"].splitlines() if re.search(pattern, line)]
        assert len(references) == 1 and references[0].startswith("define internal ")
        assert not re.search(pattern, side_evidence["candidate"]["llvm_text"])
        body_pattern = r"^define internal [^\n]*" + re.escape(symbol) + r"\([^\n]*\) \{.*?^\}"
        body = re.search(body_pattern, side_evidence["baseline"]["llvm_text"], re.M | re.S)
        assert body
        detail.append({"function": symbol, "parameters": fn["parameters"],
                       "return_type": fn["return_type"], "before_obligations": item["before_obligations"],
                       "after_obligations": 0, "typed_function_sha256": canonical_digest(fn),
                       "exact_origin_operations": origins, "raw_extraction_records": item["before_records"],
                       "old_llvm_symbol_occurrences": references, "new_llvm_symbol_occurrences": [],
                       "old_complete_llvm_function": body.group(),
                       "disposition": "Previously emitted internal function has no call, address-taken or other symbol reference in the full retained LLVM module; it is absent in the candidate typed and LLVM modules. Its obligations leave the input denominator, not the proof-failure set."})
    rows.append({"program": entry["program"], "site_excerpts": excerpt_info,
                 "sides": {side: {k: v for k, v in evidence.items() if k != "llvm_text"}
                           for side, evidence in side_evidence.items()},
                 "decrease": sum(x["before_obligations"] for x in changes), "helpers": detail})

assert len(rows) == 16
assert sum(len(row["helpers"]) for row in rows) == 18
assert sum(row["decrease"] for row in rows) == 102
result = {"status": "reviewed_gc_helper_denominators_pending_final_census_binding",
          "observed_utc": datetime.now(timezone.utc).isoformat(),
          "source_commits": inventory["source_commits"], "inventory": identity(IPATH),
          "review_script": identity(Path(__file__)), "raw_json_helper": identity(HERE / "raw_json_review.py"),
          "unchanged_library_source": source_receipt,
          "programs": 16, "removed_internal_functions": 18, "gc_denominator_decrease": 102,
          "rows": rows,
          "limits": ["The separate dynany_identity_boundary GC decrease of four is reviewed with its source/storage move.",
                     "Origin records can describe several graph nodes at one typed operation; their cardinality is not substituted for the adapter's obligation count.",
                     "Early candidate snapshots/counts still need exact final-source census binding.",
                     "No compiler, normalizer, theorem checker or runtime was executed. No IR normalization was used."]}
(HERE / "gc-helper-count-attribution-review.json").write_text(json.dumps(result, indent=2) + "\n")
lines = ["# Independent GC helper denominator review", "",
         "Sixteen fixtures lose 102 counted GC obligations because 18 previously emitted internal mappingproxy reflected-union helpers are omitted. Each old helper symbol occurs exactly once in the full retained LLVM module, at its internal definition; there is no call or address-taken reference. Each is absent from the candidate typed function inventory and LLVM module. The complete mappingproxy library file is byte-identical across the two sources.", "",
         "The review rehashed all raw snapshots and compact/extracted inventories, matched the complete typed helper functions to the raw snapshot array, and located every recorded GC origin in the exact old typed operations. Full LLVM helper bodies, signatures, origin operations and source hashes are retained in JSON. Each str/int dictionary helper contributes three counted obligations; the remaining sixteen helper instances contribute six each.", "",
         "| Fixture | Omitted helpers | Fewer GC obligations |", "| --- | ---: | ---: |"]
lines += [f"| {Path(row['program']).name} | {len(row['helpers'])} | {row['decrease']} |" for row in rows]
lines += ["", "The remaining four-obligation GC decrease belongs to the edited identity-boundary deviation and is reviewed separately with its moved observations. These are denominator changes, not newly proved obligations. Final-source census binding remains mandatory; no compiler/checker/runtime execution or broad IR normalization occurred in this review."]
(HERE / "gc-helper-count-attribution-review.md").write_text("\n".join(lines) + "\n")
print(json.dumps({"status": result["status"], "programs": 16, "helpers": 18, "decrease": 102,
                  "review": identity(HERE / "gc-helper-count-attribution-review.json")}))
