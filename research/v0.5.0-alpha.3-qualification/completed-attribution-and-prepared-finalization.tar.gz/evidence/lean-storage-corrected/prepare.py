"""Bind the frozen storage repair to unchanged, identified Lean executables."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys

OUT = Path(__file__).resolve().parent
CONFIG_PATH = OUT / "attribution-config.json"
CONFIG = json.loads(CONFIG_PATH.read_text())
REPO = Path(CONFIG["candidate_repo"])
EXPECTED = CONFIG["candidate_commit"]
TREE = CONFIG["candidate_tree"]
BASE = "b0bda81ec2b9954c3c5e0f658c051439126a5c22"
ORIGIN = Path("/workspace/scratch/f0e0f1c84d2f/pystachy")
PRIOR = Path("/workspace/scratch/9d370b13f051")
FIRST_REPAIR = OUT.parent / "lean/adapter-repair/frozen-repair.json"
STORAGE_REPAIR = OUT.parent / "lean/optional-storage-repair/frozen-repair.json"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def identity(path):
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest(path)}


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()


assert git(REPO, "rev-parse", "HEAD") == EXPECTED
assert git(REPO, "rev-parse", "HEAD^{tree}") == TREE
assert not git(REPO, "status", "--porcelain")
assert not (OUT / "records.jsonl").exists(), "Final checker source requires fresh records."
first = json.loads(FIRST_REPAIR.read_text())
storage = json.loads(STORAGE_REPAIR.read_text())
assert first["base_commit"] == BASE
assert storage["base_commit"] == "94f472d6de5350fc9481ecf3b9ec019d2ecdb4f2"
assert first["proposed_tree"] == storage["base_tree"]
assert storage["repair_tree"] == TREE
first_files = {row["path"]: row for row in first["files"]}
storage_files = storage["files"]
assert not (first_files.keys() & storage_files.keys())
assert set(git(REPO, "diff", "--name-only", BASE, EXPECTED).splitlines()) == first_files.keys() | storage_files.keys()
for path, row in first_files.items():
    assert digest(REPO / path) == digest(row["frozen_copy"]) == row["sha256"], path
for path, row in storage_files.items():
    assert digest(REPO / path) == row["sha256"], path
    assert git(REPO, "rev-parse", f"HEAD:{path}") == row["git_blob"], path
for path, expected in storage["target_inputs"].items():
    assert digest(REPO / path) == expected, path

old_manifest_path = PRIOR / "enum-lean-evidence/final-checker-source-correspondence.json"
old_manifest = json.loads(old_manifest_path.read_text())
source_rows, changed = [], []
repaired = {**first_files, **storage_files}
expected_changes = {"tools/check_lean_guards.py", "tools/lean_report.py", "tools/check_lean_storage.py"}
for row in old_manifest:
    path = row["path"]
    assert digest(ORIGIN / path) == row["sha256"], path
    current = digest(REPO / path)
    if current != row["sha256"]:
        assert path in expected_changes
        assert current == repaired[path]["sha256"]
        changed.append(path)
    source_rows.append({"path": path, "sha256": current,
                        "prior_sha256": row["sha256"],
                        "unchanged_from_binary_origin": current == row["sha256"]})
assert set(changed) == expected_changes
lean_sources = [row for row in source_rows if row["path"].startswith("tools/lean_boundary/")]
assert len(lean_sources) == 19 and all(row["unchanged_from_binary_origin"] for row in lean_sources)

prior_bins = json.loads((PRIOR / "lean-checker-identity.json").read_text())["reused_executables"]
destination = REPO / "tools/lean_boundary/.lake/build/bin"
destination.mkdir(parents=True, exist_ok=True)
copied = {}
for name, row in prior_bins.items():
    source, target = Path(row["path"]), destination / name
    assert digest(source) == row["sha256"], name
    assert not target.exists(), target
    shutil.copy2(source, target)
    assert digest(target) == row["sha256"] and os.access(target, os.X_OK), name
    copied[name] = {"origin": str(source), "destination": str(target), "sha256": digest(target)}

sys.path.insert(0, str(REPO / "tools"))
import lean_report as report

paths = git(REPO, "ls-files", "--", *report.INPUTS["checkers"]).splitlines()
assert set(paths) == {row["path"] for row in source_rows}
inputs = report.inputs()
assert report.clean_inputs(inputs)
programs = report.corpus.corpus()
promoting = report.storage_corpus.select(programs)
assert len(programs) == 2699 and len(promoting) == 196
assert not git(REPO, "status", "--porcelain")
record = {
    "repo": str(REPO), "commit": EXPECTED, "tree": TREE,
    "python": platform.python_version(), "platform": sys.platform,
    "inputs": inputs, "programs": list(programs), "promoting": list(promoting),
    "expected_programs": len(programs), "expected_promoting": len(promoting),
    "checker_executables": report.checker_executables(report.boundary.DEFAULT_CHECKER, report.access.DEFAULT_CHECKER),
    "copied_executables": copied, "source_correspondence": source_rows,
    "unchanged_lean_source_count": len(lean_sources), "changed_adapter_inputs": changed,
    "origin_checkout_commit": git(ORIGIN, "rev-parse", "HEAD"),
    "origin_relevant_source_changes": git(ORIGIN, "status", "--porcelain", "--", *paths),
    "prior_identity_file": str(PRIOR / "lean-checker-identity.json"),
    "prior_identity_sha256": digest(PRIOR / "lean-checker-identity.json"),
    "prior_source_correspondence_sha256": digest(old_manifest_path),
    "first_repair": identity(FIRST_REPAIR), "storage_repair": identity(STORAGE_REPAIR),
    "configuration": identity(CONFIG_PATH), "preparation_script": identity(Path(__file__)),
    "previous_complete_failed_census": identity(OUT.parent / "lean-corrected/complete-blocked-census.json"),
    "fresh_full_records": True,
    "note": "Physical copies of identified Lean executables; all 19 Lean package sources/build inputs match the binary origin. The three changed Python checker/report inputs are bound to the two frozen reviewed repairs. All 2,699 programs will be inspected afresh with one worker. No earlier-checker records or headers are reused; any later resume must remain on this same frozen source and use maintained identity checks.",
}
assert not record["origin_relevant_source_changes"]
(OUT / "prepared.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({key: record[key] for key in ("repo", "commit", "tree", "expected_programs",
                                             "expected_promoting", "unchanged_lean_source_count",
                                             "changed_adapter_inputs")}))
