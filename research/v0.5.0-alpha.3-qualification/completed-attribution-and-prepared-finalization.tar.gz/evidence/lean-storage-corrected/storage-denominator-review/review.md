# Storage denominator changes

Two shared fixtures account for the ten-obligation net storage decrease in the comparison selection. The historical snapshot/count bindings are exact. These inventories come from frozen final source `0a2fe77a`; its fresh census must still match every candidate snapshot and count and pass the strict-storage gate.

## Identity boundary: 2 → 1 storage, 8 → 4 GC

The deviation fixture removes two formerly failing observations after support is added: identity through a typed VTuple holding `int("1000")`, and identity through an optional float list. The remaining union-list and wide-integer observations stay.

The one removed storage obligation is the low word extracted from the `big.from_str` result for the typed tuple's `int("1000")`. The surviving wide-integer low word comes from `big.op` (old `%t252`, new `%t130`). The four removed GC sites are the optional list's append, global store and two reads. All four surviving GC sites belong to the separate union-list observation.

The precise promoting-int positive replacement is `python_int_vtuple_identity.py`, which includes both directives, `int("1000")`, repeated VTuple entries, list conversion and checked helper boundaries. `python_int_optional_container_identity.py` also has storage coverage; the ordinary optional-list identity test adds separate dynamic coverage. The generic VTuple identity test is not being called a storage-proof replacement. The original edited fixture was independently compiled and audited in the retained original-input review.

## VTuple materialization: 46 → 37 storage

This source is unchanged. The net decrease consists of two different changes:

| Function | Alpha2 | Candidate inventory | Change |
|---|---:|---:|---:|
| `main.init` | 8 | 8 | 0 |
| `small` | 6 | 8 | +2 |
| `optional` | 18 | 7 | −11 |
| `dynamic` | 6 | 6 | 0 |
| `converted` | 8 | 8 | 0 |
| Total | 46 | 37 | −9 |

`optional` no longer allocates, fills, narrows and decodes an intermediate fixed tuple before creating the final VTuple. That removes twelve tuple-specific obligations: two tail-marker, six narrowing and four tuple-decode sites. Its direct low-word checks rise from six to seven, including identity capture. Both final integer fit checks and the overflow-raising path remain.

`small` adds two low-word uses for identity capture of its two item-call results. Its final VTuple materialization checks remain. These two new obligations offset part of `optional`'s reduction. This is not a claim that exactly nine old sites were simply deleted.

`review.json` retains every exact old/new site and low-word producer/use context, complete relevant typed functions, both emitted function bodies, raw source/IR hashes and the independent IR disposition. This read-only review ran no compiler, runtime or Lean checker. Final fresh-census binding remains mandatory.
