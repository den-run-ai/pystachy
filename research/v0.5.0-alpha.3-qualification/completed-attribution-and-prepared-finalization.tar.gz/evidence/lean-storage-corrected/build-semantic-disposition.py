"""Build the final semantic disposition only from completed, bound qualification.

All failed earlier attempts remain separate evidence. Rejected and unsupported
model results are explained without turning them into accepted proofs.
"""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
EVIDENCE = OUT.parent
ROOT = OUT.parents[1]


def read(path):
    return json.loads(path.read_text())


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def record_map(path):
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    return rows[0]["header"], {row["program"]: row for row in rows[1:]}


def canonical(row):
    return json.dumps(row, sort_keys=True, separators=(",", ":"))


def unknown_counts(records):
    result = Counter()
    for record in records.values():
        for category, check in record.get("checks", {}).items():
            result[category] += sum(row["obligations"] is None for row in check["unproved"])
    return dict(result)


prepared = read(OUT / "prepared.json")
acceptance = read(OUT / "acceptance.json")
delta = read(OUT / "delta-alpha2.json")
binding = read(OUT / "count-attribution/final-census-binding.json")
receipt = read(OUT / "final-census-receipt.json")
equivalence = read(OUT / "qualification-source-equivalence.json")
inventory_path = OUT / "count-attribution/inventory.json"
inventory = read(inventory_path)
inventory_rows = {row["program"]: row for row in inventory["rows"]}
baseline_header, baseline = record_map(Path(delta["baseline_records"]))
header, candidate = record_map(OUT / "records.jsonl")
_, prior94 = record_map(EVIDENCE / "lean-corrected/records.jsonl")
prior_delta = read(EVIDENCE / "lean-corrected/delta-alpha2.json")

review_paths = {
    "enum": OUT / "independent-review/enum-count-attribution-review.json",
    "gc_helpers": OUT / "independent-review/gc-helper-count-attribution-review.json",
    "tomllib": OUT / "independent-review/tomllib-count-attribution-review.json",
    "storage": OUT / "independent-review/storage-count-attribution-review.json",
    "access": EVIDENCE / "lean/access-count-decrease-1158/review.json",
    "complex": EVIDENCE / "lean-corrected/added-complex-residual-review/review.json",
    "complex_independent": EVIDENCE / "lean-corrected/independent-review/added-complex-independent-review.json",
    "new_gc": EVIDENCE / "lean/complex-copy-gc-independent-review/review.json",
    "native": EVIDENCE / "ci/b0-native-coverage/all-residual-coverage.json",
}
reviews = {name: read(path) for name, path in review_paths.items()}
expected_review_statuses = {
    "enum": "reviewed_denominator_attribution_pending_final_census_binding",
    "gc_helpers": "reviewed_gc_helper_denominators_pending_final_census_binding",
    "tomllib": "independently_verified_exact_tomllib_sites_pending_final_census_binding",
    "storage": "independently_reviewed_storage_denominators_pending_final_census_binding",
    "access": "explained: unchecked load replaced by runtime-checked access",
    "complex_independent": "reviewed_first_failure_dispositions_no_proof_waiver",
    "new_gc": "reviewed_existing_model_limitation_encountered_by_added_fixture",
    "native": "twelve_residual_fixtures_passed_retained_native_jit_and_aot",
}
enum_programs = {row["program"] for row in reviews["enum"]["rows"]}
gc_programs = {row["program"] for row in reviews["gc_helpers"]["rows"]}
toml_programs = {row["program"] for row in reviews["tomllib"]["rows"]}
boundary_program = "tests/deviations/dynany_identity_boundary.py"
materialization_program = "tests/programs/numbers/python_int_vtuple_materialization.py"
storage_programs = {boundary_program, materialization_program}
access_program = reviews["access"]["program"]

dispositions = []
for decrease in delta["obligation_decreases"]:
    program, category = decrease["program"], decrease["check"]
    if category == "null" and program in enum_programs:
        review = "enum"
        reason = "Typed enum comparison specializations and their _value_ null-removal sites change under native comparison dispatch. Matching uses full parameter/return signatures, including reused names and the retained _int_of.3→.2 specialization, not suffix identity alone."
    elif category == "null" and program in toml_programs:
        review = "tomllib"
        reason = "Three Flags receiver checks previously removed by the null pass now remain at runtime: add_pending, the second is_, and unset_all. The receiver is Output.flags (field 1); failure raises AttributeError. Exact before/after pass records preserve each check."
    elif category == "gc" and program in gc_programs:
        review = "gc_helpers"
        reason = "Only unreferenced internal mappingproxy.__ror__ specializations disappear. Each old symbol occurs solely in its definition, and the source library is unchanged. Their complete GC origins are retained."
    elif (category == "storage" and program in storage_programs) or (category == "gc" and program == boundary_program):
        review = "storage"
        reason = ("The deviation source removes the formerly failing VTuple/optional-list observations after support is added; exact removed sites and named positive coverage are retained. The surviving union-list and wide-integer sites remain."
                  if program == boundary_program else
                  "The unchanged source has a net -9 storage count: optional 18→7 (-11), small 6→8 (+2). Twelve intermediate-tuple marker/narrow/decode obligations disappear; three identity-capture low-word obligations are added. Final overflow guards and evaluation order remain.")
    elif category == "access" and program == access_program:
        review = "access"
        reason = "The final [1,None] loop changes from an unchecked backing-array read to pys_list_get_identity plus pys_list_get, both of which call runtime idx() bounds validation. The earlier action-loop unchecked read remains proved; no C-helper Lean proof is claimed."
    else:
        raise AssertionError(f"No semantic disposition for {program} {category}")
    row = {**decrease, "before_proved": baseline[program]["checks"][category]["proved"],
           "after_proved": candidate[program]["checks"][category]["proved"],
           "baseline_snapshot_sha256": baseline[program]["snapshot_sha256"],
           "candidate_snapshot_sha256": candidate[program]["snapshot_sha256"],
           "semantic_review": review, "review": identity(review_paths[review]), "disposition": reason,
           "counted_gap_unchanged": decrease["before"] - baseline[program]["checks"][category]["proved"]
               == decrease["after"] - candidate[program]["checks"][category]["proved"]}
    if program in inventory_rows and category in inventory_rows[program]["attribution"]:
        row["site_excerpts"] = inventory_rows[program]["site_excerpts"]
        row["literal_symbol_count_changes"] = [
            {key: item[key] for key in ("function", "before_obligations", "after_obligations", "function_absent_in_candidate")}
            for item in inventory_rows[program]["attribution"][category]]
    dispositions.append(row)

raw_shared_residual_changes = []
for program in sorted(baseline.keys() & candidate.keys()):
    for category in sorted(baseline[program]["checks"].keys() | candidate[program]["checks"].keys()):
        old = baseline[program]["checks"].get(category, {}).get("unproved", [])
        new = candidate[program]["checks"].get(category, {}).get("unproved", [])
        if old != new:
            raw_shared_residual_changes.append({"program": program, "check": category, "before": old, "after": new})

expected_added_residuals = [row for row in prior_delta["added_program_unproved"] if row["check"] != "storage"]
actual_added_residuals = delta["added_program_unproved"]
complex_programs = {row["program"]: row for row in reviews["complex"]["programs"]}
complex_count_bindings = []
for program, prior_review in complex_programs.items():
    record = candidate[program]
    union = record["checks"]["union"]
    payload = record["checks"]["union_payload"]
    complex_count_bindings.append({"program": program,
                                  "union_gap": union["obligations"] - union["proved"],
                                  "payload_gap": payload["obligations"] - payload["proved"],
                                  "matches_review": union["obligations"] - union["proved"] == prior_review["rejected_union_reads"]
                                    and payload["obligations"] - payload["proved"] == prior_review["unproved_payload_bits"]})
target = "tests/programs/numbers/python_int_optional_tuple_keys.py"
storage_target = candidate[target]["checks"]["storage"]
old_unknowns, new_unknowns = unknown_counts(baseline), unknown_counts(candidate)
totals = {}
for name, values in acceptance["full_proof_totals"].items():
    before = acceptance["baseline_proof_totals"][name]
    totals[name] = {"baseline": {key: before[key] for key in ("programs", "functions", "obligations", "proved")},
                    "candidate": {key: values[key] for key in ("programs", "functions", "obligations", "proved")},
                    "baseline_counted_gap": before["obligations"] - before["proved"],
                    "candidate_counted_gap": values["obligations"] - values["proved"],
                    "baseline_unknown_count_function_entries": old_unknowns.get(name, 0),
                    "candidate_unknown_count_function_entries": new_unknowns.get(name, 0)}

checks = {
    "all_census_acceptance_checks_passed": all(acceptance["checks"].values()),
    "final_census_receipt_passed": receipt["status"] == "complete_and_strict_storage_accepted" and all(receipt["checks"].values()),
    "exact_final_census_binding_passed": binding["status"] == "bound_to_complete_final_source_census" and all(binding["checks"].values()),
    "common_frozen_source": prepared["commit"] == acceptance["commit"] == receipt["candidate_commit"] == binding["candidate_commit"]
        and prepared["tree"] == acceptance["tree"] == receipt["candidate_tree"] == binding["candidate_tree"],
    "proof_and_integrated_release_trees_identical": equivalence["pairs"]["alpha3_storage_repair"]["identical_complete_tree"]
        and equivalence["pairs"]["alpha3_storage_repair"]["proof_commit"] == prepared["commit"]
        and equivalence["pairs"]["alpha3_storage_repair"]["proof_tree"] == prepared["tree"],
    "published_alpha2_and_proof_trees_identical": equivalence["pairs"]["alpha2"]["identical_complete_tree"],
    "baseline_corpus_and_storage_selection_retained": not delta["missing_programs"] and not delta["storage_selection_delta"]["removed"],
    "all_38_decreases_reviewed": len(dispositions) == 38 == len(delta["proved_count_decreases"])
        and len({(r["program"], r["check"]) for r in dispositions}) == 38,
    "all_decreases_preserve_counted_gap": all(row["counted_gap_unchanged"] for row in dispositions),
    "exact_raw_shared_residuals_unchanged": not raw_shared_residual_changes,
    "no_shared_counted_or_unknown_gap_increases": not delta["shared_unproved_count_increases"],
    "all_new_model_residuals_match_reviewed_inventory": Counter(map(canonical, actual_added_residuals))
        == Counter(map(canonical, expected_added_residuals)),
    "complex_union_and_payload_counts_match_reviews": all(row["matches_review"] for row in complex_count_bindings)
        and sum(row["union_gap"] for row in complex_count_bindings) == 542
        and sum(row["payload_gap"] for row in complex_count_bindings) == 409,
    "all_denominator_reviews_bind_exact_inventory": all(
        reviews[key]["inventory"]["sha256"] == identity(inventory_path)["sha256"]
        for key in ("enum", "gc_helpers", "tomllib", "storage")),
    "independent_review_statuses_match_completed_reviews": all(
        reviews[name]["status"] == status for name, status in expected_review_statuses.items()),
    "independent_storage_site_checks_passed": all(reviews["storage"]["checks"].values()),
    "storage_blocker_resolved_in_fresh_census": storage_target["obligations"] == storage_target["proved"] == 142
        and not storage_target["unproved"] and not acceptance["storage_gaps"],
    "no_unknown_count_storage_functions": new_unknowns.get("storage", 0) == 0,
    "guard_and_report_models_unchanged_since_complex_review": all(
        identity(Path(prepared["repo"]) / path)["sha256"] == reviews["complex"]["evidence"][name]["sha256"]
        for name, path in (("guard_adapter", "tools/check_lean_guards.py"), ("report_adapter", "tools/lean_report.py"))),
}
decrease_totals = Counter()
for row in dispositions:
    decrease_totals[row["check"]] += row["before"] - row["after"]
if not all(checks.values()):
    diagnostic = {
        "schema_version": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
        "status": "failed_semantic_preconditions_no_accepted_disposition_generated",
        "candidate_commit": prepared["commit"], "candidate_tree": prepared["tree"],
        "checks": checks, "failed_checks": [name for name, passed in checks.items() if not passed],
        "observed_storage_target": storage_target,
        "observed_storage_gaps": acceptance["storage_gaps"],
        "observed_raw_shared_residual_changes": raw_shared_residual_changes,
        "observed_added_residual_functions": actual_added_residuals,
        "expected_reviewed_added_residual_functions": expected_added_residuals,
        "observed_complex_counts": complex_count_bindings,
        "existing_disposition_files_not_regenerated": [identity(OUT / name)
            for name in ("semantic-disposition.json", "semantic-disposition.md") if (OUT / name).exists()],
        "evidence": {name: identity(OUT / name) for name in (
            "records.jsonl", "report.md", "acceptance.json", "delta-alpha2.json",
            "final-census-receipt.json", "count-attribution/final-census-binding.json",
            "build-semantic-disposition.py")},
    }
    failure_path = OUT / "semantic-precondition-failure.json"
    failure_path.write_text(json.dumps(diagnostic, indent=2) + "\n")
    print(json.dumps({"status": diagnostic["status"], "failed_checks": diagnostic["failed_checks"],
                      "diagnostic": identity(failure_path)}))
    raise SystemExit(1)
result = {
    "schema_version": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
    "status": "reviewed_with_explicit_model_limits",
    "candidate_commit": prepared["commit"], "candidate_tree": prepared["tree"],
    "baseline_proof_commit": equivalence["pairs"]["alpha2"]["proof_commit"],
    "baseline_published_commit": equivalence["pairs"]["alpha2"]["release_or_integration_commit"],
    "observed_integrated_release_commit": equivalence["pairs"]["alpha3_storage_repair"]["release_or_integration_commit"],
    "checks": checks,
    "coverage": {"baseline_programs": len(baseline), "candidate_programs": len(candidate),
                 "added_programs": len(delta["added_programs"]), "removed_programs": len(delta["missing_programs"]),
                 "storage_selection": delta["storage_selection_delta"], "proof_counts": totals},
    "denominator_dispositions": dispositions, "net_decreases_by_category": dict(decrease_totals),
    "raw_shared_residual_changes_without_normalization": raw_shared_residual_changes,
    "added_residual_functions": actual_added_residuals,
    "complex_joint_verdict_counts": complex_count_bindings,
    "unknown_count_entries": {"baseline": old_unknowns, "candidate": new_unknowns,
                              "unit": "program/check/function record whose obligation count is null; not a count of missing obligations"},
    "storage_blocker_resolution": {"program": target, "previous_complete_failed_record": prior94[target],
                                   "final_fresh_record": candidate[target],
                                   "repair_manifest": identity(EVIDENCE / "lean/optional-storage-repair/frozen-repair.json")},
    "focused_enum_gc_statement": {"program": "tests/programs/library/lib_enum.py",
                                  "before": baseline["tests/programs/library/lib_enum.py"]["checks"]["gc"],
                                  "after": candidate["tests/programs/library/lib_enum.py"]["checks"]["gc"],
                                  "meaning": "The same three memo-get GC obligations remain rejected in this focused fixture. This is not the whole-corpus GC gap count."},
    "model_limit_dispositions": [
        "All 542 added union reads and 409 added payload-bit obligations remain unproved in 21 functions across nine new complex fixtures. The exact first failures reflect the conservative null domain for the internal complex member; native/IR review is not a proof of later obligations.",
        "The three added GC obligations in complex_values remain rejected. The memo-get body/protocol matches the already exposed alpha2 helper after explicit verified metadata/string bindings; runtime oracle coverage is separate.",
        "Decimal main.init remains an unsupported field-initialization case with unknown obligation count because candidate inference exceeds the prototype resource bound. It does not enter the counted denominator and is not counted as a successful proof.",
        "The former three unsupported storage functions are resolved by the separately reviewed optional-tuple adapter repair and the fresh complete census. No known-count 8/8 waiver is used.",
    ],
    "limits": [
        "This is bounded model qualification, not a claim of complete formal correctness of the compiler or runtime. Python adapters, typed inspection, runtime contracts and model limits remain explicit trust boundaries.",
        "Known counted denominators exclude unknown-count unsupported functions; no total coverage percentage is inferred from the numerical ratios.",
        "The reviewed runtime idx() checks and nonnull box-allocation contracts are source/IR evidence, not new Lean proofs of the C runtime.",
        "Native JIT/AOT coverage was executed on the retained b0-equivalent production source and is bridged by explicit compiler/runtime/corpus equivalence to 0a2f; it is not represented as a new execution.",
        "The complex-null fixture has a handwritten TypeError deviation oracle, not a CPython-parity assertion.",
        "Publication additionally requires the parent's live head/base/integrated-CI checks and independent final acceptance; this file does not itself publish or merge a release.",
    ],
    "review_evidence": {name: identity(path) for name, path in review_paths.items()},
    "review_statuses": {name: review["status"] for name, review in reviews.items()},
    "evidence": {name: identity(path) for name, path in {
        "records": OUT / "records.jsonl", "report": OUT / "report.md", "acceptance": OUT / "acceptance.json",
        "delta": OUT / "delta-alpha2.json", "census_receipt": OUT / "final-census-receipt.json",
        "attribution_inventory": inventory_path, "final_binding": OUT / "count-attribution/final-census-binding.json",
        "tree_equivalence": OUT / "qualification-source-equivalence.json",
        "production_equivalence": EVIDENCE / "lean/optional-storage-repair/final-source-equivalence-b0-to-0a2f.json",
        "storage_explanation": OUT / "storage-denominator-review/review.json",
        "tomllib_prose_correction": EVIDENCE / "ir-review/tomllib-guard-attribution-correction.json",
        "tomllib_exact_sites": EVIDENCE / "lean/tomllib-count-attribution-support/exact-null-site-confirmation.json",
        "enum_signature_correction": OUT / "independent-review/enum-renamed-specialization-evidence.json",
        "builder": Path(__file__),
    }.items()},
}
(OUT / "semantic-disposition.json").write_text(json.dumps(result, indent=2) + "\n")

labels = {"payload": "Dynamic payload reads", "access": "Unchecked list/dict accesses",
          "null": "Removed null checks", "union": "Closed-union reads", "union_payload": "Union payload bits",
          "fields": "Field initialization", "gc": "Collector scanning", "int": "Promoting-int fit claims",
          "int_inline": "Promoting-int inline arithmetic", "storage": "Promoting-int storage"}
lines = ["# Alpha3 complete Lean census and semantic disposition", "",
         f"Status: **{result['status']}**. The frozen proof source is `{prepared['commit']}`, tree `{prepared['tree']}`. Its complete tree equals the observed integrated release head `{result['observed_integrated_release_commit']}`. The alpha2 proof source `{result['baseline_proof_commit']}` likewise has the exact tree of published alpha2 `{result['baseline_published_commit']}`.", "",
         f"The census covers **{len(candidate):,} programs** and **{len(header['promoting'])} strict-storage selections**. All {len(baseline):,} alpha2 programs and all {len(baseline_header['promoting'])} alpha2 storage selections remain. There are {len(delta['added_programs'])} added programs and {len(delta['storage_selection_delta']['added'])} added storage selections. Every selected program was inspected and every required checker category produced a completed result; no failed or error record is hidden.", "",
         f"Strict storage accepts all **{totals['storage']['candidate']['proved']:,} counted obligations** with no rejected, unsupported or unknown-count storage function. This includes a fresh **142/142** for `python_int_optional_tuple_keys.py`, replacing the earlier complete census's three unknown-count unsupported functions. The earlier 8/8 known subtotal was correctly treated as insufficient.", "",
         "## Counts and remaining model limits", "",
         "Each ratio below is proved/countable obligations in that model. An unsupported function with an unknown obligation count is listed separately and does not enter that denominator. Counts overlap in scope across models and are not summed into an overall proof percentage.", "",
         "| Model | Alpha2 proved / counted | Alpha3 proved / counted | Unknown-count function entries, alpha2 → alpha3 |",
         "|---|---:|---:|---:|"]
for name, row in totals.items():
    old, new = row["baseline"], row["candidate"]
    lines.append(f"| {labels[name]} | {old['proved']:,} / {old['obligations']:,} | {new['proved']:,} / {new['obligations']:,} | {row['baseline_unknown_count_function_entries']} → {row['candidate_unknown_count_function_entries']} |")
lines += ["", "All exact raw residual dictionaries in shared programs remain unchanged, without temporary-name or specialization-suffix normalization. No shared counted gap or unknown-count entry grows. New coverage retains these explicit limits:", "",
          "- Nine complex fixtures add 21 rejected functions: **542 union reads and 409 payload-bit obligations remain unproved**. Every retained first diagnostic is consistent with the adapter's conservative extra null for `_pystachy_complex$complex`. The review retains callers, normal boxed returns, tuple/list transport and the exact emitted operations; it does not prove all later obligations in each rejected function. Payload-bit totals use the same function verdict and are intentionally listed with union functions.",
          "- `complex_values.py` exposes **three rejected GC obligations** in the existing heterogeneous memo-get protocol. Its body and source contract match the known alpha2 helper under narrowly verified metadata/string bindings. All three remain rejected.",
          "- `lib_decimal.py` adds **one field-initialization function with an unknown obligation count** because prototype inference exceeds its resource bound. Native passes do not convert it into an accepted proof.", "",
          "The user's earlier statement about three unchanged GC gaps concerns the focused `lib_enum.py` fixture. Those same three remain unchanged there; the full-corpus GC counts and unknown functions are shown in the table above.", "",
          "## Every decreased denominator", "",
          "All 38 decreases have exact side-specific snapshots, adapter module identities, per-function sites and independent semantic review. The final fresh census independently matches every candidate snapshot hash and count; the alpha2 side matches its historical census exactly. The 37 null/GC/storage pairs were inspected in 29 programs before the fresh census and then bound by the final verifier. The remaining access pair has a separate exact emitted-IR/runtime contract review.", "",
          "### Enum null checks: 49 fewer obligations across 11 fixtures", "",
          "Typed enum comparison dispatch no longer emits some library comparison/helper specializations and their `_value_` null-check removals. The review matches complete parameter and return signatures. In `lib_enum_plain_isinstance`, five retained names now denote Any/dyn specializations while seven other old names are absent. In `lib_enum_intflag`, the old `_int_of.3` specialization survives as `_int_of.2` with the same typed signature and null-removal site; the actually lost specialization is the old `_int_of.2` for the other signature. Literal name arithmetic is preserved but is not substituted for semantic identity.", "",
          "### Tomllib null checks: 21 fewer removals across seven fixtures", "",
          "The three checks per fixture are on **Output.flags receivers**, loaded from field 1, before `Flags.add_pending`, the second `Flags.is_`, and `Flags.unset_all`. Failure raises **AttributeError** with the corresponding method message. The exact same checks appear in both before-pass inputs; they are absent after the old pass and retained after the new pass. The `Flags.is_` effect summary now includes object reads/writes through VTuple slicing, so a later heap reload no longer inherits an earlier nonnull fact across that call. These checks remain at runtime rather than contributing removed-check proof obligations. Earlier tuple-pointer/TypeError wording is explicitly corrected in the retained correction history.", "",
          "### GC helpers: 102 fewer obligations across 16 fixtures", "",
          "Eighteen unreferenced internal `mappingproxy.__ror__` bodies disappear. Each old symbol has exactly one occurrence in its full LLVM module—the definition—and no call or address reference. The mappingproxy library source is unchanged. The separate four-obligation GC decrease below comes from the deliberately edited identity deviation fixture.", "",
          "### Storage and moved identity observations", "",
          "`dynany_identity_boundary.py` removes the formerly failing typed-VTuple and optional-float-list observations after their support is added, leaving the union-list and wide-integer observations. The removed storage site is the low word of the parsed `int(\"1000\")`; the four removed GC sites are the optional list's append, global store and two reads. Positive promoting-int coverage is specifically `python_int_vtuple_identity.py` (both directives, `int(\"1000\")`, repeated entries, list conversion and checked helpers), with optional integer-container and ordinary optional-float-list fixtures covering their respective scopes. The original edited source was separately recompiled and audited; this is not described as unchanged input coverage.", "",
          "`python_int_vtuple_materialization.py` is unchanged source. Its net storage decrease **46→37** is `optional` **18→7** (-11) plus `small` **6→8** (+2); the other three functions stay at 8/6/8. Removing the intermediate fixed tuple eliminates twelve marker/narrow/decode obligations. Identity capture adds one low-word use in `optional` and two in `small`. Both final overflow guards remain in each function, as do item evaluation and direct VTuple materialization. It is not simply nine deleted sites.", "",
          "### One unchecked access moves to runtime bounds checking", "",
          "In `dynany_iter_errors.py`, the final `[1, None]` loop uses `pys_list_get_identity` and `pys_list_get`; both call `idx()` before indexing. Its former unchecked backing-array read no longer enters the Lean unchecked-access count. The earlier action-loop unchecked read remains proved. The C-helper bounds contract is retained source evidence, not a newly granted Lean theorem.", "",
          "## Exact decrease rows", "",
          "| Program | Category | Alpha2 proved / counted | Alpha3 proved / counted | Denominator change | Review |",
          "|---|---|---:|---:|---:|---|"]
for row in dispositions:
    lines.append(f"| `{row['program']}` | {row['check']} | {row['before_proved']} / {row['before']} | {row['after_proved']} / {row['after']} | {row['after'] - row['before']} | {row['semantic_review']} |")
lines += ["", "## Execution, provenance and historical failures", "",
          "The final census started with new records on the frozen storage-repair source, using one worker and a 300-second inspection timeout. The five identified Lean executables were physically copied only after all 19 Lean theorem/build inputs matched their recorded binary origin. The maintained report header and resume checks directly pin the boundary/access binaries; the separate qualification preparation and independent audit pin all five binaries, including int/alias/companion. Any resume also requires an explicit all-five-binary preflight. The three changed Python checker/report inputs are bound to the two reviewed repair manifests. No record or header from an earlier checker source was reused. Any supported same-source resume is explicitly listed in `final-census-receipt.json`, with its exact preserved prefix and per-attempt source identity; no interrupted run is silently presented as uninterrupted.", "",
          "The original b0 partial census remains interrupted and incomplete. The complete 94f4 census remains a strict-storage failure despite its known 25,682/25,682 subtotal, because three storage functions had unknown counts. Its primary report-process -9 and earlier isolated inspection -9 exits are preserved with unknown causes; RSS samples alone are not OOM attribution. The final storage repair is separately reviewed, source-bound and freshly qualified.", "",
          "## Runtime evidence and scope", "",
          "Retained native CI artifacts establish JIT and AOT oracle execution of all twelve fixtures that had added residuals in the earlier census, including the seven numeric complex-union fixtures, complex-copy, Decimal and the optional tuple storage target. The successful synthetic CI checkout has the exact b0 production tree; an explicit final source-equivalence receipt binds its compiler/runtime/corpus to the proof-only final repairs. These are reused executions under verified source equality, not newly claimed runs. The complex-null fixture uses a handwritten TypeError deviation oracle, not a CPython parity claim.", "",
          "This qualification concerns bounded models and the recorded Linux/Python/toolchain configuration. Python adapters, typed inventory export and runtime contracts remain trust boundaries. It is not a proof of all compiler/runtime behavior or a waiver of any rejected/unsupported obligation. Final publication also requires the parent's live release-head/base and integrated-CI checks and the independent final acceptance receipt.", "",
          "The JSON companion binds every final record/report/acceptance/delta, the exact final snapshot-count binding, all source trees and review receipts by path, size and SHA256. The independent final acceptance will separately bind this completed disposition.", ""]
(OUT / "semantic-disposition.md").write_text("\n".join(lines))
print(json.dumps({"status": result["status"], "checks": checks,
                  "decrease_rows": len(dispositions), "new_residual_functions": len(actual_added_residuals)}))
raise SystemExit(0 if all(checks.values()) else 1)
