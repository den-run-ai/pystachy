    if k == "tuple":
        ws = targs(want) if is_tuple(want) else ["dyn"] * len(n.kids) if want == "dyn" else []  # (dynamic items: dynamic.py)
        if is_vtuple(unopt(want)) and targs(unopt(want))[0] == "dyn":
            # Box each fresh item while its numeric identity is still available;
            # first storing it in a typed tuple loses that companion (#858).
            ws = ["dyn"] * len(n.kids)
        vals: list[Val] = []
        for i in range(len(n.kids)):
            v = self.expr(n.kids[i], ws[i] if i < len(ws) else "", returnctx, resultsoft)
            if i < len(ws) and v.t != ws[i] and self.widens(v.t, ws[i]):
                v = Val(v.v, ws[i])  # (None as an object, T as T | None)
            elif i < len(ws) and self.converts(v.t, ws[i]) and (not is_sopt(v.t) or ws[i] == "dyn") and not (int_lists() and big_viewable(v.t, ws[i])):
                # An Any item must capture optional numeric identity before a
                # typed tuple slot would discard the original box's provenance.
                v = self.coerce(v, ws[i])  # (an int as an int | None: its box; a tuple of promoting ints stays one, as its int items do: bigints.held)
            elif i < len(ws) and is_fn(v.t) and is_callable(unopt(ws[i])):
                v = self.coerce(v, ws[i])  # (a function where a Callable is expected: made one)
            if is_vtuple(unopt(want)) and self.list_id_kind(self.ctype("list", [targs(unopt(want))[0]])) != 0 and v.idslot != "":
                v.idfrom = self.dyn_id_box(v).v
            vals.append(v)
        tconst = self.tuple_const(n, vals)
        if tconst.v != "":
            return tconst  # (a display of literals: CPython's constant, the same object at each run)
        if is_vtuple(want) and not resultsoft:
            # Every item is evaluated before these remaining coercions. want is also
            # an operand hint: concatenation may widen it (int plus int | None).
            # Comparisons preserve each side's own element representation.
            et = targs(want)[0]
            if all(self.widens(v.t, et) or self.boxes(v.t, et) or (v.t == BIG and et in ["int", "opt[int]"]) or (v.t == BIGOPT and et == "opt[int]") for v in vals):
                return self.vtuple_make([self.coerce(v, et) for v in vals], want)
        return self.stack_tuple(vals) if n is self.stkkey else self.tuple_(vals)
    if k == "listcomp":

def gen_vtuple_make(self, vals: list[Val], t: str) -> Val:
    # Already evaluated and coerced homogeneous items. Keep their native types,
    # including references, until lowering allocates the final scanned VTuple.
    # This is also the copy boundary for an existing fixed tuple: it never edits
    # or reinterprets the source tuple's storage.
    if self.rtmode and self.curfn.ll == "@pys_alloc":
        self.err("pys_alloc() implements an operation that it uses: write it without that operation")
    kind = self.list_id_kind(self.ctype("list", [targs(t)[0]]))
    boxes = [self.dyn_id_arg(v) for v in vals] if kind != 0 else []
    self.runtime("pys_alloc")
    i = Ins("vtuple.make", t, "")
    i.a = vals
    self.put(i, 1)
    result = Val(tmpname(i.r[0]), t)
    for j in range(len(boxes)):
        self.rt("pys_vtuple_set_identity", "void", [f"ptr {result.v}", f"i64 {j}", f"ptr {boxes[j].v}", f"i64 {kind}"])
    return result

