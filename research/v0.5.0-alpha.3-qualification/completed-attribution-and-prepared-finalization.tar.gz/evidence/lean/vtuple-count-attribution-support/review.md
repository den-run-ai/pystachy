# VTuple materialization denominator review

Read-only review of case 1994, `python_int_vtuple_materialization.py`, independently reconciles the storage inventory decrease from **46 to 37 obligations** with the changed tuple construction.

| Function | Historical inventory | Candidate inventory | Mechanism |
|---|---:|---:|---|
| `f.optional` | 18 | 7 | Eliminates an intermediate fixed tuple and its encode/decode boundaries; net one additional low-word obligation accompanies identity capture. |
| `f.small` | 6 | 8 | Retains direct checked scalar construction and adds two low-word obligations for item identity capture. |
| `main.init`, `f.dynamic`, `f.converted` | 22 total | 22 total | Exact per-function inventory records, graph hashes, and counts unchanged. |

In `f.optional`, the old `tuple[int+,None,int+]` allocation `%t85` is gone. Its **two tail-marker, six narrowing-view, and four tuple-decode obligations** therefore disappear with the corresponding intermediate storage: twelve obligations in total. Low-word obligations change from six to seven. Together with the two additional low-word obligations in `f.small`, the arithmetic is **−12 + 1 + 2 = −9**.

The retained typed IR still contains **two explicit `OverflowError: Python int too large to convert to C long` checks in each function**. `f.optional` now boxes the two directly narrowed values and passes them, with an explicit null middle element, to `vtuple.make`. `f.small` likewise passes its two directly narrowed values. The new identity-box calls and `vtuple.set_identity` calls retain numeric companions for the final runtime-length tuple. The calls to `item` remain in source order: one in `optional`, two in `small`; no item evaluation is removed.

This agrees with the source path in `expressions.py`: evaluate tuple-literal items and capture available numeric identity, then coerce the evaluated items and build the final VTuple directly when the contextual element type permits it. The optional case avoids first materializing and then decoding a fixed tuple. The low-word count comparison is a net reconciliation; old construction low-word uses and new directly boxed low-word uses are different operations even where their counts balance.

`review.json` binds both extracted inventories and the compact typed excerpt, includes the exact obligation-kind distributions, preserves the two overflow checks and item calls per function, and references complete before/after typed functions and LLVM bodies saved beside this note. The operation-only diff was used for navigation; it is not the basis for a claim of equivalence by itself.

The extraction inventories explicitly report `proof_executed=false`. This review ran no compiler, Lean checker, or native program. It explains the inventory change and the retained runtime checks; final qualification still requires binding the inventory to the fresh immutable-source census. It does not claim a formal proof of evaluation, identity, or whole-program equivalence.
