# Exact Tomllib null-removal attribution

Read-only review of all seven completed compact pass excerpts independently confirms **21 old-removed/new-retained checks**, three per fixture. The previously provisional association between the three added LLVM receiver guards and the three-fewer removed-null-check obligations is now supported by exact before/after pass records.

Each changed parser function has four removed-check obligations in the historical extraction and three in candidate `0a2fe77a580106c197face4d2904be80e3f85dbc`. For each function, the removed-site sets differ by exactly the one operation below, with no added removed-site entry. The operation itself is identical in both before-pass inputs, absent from the old after-pass function, and retained exactly in the new after-pass function.

| Parser function | Before-pass site | Candidate retained site | Guarded Flags method |
|---|---|---|---|
| `create_dict_rule` | `L83:3` | `L79:4` | `is_` |
| `create_list_rule` | `L103:3` | `L81:4` | `unset_all` |
| `key_value_rule` | `L114:3` | `L92:4` | `add_pending` |

The exact dependency chain is a field-1 address on `tomllib$_parser$Output`, a `mem.load` of `tomllib$_parser$Flags`, comparison of that receiver with null, and a method-specific `AttributeError` check. The downstream method call uses that same receiver. These are **Output.flags receiver checks**, not checks on a tuple pointer, and their exception is **AttributeError**.

| Fixture | Removed-check function count | Historical obligations | Candidate obligations |
|---|---:|---:|---:|
| `lib_tomllib.py` | 85 unchanged | 759 | 756 |
| `lib_tomllib_boundary.py` | 79 unchanged | 736 | 733 |
| `lib_tomllib_dynamic.py` | 83 unchanged | 751 | 748 |
| `lib_tomllib_flags.py` | 77 unchanged | 731 | 728 |
| `lib_tomllib_uncaught.py` | 77 unchanged | 731 | 728 |
| `upstream_tomllib_data.py` | 77 unchanged | 731 | 728 |
| `upstream_tomllib_misc.py` | 79 unchanged | 736 | 733 |

In every fixture, the function set is identical and all other per-function null-removal obligation counts agree. The typed-callback fixture has no corresponding null-removal decrease and is excluded from these seven; its separate GC helper removal remains a different attribution.

`exact-null-site-confirmation.json` retains each program, source commits, compact excerpt and extracted-inventory hashes, raw snapshot references, exact removed operation, receiver dependency chain, downstream method call, retained location, and hashes of all inspected before/after functions. It binds the completed extraction inventory with SHA256 `7200136d2f198e297688a66aeceb60eb1e7ade0423e8f2dd27a286fb098ccb00`.

The extraction inventory records exact correspondence to the historical alpha.2 qualification snapshots/counts and the previous `94f472d6` candidate counts. Its baseline source commit is preserved as `950c0440ad793dc6c34664f591383a5e6bba14dd`; it is not relabeled as another commit. Binding these candidate counts to the newly running final full census remains pending.

This review executed no compiler or Lean checker. It hashed the compact excerpts and extracted inventories; large raw snapshot hashes are retained as extraction references rather than independently rehashed here. It explains the denominator change and confirms the actual retained guard operations; it does not convert existing proof residuals into passes or establish whole-program equivalence. The separate source/LLVM review still supplies the `vtuple.slice` effect and reaching-load explanation.
