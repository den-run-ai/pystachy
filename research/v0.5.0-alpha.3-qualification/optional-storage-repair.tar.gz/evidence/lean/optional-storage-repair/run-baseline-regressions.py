"""Run the new storage regressions with the exact pre-repair adapter."""
from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import sys
import time
import types
import unittest

ROOT = Path('/workspace/scratch/980402bc01c4/alpha3-storage-fix')
OUT = Path(__file__).resolve().parent
BASE = '94f472d6de5350fc9481ecf3b9ec019d2ecdb4f2'
sys.path[:0] = [str(ROOT / 'tools'), str(ROOT)]

def baseline(path):
    return subprocess.check_output(['git', '-C', str(ROOT), 'show', BASE + ':' + path], text=True)

def methods(source):
    result = set()
    for node in ast.parse(source).body:
        if isinstance(node, ast.ClassDef):
            result.update(node.name + '.' + item.name for item in node.body
                          if isinstance(item, ast.FunctionDef) and item.name.startswith('test_'))
    return result

adapter = baseline('tools/check_lean_storage.py')
saved = OUT / 'baseline-check-lean-storage.py'
saved.write_text(adapter)
module = types.ModuleType('check_lean_storage')
module.__file__ = str(saved)
sys.modules[module.__name__] = module
exec(compile(adapter, str(saved), 'exec'), module.__dict__)
selected, hashes = [], {}
for name in ('test_lean_storage', 'test_lean_storage_layout'):
    path = 'tools/' + name + '.py'
    source = (ROOT / path).read_text()
    selected.extend(name + '.' + method for method in sorted(methods(source) - methods(baseline(path))))
    hashes[path] = hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
selected.append('test_lean_storage_layout.StorageLayoutTests.test_real_nested_and_mixed_container_baselines')
stream = io.StringIO()
start = time.monotonic()
result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
    unittest.defaultTestLoader.loadTestsFromNames(selected))
seconds = round(time.monotonic() - start, 3)
(OUT / 'baseline-final-regressions.log').write_text(stream.getvalue())
receipt = {
    'baseline_commit': BASE,
    'adapter_sha256': hashlib.sha256(adapter.encode()).hexdigest(),
    'test_file_sha256': hashes,
    'selected_tests': selected,
    'tests': result.testsRun,
    'failures': len(result.failures),
    'errors': len(result.errors),
    'skipped': len(result.skipped),
    'expected_failure_observed': not result.wasSuccessful(),
    'seconds': seconds,
    'method': 'Exact git-show baseline adapter loaded under its module name; final regression files and unchanged production compiler inputs used. No working-tree file replaced.',
}
(OUT / 'baseline-final-regressions.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
raise SystemExit(0 if not result.wasSuccessful() else 1)
