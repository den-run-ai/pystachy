"""Read-only tracked-source binding of prior b0 evidence to the final repair commit."""
from pathlib import Path
import hashlib
import json
import posixpath
import subprocess

ROOT = Path('/workspace/scratch/980402bc01c4/alpha3-storage-fix')
WORK = ROOT.parent
OUT = Path(__file__).resolve().parent
BASE = 'b0bda81ec2b9954c3c5e0f658c051439126a5c22'
FINAL = '0a2fe77a580106c197face4d2904be80e3f85dbc'
OLD = WORK / 'evidence/lean/adapter-repair'

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def tree(revision):
    result = {}
    for row in git('ls-tree', '-r', '-z', revision).split(b'\0'):
        if not row:
            continue
        metadata, name = row.split(b'\t', 1)
        mode, kind, oid = metadata.decode().split()
        name = name.decode()
        assert kind == 'blob', (name, kind)
        result[name] = {'path': name, 'mode': mode, 'type': kind, 'git_blob': oid}
    return result

before, after = tree(BASE), tree(FINAL)
assert set(before) == set(after)
objects = {row['git_blob'] for source in (before, after) for row in source.values()}
links = {row['git_blob'] for source in (before, after) for row in source.values() if row['mode'] == '120000'}
hashes, link_contents = {}, {}
process = subprocess.Popen(['git', '-C', str(ROOT), 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
for oid in sorted(objects):
    process.stdin.write((oid + '\n').encode())
    process.stdin.flush()
    header = process.stdout.readline().decode().strip().split()
    assert header[:2] == [oid, 'blob'], header
    remaining = int(header[2])
    sha = hashlib.sha256()
    kept = []
    while remaining:
        data = process.stdout.read(min(remaining, 65536))
        assert data
        remaining -= len(data)
        sha.update(data)
        if oid in links:
            kept.append(data)
    assert process.stdout.read(1) == b'\n'
    hashes[oid] = sha.hexdigest()
    if oid in links:
        link_contents[oid] = b''.join(kept).decode()
process.stdin.close()
assert process.wait() == 0
for source in (before, after):
    for row in source.values():
        row['sha256'] = hashes[row['git_blob']]

changed = [name for name in sorted(before) if before[name] != after[name]]
first_repair = json.loads((OLD / 'frozen-repair.json').read_text())
last_repair = json.loads((OUT / 'frozen-repair.json').read_text())
first_repair['files'] = {row['path']: row for row in first_repair['files']}
expected = set(first_repair['files']) | set(last_repair['files'])
assert set(changed) == expected and len(changed) == 8, changed
assert git('rev-parse', FINAL + '^{tree}').decode().strip() == last_repair['repair_tree']
for manifest in (first_repair, last_repair):
    for name, record in manifest['files'].items():
        assert after[name]['sha256'] == record['sha256'], name

old_inventories = json.loads((OLD / 'source-equivalence-inventories.json').read_text())
selections = {name: [row['path'] for row in group['entries']] for name, group in old_inventories.items()
              if name != 'all_unchanged_tracked_files'}
selections['all_unchanged_tracked_files'] = sorted(set(before) - set(changed))
selections['release_documentation'] = sorted(name for name in before
                                            if name.startswith('docs/releases/') or name == 'docs/releasing.md')
selections['lean_theorems_and_build_inputs'] = sorted(name for name in before
    if name.startswith('tools/lean_boundary/') and
    (name.endswith('.lean') or Path(name).name in ('lean-toolchain', 'lake-manifest.json', 'lakefile.toml')))
groups = {}
for name, paths in selections.items():
    a = [before[path] for path in sorted(paths)]
    b = [after[path] for path in sorted(paths)]
    assert a == b, name
    groups[name] = {'files': len(paths), 'paths': sorted(paths),
                    'before_sha256': hashlib.sha256(encoded(a)).hexdigest(),
                    'after_sha256': hashlib.sha256(encoded(b)).hexdigest(), 'equal': True}

def resolve(source, name):
    chain = []
    seen = set()
    while source[name]['mode'] == '120000':
        assert name not in seen
        seen.add(name)
        row = source[name]
        link = link_contents[row['git_blob']]
        chain.append({'path': name, 'target_text': link, 'link_blob_sha256': row['sha256']})
        assert not link.startswith('/')
        name = posixpath.normpath(posixpath.join(posixpath.dirname(name), link))
        assert not name.startswith('../') and name in source
    return {'resolved_path': name, 'sha256': source[name]['sha256'], 'symlinks': chain}

ir_identity_path = WORK / 'ir-audit/identity.json'
ir_analysis_path = WORK / 'ir-audit/analysis.json'
ir_identity = json.loads(ir_identity_path.read_text())
ir_analysis = json.loads(ir_analysis_path.read_text())
assert ir_identity['homes']['head']['source_sha'] == ir_analysis['source'] == BASE
assert ir_analysis['identity_sha256'] == digest(ir_identity_path)
corpus = {row['path']: row['sha256'] for row in ir_identity['corpus']}
cases = {row['case']: row['source_sha256'] for row in ir_analysis['rows']}
assert len(corpus) == len(cases) == 4771 and corpus == cases
input_rows = []
for name, recorded in sorted(corpus.items()):
    a, b = resolve(before, name), resolve(after, name)
    assert a == b and a['sha256'] == recorded, name
    input_rows.append({'path': name, 'recorded_sha256': recorded, 'baseline': a, 'final': b, 'match': True})
assert before['tools/irsame.sh']['sha256'] == after['tools/irsame.sh']['sha256'] == ir_identity['maintained_oracle_sha256']
retained_oracle = WORK / 'ir-audit/irsame-retained.sh'
assert digest(retained_oracle) == ir_identity['retained_oracle_sha256']

perf_identity_path = WORK / 'performance/identity.json'
perf_report_path = WORK / 'performance/report.json'
perf_identity = json.loads(perf_identity_path.read_text())
perf_report = json.loads(perf_report_path.read_text())
head = perf_identity['revisions']['head']
assert head['built_source_sha'] == head['release_sha'] == BASE
assert perf_report['identity_sha256'] == digest(perf_identity_path)
assert head['original_identity_sha256'] == digest(ir_identity_path)
workloads = []
assert len(head['workloads']) == len(perf_report['cases']) == 3
for label, (name, arguments) in perf_report['cases'].items():
    a, b = resolve(before, name), resolve(after, name)
    assert a == b and a['sha256'] == head['workloads'][name], name
    workloads.append({'label': label, 'path': name, 'arguments': arguments,
                      'recorded_sha256': head['workloads'][name], 'baseline': a, 'final': b, 'match': True})

bootstrap_path = WORK / 'evidence/bootstrap.json'
bootstrap = json.loads(bootstrap_path.read_text())
assert bootstrap['commit'] == bootstrap['commit_after'] == BASE
assert bootstrap['tree'] == bootstrap['tree_after'] == git('rev-parse', BASE + '^{tree}').decode().strip()
assert bootstrap['status_before'] == bootstrap['status_after'] == '' and bootstrap['returncode'] == 0
assert ir_identity['candidate_bootstrap_receipt_sha256'] == digest(bootstrap_path)

evidence = {name: {'path': str(path), 'sha256': digest(path)} for name, path in {
    'bootstrap': bootstrap_path, 'ir_identity': ir_identity_path, 'ir_analysis': ir_analysis_path,
    'retained_ir_oracle': retained_oracle, 'build_cost_identity': perf_identity_path, 'build_cost_report': perf_report_path,
    'previous_four_file_receipt': OLD / 'source-equivalence-b0-to-94f4.json',
    'previous_four_file_manifests': OLD / 'source-equivalence-inventories.json',
}.items()}
old_receipt = json.loads((OLD / 'source-equivalence-b0-to-94f4.json').read_text())
assert digest(OLD / 'source-equivalence-inventories.json') == old_receipt['inventories']['sha256']
for name, original in old_receipt['retained_evidence'].items():
    assert digest(original['path']) == original['sha256'], name

inventories = OUT / 'final-source-inventories.json'
save(inventories, {'baseline_commit': BASE, 'final_commit': FINAL,
    'baseline': [before[name] for name in sorted(before)],
    'final': [after[name] for name in sorted(after)], 'groups': groups})
inputs = OUT / 'final-source-input-bindings.json'
save(inputs, {'ir': input_rows, 'build_cost_workloads': workloads})
subtrees = {name: {side: git('rev-parse', revision + ':' + name).decode().strip()
                       for side, revision in (('baseline', BASE), ('final', FINAL))}
            for name in ('src', 'lib', 'tests', 'bench', 'examples', 'ports', 'mpz', 'ryu', '.github')}
assert all(pair['baseline'] == pair['final'] for pair in subtrees.values())
receipt = {
    'status': 'tracked production source equivalence verified',
    'meaning': 'Fresh Git-object byte/mode comparison only; earlier executions remain attributed to b0. No bootstrap, IR scan, build-cost sample, runtime test or census rerun is claimed.',
    'baseline_commit': BASE, 'baseline_tree': git('rev-parse', BASE + '^{tree}').decode().strip(),
    'final_commit': FINAL, 'final_tree': git('rev-parse', FINAL + '^{tree}').decode().strip(),
    'final_parents': git('show', '-s', '--format=%P', FINAL).decode().strip().split(),
    'tracked_files_before': len(before), 'tracked_files_after': len(after),
    'unchanged_tracked_files': len(before) - len(changed),
    'changed_files': [{'path': name, 'baseline': before[name], 'final': after[name]} for name in changed],
    'frozen_repairs_match': True,
    'comparison_script': {'path': str(Path(__file__).resolve()), 'sha256': digest(__file__)},
    'groups': {name: {key: value for key, value in row.items() if key != 'paths'} for name, row in groups.items()},
    'direct_subtree_objects': subtrees,
    'inventories': {'path': str(inventories), 'sha256': digest(inventories)},
    'input_bindings': {'path': str(inputs), 'sha256': digest(inputs)},
    'retained_evidence': evidence,
    'bindings': {
        'bootstrap': {'evaluated_commit': BASE, 'command': bootstrap['command'], 'returncode': bootstrap['returncode'],
                      'seconds': bootstrap['seconds'], 'fixed_point_hashes': ir_identity['candidate_fixed_point']},
        'ir': {'evaluated_commit': BASE, 'comparison_baseline': ir_analysis['baseline'], 'cases': len(corpus),
               'differences': ir_analysis['differences'], 'new_rejections': len(ir_analysis['newly_rejected']),
               'all_recorded_input_hashes_match_both_commits': True,
               'symlink_inputs': [row for row in input_rows if row['baseline']['symlinks']],
               'maintained_oracle_unchanged': True, 'retained_oracle_matches_earlier_identity': True},
        'build_cost': {'evaluated_commit': BASE, 'status': perf_report['status'], 'scope': perf_report['scope'],
                       'binary_sha256': head['binary_sha256'], 'workloads': workloads,
                       'all_recorded_workload_hashes_match_both_commits': True, 'new_samples': 0},
    },
    'limits': [
        'Only tracked Git objects and recorded input hashes are compared; arbitrary untracked imports, machine state and toolchain changes are outside this receipt.',
        'Eight checker/documentation/unit-test paths and Git commit identity differ, so whole-checkout input identity differs despite byte-identical production sources.',
        'Do not bypass verification_bootstrap.py commit, tracked-source, run, payload, toolchain or ABI checks. This does not authorize strict artifact reuse across commits.',
        'Earlier binaries retain b0 source provenance and may embed that revision; they are not final-repair or eventual-main release artifacts.',
        'Changed guard/storage adapters and reporter require fresh qualification on the immutable repaired source. Historical census failures and proof counts stay historical.',
        'The three performance workloads measure native build costs with warm runtime caches, not timed program runtime or compiler bootstrap performance.',
        'VERSION bytes are unchanged; actual binary versions and GitHub, Docker and PyPI artifact provenance require publication-stage verification.',
    ],
}
save(OUT / 'final-source-equivalence-b0-to-0a2f.json', receipt)
print(json.dumps({key: receipt[key] for key in ('status', 'baseline_commit', 'final_commit', 'final_tree',
    'tracked_files_before', 'tracked_files_after', 'unchanged_tracked_files', 'groups')}, indent=2))
print('changed_files:', changed)
print('IR inputs:', len(input_rows), 'build-cost workloads:', len(workloads))
