"""Bind all newly residual fixtures to already retained successful native CI.

Read only: no compiler, runtime, checker, or network operation.
"""
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parents[2]
REPO = WORK / 'alpha3'
BASE = 'b0bda81ec2b9954c3c5e0f658c051439126a5c22'
HEAD = '94f472d6de5350fc9481ecf3b9ec019d2ecdb4f2'
CHECKOUT = 'e51127bc8aff094c26c64c5575d58f34adc49655'
CENSUS = WORK / 'evidence/lean-corrected'
RECORDS_SHA = '396f4b02ede94afda93ecc796f1da3aa1d3cb022a78939c51c4fc34a22101bbe'

def digest(data):
    return sha256(data).hexdigest()

def identity(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path.read_bytes())}

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

@lru_cache(None)
def source(path):
    content = git('show', BASE + ':' + path)
    assert content == git('show', CHECKOUT + ':' + path) == git('show', HEAD + ':' + path)
    assert content == (REPO / path).read_bytes()
    return {'path': path, 'bytes': len(content), 'sha256': digest(content),
            'identical_at': [BASE, CHECKOUT, HEAD]}

assert digest((CENSUS / 'records.jsonl').read_bytes()) == RECORDS_SHA
delta = json.loads((CENSUS / 'delta-alpha2.json').read_text())
targets = sorted({row['program'] for row in delta['added_program_unproved']})
assert len(targets) == 12
original = json.loads((ROOT / 'native-coverage.json').read_text())
api = json.loads((ROOT / 'github-receipt.json').read_text())
run = api['run']['data']
assert run['id'] == 43681595990 and run['head_sha'] == BASE
assert (run['status'], run['conclusion']) == ('completed', 'success')
jobs = {row['id']: row for row in api['jobs']['data']['jobs']}
assert api['jobs']['data']['total_count'] == len(jobs) == 16
tree = git('rev-parse', BASE + '^{tree}').decode().strip()
assert tree == git('rev-parse', CHECKOUT + '^{tree}').decode().strip()
assert tree == original['checkout']['trees'][BASE]
assert git('diff', '--name-only', BASE, HEAD).decode().splitlines() == original['checkout']['only_repair_changes']
job_ids = {'native-jit-0': 132714325039, 'native-jit-1': 132714325020,
           'native-aot-0': 132714325071, 'native-aot-1': 132714325093,
           'native-aot-2': 132714325032, 'native-aot-3': 132714325041}
downloads = json.loads((ROOT / 'artifact-downloads.json').read_text())
groups, found = [], {target: {} for target in targets}
for downloaded in downloads:
    artifact = downloaded['artifact']
    group = artifact['name'].removeprefix('x86_64-verification-')
    assert group in job_ids
    mode = 'jit' if group.startswith('native-jit') else 'aot'
    job = jobs[job_ids[group]]
    assert job['head_sha'] == BASE and (job['status'], job['conclusion']) == ('completed', 'success')
    assert artifact['workflow_run']['id'] == run['id'] and artifact['workflow_run']['head_sha'] == BASE
    zipped = ROOT / (str(artifact['id']) + '.zip')
    assert artifact['digest'] == 'sha256:' + digest(zipped.read_bytes())
    assert downloaded['sha256'] == digest(zipped.read_bytes())
    folder = ROOT / artifact['name']
    receipt_path = folder / 'verification.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['result'] == 'pass' and receipt['profile'] == 'pr' and receipt['group'] == group
    assert receipt['git'] == {'commit': CHECKOUT, 'dirty': False}
    native = next(step for step in receipt['steps'] if step['name'] == 'tests-' + group)
    assert native['result'] == 'pass' and native['failed'] == 0 and native['failures'] == []
    assert native['passed'] == native['expected'] and native['modes'] == [mode]
    assert native['compiler'] == 'stage2'
    prefix = folder / 'verify' / ('tests-' + group)
    cases_path, times_path, log_path = [Path(str(prefix) + suffix) for suffix in ('-cases.log', '-times.log', '.log')]
    with zipfile.ZipFile(zipped) as archive:
        for path in (receipt_path, cases_path, times_path, log_path):
            assert archive.read(str(path.relative_to(folder))) == path.read_bytes()
    cases, times = cases_path.read_text().splitlines(), times_path.read_text().splitlines()
    assert len(cases) == len(set(cases)) == len(times)
    assert native['selected_cases'] == cases
    assert [line.split(' ', 1)[1] for line in times] == cases
    assert log_path.read_text().splitlines() == ['selected %d cases' % len(cases), '%d passed, 0 failed' % native['passed']]
    source_ids = []
    for path, info in receipt['sources'].items():
        if isinstance(info, dict) and 'sha256' in info:
            record = source(path)
            assert record['sha256'] == info['sha256']
            source_ids.append(record)
    matched = []
    for target in targets:
        if target not in cases:
            continue
        assert mode not in found[target]
        i = cases.index(target)
        record = {'group': group, 'job_id': job['id'], 'job_url': job['html_url'],
                  'artifact_id': artifact['id'], 'case_line': i + 1, 'timing_line': i + 1,
                  'duration_ms': int(times[i].split(' ', 1)[0]),
                  'result': 'executed_and_oracle_passed'}
        found[target][mode] = record
        matched.append({'program': target, **record})
    groups.append({'group': group, 'job': {k: job[k] for k in ('id', 'name', 'html_url', 'status', 'conclusion', 'head_sha', 'started_at', 'completed_at')},
                   'artifact': artifact, 'zip': identity(zipped),
                   'receipt': identity(receipt_path), 'case_list': identity(cases_path),
                   'timings': identity(times_path), 'log': identity(log_path),
                   'selected_cases': len(cases), 'passed_checks': native['passed'], 'failed_checks': 0,
                   'matched_targets': matched, 'verified_source_hashes': source_ids})
fixtures = []
for target in targets:
    assert set(found[target]) == {'jit', 'aot'}
    paths = sorted((REPO / target).parent.glob(Path(target).stem + '.*'))
    sides = [source(str(path.relative_to(REPO))) for path in paths]
    expected = (REPO / Path(target).with_suffix('.out')).read_text()
    assert expected.endswith('[exit 0]\n')
    deviation = '/deviations/' in target
    if not deviation:
        assert not (REPO / Path(target).with_suffix('.err')).exists()
    helpers = []
    if target.endswith('python_int_optional_tuple_keys.py'):
        helpers.append(source('tests/python_int_modules/fixed_optional_tuple_keys.py'))
    fixtures.append({'program': target, 'modes': found[target], 'source_and_sidecars': sides,
                     'import_helpers': helpers,
                     'oracle': ('Handwritten documented-deviation stdout/stderr/exit oracle; annotation-violating None must raise the expected TypeError.' if deviation
                                else 'Recorded CPython stdout and exit 0; no .err sidecar, so stderr must be empty. AOT build stderr must be empty.'),
                     'expected_output_bytes': len(expected.encode()), 'expected_output_lines': len(expected.splitlines())})
report = {'status': 'twelve_residual_fixtures_passed_retained_native_jit_and_aot',
          'scope': 'Runtime evidence only; current strict-storage gate remains blocked and no Lean obligation is waived.',
          'records_sha256': RECORDS_SHA, 'delta': identity(CENSUS / 'delta-alpha2.json'),
          'workflow_run': original['workflow_run'], 'checkout': original['checkout'],
          'groups': groups, 'fixtures': fixtures, 'fixture_count': 12, 'executions': 24,
          'harness': original['harness'],
          'limitations': ['No new executions or network retrievals were performed.',
                          'Successful cases have no individual PASS line: exact case lists and post-execution timings, complete expected check counts and zero failures establish execution and oracle acceptance.',
                          'Finite fixture executions do not prove each lowered operation or every possible input.',
                          'All 542 union-read and 409 associated payload obligations, 3 GC obligations and 4 unknown-count function results remain recorded as unproved/unsupported.']}
(ROOT / 'all-residual-coverage.json').write_text(json.dumps(report, indent=2) + '\n')
lines = ['# Native coverage of every added residual fixture', '',
         'All 12 fixtures with newly recorded Lean residuals passed both retained native JIT and AOT in CI run 43681595990: 24 fixture executions. This is bounded runtime evidence; it does not satisfy the failed strict-storage gate or discharge any proof obligation.', '',
         '| Fixture | JIT job / line / ms | AOT job / line / ms |', '|---|---|---|']
for row in fixtures:
    a, b = row['modes']['jit'], row['modes']['aot']
    lines.append('| `%s` | %d / %d / %d | %d / %d / %d |' % (row['program'], a['job_id'], a['case_line'], a['duration_ms'], b['job_id'], b['case_line'], b['duration_ms']))
lines += ['', 'The six GitHub artifact ZIP hashes match retained API digests. Each extracted verification receipt, selected-case log, post-execution timing log, and zero-failure execution log was checked against its ZIP bytes. The receipts identify synthetic merge e51127bc, whose full tree equals b0bda81ec. The four proof repair files are the entire b0→94f4 difference; source, runtime, fixtures, sidecars and the native harness retain the same bytes.', '',
          'The complex-null deviation uses its handwritten TypeError oracle. The other eleven fixtures use recorded CPython stdout and exit status. Successful individual cases intentionally emit no PASS line; complete expected counts, zero failures and timing rows establish the executions. All raw file hashes, job URLs, suite counts, source/oracle hashes and artifact identities are retained in the companion JSON.', '']
(ROOT / 'all-residual-coverage.md').write_text('\n'.join(lines))
print(json.dumps({'status': report['status'], 'fixtures': 12, 'executions': 24, 'groups': len(groups)}))
