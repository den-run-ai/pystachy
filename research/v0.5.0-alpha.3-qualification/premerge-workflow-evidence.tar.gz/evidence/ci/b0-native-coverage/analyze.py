#!/usr/bin/env python3
"""Bind three residual fixtures to retained successful native CI; no execution."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2] / "alpha3"
BASE = "b0bda81ec2b9954c3c5e0f658c051439126a5c22"
HEAD = "94f472d6de5350fc9481ecf3b9ec019d2ecdb4f2"
CHECKOUT = "e51127bc8aff094c26c64c5575d58f34adc49655"
TARGETS = ["tests/programs/inference/dynany_complex_union_identity.py",
           "tests/programs/library/lib_decimal.py",
           "tests/deviations/complex_union_none.py"]

def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def file_record(path):
    return {"path": str(path.relative_to(ROOT)), "bytes": path.stat().st_size,
            "sha256": sha(path.read_bytes())}

def source_record(path):
    content = git("show", BASE + ":" + path)
    assert content == git("show", CHECKOUT + ":" + path)
    assert content == git("show", HEAD + ":" + path)
    assert content == (REPO / path).read_bytes()
    return {"path": path, "bytes": len(content), "sha256": sha(content),
            "identical_at": [BASE, CHECKOUT, HEAD]}

api = json.loads((ROOT / "github-receipt.json").read_text())
run = api["run"]["data"]
assert run["id"] == 43681595990 and run["head_sha"] == BASE
assert (run["status"], run["conclusion"]) == ("completed", "success")
jobs = {j["id"]: j for j in api["jobs"]["data"]["jobs"]}
assert api["jobs"]["data"]["total_count"] == len(jobs) == 16
trees = {commit: git("rev-parse", commit + "^{tree}").decode().strip()
         for commit in (BASE, CHECKOUT, HEAD)}
assert trees[BASE] == trees[CHECKOUT] == "e027b37c888326e3d8a3e8b89522a6b397dcb86d"
changed = git("diff", "--name-only", BASE, HEAD).decode().splitlines()
assert changed == ["tools/check_lean_guards.py", "tools/lean_report.py",
                   "tools/test_lean_report.py", "tools/test_lean_union_split.py"]
manifest = json.loads((ROOT / "artifact-downloads.json").read_text())
downloads = {d["artifact"]["id"]: d for d in manifest}
modes = {}
for mode, artifact_id, job_id, group in [
    ("jit", 14148990788, 132714325039, "native-jit-0"),
    ("aot", 14149080508, 132714325032, "native-aot-2")]:
    job = jobs[job_id]
    assert (job["status"], job["conclusion"]) == ("completed", "success")
    assert job["head_sha"] == BASE
    downloaded = downloads[artifact_id]
    artifact = downloaded["artifact"]
    assert artifact["workflow_run"]["id"] == run["id"]
    assert artifact["workflow_run"]["head_sha"] == BASE
    zip_path = ROOT / (str(artifact_id) + ".zip")
    zip_sha = sha(zip_path.read_bytes())
    assert artifact["digest"] == "sha256:" + zip_sha
    assert downloaded["sha256"] == zip_sha
    folder = ROOT / artifact["name"]
    receipt = json.loads((folder / "verification.json").read_text())
    assert receipt["result"] == "pass" and receipt["profile"] == "pr"
    assert receipt["group"] == group
    assert receipt["git"] == {"commit": CHECKOUT, "dirty": False}
    native = next(s for s in receipt["steps"] if s["name"] == "tests-" + group)
    assert native["result"] == "pass" and native["failed"] == 0 and native["failures"] == []
    assert native["passed"] == native["expected"]
    assert native["modes"] == [mode] and native["compiler"] == "stage2"
    prefix = folder / "verify" / ("tests-" + group)
    cases_path = Path(str(prefix) + "-cases.log")
    times_path = Path(str(prefix) + "-times.log")
    log_path = Path(str(prefix) + ".log")
    cases = cases_path.read_text().splitlines()
    timings = times_path.read_text().splitlines()
    assert len(cases) == len(set(cases)) == len(timings)
    assert native["selected_cases"] == cases
    assert [line.split(" ", 1)[1] for line in timings] == cases
    assert log_path.read_text().splitlines() == [
        "selected %d cases" % len(cases), "%d passed, 0 failed" % native["passed"]]
    matched_sources = []
    for path, info in receipt["sources"].items():
        if isinstance(info, dict) and "sha256" in info:
            record = source_record(path)
            assert record["sha256"] == info["sha256"]
            matched_sources.append(record)
    targets = []
    for target in TARGETS:
        index = cases.index(target)
        assert timings[index].split(" ", 1)[1] == target
        targets.append({"case": target, "case_list_line": index + 1,
                        "timing_line": index + 1,
                        "duration_ms": int(timings[index].split(" ", 1)[0]),
                        "status": "executed_and_oracle_passed",
                        "basis": "Selected case and post-execution timing; zero-failure complete shard receipt and run log."})
    raw_job = ROOT / ("job-%d.log" % job_id)
    job_lines = raw_job.read_text().splitlines()
    anchors = [{"line": i + 1, "text": line} for i, line in enumerate(job_lines)
               if CHECKOUT in line or "HEAD is now" in line or
               (("tests-" + group + " pass") in line)]
    modes[mode] = {"job_id": job_id, "job_name": job["name"], "job_url": job["html_url"],
                   "started_at": job["started_at"], "completed_at": job["completed_at"],
                   "status": job["status"], "conclusion": job["conclusion"],
                   "artifact": {k: artifact[k] for k in ("id", "name", "digest", "created_at", "workflow_run")},
                   "receipt": file_record(folder / "verification.json"),
                   "case_list": file_record(cases_path), "case_times": file_record(times_path),
                   "execution_log": file_record(log_path), "job_log": file_record(raw_job),
                   "job_log_anchors": anchors,
                   "native_step": {k: v for k, v in native.items() if k != "selected_cases"},
                   "selected_case_count": len(cases), "cases": targets,
                   "receipt_source_hashes_verified": matched_sources}

fixtures = []
for target in TARGETS:
    sides = [str(p.relative_to(REPO)) for p in sorted((REPO / target).parent.glob(Path(target).stem + ".*"))]
    records = [source_record(path) for path in sides]
    expected = git("show", BASE + ":" + str(Path(target).with_suffix(".out"))).decode()
    item = {"case": target, "source_and_sidecars": records,
            "expected_output_bytes": len(expected.encode()),
            "expected_output_lines": len(expected.splitlines()),
            "expected_exit": 0, "modes_passed": ["jit", "aot"]}
    assert expected.endswith("[exit 0]\n")
    if "/deviations/" in target:
        item["oracle"] = "Handwritten documented-deviation oracle; combined stdout/stderr and exit status."
        item["expected_output"] = expected
        item["interpretation"] = "Valid complex/narrowed optional inputs return 1j, 0, 2j; passing None under a complex annotation raises the explicitly expected TypeError, caught by the fixture. This is not CPython parity."
    else:
        item["oracle"] = "Recorded CPython stdout and exit; stderr must be empty because no .err sidecar exists; AOT build stderr must also be empty."
        assert not (REPO / Path(target).with_suffix(".err")).exists()
        if "dynany_complex" in target:
            item["expected_output"] = expected
            item["interpretation"] = "Finite and NaN complex identity preserved across scalar union/Any, tuple membership/count/item, optional, typed and dynamic generators."
        else:
            item["interpretation"] = "Broad recorded Decimal construction/arithmetic/comparison/context/exception fixture matches its 31,462-byte CPython output oracle."
    fixtures.append(item)

report = {"status": "three_fixtures_passed_native_jit_and_aot",
          "observed_utc": api["observed_utc"], "repository": "den-run-ai/pystachy",
          "workflow_run": {k: run[k] for k in ("id", "head_sha", "html_url", "status", "conclusion", "event", "run_attempt")},
          "checkout": {"receipt_commit": CHECKOUT, "head_commit": BASE, "trees": trees,
                       "exact_checkout_tree_matches_head": True,
                       "repair_head": HEAD, "only_repair_changes": changed,
                       "production_runtime_libraries_corpus_and_native_harness_unchanged": True},
          "modes": modes, "fixtures": fixtures,
          "harness": {"files": [source_record(p) for p in ("tests/run.sh", "tests/verify.sh", "tests/corpus.sh")],
                      "program_oracle_lines": [88, 121], "deviation_oracle_lines": [122, 135],
                      "post_execution_timing_and_missing_result_lines": [166, 220],
                      "receipt_count_enforcement_lines": [367, 380],
                      "native_shard_invocation_lines": [591, 608]},
          "limits": ["These are retained x86_64 CI executions, not new local reruns.",
                     "Successful individual cases deliberately have no PASS line. Actual case lists and post-execution timing records, complete matching counts, and zero failures establish these six passing executions.",
                     "Fixture-level runtime observations do not prove every lowered IR access or every path; rejected Lean obligations remain unproved.",
                     "The complex-null case follows its explicit documented-deviation oracle, not CPython behavior for annotation-violating None.",
                     "The receipts name GitHub's synthetic PR merge e51127bc; its complete source tree is exactly equal to b0bda81ec, verified locally."]}
(ROOT / "native-coverage.json").write_text(json.dumps(report, indent=2) + "\n")
md = ["# Native CI evidence for three bounded-model residual fixtures", "",
      "All three fixtures passed both native JIT and AOT in retained CI run [43681595990](%s), head `%s`. No rerun was performed." % (run["html_url"], BASE), "",
      "The receipts identify synthetic PR merge `%s`; its full tree `%s` is identical to the candidate head. The repair head `%s` changes exactly four proof-adapter/report/test files; compiler, runtime, libraries, corpus, and native harness bytes remain identical." % (CHECKOUT, trees[BASE], HEAD), "",
      "| Fixture | JIT worker 0 | AOT shard 2 | Oracle |", "|---|---|---|---|"]
for index, target in enumerate(TARGETS):
    j, a = modes["jit"]["cases"][index], modes["aot"]["cases"][index]
    md.append("| `%s` | %d ms; case/timing line %d | %d ms; case/timing line %d | %s |" %
              (target, j["duration_ms"], j["case_list_line"], a["duration_ms"], a["case_list_line"],
               "Documented deviation" if "/deviations/" in target else "Recorded CPython output"))
md += ["", "## Exact successful jobs and artifacts", ""]
for mode, evidence in modes.items():
    step = evidence["native_step"]
    md += ["- **%s:** [%s](%s), artifact `%d` (`%s`); %d selected cases, **%d passed checks / 0 failed**, expected %d. The stage2 native suite took %.3f seconds. GitHub artifact SHA256 was checked against the downloaded ZIP." %
           (mode.upper(), evidence["job_name"], evidence["job_url"], evidence["artifact"]["id"], evidence["artifact"]["name"], evidence["selected_case_count"], step["passed"], step["expected"], step["seconds"])]
md += ["", "The retained `*-cases.log` lists actual shard membership. The matching `*-times.log` records elapsed milliseconds after each case completes. The execution logs contain exactly the selected-case count and a zero-failure summary. The harness treats a missing worker result as failure and verifies the expected check total; successful cases intentionally emit no individual PASS line. `native-coverage.json` pins these files and source/oracle/harness SHA256 hashes, complete receipt fields, and raw job-log anchors.", "",
       "## What the observations establish", "",
       "The complex identity fixture matches both finite and NaN reference-identity observations through union/Any, tuple, optional, and generator paths. The Decimal fixture matches its full 31,462-byte recorded CPython output. Both have exit 0 and no expected stderr; the harness also requires an empty AOT build stderr.", "",
       "The complex-null fixture is an explicit deviation: the annotation-violating call with `None` must raise the documented TypeError, caught by the test; valid and narrowed inputs print `1j 0 2j`. Its oracle is:", "",
       "```text", fixtures[2]["expected_output"].rstrip(), "```", "",
       "These six native fixture executions support a bounded runtime disposition. They do not discharge the rejected Lean obligations, prove every lowered access/path, or establish CPython parity for the documented deviation. The raw artifacts, API metadata, and exact successful job logs are retained beside this report.", ""]
(ROOT / "native-coverage.md").write_text("\n".join(md))
print(json.dumps({"status": report["status"], "cases": len(fixtures), "native_executions": 6,
                  "checkout_tree": trees[BASE], "receipt_source_hashes_verified_per_mode":
                  {mode: len(value["receipt_source_hashes_verified"]) for mode, value in modes.items()},
                  "reports": [str(ROOT / "native-coverage.json"), str(ROOT / "native-coverage.md")]}, indent=2))
