# Native CI evidence for three bounded-model residual fixtures

All three fixtures passed both native JIT and AOT in retained CI run [43681595990](https://github.com/den-run-ai/pystachy/actions/runs/43681595990), head `b0bda81ec2b9954c3c5e0f658c051439126a5c22`. No rerun was performed.

The receipts identify synthetic PR merge `e51127bc8aff094c26c64c5575d58f34adc49655`; its full tree `e027b37c888326e3d8a3e8b89522a6b397dcb86d` is identical to the candidate head. The repair head `94f472d6de5350fc9481ecf3b9ec019d2ecdb4f2` changes exactly four proof-adapter/report/test files; compiler, runtime, libraries, corpus, and native harness bytes remain identical.

| Fixture | JIT worker 0 | AOT shard 2 | Oracle |
|---|---|---|---|
| `tests/programs/inference/dynany_complex_union_identity.py` | 136 ms; case/timing line 671 | 338 ms; case/timing line 336 | Recorded CPython output |
| `tests/programs/library/lib_decimal.py` | 1236 ms; case/timing line 763 | 3393 ms; case/timing line 382 | Recorded CPython output |
| `tests/deviations/complex_union_none.py` | 60 ms; case/timing line 495 | 253 ms; case/timing line 248 | Documented deviation |

## Exact successful jobs and artifacts

- **JIT:** [native JIT and variants (worker 0)](https://github.com/den-run-ai/pystachy/actions/runs/43681595990/job/132714325039), artifact `14148990788` (`x86_64-verification-native-jit-0`); 2334 selected cases, **2456 passed checks / 0 failed**, expected 2456. The stage2 native suite took 86.989 seconds. GitHub artifact SHA256 was checked against the downloaded ZIP.
- **AOT:** [verify (native-aot-2, x86_64)](https://github.com/den-run-ai/pystachy/actions/runs/43681595990/job/132714325032), artifact `14149080508` (`x86_64-verification-native-aot-2`); 1168 selected cases, **1229 passed checks / 0 failed**, expected 1229. The stage2 native suite took 122.430 seconds. GitHub artifact SHA256 was checked against the downloaded ZIP.

The retained `*-cases.log` lists actual shard membership. The matching `*-times.log` records elapsed milliseconds after each case completes. The execution logs contain exactly the selected-case count and a zero-failure summary. The harness treats a missing worker result as failure and verifies the expected check total; successful cases intentionally emit no individual PASS line. `native-coverage.json` pins these files and source/oracle/harness SHA256 hashes, complete receipt fields, and raw job-log anchors.

## What the observations establish

The complex identity fixture matches both finite and NaN reference-identity observations through union/Any, tuple, optional, and generator paths. The Decimal fixture matches its full 31,462-byte recorded CPython output. Both have exit 0 and no expected stderr; the harness also requires an empty AOT build stderr.

The complex-null fixture is an explicit deviation: the annotation-violating call with `None` must raise the documented TypeError, caught by the test; valid and narrowed inputs print `1j 0 2j`. Its oracle is:

```text
1j 0 2j
TypeError: a value used as complex | int is None; annotate it complex | int | None
[exit 0]
```

These six native fixture executions support a bounded runtime disposition. They do not discharge the rejected Lean obligations, prove every lowered access/path, or establish CPython parity for the documented deviation. The raw artifacts, API metadata, and exact successful job logs are retained beside this report.
