"""Read retained completed CodeQL logs and API output; no GitHub mutations."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
HEAD = "328b945f02788b296d9981d1b44706a2a0092255"
SNAPSHOT = ROOT / "observed-008.json"
snapshot = json.loads(SNAPSHOT.read_text())
responses = snapshot["responses"]
qualification = json.loads((ROOT / "qualification.json").read_text())
assert qualification["observed_utc"] == snapshot["observed_utc"]
assert qualification["expected_head_sha"] == HEAD and qualification["status"] == "all_observed_runs_completed"
run = responses["run_43692897923"]["data"]
assert run["head_sha"] == HEAD and run["status"] == "completed" and run["conclusion"] == "success"
jobs = responses["jobs_43692897923"]["data"]["jobs"]
assert {job["id"] for job in jobs} == {132747065881, 132747066006, 132747066072}

def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}

rows = []
warning = "Cannot retrieve the full diff because there are too many (300) changed files in the pull request."
for job in jobs:
    assert job["head_sha"] == HEAD and job["status"] == "completed" and job["conclusion"] == "success"
    toolpath = ROOT / f"job-{job['id']}.tool.json"
    logfile = ROOT / f"job-{job['id']}.log"
    tool = json.loads(toolpath.read_text())
    text = logfile.read_text()
    assert tool["job_id"] == job["id"] and not tool["result"]["isError"]
    assert text == tool["result"]["structuredContent"]["content"]
    lines = text.splitlines()
    hashes = [lines[i + 1].split()[-1] for i, line in enumerate(lines)
              if "git log -1 --format=%H" in line]
    assert hashes == [HEAD]
    warnings = [{"line": i + 1, "text": line} for i, line in enumerate(lines) if "##[warning]" in line]
    assert len(warnings) == 1 and warning in warnings[0]["text"]
    assert not any("##[error]" in line for line in lines)
    evidence = {}
    for name, phrase in (("sarif_uploaded", "Successfully uploaded results"),
                         ("upload_processed", "Analysis upload status is complete."),
                         ("job_success", "CodeQL job status was success.")):
        matches = [{"line": i + 1, "text": line} for i, line in enumerate(lines) if phrase in line]
        assert len(matches) == 1
        evidence[name] = matches[0]
    if job["name"] in ("Analyze (c-cpp)", "Analyze (python)"):
        phrase = "Reverting overlay database mode to none because the PR diff ranges could not be computed."
        disposition = "The diff-range optimization was disabled and analysis continued without overlay mode."
    else:
        phrase = "Using overlay database mode: none without caching."
        disposition = "Actions analysis was already using no-overlay mode; the diff-range warning did not prevent analysis or upload."
    matches = [{"line": i + 1, "text": line} for i, line in enumerate(lines) if phrase in line]
    assert len(matches) == 1
    evidence["overlay_mode"] = matches[0]
    seconds = (datetime.fromisoformat(job["completed_at"]) - datetime.fromisoformat(job["started_at"])).total_seconds()
    rows.append({"job_id": job["id"], "name": job["name"], "url": job["html_url"], "head_sha": HEAD,
                 "conclusion": job["conclusion"], "seconds": seconds,
                 "log": identity(logfile), "tool_result": identity(toolpath),
                 "exact_checkout_sha_from_log": hashes[0], "warnings": warnings,
                 "disposition": disposition, "completion_evidence": evidence})
aggregate = next(check for check in qualification["check_runs"] if check["name"] == "CodeQL")
assert aggregate["status"] == "completed" and aggregate["conclusion"] == "success"
assert aggregate["output"]["title"] == "No new alerts in code changed by this pull request"
assert aggregate["output"]["annotations_count"] == 0
result = {"schema_version": 1, "status": "all_managed_codeql_jobs_completed_warning_disposed",
          "observed_utc": snapshot["observed_utc"], "head_sha": HEAD,
          "workflow_run": {key: run[key] for key in ("id", "name", "path", "html_url", "status", "conclusion", "head_sha", "run_attempt")},
          "aggregate_check": aggregate, "jobs": rows,
          "snapshot": identity(SNAPSHOT), "qualification": identity(ROOT / "qualification.json"),
          "review_script": identity(Path(__file__)),
          "limits": ["The aggregate check retains an early completed_at timestamp from its initial neutral state. Final readiness is based on this successful observation and completed per-language jobs, not that stale timestamp.",
                     "The 300-file warning concerns diff-range/overlay optimization. It is not a claim that only 300 files were analyzed.",
                     "The aggregate says no new alerts in this pull request; it is not a guarantee that the project has no vulnerabilities.",
                     "This review does not grant release readiness while the separate full census and semantic gates remain pending."]}
(ROOT / "managed-codeql-review.json").write_text(json.dumps(result, indent=2) + "\n")
lines = ["# Integrated CodeQL warning disposition", "",
         f"Exact head `{HEAD}` was observed fully successful at **{snapshot['observed_utc']}**. Managed run [43692897923](https://github.com/den-run-ai/pystachy/actions/runs/43692897923) and all three language jobs completed successfully. Every retained log records checkout of that exact commit, successful SARIF upload and completed upload processing. The aggregate reports **no new alerts in code changed by this pull request**, with zero annotations.", "",
         "| Language | Successful job | Seconds |", "| --- | --- | ---: |"]
lines += [f"| {row['name']} | [{row['job_id']}]({row['url']}) | {row['seconds']} |" for row in rows]
lines += ["", "Each log has the same 300-file diff-range warning. C++ and Python explicitly fall back from overlay mode to full no-overlay analysis; Actions was already using no-overlay mode. All continue through query evaluation, result export and successful upload processing. No error annotation appears in the retained logs. The warning is not a limit of 300 analyzed files.", "",
          "The aggregate check's early completed_at value persists from its initial neutral state, before Python finished. Its final successful status was observed at the time above; the raw timestamps and completed language jobs are retained without rewriting that discrepancy.", "",
          "All complete API pages, every job/step duration, exact decoded tool log text and input hashes are preserved. This is a successful scan of this head with the stated warning disposition, not a guarantee of absence of vulnerabilities or a substitute for the remaining release qualification gates."]
(ROOT / "managed-codeql-review.md").write_text("\n".join(lines) + "\n")
print(json.dumps({"status": result["status"], "jobs": len(rows), "head_sha": HEAD,
                  "review": identity(ROOT / "managed-codeql-review.json")}))
