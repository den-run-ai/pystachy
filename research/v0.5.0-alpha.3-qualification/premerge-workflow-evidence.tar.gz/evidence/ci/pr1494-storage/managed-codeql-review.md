# Integrated CodeQL warning disposition

Exact head `328b945f02788b296d9981d1b44706a2a0092255` was observed fully successful at **2026-11-15 08:28:25 UTC**. Managed run [43692897923](https://github.com/den-run-ai/pystachy/actions/runs/43692897923) and all three language jobs completed successfully. Every retained log records checkout of that exact commit, successful SARIF upload and completed upload processing. The aggregate reports **no new alerts in code changed by this pull request**, with zero annotations.

| Language | Successful job | Seconds |
| --- | --- | ---: |
| Analyze (c-cpp) | [132747065881](https://github.com/den-run-ai/pystachy/actions/runs/43692897923/job/132747065881) | 86.0 |
| Analyze (actions) | [132747066006](https://github.com/den-run-ai/pystachy/actions/runs/43692897923/job/132747066006) | 47.0 |
| Analyze (python) | [132747066072](https://github.com/den-run-ai/pystachy/actions/runs/43692897923/job/132747066072) | 1233.0 |

Each log has the same 300-file diff-range warning. C++ and Python explicitly fall back from overlay mode to full no-overlay analysis; Actions was already using no-overlay mode. All continue through query evaluation, result export and successful upload processing. No error annotation appears in the retained logs. The warning is not a limit of 300 analyzed files.

The aggregate check's early completed_at value persists from its initial neutral state, before Python finished. Its final successful status was observed at the time above; the raw timestamps and completed language jobs are retained without rewriting that discrepancy.

All complete API pages, every job/step duration, exact decoded tool log text and input hashes are preserved. This is a successful scan of this head with the stated warning disposition, not a guarantee of absence of vulnerabilities or a substitute for the remaining release qualification gates.
