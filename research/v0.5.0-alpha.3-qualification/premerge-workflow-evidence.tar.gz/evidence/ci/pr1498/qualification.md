# Repair PR #1498 check qualification

Head: `94f472d6de5350fc9481ecf3b9ec019d2ecdb4f2`. Observed: 2026-11-15 06:27:51 UTC. State: **all_observed_runs_completed**.

| Workflow | Status | Conclusion | Attempt |
| --- | --- | --- | ---: |
| [Submission format](https://github.com/den-run-ai/pystachy/actions/runs/43685175685) | completed | success | 1 |
| [Submission format](https://github.com/den-run-ai/pystachy/actions/runs/43684181046) | completed | success | 1 |
| [DCO (legacy)](https://github.com/den-run-ai/pystachy/actions/runs/43684181057) | completed | skipped | 1 |
| [Lint](https://github.com/den-run-ai/pystachy/actions/runs/43684181117) | completed | success | 1 |
| [CI](https://github.com/den-run-ai/pystachy/actions/runs/43684181107) | completed | success | 1 |

CodeQL: **not observed on this exact SHA**. This is not counted as passed.

Reviews: 0; issue comments: 0; inline comments: 0.

## Every observed job

| Job | Status | Conclusion | Seconds |
| --- | --- | --- | ---: |
| [Check title and description](https://github.com/den-run-ai/pystachy/actions/runs/43685175685/job/132724047388) | completed | success | 7.0 |
| [Check title and description](https://github.com/den-run-ai/pystachy/actions/runs/43684181046/job/132721050973) | completed | success | 10.0 |
| [DCO certified (fork pull requests)](https://github.com/den-run-ai/pystachy/actions/runs/43684181057/job/132721078798) | completed | skipped | — |
| [make lint (ruff, shellcheck, clang -Wall -Wextra)](https://github.com/den-run-ai/pystachy/actions/runs/43684181117/job/132721049598) | completed | success | 818.0 |
| [verify (bootstrap, x86_64)](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132721049794) | completed | success | 309.0 |
| [native JIT and variants (worker 1)](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132722237487) | completed | success | 433.0 |
| [native JIT and variants (worker 0)](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132722237496) | completed | success | 478.0 |
| [verify (contracts, x86_64)](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132722237617) | completed | success | 508.0 |
| [verify (native-aot-0, x86_64)](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132722237627) | completed | success | 239.0 |
| [verify (safety-0, x86_64)](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132722237639) | completed | success | 269.0 |
| [verify (native-aot-1, x86_64)](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132722237642) | completed | success | 270.0 |
| [verify (safety-1, x86_64)](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132722237645) | completed | success | 315.0 |
| [verify (cache-gc, x86_64)](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132722237648) | completed | success | 687.0 |
| [verify (native-aot-3, x86_64)](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132722237668) | completed | success | 240.0 |
| [verify (opt-in, x86_64)](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132722237675) | completed | success | 203.0 |
| [verify (hosted, x86_64)](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132722237694) | completed | success | 424.0 |
| [verify (native-aot-2, x86_64)](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132722237709) | completed | success | 168.0 |
| [verify (benchmarks, x86_64)](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132722237750) | completed | success | 432.0 |
| [Bootstrap tier and native archive qualification](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132722238772) | completed | skipped | — |
| [Verification](https://github.com/den-run-ai/pystachy/actions/runs/43684181107/job/132724872099) | completed | success | 20.0 |

## Conditional skips

- DCO certified (fork pull requests): Legacy placeholder intentionally false for its only pull_request_target event. Condition: `github.event_name != 'pull_request_target'`.
- Bootstrap tier and native archive qualification: Native archive/tier qualification belongs to non-PR workflows; this exact job condition excludes pull_request. Condition: `github.event_name != 'pull_request'`.

Every step status, timestamp, duration and source condition is retained in `qualification.json`. Skipped GitHub jobs can report inverted timestamps; those retain the raw dates and no invented duration.

The PR profile selects x86_64 bootstrap, eleven verification groups, two JIT/variant workers and the Verification aggregate. Archive qualification is expressly excluded from pull_request runs. Other committed workflows are push/schedule/manual/release-tag workflows rather than PR triggers.

## Limits

- Read-only snapshot; no workflows rerun/cancelled, metadata changed, reviews posted or PR merged.
- Parent owns the final live check before merge. CI PR profile is not the full release qualification suite.
- Gate names are requested release gates; branch-rule enforcement was not independently retrieved: the connector rejected its encoded branch URL.
- The connector rejects the actions/workflows collection. Exact pinned local workflow source is unchanged from the reviewed base; applicable run/check/job endpoints are retained.
