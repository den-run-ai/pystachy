"""Read-only aggregation of retained GitHub API pages for storage repair PR #1501."""
from pathlib import Path
import hashlib
import json
from datetime import datetime
import subprocess
import yaml

ROOT=Path('/workspace/scratch/980402bc01c4')
OUT=ROOT/'evidence/ci/pr1501'
WORK=ROOT/'alpha3-lean-storage-corrected'
SHA='0a2fe77a580106c197face4d2904be80e3f85dbc'
path=sorted(OUT.glob('observed-*.json'))[-1]
snapshot=json.loads(path.read_text());rs=snapshot['responses']
pr=rs['pr']['data'];runs=rs['runs']['data'];checks=rs['checks']['data'];statuses=rs['statuses']['data']
assert pr['head']['sha']==SHA
assert len(runs['workflow_runs'])==runs['total_count']
assert len(checks['check_runs'])==checks['total_count']
assert len(statuses['statuses'])==statuses['total_count']
for name, response in rs.items():
    if 'pagination' in response:
        assert response['pagination']['complete'], (name, response['pagination'])
    if response.get('isError'):
        raise AssertionError((name, response))

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def seconds(start,end):
    if not start or not end:return None
    duration=(datetime.fromisoformat(end)-datetime.fromisoformat(start)).total_seconds()
    return duration if duration>=0 else None

definitions={}
workflow_inventory=[]
workflow_paths=subprocess.check_output(['git','ls-tree','-r','--name-only',SHA,'--','.github/workflows'],cwd=WORK).decode().splitlines()
for relative in sorted(p for p in workflow_paths if p.endswith(('.yml','.yaml'))):
    content=subprocess.check_output(['git','show',SHA+':'+relative],cwd=WORK)
    data=yaml.load(content.decode(),Loader=yaml.BaseLoader)
    definitions[relative]=data
    workflow_inventory.append({'path':relative,'name':data.get('name'),'sha256':hashlib.sha256(content).hexdigest(),'commit':SHA,'triggers':data.get('on'),
        'pr_applicable':bool(set(data.get('on',{}))&{'pull_request','pull_request_target'})})

def job_definition(run,name):
    d=definitions.get(run['path'],{}).get('jobs',{})
    if run['name']=='CI':
        key=('bootstrap' if name.startswith('verify (bootstrap,') else
             'verification' if name.startswith('verify (') else
             'pr-variants' if name.startswith('native JIT and variants') else
             'qualification' if name=='Bootstrap tier and native archive qualification' else
             'verify' if name=='Verification' else None)
        return key,d.get(key,{})
    for key,value in d.items():
        if value.get('name')==name:return key,value
    return None,{}

jobs=[];run_rows=[];failures=[]
for collection_run in runs['workflow_runs']:
    run=rs['run_'+str(collection_run['id'])]['data']
    assert run['head_sha']==SHA
    data=rs['jobs_'+str(run['id'])]['data']
    assert len(data['jobs'])==data['total_count'],run['id']
    if run['conclusion'] not in [None,'success','skipped','neutral']:
        failures.append({'kind':'workflow','id':run['id'],'name':run['name'],'conclusion':run['conclusion'],'url':run['html_url']})
    for job in data['jobs']:
        assert job['head_sha']==SHA
        key,definition=job_definition(run,job['name'])
        source_steps=definition.get('steps',[])
        condition_by_name={s.get('name') or ('Run '+s['uses'] if 'uses' in s else 'Run '+s.get('run','')):s.get('if') for s in source_steps}
        steps=[]
        for step in job.get('steps',[]):
            item={k:step.get(k) for k in ['number','name','status','conclusion','started_at','completed_at']}
            item['seconds']=seconds(step.get('started_at'),step.get('completed_at'))
            if step['name'] in condition_by_name:item['source_if']=condition_by_name[step['name']]
            if step.get('conclusion')=='skipped':
                item['skip_disposition']=('workflow condition; see source_if' if item.get('source_if') else
                    'GitHub-managed workflow; exact source condition is not exposed by the retained API. Raw skipped state is preserved without counting it as a pass.' if run['path'].startswith('dynamic/') else
                    'post-action or source condition inherited from its paired action; raw API retained')
            steps.append(item)
            if step.get('conclusion') not in [None,'success','skipped','neutral']:
                failures.append({'kind':'step','job_id':job['id'],'job':job['name'],'step':step['name'],'conclusion':step['conclusion'],'url':job['html_url']})
        row={k:job.get(k) for k in ['id','name','status','conclusion','head_sha','started_at','completed_at','html_url','run_attempt']}
        row.update(workflow=run['name'],run_id=run['id'],workflow_path=run['path'],workflow_job=key,source_if=definition.get('if'),
                   timeout_minutes=definition.get('timeout-minutes'),seconds=seconds(job.get('started_at'),job.get('completed_at')),steps=steps)
        if job.get('conclusion')=='skipped':
            row['skip_disposition']={'dco':'Legacy placeholder intentionally false for its only pull_request_target event.',
                'qualification':'Native archive/tier qualification belongs to non-PR workflows; this exact job condition excludes pull_request.'}.get(key,'See explicit source_if and retained API.')
            if job.get('started_at') and job.get('completed_at') and row['seconds'] is None:
                row['timestamp_note']='GitHub reports completion before start for this skipped job; no fabricated runtime duration is assigned.'
        if job.get('conclusion') not in [None,'success','skipped','neutral']:
            failures.append({'kind':'job','id':job['id'],'name':job['name'],'conclusion':job['conclusion'],'url':job['html_url']})
        jobs.append(row)
    run_rows.append({k:run.get(k) for k in ['id','name','path','event','status','conclusion','head_sha','run_attempt','run_started_at','updated_at','html_url']})

for check in checks['check_runs']:
    assert check['head_sha']==SHA
    if check['conclusion'] not in [None,'success','skipped','neutral']:
        failures.append({'kind':'check','id':check['id'],'name':check['name'],'conclusion':check['conclusion'],'url':check['html_url']})
for status in statuses['statuses']:
    if status['state'] in ['error','failure']:
        failures.append({'kind':'status','context':status['context'],'state':status['state'],'url':status['target_url']})

codeql=[{'kind':'workflow','name':r['name'],'status':r['status'],'conclusion':r['conclusion'],'url':r['html_url']} for r in run_rows if 'codeql' in r['name'].lower() or 'codeql' in r['path'].lower()]
codeql += [{'kind':'check','name':c['name'],'status':c['status'],'conclusion':c['conclusion'],'url':c['html_url']} for c in checks['check_runs'] if 'codeql' in c['name'].lower()]
latest={}
for run in sorted(run_rows,key=lambda r:r['id']):latest[run['name']]=run
gate={name:{'status':latest[name]['status'],'conclusion':latest[name]['conclusion'],'url':latest[name]['html_url']} if name in latest else {'status':'not_observed'} for name in ['CI','Lint','Submission format']}
gate['Submission format status']=[{k:s.get(k) for k in ['state','context','description','target_url','updated_at']} for s in statuses['statuses'] if s['context']=='Submission format']
gate['CodeQL']=codeql or [{'status':'not_observed_on_exact_head','note':'No CodeQL run or check is currently returned on this SHA; this is not a pass or an inferred failure.'}]
assert len(rs['suites']['data']['check_suites'])==rs['suites']['data']['total_count']
report={'schema_version':1,'observed_utc':snapshot['observed_utc'],'repository':'den-run-ai/pystachy','pr_number':1501,'expected_head_sha':SHA,
    'status':'failure_observed' if failures else 'all_observed_runs_completed' if all(r['status']=='completed' for r in run_rows) and all(j['status']=='completed' for j in jobs) and all(c['status']=='completed' for c in checks['check_runs']) else 'checks_in_progress',
    'pr':{k:pr.get(k) for k in ['state','draft','merged','merged_at','merge_commit_sha','mergeable','mergeable_state','html_url','updated_at']},'head':pr['head']['sha'],'base':pr['base']['sha'],
    'gate_statuses':gate,'failures':failures,'workflow_runs':run_rows,'jobs':jobs,
    'check_runs':[{k:c.get(k) for k in ['id','name','status','conclusion','head_sha','started_at','completed_at','html_url','details_url','output']} for c in checks['check_runs']],
    'check_suites':rs['suites']['data'],'review_threads':rs['review_threads']['data']['review_threads'],
    'check_annotations':{k:v for k,v in rs.items() if k.startswith('annotations_')},
    'reviews':rs['reviews']['data'],'discussion_comments':rs['comments']['data'],'inline_comments':rs['inline']['data'],
    'workflow_source_inventory':workflow_inventory,'raw_snapshot':{'path':str(path),'sha256':digest(path)},
    'coverage':{'paginated_collections':{name:response['pagination'] for name,response in rs.items() if 'pagination' in response},
       'workflow_run_pages':'All events on exact head_sha; every fetched page retained and row/total equality verified; final details retained for every run.',
       'jobs_pages':'Every observed run, all attempts filter; all pages fetched until fewer than100 rows, with row/total equality verified.',
       'check_pages':'Exact head check-runs/check-suites/statuses; every page retained and counts verified.',
       'review_pages':'All review submissions, inline comments and issue comments pages until fewer than100; separate review-thread tool returned the retained resolved-state inventory.'},
    'limits':['Read-only snapshot; no workflows rerun/cancelled, metadata changed, reviews posted or PR merged.',
       'Parent owns the final live check before merge. CI PR profile is not the full release qualification suite.',
       'Gate names are requested release gates; parent owns branch protection and release qualification.',
       'Exact committed workflow sources were read at the integrated head. Managed CodeQL has a GitHub-generated dynamic path rather than committed YAML; its run, jobs and aggregate check remain distinct evidence.',
       'No managed CodeQL success is inferred from its absence; any observed managed jobs and check output are reported separately.']}
(OUT/'qualification.json').write_text(json.dumps(report,indent=2)+'\n')
lines=['# Storage repair PR #1501 check qualification','',f"Head: `{SHA}`. Observed: {snapshot['observed_utc']}. State: **{report['status']}**.",'',
       '| Workflow | Status | Conclusion | Attempt |','| --- | --- | --- | ---: |']
for r in run_rows:lines += [f"| [{r['name']}]({r['html_url']}) | {r['status']} | {r['conclusion'] or 'pending'} | {r['run_attempt']} |"]
lines += ['', 'CodeQL: '+('observed; see JSON for exact results.' if codeql else '**not observed on this exact SHA**. This is not counted as passed.'),'',
          f"Reviews: {len(report['reviews'])}; review threads: {len(report['review_threads'])}; issue comments: {len(report['discussion_comments'])}; inline comments: {len(report['inline_comments'])}.",'',
          '## Every observed job','', '| Job | Status | Conclusion | Seconds |','| --- | --- | --- | ---: |']
for j in jobs:lines += [f"| [{j['name']}]({j['html_url']}) | {j['status']} | {j['conclusion'] or 'pending'} | {j['seconds'] if j['seconds'] is not None else '—'} |"]
lines += ['', '## Conditional skips','']
for j in jobs:
    if j.get('skip_disposition'):lines += [f"- {j['name']}: {j['skip_disposition']} Condition: `{j.get('source_if')}`."]
lines += ['', 'Every step status, timestamp, duration and source condition is retained in `qualification.json`. Skipped GitHub jobs can report inverted timestamps; those retain the raw dates and no invented duration.','',
          'The PR profile selects x86_64 bootstrap, eleven verification groups, two JIT/variant workers and the Verification aggregate. Archive qualification is expressly excluded from pull_request runs. Other committed workflows are push/schedule/manual/release-tag workflows rather than PR triggers.','', '## Limits','']
lines += ['- '+x for x in report['limits']]
(OUT/'qualification.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'status':report['status'],'observed':report['observed_utc'],'gates':gate,'jobs':len(jobs),'failures':failures},indent=2))
