# Managed CodeQL qualification for integrated alpha.3

Observed **2026-11-15 06:53:21 UTC** on exact head `bbc8c8c38858ea2d90859751e34b885fdea1ca1d`. Managed [run 43685666640](https://github.com/den-run-ai/pystachy/actions/runs/43685666640) completed successfully, and its [aggregate check](https://github.com/den-run-ai/pystachy/runs/132725624113) reports **No new alerts in code changed by this pull request**.

| Analysis | Result | Duration | Completed UTC |
|---|---|---:|---|
| [Analyze (c-cpp)](https://github.com/den-run-ai/pystachy/actions/runs/43685666640/job/132725525017) | success | 74 s | 2026-11-15T06:30:47Z |
| [Analyze (python)](https://github.com/den-run-ai/pystachy/actions/runs/43685666640/job/132725525279) | success | 1381 s | 2026-11-15T06:52:34Z |
| [Analyze (actions)](https://github.com/den-run-ai/pystachy/actions/runs/43685666640/job/132725525296) | success | 34 s | 2026-11-15T06:30:07Z |

All three analyses warn that GitHub cannot supply the full PR diff at the 300-file threshold. C/C++ and Python revert overlay mode to none; each log explicitly skips the diff-informed stage and continues through successful query evaluation and SARIF upload. This is an optimization fallback, not a failed analysis. The earlier neutral aggregate missing-Python configuration result resolves to success after Python finishes.

The aggregate check retains its original completed_at timestamp even though its conclusion/output changed after Python analysis. Qualification uses the observed snapshot timestamp and successful language job completion dates, not that stale aggregate timestamp, to date final success.

The GitHub connector rejects check-run annotations URLs; exact errors and all three full job logs are retained. Check outputs and raw log warnings/notices support the disposition.

The complete logs, warning/notice anchors and SHA256 hashes are retained in `managed-codeql-review.json`. The full workflow/check/job/review snapshot is `observed-008.json`; `qualification.json` accounts for every observed job and conditional skip.

## Limits

- The aggregate reports no new alerts in code changed by this pull request; this is not a claim that the entire branch is free of historical alerts or that static analysis proves safety.
- No reruns, cancellations, source edits, reviews, comments, or merge operations were performed.
