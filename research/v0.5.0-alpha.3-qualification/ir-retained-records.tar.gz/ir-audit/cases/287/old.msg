tests/programs/classes/obj_number_conversions.py:68: error: int() argument must be a string, a bytes-like object or a real number, not 'Slot'
