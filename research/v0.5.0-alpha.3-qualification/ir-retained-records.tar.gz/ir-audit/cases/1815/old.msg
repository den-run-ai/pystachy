tests/programs/numbers/complex_optional_number_eq.py:16: error: unsupported type annotation
