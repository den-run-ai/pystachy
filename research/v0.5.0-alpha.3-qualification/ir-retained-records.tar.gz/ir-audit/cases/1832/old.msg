tests/programs/numbers/complex_union_subclass_eq.py:19: error: unsupported type annotation
