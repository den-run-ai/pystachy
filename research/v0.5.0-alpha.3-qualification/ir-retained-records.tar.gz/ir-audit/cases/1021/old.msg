tests/programs/inference/dynany_complex_setter.py:18: error: complex numbers are not supported
