tests/programs/reflection/reflected_rand.py:10: error: reflected operator methods are not supported (int & Bits calls Bits.__rand__)
