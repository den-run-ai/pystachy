tests/programs/optional/opt_none_unknown.py:5: error: NoneType | None values cannot be compared or printed
