tests/programs/inference/dynany_complex_init_packed.py:7: error: complex numbers are not supported
