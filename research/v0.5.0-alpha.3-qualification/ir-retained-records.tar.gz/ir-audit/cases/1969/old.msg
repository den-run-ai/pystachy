tests/programs/numbers/python_int_optional_tuple_keys.py:7: error: set elements must be int or str, not tuple[int,str] | None (an element cannot be None)
