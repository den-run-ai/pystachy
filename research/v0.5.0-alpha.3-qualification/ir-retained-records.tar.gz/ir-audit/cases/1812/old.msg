tests/programs/numbers/complex_none_compare.py:3: error: unsupported type annotation
