tests/programs/numbers/complex_subclass_eq.py:9: error: unsupported type annotation
