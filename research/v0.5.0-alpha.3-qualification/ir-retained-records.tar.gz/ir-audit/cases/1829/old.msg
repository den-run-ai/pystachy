tests/programs/numbers/complex_union_object_eq.py:14: error: unsupported type annotation
