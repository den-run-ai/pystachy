tests/programs/numbers/complex_union_enum_eq.py:16: error: unsupported type annotation
