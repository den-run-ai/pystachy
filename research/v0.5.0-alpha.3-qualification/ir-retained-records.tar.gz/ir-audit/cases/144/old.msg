tests/programs/classes/cmp_notimplemented_runtime.py:10: error: the builtin 'NotImplemented' cannot be used as a value (not supported)
