tests/programs/numbers/complex_enum_eq.py:25: error: unsupported type annotation
