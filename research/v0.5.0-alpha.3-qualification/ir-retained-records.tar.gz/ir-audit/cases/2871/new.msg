tests/errors/classes/constructor_dependency_variable.py:15: error: inheritance with generic class templates is not supported: annotate __init__ parameters with concrete types (not Any or object)
