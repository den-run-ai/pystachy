tests/programs/library/lib_enum_int_left.py:19: error: unsupported operand type(s) for +: 'int' and 'Color'
