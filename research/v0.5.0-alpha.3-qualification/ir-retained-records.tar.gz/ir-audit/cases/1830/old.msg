tests/programs/numbers/complex_union_reference.py:11: error: unsupported type annotation
