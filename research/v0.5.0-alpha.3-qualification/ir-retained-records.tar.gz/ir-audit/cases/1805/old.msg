tests/programs/numbers/complex_enum_decline.py:25: error: unsupported type annotation
