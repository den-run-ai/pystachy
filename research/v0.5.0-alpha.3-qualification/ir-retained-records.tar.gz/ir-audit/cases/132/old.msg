tests/programs/classes/cmp_notimplemented_enum.py:11: error: type None has no attribute 'value' (compiling Level.__lt__(None) for the call at tests/programs/classes/cmp_notimplemented_enum.py:20)
