tests/errors/classes/constructor_dependency_annotated.py:7: error: mods.constructor_dependency_alias.Wrapped.__init__() is not supported: parameter 'errors': unsupported type annotation
