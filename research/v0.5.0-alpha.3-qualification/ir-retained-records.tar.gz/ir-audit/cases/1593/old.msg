tests/programs/library/lib_datetime_reflected.py:5: error: reflected operator methods are not supported (int * timedelta calls timedelta.__rmul__)
