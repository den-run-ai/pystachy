tests/programs/classes/obj_reflected_number.py:86: error: reflected operator methods are not supported (int + Money calls Money.__radd__)
