tests/programs/classes/constructor_fixed_hierarchy_leaf.py:6: error: inheritance with generic class templates is not supported: annotate __init__ parameters with concrete types (not Any or object)
