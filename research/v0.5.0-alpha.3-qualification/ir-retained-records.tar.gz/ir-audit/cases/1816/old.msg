tests/programs/numbers/complex_optional_number_search.py:16: error: unsupported type annotation
