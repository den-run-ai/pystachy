tests/programs/numbers/complex_new_errors.py:17: error: unsupported call complex(str,int)
