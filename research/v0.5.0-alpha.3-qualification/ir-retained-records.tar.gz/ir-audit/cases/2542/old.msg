tests/programs/upstream/upstream_setcomps.py:25: error: set elements must be int or str, objects, or tuples of int, bool, str, str | None and objects, not None
