tests/programs/numbers/complex_init_noop.py:9: error: unsupported type annotation
