tests/programs/numbers/python_int_vtuple_keys.py:7: error: dict keys must be int or str, objects, or tuples of int, bool, str, str | None and objects, not tuple[int, ...]
