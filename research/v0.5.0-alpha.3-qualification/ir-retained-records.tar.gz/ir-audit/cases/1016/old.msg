tests/programs/inference/dynany_complex_init.py:13: error: complex numbers are not supported
