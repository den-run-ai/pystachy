tests/programs/numbers/complex_union_none_eq.py:6: error: unsupported type annotation
