tests/programs/numbers/complex_enum_own_eq.py:11: error: unsupported type annotation
