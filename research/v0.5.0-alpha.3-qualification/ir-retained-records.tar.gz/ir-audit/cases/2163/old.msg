tests/programs/optional/opt_none_provisional_print.py:6: error: NoneType | None values cannot be compared or printed
