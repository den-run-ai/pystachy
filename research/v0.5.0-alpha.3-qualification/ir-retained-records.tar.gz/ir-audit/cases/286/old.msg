tests/programs/classes/obj_number_conversion_subclass.py:71: error: int() argument must be a string, a bytes-like object or a real number, not 'Base'
