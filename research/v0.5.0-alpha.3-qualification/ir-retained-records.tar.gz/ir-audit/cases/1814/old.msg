tests/programs/numbers/complex_object_eq.py:17: error: complex numbers are not supported
