tests/programs/numbers/complex_unions.py:9: error: unsupported type annotation
