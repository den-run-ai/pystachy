tests/programs/inference/dynany_complex_eq.py:6: error: complex numbers are not supported
