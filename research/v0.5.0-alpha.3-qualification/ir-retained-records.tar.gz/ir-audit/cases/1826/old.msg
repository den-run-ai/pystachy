tests/programs/numbers/complex_union_identity.py:3: error: unsupported type annotation
