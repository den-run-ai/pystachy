tests/programs/numbers/complex_optional_object_eq.py:5: error: unsupported type annotation
