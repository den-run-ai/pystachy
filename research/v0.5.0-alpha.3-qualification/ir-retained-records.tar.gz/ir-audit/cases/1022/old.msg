tests/programs/inference/dynany_complex_union_identity.py:8: error: unsupported type annotation
