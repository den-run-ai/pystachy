define internal void @main.init() personality ptr @pys_personality {
entry:
  %h.63 = alloca ptr
  store ptr zeroinitializer, ptr %h.63
  %t1 = load i64, ptr @pys_recursion_state, !tbaa !6
  store i1 true, ptr @g.Optional.imp
  %t2 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t2, double 0.0, double 1.0)
  %t3 = call ptr @f.widen(ptr %t2)
  %t4 = call ptr @f.pick(ptr null)
  %t5 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t5, double 0.0, double 2.0)
  %t6 = call ptr @f.pick(ptr %t5)
  %t8 = load i64, ptr %t3
  %t11 = icmp eq i64 %t8, 1
  br i1 %t11, label %L10, label %L9
L10:
  %t12 = getelementptr i64, ptr %t3, i64 1
  %t13 = load i64, ptr %t12
  %t14 = inttoptr i64 %t13 to ptr
  %t18 = icmp eq ptr %t14, null
  br i1 %t18, label %L15, label %L16
L15:
  br label %L17
L16:
  %t19 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t14)
  br label %L17
L17:
  %t20 = phi ptr [@s.2, %L15], [%t19, %L16]
  br label %L7
L9:
  %t21 = getelementptr i64, ptr %t3, i64 1
  %t22 = load i64, ptr %t21
  %t23 = call ptr @pys_str_int(i64 %t22)
  br label %L7
L7:
  %t24 = phi ptr [%t20, %L17], [%t23, %L9]
  call void @pys_write(ptr %t24, i64 1)
  call void @pys_write(ptr @s.0, i64 1)
  %t26 = load i64, ptr %t4
  %t29 = icmp eq i64 %t26, 1
  br i1 %t29, label %L28, label %L27
L28:
  %t30 = getelementptr i64, ptr %t4, i64 1
  %t31 = load i64, ptr %t30
  %t32 = inttoptr i64 %t31 to ptr
  %t36 = icmp eq ptr %t32, null
  br i1 %t36, label %L33, label %L34
L33:
  br label %L35
L34:
  %t37 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t32)
  br label %L35
L35:
  %t38 = phi ptr [@s.2, %L33], [%t37, %L34]
  br label %L25
L27:
  %t39 = getelementptr i64, ptr %t4, i64 1
  %t40 = load i64, ptr %t39
  %t41 = call ptr @pys_str_int(i64 %t40)
  br label %L25
L25:
  %t42 = phi ptr [%t38, %L35], [%t41, %L27]
  call void @pys_write(ptr %t42, i64 1)
  call void @pys_write(ptr @s.0, i64 1)
  %t44 = load i64, ptr %t6
  %t47 = icmp eq i64 %t44, 1
  br i1 %t47, label %L46, label %L45
L46:
  %t48 = getelementptr i64, ptr %t6, i64 1
  %t49 = load i64, ptr %t48
  %t50 = inttoptr i64 %t49 to ptr
  %t54 = icmp eq ptr %t50, null
  br i1 %t54, label %L51, label %L52
L51:
  br label %L53
L52:
  %t55 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t50)
  br label %L53
L53:
  %t56 = phi ptr [@s.2, %L51], [%t55, %L52]
  br label %L43
L45:
  %t57 = getelementptr i64, ptr %t6, i64 1
  %t58 = load i64, ptr %t57
  %t59 = call ptr @pys_str_int(i64 %t58)
  br label %L43
L43:
  %t60 = phi ptr [%t56, %L53], [%t59, %L45]
  call void @pys_write(ptr %t60, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t61 = call i64 @pys_try_mark()
  %t62 = call ptr @pys_exc_handled()
  br label %L66
L66:
  %t67 = invoke ptr @f.widen(ptr null) to label %L97 unwind label %L64
L97:
  %t69 = load i64, ptr %t67
  %t72 = icmp eq i64 %t69, 1
  br i1 %t72, label %L71, label %L70
L71:
  %t73 = getelementptr i64, ptr %t67, i64 1
  %t74 = load i64, ptr %t73
  %t75 = inttoptr i64 %t74 to ptr
  %t79 = icmp eq ptr %t75, null
  br i1 %t79, label %L76, label %L77
L76:
  br label %L78
L77:
  %t80 = invoke ptr @m._pystachy_complex$complex.__repr__(ptr %t75) to label %L98 unwind label %L64
L98:
  br label %L78
L78:
  %t81 = phi ptr [@s.2, %L76], [%t80, %L98]
  br label %L68
L70:
  %t82 = getelementptr i64, ptr %t67, i64 1
  %t83 = load i64, ptr %t82
  %t84 = call ptr @pys_str_int(i64 %t83)
  br label %L68
L68:
  %t85 = phi ptr [%t81, %L78], [%t84, %L70]
  invoke void @pys_write(ptr %t85, i64 1) to label %L99 unwind label %L64
L99:
  invoke void @pys_write(ptr @s.1, i64 1) to label %L100 unwind label %L64
L100:
  br label %L65
L64:
  %t87 = landingpad { ptr, i32 } catch ptr null
  %t88 = extractvalue { ptr, i32 } %t87, 0
  store ptr %t88, ptr %h.63
  br label %L86
L86:
  %t89 = load ptr, ptr %h.63
  store i64 %t1, ptr @pys_recursion_state, !tbaa !6
  %t90 = call ptr @pys_exc_begin(ptr %t89, i64 %t61)
  %t93 = call i64 @pys_exc_in(ptr %t90, ptr @s.3)
  %t94 = icmp ne i64 %t93, 0
  br i1 %t94, label %L91, label %L92
L91:
  store ptr %t90, ptr @g.e
  %t95 = load ptr, ptr @g.e
  call void @pys_write(ptr @s.4, i64 1)
  call void @pys_write(ptr @s.0, i64 1)
  %t96 = call ptr @pys_exc_str(ptr %t95)
  call void @pys_write(ptr %t96, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  call void @pys_exc_restore(ptr %t62)
  br label %L65
L92:
  call void @pys_throw(ptr %t90)
  unreachable
L65:
  ret void
}
