define internal ptr @f.widen(ptr %a0) {
entry:
  %c.2 = alloca ptr
  store ptr zeroinitializer, ptr %c.2
  store ptr %a0, ptr %c.2
  %t3 = load ptr, ptr %c.2
  %t4 = icmp eq ptr %t3, null
  br i1 %t4, label %L5, label %L6
L6:
  %t7 = ptrtoint ptr %t3 to i64
  %t8 = call ptr @pys_ubox(i64 1, i64 %t7)
  ret ptr %t8
L5:
  call void @pys_raise(ptr @s.6, ptr @s.5)
  unreachable
}

define internal ptr @f.pick(ptr %a0) {
entry:
  %c.2 = alloca ptr
  store ptr zeroinitializer, ptr %c.2
  store ptr %a0, ptr %c.2
  %t3 = load ptr, ptr %c.2
  %t4 = icmp eq ptr %t3, null
  br i1 %t4, label %L5, label %L6
L5:
  %t8 = call ptr @pys_ubox(i64 2, i64 0)
  ret ptr %t8
L6:
  br label %L7
L7:
  %t9 = load ptr, ptr %c.2
  %t13 = ptrtoint ptr %t9 to i64
  %t14 = call ptr @pys_ubox(i64 1, i64 %t13)
  ret ptr %t14
}
