# Complex union None: independent residual review

The 12 union obligations for `@main.init` remain **rejected**. The first is the tag load from `%t3` at typed `entry:9`, where `%t3` is the normal return of `f.widen`.

There is no caller-local guard before this load. Its safety relies on the separately inspected callee: `f.widen` tests its input, returns a fresh `pys_ubox` only on the non-null arm, and raises TypeError with an `unreachable` terminator on the null arm. Both `f.pick` returns likewise construct union boxes. The intentional later `widen(None)` call unwinds to the TypeError handler rather than reaching its normal-result loads.

The current finite-tag model adds `null` for the internal `_pystachy_complex$complex` name (the nonnullable name list contains `complex`) and proves only that declared return domain. It does not infer the narrower normal-return range established by these bodies. This is an explicit conservative-domain limitation, not a passed proof or a reason to erase any obligation.

Exact typed operations, retained LLVM bodies, runtime boxing source and model-domain excerpts are beside `review.json`, with source hashes and the original rejected count. No checker/source changes or new execution were performed by this reviewer.
