def union_members(typ):
    optional = typ.startswith("opt[") and typ.endswith("]")
    if optional:
        typ = typ[4:-1]
    if not typ.startswith("union[") or not typ.endswith("]"):
        return None
    body, level, start, parts = typ[6:-1], 0, 0, []
    for pos, char in enumerate(body):
        if char == "[":
            level += 1
        elif char == "]":
            level -= 1
        elif char == "," and level == 0:
            parts.append(body[start:pos])
            start = pos + 1
        boundary.require(level >= 0, "unbalanced union type")
    parts.append(body[start:])
    boundary.require(level == 0 and len(parts) >= 2 and len(set(parts)) == len(parts)
                     and all(parts), "invalid union type")
    # Class/file union members may themselves be null. Conservatively retain null
    # unless every member belongs to a known nonnullable value representation.
    value = {"int", "float", "bool", "str", "bytes", "big", "complex"}
    nullable = optional or any(p not in value and not p.startswith(
        ("list[", "dict[", "set[", "frozenset[", "tuple[")) for p in parts)
    return sorted(["member:" + part for part in parts] + ([NULL] if nullable else []))


def proved_returns(snapshot, checker=boundary.DEFAULT_CHECKER):
    """The declared union domains of the functions each of whose returns Lean proves in that
    domain, every proof assuming the others' results (normalize's returns): a greatest fixed
    point, which drops a function whose proof fails and redoes the others without it. Over the
    returns of a run, by induction, each such function returns a value of its domain, given
    union boxes are immutable (box_writes) and parameters hold their declared domains, as every
    union read proof assumes too."""
    functions = {fn["symbol"]: fn for fn in snapshot["functions"]}
    assumed = {symbol: union_members(fn.get("return_representation") or "") for symbol, fn in functions.items()}
    assumed = {symbol: tags for symbol, tags in assumed.items() if tags}
    while True:
        proved = {}
        for symbol, tags in assumed.items():
            try:
                candidate, meta = normalize(snapshot, functions[symbol], immutable_boxes=True, returns=assumed,
                                            obligate_returns=True)
                meta.pop("origins")
                if boundary.run_checker(checker, boundary.encode(candidate), meta):
                    proved[symbol] = tags
            except (boundary.Unsupported, ValueError, KeyError, OSError, subprocess.SubprocessError, RecursionError):
                pass
        if proved.keys() == assumed.keys():
            return proved
        assumed = proved

