"""Bind an isolated full-census checkout to retained, matching Lean executables."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys

OUT = Path(__file__).resolve().parent
REPO = OUT.parents[1] / "alpha3-lean"
EXPECTED = "b0bda81ec2b9954c3c5e0f658c051439126a5c22"
ORIGIN = Path("/workspace/scratch/f0e0f1c84d2f/pystachy")
PRIOR = Path("/workspace/scratch/9d370b13f051")

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()

assert git(REPO, "rev-parse", "HEAD") == EXPECTED
assert git(REPO, "status", "--porcelain") == ""
old_manifest = json.loads((PRIOR / "enum-lean-evidence/final-checker-source-correspondence.json").read_text())
source_rows = []
for row in old_manifest:
    current = REPO / row["path"]
    origin = ORIGIN / row["path"]
    assert digest(current) == digest(origin) == row["sha256"], row["path"]
    source_rows.append(row)
prior_bins = json.loads((PRIOR / "lean-checker-identity.json").read_text())["reused_executables"]
destination = REPO / "tools/lean_boundary/.lake/build/bin"
destination.mkdir(parents=True, exist_ok=True)
copied = {}
for name, row in prior_bins.items():
    source = Path(row["path"])
    assert digest(source) == row["sha256"], name
    target = destination / name
    assert not target.exists(), target
    shutil.copy2(source, target)
    assert digest(target) == row["sha256"] and os.access(target, os.X_OK), name
    copied[name] = {"origin": str(source), "destination": str(target), "sha256": digest(target)}

sys.path.insert(0, str(REPO / "tools"))
import lean_report as r

paths = git(REPO, "ls-files", "--", *r.INPUTS["checkers"]).splitlines()
assert set(paths) == {row["path"] for row in source_rows}, "checker source census changed"
inputs = r.inputs()
assert r.clean_inputs(inputs)
programs = r.corpus.corpus()
promoting = r.storage_corpus.select(programs)
assert git(REPO, "status", "--porcelain") == ""
record = {
    "repo": str(REPO), "commit": EXPECTED, "tree": git(REPO, "rev-parse", "HEAD^{tree}"),
    "python": platform.python_version(), "platform": sys.platform,
    "inputs": inputs, "programs": list(programs), "promoting": list(promoting),
    "expected_programs": len(programs), "expected_promoting": len(promoting),
    "checker_executables": r.checker_executables(r.boundary.DEFAULT_CHECKER, r.access.DEFAULT_CHECKER),
    "copied_executables": copied, "source_correspondence": source_rows,
    "origin_checkout_commit": git(ORIGIN, "rev-parse", "HEAD"),
    "origin_relevant_source_changes": git(ORIGIN, "status", "--porcelain", "--", *paths),
    "prior_identity_file": str(PRIOR / "lean-checker-identity.json"),
    "prior_identity_sha256": digest(PRIOR / "lean-checker-identity.json"),
    "prior_source_correspondence_sha256": digest(PRIOR / "enum-lean-evidence/final-checker-source-correspondence.json"),
    "note": "Physical copies of previously built executables; all 35 checker/adapter/source inputs and five executable SHA256 values independently rechecked. No sources or former evidence changed.",
}
assert not record["origin_relevant_source_changes"]
(OUT / "prepared.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({key: record[key] for key in ("repo", "commit", "tree", "expected_programs", "expected_promoting")}))
