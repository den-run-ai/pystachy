L10:
  %t13 = load i64, ptr %h.8
  %t14 = load i64, ptr %t4
  %t15 = icmp slt i64 %t13, %t14
  br i1 %t15, label %L16, label %L12
L16:
  %t282 = getelementptr inbounds {i64, i64, ptr}, ptr %t4, i64 0, i32 2
  %t283 = load ptr, ptr %t282, !tbaa !16
  %t284 = getelementptr inbounds i64, ptr %t283, i64 %t13
  %t17 = load i64, ptr %t284, !tbaa !17
  %t18 = inttoptr i64 %t17 to ptr
  store ptr %t18, ptr @g.action
