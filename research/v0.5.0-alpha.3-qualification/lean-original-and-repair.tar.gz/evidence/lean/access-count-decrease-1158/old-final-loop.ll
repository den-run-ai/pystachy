  %t241 = call ptr @pys_list_new(i64 2)
  %t242 = ptrtoint ptr %t240 to i64
  call void @pys_list_append(ptr %t241, i64 %t242)
  %t243 = ptrtoint ptr null to i64
  call void @pys_list_append(ptr %t241, i64 %t243)
  store i64 0, ptr %h.244
  %t245 = load i64, ptr %t241
  br label %L246
L246:
  %t249 = load i64, ptr %h.244
  %t250 = load i64, ptr %t241
  %t251 = icmp slt i64 %t249, %t250
  br i1 %t251, label %L252, label %L248
L252:
  %t285 = getelementptr inbounds {i64, i64, ptr}, ptr %t241, i64 0, i32 2
  %t286 = load ptr, ptr %t285, !tbaa !16
  %t287 = getelementptr inbounds i64, ptr %t286, i64 %t249
  %t253 = load i64, ptr %t287, !tbaa !17
  %t254 = inttoptr i64 %t253 to ptr
  %t257 = icmp eq ptr %t254, null
  br i1 %t257, label %L255, label %L256
L256:
  %t258 = load i64, ptr %t254
  %t259 = call ptr @pys_dyn_int(i64 %t258)
  br label %L255
L255:
  %t260 = phi ptr [@pys_dyn_none_box, %L252], [%t259, %L256]
  store ptr %t260, ptr @g.bad
