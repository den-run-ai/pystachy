  %t241 = call ptr @pys_list_new(i64 2)
  %t242 = ptrtoint ptr %t240 to i64
  %t245 = icmp eq ptr %t240, null
  br i1 %t245, label %L243, label %L244
L244:
  %t246 = load i64, ptr %t240
  %t247 = call ptr @pys_dyn_int(i64 %t246)
  br label %L243
L243:
  %t248 = phi ptr [@pys_dyn_none_box, %L229], [%t247, %L244]
  call void @pys_list_append_identity(ptr %t241, i64 %t242, ptr %t248, i64 9)
  %t249 = ptrtoint ptr null to i64
  call void @pys_list_append_identity(ptr %t241, i64 %t249, ptr @pys_dyn_none_box, i64 9)
  store i64 0, ptr %h.250
  %t251 = load i64, ptr %t241
  br label %L252
L252:
  %t255 = load i64, ptr %h.250
  %t256 = load i64, ptr %t241
  %t257 = icmp slt i64 %t255, %t256
  br i1 %t257, label %L258, label %L254
L258:
  %t259 = call ptr @pys_list_get_identity(ptr %t241, i64 %t255, i64 9)
  %t260 = call i64 @pys_list_get(ptr %t241, i64 %t255)
  %t261 = inttoptr i64 %t260 to ptr
  store ptr %t259, ptr @g.bad
