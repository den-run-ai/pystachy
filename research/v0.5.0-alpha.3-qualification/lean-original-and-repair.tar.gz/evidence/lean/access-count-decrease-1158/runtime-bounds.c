static I idx(I i, I n, const char *m) { if (i < 0) i += n; if (i < 0 || i >= n) pys_fail(m); return i; }

Dyn *pys_list_get_identity(List *l, I i, I kind) {
  i = idx(i, l->len, "IndexError: list index out of range");
  pys_list_identity(l, kind); return (Dyn *)l->ids[i + 1];
}

I pys_list_get(List *l, I i) { return AT(l, idx(i, l->len, "IndexError: list index out of range")); }
