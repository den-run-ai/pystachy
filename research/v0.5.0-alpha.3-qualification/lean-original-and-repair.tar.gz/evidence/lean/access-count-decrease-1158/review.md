# Access-count decrease in dynany_iter_errors.py

The access census decreases from two proved unchecked reads to one because the final `for bad in [1, None]` read becomes runtime checked. No remaining unchecked read was removed from the adapter inventory.

Old `@main.init` block `L252` directly loads the list backing array and its indexed payload. New block `L258` calls `pys_list_get_identity` with optional-int identity kind 9, then `pys_list_get` to retain the existing optional representation. Both C helpers invoke `idx` before indexing; `idx` adjusts a negative index and rejects an index outside the current length.

The compiler emits this pair in `gen_list_item`. `list.get_identity` has a `wL` effect because identity materialization can write companion storage. `gen_listget` conservatively stops its unchecked-read rewrite when it encounters that effect, leaving the subsequent runtime bounds check intact. The one remaining unchecked read is the earlier `for action in ['iter', 'list', 'loop']` loop; its backing-array read remains behind its index/length branch.

This is a source/retained-IR explanation of the decreased proof denominator. Runtime C bounds safety is outside the Lean unchecked-access model and is not counted as a newly proved Lean obligation. No compilation, runtime test or checker execution was performed for this review. Exact IR/source hashes and retained snippets are in `review.json` and the adjacent files.
