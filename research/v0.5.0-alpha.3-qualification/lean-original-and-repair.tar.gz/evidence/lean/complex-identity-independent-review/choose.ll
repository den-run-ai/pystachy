define internal ptr @f.choose(ptr %a0) {
entry:
  %value.2 = alloca ptr
  store ptr zeroinitializer, ptr %value.2
  store ptr %a0, ptr %value.2
  %t3 = load ptr, ptr %value.2
  %t4 = icmp eq ptr %t3, null
  br i1 %t4, label %L5, label %L6
L6:
  %t7 = ptrtoint ptr %t3 to i64
  %t8 = call ptr @pys_ubox(i64 1, i64 %t7)
  ret ptr %t8
L5:
  call void @pys_raise(ptr @s.2, ptr @s.1)
  unreachable
}
