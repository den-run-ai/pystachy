# Complex union identity: explicit proof-model limit

The new `dynany_complex_union_identity.py` fixture retains **30 rejected union obligations**: four in the generated complex equality specialization and 26 in `f.check`. The full census does not prove these functions.

The first reported failure in `f.check` is a union-tag read of a value recovered from a tuple. Retained LLVM shows that this word comes from `selected`, which holds the normal return of `f.choose`. `f.choose` raises on a null complex input and returns a fresh `pys_ubox` on its normal arm. The runtime box allocator is nonnull on normal return. The tuple store/load preserves that pointer. The two equality calls likewise obtain their second argument from `selected`.

The adapter conservatively includes null for the internal member spelling `_pystachy_complex$complex`, although its special handling recognizes the public spelling `complex`. Its interprocedural domains therefore retain a null possibility. The caller does not have a local guard proving the problematic read; the reviewed invariant depends on the normal-return contract and pointer preservation. This explains the reported rejection without changing it into an accepted theorem.

The neighboring complex-null fixture's separate 12 rejected obligations have the same return-domain limitation. Together these are 42 rejected obligations newly encountered by alpha3 coverage. The adapter sparse-tag repair does not change this null domain. Exact source/IR hashes, complete relevant functions, and original residual rows are retained in `review.json` and its adjacent files. This audit ran no compiler, runtime, or checker.
