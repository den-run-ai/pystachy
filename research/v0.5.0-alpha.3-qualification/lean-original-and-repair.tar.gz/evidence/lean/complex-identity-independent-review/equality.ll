define internal i1 @m._pystachy_complex$complex.__eq__.1(ptr nonnull %a0, ptr %a1) {
entry:
  %self.2 = alloca ptr
  store ptr zeroinitializer, ptr %self.2
  %other.3 = alloca ptr
  store ptr zeroinitializer, ptr %other.3
  store ptr %a0, ptr %self.2
  store ptr %a1, ptr %other.3
  %t4 = load ptr, ptr %other.3
  %t5 = load i64, ptr %t4
  %t6 = icmp eq i64 %t5, 1
  br i1 %t6, label %L7, label %L8
L7:
  %t10 = load ptr, ptr %self.2
  %t11 = getelementptr %C._pystachy_complex$complex, ptr %t10, i32 0, i32 0
  %t12 = getelementptr %C._pystachy_complex$complex, ptr %t10, i32 0, i32 2
  %t13 = load double, ptr %t11, !tbaa !16
  %t14 = load ptr, ptr %t12, !tbaa !17
  %t15 = call ptr @pys_dyn_float_box(double %t13, ptr %t14)
  store ptr %t15, ptr %t12, !tbaa !17
  %t16 = load ptr, ptr %other.3
  %t19 = icmp eq ptr %t16, null
  br i1 %t19, label %L18, label %L17
L17:
  %t20 = getelementptr i64, ptr %t16, i64 1
  %t21 = load i64, ptr %t20
  %t22 = inttoptr i64 %t21 to ptr
  br label %L18
L18:
  %t23 = phi ptr [null, %L7], [%t22, %L17]
  %t24 = icmp eq ptr %t23, null
  br i1 %t24, label %L25, label %L26
L26:
  %t27 = getelementptr %C._pystachy_complex$complex, ptr %t23, i32 0, i32 0
  %t28 = getelementptr %C._pystachy_complex$complex, ptr %t23, i32 0, i32 2
  %t29 = load double, ptr %t27, !tbaa !16
  %t30 = load ptr, ptr %t28, !tbaa !17
  %t31 = call ptr @pys_dyn_float_box(double %t29, ptr %t30)
  store ptr %t31, ptr %t28, !tbaa !17
  %t32 = fcmp oeq double %t13, %t29
  br i1 %t32, label %L33, label %L34
L33:
  %t35 = load ptr, ptr %self.2
  %t36 = getelementptr %C._pystachy_complex$complex, ptr %t35, i32 0, i32 1
  %t37 = getelementptr %C._pystachy_complex$complex, ptr %t35, i32 0, i32 3
  %t38 = load double, ptr %t36, !tbaa !18
  %t39 = load ptr, ptr %t37, !tbaa !19
  %t40 = call ptr @pys_dyn_float_box(double %t38, ptr %t39)
  store ptr %t40, ptr %t37, !tbaa !19
  %t41 = load ptr, ptr %other.3
  %t44 = icmp eq ptr %t41, null
  br i1 %t44, label %L43, label %L42
L42:
  %t45 = getelementptr i64, ptr %t41, i64 1
  %t46 = load i64, ptr %t45
  %t47 = inttoptr i64 %t46 to ptr
  br label %L43
L43:
  %t48 = phi ptr [null, %L33], [%t47, %L42]
  %t49 = icmp eq ptr %t48, null
  br i1 %t49, label %L50, label %L51
L51:
  %t52 = getelementptr %C._pystachy_complex$complex, ptr %t48, i32 0, i32 1
  %t53 = getelementptr %C._pystachy_complex$complex, ptr %t48, i32 0, i32 3
  %t54 = load double, ptr %t52, !tbaa !18
  %t55 = load ptr, ptr %t53, !tbaa !19
  %t56 = call ptr @pys_dyn_float_box(double %t54, ptr %t55)
  store ptr %t56, ptr %t53, !tbaa !19
  %t57 = fcmp oeq double %t38, %t54
  br label %L34
L34:
  %t58 = phi i1 [%t32, %L26], [%t57, %L51]
  ret i1 %t58
L8:
  br label %L9
L9:
  %t59 = load ptr, ptr %self.2
  %t60 = getelementptr %C._pystachy_complex$complex, ptr %t59, i32 0, i32 1
  %t61 = getelementptr %C._pystachy_complex$complex, ptr %t59, i32 0, i32 3
  %t62 = load double, ptr %t60, !tbaa !18
  %t63 = fcmp oeq double %t62, 0.0
  br i1 %t63, label %L64, label %L65
L64:
  %t66 = load ptr, ptr %self.2
  %t67 = getelementptr %C._pystachy_complex$complex, ptr %t66, i32 0, i32 0
  %t68 = getelementptr %C._pystachy_complex$complex, ptr %t66, i32 0, i32 2
  %t69 = load double, ptr %t67, !tbaa !16
  %t70 = load ptr, ptr %t68, !tbaa !17
  %t71 = call ptr @pys_dyn_float_box(double %t69, ptr %t70)
  store ptr %t71, ptr %t68, !tbaa !17
  %t72 = load ptr, ptr %other.3
  %t73 = getelementptr i64, ptr %t72, i64 1
  %t74 = load i64, ptr %t73
  %t75 = call i64 @pys_cmp_if(i64 %t74, double %t69)
  %t76 = icmp eq i64 %t75, 2
  %t77 = sub i64 0, %t75
  %t78 = select i1 %t76, i64 2, i64 %t77
  %t79 = icmp eq i64 %t78, 0
  br label %L65
L65:
  %t80 = phi i1 [%t63, %L9], [%t79, %L64]
  ret i1 %t80
L25:
  call void @pys_raise(ptr @s.12, ptr @s.11)
  unreachable
L50:
  call void @pys_raise(ptr @s.12, ptr @s.13)
  unreachable
}
