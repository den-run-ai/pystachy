"""Record the independent per-case alpha.2 -> alpha.3 IR review.

This is evidence assembly, not a replacement comparator or an IR oracle change.
Every semantic disposition is explicit below. Raw files are retained and hashed.
"""
from pathlib import Path
from collections import Counter
import hashlib
import json
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/980402bc01c4')
AUDIT = ROOT/'ir-audit'
OUT = ROOT/'evidence/ir-review'
SOURCE = ROOT/'alpha3'

def read(name):
    return json.loads((OUT/name).read_text())

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def receipt(p):
    return {'path':str(p), 'bytes':p.stat().st_size, 'sha256':digest(p)}

analysis=json.loads((AUDIT/'analysis.json').read_text())
triage=read('accepted-ir-triage.json')
semantic={r['case_id']:r for r in read('semantic-inventory.json')['rows']}
layout={r['case_id']:r for r in read('vtuple-layout-evidence.json')['rows']}
constructors={r['case_id']:r for r in read('constructor-equivalence.json')}
prior={r['case_id']:r for r in read('prior-enum-equivalence.json')['rows']}
globals_={r['case_id']:r for r in read('globals-inventory.json')}
notes={}

def put(ids,category,note,anchors):
    for cid in ids:
        assert cid not in notes,cid
        notes[cid]={'category':category,'reason':note,'source_anchors':anchors}

layout_anchors=['runtime.c:106 (VTuple len, ids, a[])','src/pystachy_compiler/lowering.py:321 (vtuple.make)','src/pystachy_compiler/expressions.py:2569 (gen_vtuple_make)']
pure_layout=[85,86,110,412,431,441,448,452,453,454,455,456,457,459,460,463,998,1070,1125,1211,1262,1277,1576,1577,1585,1586,1681,1682,1896,1968,1978,1986,2214,2217,2424,2438,2472,2526,2546,2607,2636,2700,2795]
put(pure_layout,'runtime-tuple-header-layout',
    'The runtime-length tuple now reserves one scanned identity-pointer word after its length. Each recorded allocation grows from 8*(len+1) to 8*(len+2), matching stored length; item addresses and direct tuple iteration move by exactly one word. The addressed objects in the named iteration functions are VTuples. The exact per-function check accounts for every changed instruction: element values, indices, iteration bounds, ordering and control flow are otherwise unchanged. This does not reinterpret fixed tuples or their constant data.',layout_anchors)
for cid in pure_layout:
    r=layout[cid]
    assert not r['other_changed_functions'] and not r['removed_functions'] and not r['added_functions']

put([87,88,89,1743,1744,2674],'unreferenced-reflected-specialization-removal',
    'Only unused mappingproxy.__ror__ specializations disappear, together with now-unused runtime declarations where applicable. Every removed symbol has zero references outside the removed definitions in the old module. All retained function bodies match after exact literal/metadata resolution. This follows lazy admission of reflected methods and removes no executed call.',
    ['src/pystachy_compiler/dynamic.py:3368 (gen_dyn_reflected)','lib/_pystachy_mappingproxy.py'])

enum_anchors=['src/pystachy_compiler/expressions.py:3936 (gen_enum_compare)','evidence/enum-independent-review.md (exact PR head and contracts)']
for cid,r in prior.items():
    assert r['candidate_ir_exactly_equal_after_validated_home_literals']
    extra={
        136:' Earlier alpha.2-to-pre-repair changes are also reviewed: optional primitive tuple-search operands split around None before class dispatch, and the previously constant-false branch is represented by guarded optional paths. The final enum stage preserves lenient narrow-annotation search and correct scalar fallback.',
        625:' Earlier alpha.2-to-pre-repair changes add eleven reflected integer dunder names (__radd__, __rand__, __rfloordiv__, __rlshift__, __rmod__, __rmul__, __ror__, __rrshift__, __rsub__, __rtruediv__, __rxor__) to IntEnum/_IntMixin/IntFlag and concrete numeric enum reflection tables. Table counts and entry indices increase consistently; reflected method availability is intentional.',
        1608:' Earlier alpha.2-to-pre-repair changes remove two uncalled mappingproxy.__ror__ specializations and their now-unused dict-copy/update declarations; no retained call references those removed methods.',
        1620:' Earlier alpha.2-to-pre-repair changes remove one uncalled mappingproxy.__ror__ specialization and now-unused dict-copy/update declarations; no retained call references that method.'
    }.get(cid,'')
    if not extra:
        assert r['baseline_ir_exactly_equal_after_validated_home_literals']
    put([cid],r['prior_classification'],r['prior_note']+
        ' This case is independently tied to the retained prior repair review by whole candidate IR equality after only validated checkout-home literals. '+
        ('The broad baseline also has whole IR equality to the prior baseline; therefore its entire delta is identical.' if not extra else 'The broad baseline differs from the prior baseline, so its additional pre-repair delta was separately retained and reviewed.')+extra,enum_anchors)

constructor_notes={
160:'Used allocation moves before materializing the literal [1, 2] argument. The same list is initialized before the same initializer call; initializer and string methods are otherwise identical.',
164:'Count allocation moves before literal argument-list materialization. Stores, initializer calls and reader methods retain their order and values.',
166:'Nested fixed-field stores and constructor methods are exactly identical after the explicit class/type/function-name map.',
167:'Fixed-field store-order methods are exactly identical after the explicit class/type/function-name map.',
168:'Fixed sequence-store constructor methods are exactly identical after the explicit class/type/function-name map.',
169:'The untyped fixed-constructor methods are exactly identical after the explicit class/type/function-name map.',
1648:'The fixed IO class methods and all callers are exactly identical after the explicit class/type/function-name map.',
1650:'IncrementalNewlineDecoder allocation moves immediately before the same global decoder-argument load. Initialization and subsequent decoder operations are unchanged.',
1655:'The type-module IO class methods and all callers are exactly identical after the explicit class/type/function-name map.',
2419:'C allocation moves before the same kwargs-record materialization; keyword order, values, stores and initializer invocation are preserved.',
2642:'The zeroed newline-decoder allocation moves before constructing its Latin1 argument; Latin1 initialization still completes before decoder initialization. No user-defined allocation hook or initializer is reordered.',
2643:'The tuple decoder methods and all callers are exactly identical after the explicit class/type/function-name map.',
2468:'The S iterator class and its callers retain exact bodies after the S-1 -> S mapping except for 18 named functions. Fourteen have only precisely verified VTuple header/allocation/iteration changes. TestVariousIteratorArgs_tests additionally has the same tuple changes and S allocation before the same argument load. various.1, various.2 and various_numbers move only zeroed S allocation before argument loads or literal [1,2,3,4,5] construction; argument values and initializer-before-iterator-use order are preserved.'
}
for cid,note in constructor_notes.items():
    put([cid],'fixed-constructor-admission-and-layout' if cid!=2468 else 'fixed-constructor-and-runtime-tuple-layout',
        'The admitted fixed layout uses the explicit class/type/TBAA/function mappings in constructor-equivalence.json; this is not a general type-name normalization. '+note+
        ' Every other function is exactly equal after that case-specific map. Moving the built-in zeroed allocation changes storage preparation, not the order of user initializer or argument effects.',
        ['src/pystachy_compiler/program.py:429 (fixed initializer admission)','src/pystachy_compiler/program.py:529 (fixed layout admission)']+(layout_anchors if cid==2468 else []))

put([1590,1594,2638],'datetime-comment-only-source-and-path',
    'Whole IR is identical after the validated checkout-home literal replacement. datetime.py bytes do differ, so this is deliberately not classified as unchanged-library path-only: its full parsed AST is identical and the retained source diff contains only the reflected-timedelta comments. No instruction or diagnostic change remains.',
    ['lib/datetime.py','supplementary-structural-evidence.json:datetime_comment_only'])

put([58,1172,1176],'unused-numeric-identity-capture',
    'Literal numeric identity capture now emits the explicitly listed pys_dyn_int(0) calls in regex parsing helpers. Each result has exactly one SSA occurrence, its definition, and is unused. The complete function is identical after only those recorded dead calls and bijective local/literal/metadata names are accounted for. No value, comparison, branch or externally consumed identity changes.',
    ['src/pystachy_compiler/expressions.py:2872 (gen_tget)','semantic-inventory.json:unused_numeric_box_calls_only'])
put([2369],'unused-numeric-identity-capture-and-constants',
    'String-join slice-bound lowering adds only explicitly recorded unused numeric identity calls. The two added static identity objects for -2**63 and -100 each have exactly one module reference, their own definition. All remaining function instructions and global payloads match; bounds and error handling do not change.',
    ['src/pystachy_compiler/expressions.py:2872 (gen_tget)','supplementary-structural-evidence.json:unused_numeric_identity_globals'])
put([1041],'literal-tuple-item-identity',
    'Identity boxes are produced from literal integers 99 and 0 instead of loading them from @tc.0. That unchanged immutable tuple constant contains exactly 99 and 0; raw tuple values, payload loads and the annotated equality method are otherwise unchanged. This retains the identity associated with source literal items.',
    ['src/pystachy_compiler/expressions.py:2872 (gen_tget)'])
put([1166],'literal-tuple-item-identity',
    'Identity boxes are produced from literal integers 1 and 2 instead of loading them from @tc.0. The unchanged tuple constant contains those exact values. Iterator descriptor identity logic and other functions are unchanged.',
    ['src/pystachy_compiler/expressions.py:2872 (gen_tget)'])
put([131],'known-nonnull-comparison-specialization',
    'The V operands at the affected direct comparison calls are newly constructed and therefore known nonnull. Specialized __eq__ and __lt__ bodies drop unreachable None receiver guards, and main drops the corresponding constant-false NoneType exception branch. The seven removed strings belong only to those unreachable branches; custom comparison method order and accepting results remain.',
    ['src/pystachy_compiler/expressions.py (comparison stage selection)','tests/programs/classes/cmp_notimplemented_direct.py'])
put([1043],'numeric-tuple-search-identity',
    'datetime._check_time_fields membership of fold in (0,1) gains the numeric item-identity fast path before its existing equality checks. Both literal values and all validation/return branches remain. The identity fast path is required for general tuple search and is harmless for these two integers.',
    ['lib/datetime.py (_check_time_fields)','src/pystachy_compiler/expressions.py (tuple search)'])
put([1321],'union-reference-identity-before-equality',
    'Membership/count of union-valued tuple elements now requires matching union alternative tag 3 before comparing the underlying list payload pointers for identity. It does not compare union wrapper addresses as object identity. The original pys_eq fallback remains for unequal identities and all other alternatives, preserving callback behavior while accepting identical reference objects before equality.',
    ['src/pystachy_compiler/expressions.py (union tuple search)','tests/programs/inference/union_object_identity.py'])
put([1236],'reflected-specialization-name-only',
    'The two Box.__radd__ specializations gain the .1 name suffix and their callers change accordingly. All 53 function bodies are exactly identical after only the two explicit symbol mappings, bijective local names and exact literal/metadata resolution. This is a verified specialization rename, not a behavior normalization.',
    ['src/pystachy_compiler/dynamic.py:3368 (gen_dyn_reflected)','supplementary-structural-evidence.json:reflected_specialization_rename'])

generator_anchors=['src/pystachy_compiler/utils.py:37 (generator_identity and generator_slots)','src/pystachy_compiler/generators.py:706 (gen_gen_keep)','src/pystachy_compiler/generators.py:716 (gen_gen_slots)','src/pystachy_compiler/generators.py:728 (yield_snapshot)','src/pystachy_compiler/generators.py:741 (gen_gen_words)','src/pystachy_compiler/generators.py:780 (gen_gen_value)']
generator_notes={
1054:'The generator expression, numbers and dyn.next carry integer identity; main reads the companion before dynamic boxing.',
1055:'The typed integers channel stores the added companion; the boxed forwarding channel snapshots it before converting to Any. Send/return protocol fields retain their original slots.',
1057:'The typed/boxed channel conversions retain the integer companion across yield-from; checked conversions still perform their existing range/type checks.',
1060:'Broken, guarded and stop_inside keep their exception/StopIteration paths; only their yielded numeric payload companions and dyn.next boxing change.',
1061:'Explicit, implicit, inferred and collected generators keep their None return semantics and add only numeric-yield identity plumbing.',
1062:'The send(None) generator retains its protocol state and send handling while yielding payload plus nullable identity; main snapshots that identity.',
1063:'Delegated and source protocol generators forward raw value and identity together; send/throw/close control paths and existing cleanup remain.',
1100:'Float and integer alias generators append slot 5; dyn.next and forwarding channels preserve the yielded boxes. check snapshots each yield before another resume; next(default) uses parallel payload and identity phis; unpack/loop assignment updates identity version only when the object changes. List materialization preserves each yielded identity. The large textual moves in the operation view come from repeated branch sequences, not a new order of source iterator consumption.',
1101:'Alias and overwritten generators store the alias box for aliased yields and null for fresh computed values. Every consumer snapshots the box before another resume. Repeated assignment, tuple unpacking and loops keep separate boxes/version counters for each result; overwriting an earlier promise does not mutate a previously saved identity.',
1102:'Protocol source/typed/dynamic channels use the added identity word after the seven existing protocol words. Raw yields, sends, return values and cleanup are retained while conversions snapshot identity.',
1103:'Scope-specific integer/float generators and dyn.next preserve companions without converting unrelated non-identity scopes to a different payload ABI.',
1158:'In addition to generator companions, the optional-int list path uses identity kind 9 for append/get, preserving the None singleton and saved integer boxes. Existing bad-iterator/error branches remain.',
1159:'DynamicHint, NullableHint, StaticBadHint and UnionHint iterators add integer companions; their length-hint validation and error behavior remain.',
1160:'Numbers.__iter__ and dyn.next carry the existing yielded integer identity; key behavior is unchanged.',
1163:'Huge and InvalidHint iterators add integer companions; sequence-fast and invalid-hint control flow remains.',
1250:'stream yields floating payload plus identity and its consumer updates local identity counters accordingly. The compensated-sum arithmetic and iteration order are unchanged.',
1258:'The imported count generator and dyn.next add identity companions. The tuple value identity uses the verified literal 1. The new dyn.sametype wrapper in this exact module only calls pys_dyn_same_type and returns whether its result is nonzero; no extra class alternative is emitted here, and negated callers use xor true.',
1266:'The typed and side-effecting writing generators preserve payload order and add identity snapshots for dyn.next; zip item acquisition remains in its original order.',
1670:'Only itertools._count and threading._counter change: count yields integer identity and _counter returns it through the existing identity output.',
1671:'Only the imported itertools._count and threading._counter identity channels change; logging configuration and handler behavior remain.',
1672:'Only the imported itertools._count and threading._counter identity channels change; minimum-int logging formatting remains.',
1673:'Only the imported itertools._count and threading._counter identity channels change; LogRecord construction remains.',
1674:'Only the imported itertools._count and threading._counter identity channels change; stderr logging behavior remains.',
1734:'Alongside _count/_counter identity channels, Barrier._enter/_exit add identity-first membership for state integers -1 and 1 before the same equality checks. Barrier synchronization and state transitions are otherwise unchanged.',
1944:'Promoting-int generator frames grow from 9 to 10 words, preserving raw low/high fields and appending identity at slot 9. Integer consumers reuse a matching int box or bigint box only after checking its type and exact wide-pointer payload; otherwise they create a box. Fresh yields store null, aliases preserve boxes, and float yields in the same promoting program use that same companion slot. Yield-from and main assignments snapshot identities before resume and preserve wide/narrow checks.',
2422:'Only the imported itertools._count/threading._counter identity channels change; context-manager and lock behavior remain.',
2602:'The documented dynamic-to-typed generator-channel deviation remains: existing checked conversion and exceptional ownership/cleanup paths are retained. The changed IR adds only the yielded companion and snapshots; it does not establish new support for the documented deviation.',
2603:'The documented protocol-channel deviation and its conversion error remain. The concrete numeric channel adds the companion without changing send/close behavior.',
2653:'Only the imported counter identity channels change; the existing logging exc_info deviation remains.',
2699:'Only the imported counter identity channels change; the existing threading.start deviation remains.',
2719:'Only the logging benchmark imported counter identity channels change; benchmark work and logging calls are unchanged.'
}
for cid,note in generator_notes.items():
    put([cid],'numeric-generator-identity-channel',
        'The numeric coroutine promise appends a nullable object-identity word after its existing raw/protocol/wide fields. Producers preserve alias boxes or use null for fresh computed values, and consumers copy the companion into a private slot before the next resume; raw numeric value layout and cleanup remain. '+note,generator_anchors)

identity_anchors=['runtime.c:106 (VTuple identity header)','runtime.c:3147 (pys_vtuple_set_identity/get_identity)','src/pystachy_compiler/expressions.py:2569 (construction)','src/pystachy_compiler/expressions.py:2587 (item access)','src/pystachy_compiler/expressions.py:2872 (fixed tuple item identity)','src/pystachy_compiler/dynamic.py (numeric identity capture and boxing)']
identity_notes={
1012:'The two float tuple items gain explicit retained identity constants for 1.0 and 2.0, the runtime tuple header grows by one word, and set_identity stores the corresponding boxes. Union-field payload values and comparison alternatives are unchanged.',
1122:'Optional-float list and VTuple effects now capture each value and its box before later arguments/callbacks can rebind or mutate the source. Mutators use kind 10. Search queries keep separate item and query descriptors (including A) rather than prematurely coercing the query to optional float. Query.__eq__ mutates payload and identity together. The added recursion-enter/restore surrounds callback-capable comparison paths.',
1123:'Imported make/replace/read and list-to-VTuple conversion preserve optional-float boxes using kind 10. None remains the singleton, cross-module mutation updates both payload and identity, and reads return the stored box instead of freshly boxing the numeric payload.',
1124:'Optional-int/float list append, set, insert, pop, remove, count, index, iteration, copy, slice, repeat and clear preserve item identities. Kinds 9 and 10 distinguish nullable payloads; searches pass separate optional/string/float query descriptors, so cross-kind equality and shared-NaN identity are retained. Pop returns the saved dynamic box and reconstructs any typed optional representation separately.',
1126:'Optional numeric VTuples reserve the identity header and set kinds 9/10 on all literal elements including the None singleton. Construction, list conversion, slicing, concatenation, widening, unpacking and reads preserve or share the same item boxes while keeping their own container storage. Nullable reads retain the raw optional payload and attach the saved identity; plain numeric reads unbox the saved identity. Fresh optional values are boxed once at the capture boundary.',
1146:'VTuple construction captures numeric boxes before later arguments mutate/rebind inputs. Generator consumption snapshots identities, and tuple comparison uses identity before equality for the same numeric object. Payload evaluation order remains the source order, and copies retain shared element identity rather than wrapper identity.',
1147:'Runtime tuple materialization, copy/slice/list conversion and item access preserve stored numeric identities, including shared NaN, positive/negative zero and static literal boxes. Fresh elements can lazily materialize their own boxes; separate equal float objects are not merged by numeric equality.',
1239:'The slice-error fixture changes only runtime tuple header sizing and three set_identity calls for the existing literal integers 1, 2 and 3. Slice bounds, step validation and exception branches remain.',
1965:'Optional promoting-int list/VTuple operations preserve kinds 9 companions for small, minimum-width and shared items. Removing a temporary fixed tuple preserves its original coerced payloads and wide checks before final VTuple storage. Pop carries the saved identity while reconstructing the optional representation. Raw-int tuples use kind 1 and widening to optional storage keeps those same identities.',
1992:'Promoting-int VTuple item reads use the retained companion and exact unboxing, including the imported checked.first path; construction and copy paths reserve and preserve the identity header. Wide/narrow numeric payload checks are retained.',
1994:'Dynamic conversion adds only the VTuple header. Optional materialization eliminates an intermediate fixed-tuple allocation while retaining original element evaluations/coercions and saving their identities before final storage. Small/promoting items reuse a bigint companion only when its type and high-pointer payload match; otherwise they call pys_dyn_big. Checked narrowing still rejects a value that does not fit.'
}
for cid,note in identity_notes.items():
    put([cid],'numeric-container-identity-companions',note+' The per-function and globals inventories retain every other change for this case; this is an intended identity-semantics repair, not a claim of raw IR equivalence.',identity_anchors)

for cid in [1736,1737,1738,1739,1740,1741,2557,2558]:
    if cid==1740:
        note='Only datetime fold membership gains identity-before-equality, and the unreferenced mappingproxy.__ror__ method disappears.'
    else:
        note='Runtime tuple allocation/iteration follows the added identity header. Separately from tuple layout, key_value_rule, create_dict_rule and create_list_rule retain null checks on Flags receivers loaded from Output.flags (field 1) before Flags.add_pending, the second Flags.is_, and Flags.unset_all respectively. Their null arms raise AttributeError with the corresponding NoneType method message. datetime fold membership gains identity-before-equality. The unreferenced mappingproxy.__ror__ method and now-unused declarations disappear.'
    put([cid],'toml-tuple-null-guards-and-layout',note+
        ' Every changed retained function has the exact same old/new canonical body as the corresponding independently inspected function in case 1736; the equality check retains exact literal and metadata contents. The removed reflected symbol has no remaining references.',
        layout_anchors+['lib/tomllib/_parser.py','lib/datetime.py (_check_time_fields)','supplementary-structural-evidence.json:toml_shared_function_checks'])

assert set(notes)==set(semantic), {'missing':sorted(set(semantic)-set(notes)), 'extra':sorted(set(notes)-set(semantic))}
rows=[]
for original in triage['rows']:
    row=dict(original)
    cid=row['case_id']; p=AUDIT/'cases'/str(cid)
    assert digest(p/'old.ll')==row['raw_ir_sha256']['old']
    assert digest(p/'new.ll')==row['raw_ir_sha256']['new']
    assert digest(SOURCE/row['case'])==row['source_sha256']
    assert (p/'old.status').read_text().strip()=='0' and (p/'new.status').read_text().strip()=='0'
    assert (p/'old.msg').read_bytes()==(p/'new.msg').read_bytes()==b''
    row['evidence']={name:receipt(p/name) for name in ['case','old.status','new.status','old.msg','new.msg','old.ll','new.ll','ir.raw.diff']}
    row['source']=receipt(SOURCE/row['case'])
    row['status']='reviewed_no_blocking_findings'
    row['runtime_or_lean_proof_granted_by_this_review']=False
    if cid in notes:
        row['structural_triage_category']=row.pop('classification')
        row.update(notes[cid])
        row['reviewed_function_inventory']=semantic[cid]
        row['reviewed_global_inventory']=globals_[cid]
        row['semantic_review_views']={name:receipt(OUT/'semantic-views'/f'{cid}.{name}.diff') for name in ['functions','globals','operations']}
        if cid in layout: row['exact_layout_checks']=layout[cid]
        if cid in constructors: row['explicit_constructor_checks']=constructors[cid]
        if cid in prior: row['retained_prior_enum_binding']=prior[cid]
    else:
        row['category']=row.pop('classification')
        row['reason']=row.pop('review_note')
    row['disposition']='expected_and_explained_IR_change'
    row['explanation']=row['case']+': '+row['reason']
    rows.append(row)

counts=dict(Counter(r['category'] for r in rows))
report={
    'schema_version':1,
    'status':'reviewed_no_blocking_findings',
    'created_utc':datetime.now(timezone.utc).isoformat(),
    'baseline_commit':analysis['baseline'],
    'candidate_commit':analysis['source'],
    'candidate_tree':'e027b37c888326e3d8a3e8b89522a6b397dcb86d',
    'analysis':receipt(AUDIT/'analysis.json'),
    'identity':receipt(AUDIT/'identity.json'),
    'counts':{'accepted_IR_differences':len(rows),'new_rejections':len(analysis['newly_rejected']),'unexpected_process_statuses':len(analysis['unexpected_process_statuses']),'unexplained_cases':0},
    'categories':counts,
    'findings':[],
    'method':[
        'Read-only independent review of retained raw old/new IR and source integration. No comparison predicate, oracle, production input or source was edited.',
        '196 path-only cases require exact validated LLVM literal replacement and equal referenced library bytes. Three changed datetime source files instead have a separately verified comment-only full AST identity.',
        '32 unused-type cases require whole IR equality outside only the changed, unreferenced declaration lines.',
        'All 151 remaining cases have explicit semantic dispositions, complete function/global inventories and retained raw diff hashes. Per-function bijective local names and exact literal/metadata contents aid reading; opcode/operand/control-flow differences remain reviewed changes.',
        'Operation views that replace locals by %VAR are reading aids only, never equality proofs or acceptance criteria.',
        'Prior enum evidence is used only for 26 individually verified whole-IR matches; 22 baseline/candidate pairs match the prior pair, and four additional broad-baseline deltas are separately reviewed.',
        'Unused numeric calls, explicit constructor/name mappings, VTuple layout changes and source AST checks have bounded dedicated evidence, never blanket normalization.'
    ],
    'limitations':[
        'This review establishes a disposition of emitted IR differences and reports no blocking source/IR finding; it is not a proof of whole-compiler, runtime or collector correctness.',
        'No compiler, native-execution, GC stress, bootstrap, performance or Lean run was performed by this review; those are separate release gates owned by the parent.',
        'Known documented deviation fixtures remain deviations. New accepted fixtures do not by themselves establish a runtime result.',
        'Lean residual obligations and the concurrently discovered dynamic-complex proof-adapter errors are not waived by this report. Any subsequent repair requires its own pinned review/validation.'
    ],
    'rows':rows
}
(OUT/'accepted-ir-review.json').write_text(json.dumps(report,indent=2)+'\n')
md=['# Independent accepted-IR disposition','',
    f"Baseline: `{analysis['baseline']}`. Candidate: `{analysis['source']}` (tree `{report['candidate_tree']}`).",'',
    '**Result: all 379 accepted-to-accepted IR differences are accounted for; no blocking source/IR finding or unexplained semantic change was identified.** This conclusion is limited to the retained IR comparison. It does not grant runtime or Lean proof, and does not waive proof-adapter errors found by other release gates.','',
    '| Disposition | Cases |','| --- | ---: |']
md += [f'| {k} | {v} |' for k,v in counts.items()]
md += ['', '## Evidence and review boundaries','']+[f'- {m}' for m in report['method']]
md += ['', 'The complete per-case reasons, exact source and raw-result hashes, changed function/global inventory, and bounded structural checks are in `accepted-ir-review.json`. `original-input-disposition.json` independently covers the old versions of changed/removed inputs and their import helpers. No raw case was deleted or rewritten.','', '## Per-case disposition','']
for r in rows:
    md += [f"### {r['case_id']}: {r['case']}",'',f"**{r['category']}.** {r['reason']}",'']
(OUT/'accepted-ir-review.md').write_text('\n'.join(md)+'\n')

other=read('acceptance-diagnostic-review.json')
assert other['status']=='reviewed_no_blocking_findings'
assert other['source_commit']==analysis['source'] and other['baseline_commit']==analysis['baseline']
combined=[]
for r in rows:
    combined.append({'case_id':r['case_id'],'case':r['case'],'old_status':0,'new_status':0,'category':r['category'],'explanation':r['explanation'],'disposition':r['disposition'],'review':'accepted-ir-review.json','evidence':r['evidence']})
for r in other['rows']:
    for item in r['evidence'].values():
        if isinstance(item,dict) and 'path' in item and 'sha256' in item:
            assert digest(Path(item['path']))==item['sha256'],item['path']
    assert digest(Path(r['source']['path']))==r['source']['sha256']
    combined.append({'case_id':r['index'],'case':r['case'],'old_status':r['old_status'],'new_status':r['new_status'],'category':r['category'],'explanation':r['case']+': '+r['reason'],'disposition':r['disposition'],'review':'acceptance-diagnostic-review.json','evidence':r['evidence']})
combined.sort(key=lambda r:r['case_id'])
expected={i:r['case'] for i,r in enumerate(analysis['rows'],1) if r['different']}
assert len(combined)==len(expected)==562
assert {r['case_id']:r['case'] for r in combined}==expected
assert len({r['case_id'] for r in combined})==562
assert all(r['explanation'] and r['disposition'] for r in combined)
original=read('original-input-disposition.json')
full={
    'schema_version':1,'status':'reviewed_no_blocking_IR_findings',
    'baseline_commit':analysis['baseline'],'candidate_commit':analysis['source'],
    'candidate_tree':report['candidate_tree'],
    'counts':{'retained_cases':4771,'unchanged':4209,'changed':562,'accepted_IR_changes':379,'new_acceptances':121,'changed_rejection_diagnostics':62,'new_rejections':0,'unexpected_process_statuses':0,'unexplained_changed_cases':0},
    'original_input_supplement':receipt(OUT/'original-input-disposition.json'),
    'component_reviews':{name:receipt(OUT/name) for name in ['accepted-ir-review.json','acceptance-diagnostic-review.json','original-input-disposition.json']},
    'analysis':receipt(AUDIT/'analysis.json'),'identity':receipt(AUDIT/'identity.json'),
    'findings':[],
    'limitations':report['limitations']+other['limitations'],
    'rows':combined
}
(OUT/'full-disposition.json').write_text(json.dumps(full,indent=2)+'\n')
summary=f'''# Independent full IR disposition: alpha.2 → alpha.3

Baseline `{analysis['baseline']}` → candidate `{analysis['source']}`, tree `{report['candidate_tree']}`.

**All 562 changed records are explained; zero new rejections, unexpected process statuses or unexplained IR cases were found.** The retained 4,771-case scan has 4,209 unchanged cases. The strict comparator's differences remain intact and its exit 1 is accounted for by the explicit dispositions below.

| Changed record | Cases | Review |
| --- | ---: | --- |
| Accepted by both, changed IR | 379 | `accepted-ir-review.json` |
| Newly accepted | 121 | `acceptance-diagnostic-review.json` |
| Rejected by both, changed diagnostic | 62 | `acceptance-diagnostic-review.json` |
| New rejection | 0 | Full retained status census |

## Main conclusions

- Of the 379 accepted IR changes, 196 are exact checkout-path literals with identical referenced library bytes, and 32 affect only unreferenced class declarations. The remaining 151 receive explicit per-case semantic dispositions and retain complete changed-function/global inventories.
- The principal semantic changes are the scanned VTuple identity header and numeric identity companions, numeric generator promise companions, fixed-constructor admission, enum comparison/payload repair, lazy uncalled reflected-method generation, and retained None guards on Tomllib Output.flags receivers before method calls. No general normalization of instructions, constants, branches, addresses or diagnostics was used to accept them.
- Prior enum-only review is bound by whole IR equality case by case. Twenty-two broad old/new pairs are exact prior pairs after validated checkout literals; four additional broad-baseline deltas were separately reviewed. That older review is not substituted for the release-wide audit.
- The 121 new acceptances comprise 120 added inputs and the changed upstream_setcomps input. There are 119 positive fixtures and two explicitly documented deviation fixtures. All 62 changed rejections keep exit 1, exactly one expected diagnostic and no LLVM output; no error fixture became accepted.
- An independent original-input supplement compiles 13 old-source cases, including six removed error inputs, five modified inputs (one an import helper), the renamed reflected_rand input, and its import consumer. All 129 original source/sidecar/helper hashes and retained results were verified. It records five cases accepted by both, three rejected by both and five newly accepted, with zero new rejections. The renamed file differs only in its first comment and has the same AST; it was not falsely called byte-identical.

## Approval scope

This independent review finds no blocking source/IR defect in the retained candidate comparison. It grants **no native runtime, GC, performance, bootstrap or Lean proof**. Those gates remain separate. In particular, concurrently discovered dynamic-complex Lean adapter errors and residual obligations are not waived; any repair must be separately pinned, reviewed and validated.

`full-disposition.json` has one unique entry for each of all 562 changed cases, with component review pointers and retained result hashes. The accepted-case source and old/new IR hashes and all acceptance/diagnostic evidence were rechecked during final assembly. Raw oracle output and production source remain untouched.
'''
(OUT/'full-disposition.md').write_text(summary)
print(json.dumps({'status':full['status'],'counts':full['counts'],'accepted_categories':counts,'artifacts':['accepted-ir-review.json','accepted-ir-review.md','full-disposition.json','full-disposition.md']},indent=2))
