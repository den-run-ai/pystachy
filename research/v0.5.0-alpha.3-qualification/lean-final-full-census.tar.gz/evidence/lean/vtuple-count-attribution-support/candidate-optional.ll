define internal ptr @f.optional({i64, ptr} %a0, ptr %aid0) {
entry:
  %n.2 = alloca {i64, ptr}
  store {i64, ptr} zeroinitializer, ptr %n.2
  %n.box.2 = alloca ptr
  store ptr zeroinitializer, ptr %n.box.2
  %n.boxgen.2 = alloca i64
  store i64 zeroinitializer, ptr %n.boxgen.2
  %h.53 = alloca ptr
  store ptr zeroinitializer, ptr %h.53
  %h.56 = alloca i64
  store i64 zeroinitializer, ptr %h.56
  store {i64, ptr} %a0, ptr %n.2
  store ptr %aid0, ptr %n.box.2
  %t3 = load {i64, ptr}, ptr %n.2
  %t4 = load ptr, ptr %n.box.2
  %t5 = load i64, ptr %n.boxgen.2
  %t9 = extractvalue {i64, ptr} %t3, 1
  %t10 = ptrtoint ptr %t9 to i64
  %t11 = icmp eq i64 %t10, 0
  br i1 %t11, label %L6, label %L7
L6:
  %t12 = extractvalue {i64, ptr} %t3, 0
  %t13 = load ptr, ptr %n.box.2
  %t14 = icmp ne ptr %t4, null
  %t15 = select i1 %t14, ptr %t4, ptr %t13
  %t20 = icmp ne ptr %t15, null
  br i1 %t20, label %L16, label %L18
L16:
  %t21 = load ptr, ptr %t15
  %t22 = icmp eq ptr %t21, @pys_dyntype_int
  %t23 = getelementptr i64, ptr %t15, i64 1
  %t24 = load i64, ptr %t23
  %t25 = icmp eq i64 %t24, %t12
  %t26 = and i1 %t22, %t25
  br i1 %t26, label %L17, label %L18
L17:
  br label %L19
L18:
  %t27 = call ptr @pys_dyn_int(i64 %t12)
  %t29 = icmp eq ptr %t15, null
  %t30 = and i1 %t29, true
  br i1 %t30, label %L28, label %L19
L28:
  store ptr %t27, ptr %n.box.2
  br label %L19
L19:
  %t31 = phi ptr [%t15, %L17], [%t27, %L18], [%t27, %L28]
  br label %L8
L7:
  %t32 = load ptr, ptr %n.box.2
  %t33 = icmp ne ptr %t4, null
  %t34 = select i1 %t33, ptr %t4, ptr %t32
  %t39 = icmp ne ptr %t34, null
  br i1 %t39, label %L35, label %L37
L35:
  %t40 = load ptr, ptr %t34
  %t41 = icmp eq ptr %t40, @pys_dyntype_bigint
  %t42 = getelementptr i64, ptr %t34, i64 1
  %t43 = load i64, ptr %t42
  %t44 = extractvalue {i64, ptr} %t3, 1
  %t45 = ptrtoint ptr %t44 to i64
  %t46 = icmp eq i64 %t43, %t45
  %t47 = and i1 %t41, %t46
  br i1 %t47, label %L36, label %L37
L36:
  br label %L38
L37:
  %t48 = extractvalue {i64, ptr} %t3, 1
  %t49 = call ptr @pys_dyn_big(i64 0, ptr %t48)
  br i1 true, label %L50, label %L38
L50:
  store ptr %t49, ptr %n.box.2
  br label %L38
L38:
  %t51 = phi ptr [%t34, %L36], [%t49, %L37], [%t49, %L50]
  br label %L8
L8:
  %t52 = phi ptr [%t31, %L19], [%t51, %L38]
  store ptr null, ptr %h.53
  %t54 = call {i64, ptr} @f.item(ptr @s.11, {i64, ptr} %t3, ptr %t52, ptr %h.53)
  %t55 = load ptr, ptr %h.53
  %t60 = extractvalue {i64, ptr} %t54, 1
  %t61 = ptrtoint ptr %t60 to i64
  %t62 = icmp eq i64 %t61, 0
  br i1 %t62, label %L57, label %L58
L57:
  %t63 = extractvalue {i64, ptr} %t54, 0
  %t64 = load ptr, ptr %h.53
  %t65 = call ptr @pys_dyn_int_box(i64 %t63, ptr %t64)
  store ptr %t65, ptr %h.53
  br label %L59
L58:
  %t66 = load ptr, ptr %h.53
  %t67 = icmp ne ptr %t55, null
  %t68 = select i1 %t67, ptr %t55, ptr %t66
  %t73 = icmp ne ptr %t68, null
  br i1 %t73, label %L69, label %L71
L69:
  %t74 = load ptr, ptr %t68
  %t75 = icmp eq ptr %t74, @pys_dyntype_bigint
  %t76 = getelementptr i64, ptr %t68, i64 1
  %t77 = load i64, ptr %t76
  %t78 = extractvalue {i64, ptr} %t54, 1
  %t79 = ptrtoint ptr %t78 to i64
  %t80 = icmp eq i64 %t77, %t79
  %t81 = and i1 %t75, %t80
  br i1 %t81, label %L70, label %L71
L70:
  br label %L72
L71:
  %t82 = extractvalue {i64, ptr} %t54, 1
  %t83 = call ptr @pys_dyn_big(i64 0, ptr %t82)
  br i1 true, label %L84, label %L72
L84:
  store ptr %t83, ptr %h.53
  br label %L72
L72:
  %t85 = phi ptr [%t68, %L70], [%t83, %L71], [%t83, %L84]
  br label %L59
L59:
  %t86 = phi ptr [%t65, %L57], [%t85, %L72]
  %t87 = load {i64, ptr}, ptr %n.2
  %t88 = load ptr, ptr %n.box.2
  %t89 = load i64, ptr %n.boxgen.2
  %t90 = insertvalue {i64, ptr} undef, i64 0, 0
  %t91 = insertvalue {i64, ptr} %t90, ptr null, 1
  %t95 = extractvalue {i64, ptr} %t91, 1
  %t96 = ptrtoint ptr %t95 to i64
  %t97 = extractvalue {i64, ptr} %t87, 1
  %t98 = ptrtoint ptr %t97 to i64
  %t99 = or i64 %t96, %t98
  %t100 = icmp eq i64 %t99, 0
  br i1 %t100, label %L92, label %L93
L92:
  %t101 = extractvalue {i64, ptr} %t91, 0
  %t102 = extractvalue {i64, ptr} %t87, 0
  %t103 = call {i64, i1} @llvm.ssub.with.overflow.i64(i64 %t101, i64 %t102)
  %t104 = extractvalue {i64, i1} %t103, 0
  %t105 = extractvalue {i64, i1} %t103, 1
  br i1 %t105, label %L93, label %L106
L106:
  %t107 = insertvalue {i64, ptr} undef, i64 %t104, 0
  %t108 = insertvalue {i64, ptr} %t107, ptr null, 1
  br label %L94
L93:
  %t109 = extractvalue {i64, ptr} %t91, 0
  %t110 = extractvalue {i64, ptr} %t91, 1
  %t111 = extractvalue {i64, ptr} %t87, 0
  %t112 = extractvalue {i64, ptr} %t87, 1
  %t113 = call {i64, ptr} @pys_big_op(i64 %t109, ptr %t110, i64 %t111, ptr %t112, i64 1)
  br label %L94
L94:
  %t114 = phi {i64, ptr} [%t108, %L106], [%t113, %L93]
  %t115 = extractvalue {i64, ptr} %t54, 1
  %t116 = ptrtoint ptr %t115 to i64
  %t117 = icmp eq i64 %t116, 0
  %t118 = xor i1 %t117, true
  br i1 %t118, label %L119, label %L120
L120:
  %t121 = extractvalue {i64, ptr} %t54, 0
  %t122 = call ptr @pys_box(i64 %t121)
  %t123 = extractvalue {i64, ptr} %t114, 1
  %t124 = ptrtoint ptr %t123 to i64
  %t125 = icmp eq i64 %t124, 0
  %t126 = xor i1 %t125, true
  br i1 %t126, label %L119, label %L127
L127:
  %t128 = extractvalue {i64, ptr} %t114, 0
  %t129 = call ptr @pys_box(i64 %t128)
  %t132 = icmp eq ptr %t129, null
  br i1 %t132, label %L130, label %L131
L131:
  %t133 = load i64, ptr %t129
  %t134 = call ptr @pys_dyn_int(i64 %t133)
  br label %L130
L130:
  %t135 = phi ptr [@pys_dyn_none_box, %L127], [%t134, %L131]
  %t136 = call ptr @pys_alloc(i64 40)
  store i64 3, ptr %t136
  %vt.136.0 = getelementptr i64, ptr %t136, i64 2
  store ptr %t122, ptr %vt.136.0
  %vt.136.1 = getelementptr i64, ptr %t136, i64 3
  store ptr null, ptr %vt.136.1
  %vt.136.2 = getelementptr i64, ptr %t136, i64 4
  store ptr %t129, ptr %vt.136.2
  call void @pys_vtuple_set_identity(ptr %t136, i64 0, ptr %t86, i64 9)
  call void @pys_vtuple_set_identity(ptr %t136, i64 1, ptr @pys_dyn_none_box, i64 9)
  call void @pys_vtuple_set_identity(ptr %t136, i64 2, ptr %t135, i64 9)
  ret ptr %t136
L119:
  call void @pys_raise(ptr @s.10, ptr @s.9)
  unreachable
}
