define internal ptr @f.optional({i64, ptr} %a0, ptr %aid0) {
entry:
  %n.2 = alloca {i64, ptr}
  store {i64, ptr} zeroinitializer, ptr %n.2
  %n.box.2 = alloca ptr
  store ptr zeroinitializer, ptr %n.box.2
  %n.boxgen.2 = alloca i64
  store i64 zeroinitializer, ptr %n.boxgen.2
  %h.53 = alloca ptr
  store ptr zeroinitializer, ptr %h.53
  %h.56 = alloca i64
  store i64 zeroinitializer, ptr %h.56
  store {i64, ptr} %a0, ptr %n.2
  store ptr %aid0, ptr %n.box.2
  %t3 = load {i64, ptr}, ptr %n.2
  %t4 = load ptr, ptr %n.box.2
  %t5 = load i64, ptr %n.boxgen.2
  %t9 = extractvalue {i64, ptr} %t3, 1
  %t10 = ptrtoint ptr %t9 to i64
  %t11 = icmp eq i64 %t10, 0
  br i1 %t11, label %L6, label %L7
L6:
  %t12 = extractvalue {i64, ptr} %t3, 0
  %t13 = load ptr, ptr %n.box.2
  %t14 = icmp ne ptr %t4, null
  %t15 = select i1 %t14, ptr %t4, ptr %t13
  %t20 = icmp ne ptr %t15, null
  br i1 %t20, label %L16, label %L18
L16:
  %t21 = load ptr, ptr %t15
  %t22 = icmp eq ptr %t21, @pys_dyntype_int
  %t23 = getelementptr i64, ptr %t15, i64 1
  %t24 = load i64, ptr %t23
  %t25 = icmp eq i64 %t24, %t12
  %t26 = and i1 %t22, %t25
  br i1 %t26, label %L17, label %L18
L17:
  br label %L19
L18:
  %t27 = call ptr @pys_dyn_int(i64 %t12)
  %t29 = icmp eq ptr %t15, null
  %t30 = and i1 %t29, true
  br i1 %t30, label %L28, label %L19
L28:
  store ptr %t27, ptr %n.box.2
  br label %L19
L19:
  %t31 = phi ptr [%t15, %L17], [%t27, %L18], [%t27, %L28]
  br label %L8
L7:
  %t32 = load ptr, ptr %n.box.2
  %t33 = icmp ne ptr %t4, null
  %t34 = select i1 %t33, ptr %t4, ptr %t32
  %t39 = icmp ne ptr %t34, null
  br i1 %t39, label %L35, label %L37
L35:
  %t40 = load ptr, ptr %t34
  %t41 = icmp eq ptr %t40, @pys_dyntype_bigint
  %t42 = getelementptr i64, ptr %t34, i64 1
  %t43 = load i64, ptr %t42
  %t44 = extractvalue {i64, ptr} %t3, 1
  %t45 = ptrtoint ptr %t44 to i64
  %t46 = icmp eq i64 %t43, %t45
  %t47 = and i1 %t41, %t46
  br i1 %t47, label %L36, label %L37
L36:
  br label %L38
L37:
  %t48 = extractvalue {i64, ptr} %t3, 1
  %t49 = call ptr @pys_dyn_big(i64 0, ptr %t48)
  br i1 true, label %L50, label %L38
L50:
  store ptr %t49, ptr %n.box.2
  br label %L38
L38:
  %t51 = phi ptr [%t34, %L36], [%t49, %L37], [%t49, %L50]
  br label %L8
L8:
  %t52 = phi ptr [%t31, %L19], [%t51, %L38]
  store ptr null, ptr %h.53
  %t54 = call {i64, ptr} @f.item(ptr @s.11, {i64, ptr} %t3, ptr %t52, ptr %h.53)
  %t55 = load ptr, ptr %h.53
  %t57 = load {i64, ptr}, ptr %n.2
  %t58 = load ptr, ptr %n.box.2
  %t59 = load i64, ptr %n.boxgen.2
  %t60 = insertvalue {i64, ptr} undef, i64 0, 0
  %t61 = insertvalue {i64, ptr} %t60, ptr null, 1
  %t65 = extractvalue {i64, ptr} %t61, 1
  %t66 = ptrtoint ptr %t65 to i64
  %t67 = extractvalue {i64, ptr} %t57, 1
  %t68 = ptrtoint ptr %t67 to i64
  %t69 = or i64 %t66, %t68
  %t70 = icmp eq i64 %t69, 0
  br i1 %t70, label %L62, label %L63
L62:
  %t71 = extractvalue {i64, ptr} %t61, 0
  %t72 = extractvalue {i64, ptr} %t57, 0
  %t73 = call {i64, i1} @llvm.ssub.with.overflow.i64(i64 %t71, i64 %t72)
  %t74 = extractvalue {i64, i1} %t73, 0
  %t75 = extractvalue {i64, i1} %t73, 1
  br i1 %t75, label %L63, label %L76
L76:
  %t77 = insertvalue {i64, ptr} undef, i64 %t74, 0
  %t78 = insertvalue {i64, ptr} %t77, ptr null, 1
  br label %L64
L63:
  %t79 = extractvalue {i64, ptr} %t61, 0
  %t80 = extractvalue {i64, ptr} %t61, 1
  %t81 = extractvalue {i64, ptr} %t57, 0
  %t82 = extractvalue {i64, ptr} %t57, 1
  %t83 = call {i64, ptr} @pys_big_op(i64 %t79, ptr %t80, i64 %t81, ptr %t82, i64 1)
  br label %L64
L64:
  %t84 = phi {i64, ptr} [%t78, %L76], [%t83, %L63]
  %t85 = call ptr @pys_alloc(i64 48)
  %t86 = extractvalue {i64, ptr} %t54, 1
  %t87 = ptrtoint ptr %t86 to i64
  %t88 = icmp ne i64 %t87, 0
  %t89 = extractvalue {i64, ptr} %t54, 0
  %t90 = select i1 %t88, i64 -9223372036854775808, i64 %t89
  %t91 = getelementptr i64, ptr %t85, i64 0
  store i64 %t90, ptr %t91
  %t92 = getelementptr i64, ptr %t85, i64 3
  store i64 %t87, ptr %t92
  %t93 = ptrtoint ptr null to i64
  %t94 = getelementptr i64, ptr %t85, i64 1
  store i64 %t93, ptr %t94
  %t95 = extractvalue {i64, ptr} %t84, 1
  %t96 = ptrtoint ptr %t95 to i64
  %t97 = icmp ne i64 %t96, 0
  %t98 = extractvalue {i64, ptr} %t84, 0
  %t99 = select i1 %t97, i64 -9223372036854775808, i64 %t98
  %t100 = getelementptr i64, ptr %t85, i64 2
  store i64 %t99, ptr %t100
  %t101 = getelementptr i64, ptr %t85, i64 5
  store i64 %t96, ptr %t101
  %t102 = getelementptr i64, ptr %t85, i64 0
  %t103 = load i64, ptr %t102
  %t106 = insertvalue {i64, ptr} undef, i64 %t103, 0
  %t107 = insertvalue {i64, ptr} %t106, ptr null, 1
  %t108 = icmp eq i64 %t103, -9223372036854775808
  br i1 %t108, label %L104, label %L105
L104:
  %t109 = getelementptr i64, ptr %t85, i64 3
  %t110 = load i64, ptr %t109
  %t111 = icmp eq i64 %t110, 0
  %t112 = select i1 %t111, i64 -9223372036854775808, i64 0
  %t113 = inttoptr i64 %t110 to ptr
  %t114 = insertvalue {i64, ptr} undef, i64 %t112, 0
  %t115 = insertvalue {i64, ptr} %t114, ptr %t113, 1
  br label %L105
L105:
  %t116 = phi {i64, ptr} [%t107, %L64], [%t115, %L104]
  %t117 = extractvalue {i64, ptr} %t116, 1
  %t118 = ptrtoint ptr %t117 to i64
  %t119 = icmp eq i64 %t118, 0
  %t120 = xor i1 %t119, true
  br i1 %t120, label %L121, label %L122
L122:
  %t123 = extractvalue {i64, ptr} %t116, 0
  %t124 = getelementptr i64, ptr %t85, i64 2
  %t125 = load i64, ptr %t124
  %t128 = insertvalue {i64, ptr} undef, i64 %t125, 0
  %t129 = insertvalue {i64, ptr} %t128, ptr null, 1
  %t130 = icmp eq i64 %t125, -9223372036854775808
  br i1 %t130, label %L126, label %L127
L126:
  %t131 = getelementptr i64, ptr %t85, i64 5
  %t132 = load i64, ptr %t131
  %t133 = icmp eq i64 %t132, 0
  %t134 = select i1 %t133, i64 -9223372036854775808, i64 0
  %t135 = inttoptr i64 %t132 to ptr
  %t136 = insertvalue {i64, ptr} undef, i64 %t134, 0
  %t137 = insertvalue {i64, ptr} %t136, ptr %t135, 1
  br label %L127
L127:
  %t138 = phi {i64, ptr} [%t129, %L122], [%t137, %L126]
  %t139 = extractvalue {i64, ptr} %t138, 1
  %t140 = ptrtoint ptr %t139 to i64
  %t141 = icmp eq i64 %t140, 0
  %t142 = xor i1 %t141, true
  br i1 %t142, label %L121, label %L143
L143:
  %t144 = extractvalue {i64, ptr} %t138, 0
  %t145 = getelementptr i64, ptr %t85, i64 0
  %t146 = load i64, ptr %t145
  %t147 = call ptr @pys_box(i64 %t146)
  %t148 = getelementptr i64, ptr %t85, i64 1
  %t149 = load i64, ptr %t148
  %t150 = inttoptr i64 %t149 to ptr
  %t151 = getelementptr i64, ptr %t85, i64 2
  %t152 = load i64, ptr %t151
  %t153 = call ptr @pys_box(i64 %t152)
  %t154 = call ptr @pys_alloc(i64 32)
  store i64 3, ptr %t154
  %vt.154.0 = getelementptr i64, ptr %t154, i64 1
  store ptr %t147, ptr %vt.154.0
  %vt.154.1 = getelementptr i64, ptr %t154, i64 2
  store ptr %t150, ptr %vt.154.1
  %vt.154.2 = getelementptr i64, ptr %t154, i64 3
  store ptr %t153, ptr %vt.154.2
  ret ptr %t154
L121:
  call void @pys_raise(ptr @s.10, ptr @s.9)
  unreachable
}
