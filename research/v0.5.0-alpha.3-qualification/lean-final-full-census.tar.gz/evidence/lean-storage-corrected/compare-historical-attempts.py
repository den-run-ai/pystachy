"""Compare preserved earlier attempts with the completed final-source census.

Pure-data documentation only: never edit a record/header or execute a checker.
"""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
EVIDENCE = OUT.parent
TARGET = "tests/programs/numbers/python_int_optional_tuple_keys.py"


def read(path):
    return json.loads(path.read_text())


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest()}


def load_records(path):
    raw = path.read_bytes()
    lines = raw.splitlines()
    parsed = [json.loads(line) for line in lines]
    records = parsed[1:]
    assert raw.endswith(b"\n") and len({r["program"] for r in records}) == len(records)
    return {
        "path": path, "identity": identity(path), "header": parsed[0]["header"],
        "raw_header_line_sha256": hashlib.sha256(lines[0]).hexdigest(),
        "records": {r["program"]: r for r in records},
    }


def nested_errors(record):
    return [{"check": category, **row}
            for category, check in record.get("checks", {}).items()
            for row in check.get("unproved", []) if row["status"] == "error"]


def changed_checks(before, after, skip_inspection_errors=False):
    changes = []
    for name in sorted(before.keys() & after.keys()):
        old, new = before[name], after[name]
        if skip_inspection_errors and old.get("error"):
            continue
        for category in sorted(old.get("checks", {}).keys() | new.get("checks", {}).keys()):
            a, b = old.get("checks", {}).get(category), new.get("checks", {}).get(category)
            if a != b:
                changes.append({"program": name, "check": category, "before": a, "after": b,
                                "before_snapshot_sha256": old.get("snapshot_sha256"),
                                "after_snapshot_sha256": new.get("snapshot_sha256")})
    return changes


paths = {
    "original_partial_receipt": EVIDENCE / "lean/interrupted-partial-census.json",
    "completed_blocked_receipt": EVIDENCE / "lean-corrected/complete-blocked-census.json",
    "prior_b0_to_94_comparison": EVIDENCE / "lean-corrected/historical-attempt-comparison.json",
    "final_census_receipt": OUT / "final-census-receipt.json",
    "final_acceptance": OUT / "acceptance.json",
    "final_semantic_disposition": OUT / "semantic-disposition.json",
    "independent_final_acceptance": OUT / "independent-review/final-acceptance.json",
    "production_source_equivalence": EVIDENCE / "lean/optional-storage-repair/final-source-equivalence-b0-to-0a2f.json",
    "sparse_tag_repair": EVIDENCE / "lean/adapter-repair/frozen-repair.json",
    "optional_storage_repair": EVIDENCE / "lean/optional-storage-repair/frozen-repair.json",
}
inputs_before = {name: identity(path) for name, path in paths.items()}
docs = {name: read(path) for name, path in paths.items()}
sources = {
    "b0_partial": load_records(EVIDENCE / "lean/records.jsonl"),
    "94_complete_blocked": load_records(EVIDENCE / "lean-corrected/records.jsonl"),
    "0a2_final": load_records(OUT / "records.jsonl"),
}
old = sources["b0_partial"]["records"]
prior = sources["94_complete_blocked"]["records"]
final = sources["0a2_final"]["records"]
partial = docs["original_partial_receipt"]
blocked = docs["completed_blocked_receipt"]
receipt = docs["final_census_receipt"]
acceptance = docs["final_acceptance"]
semantic = docs["final_semantic_disposition"]
independent = docs["independent_final_acceptance"]
commits = {"b0_partial": partial["commit"], "94_complete_blocked": blocked["commit"],
           "0a2_final": receipt["candidate_commit"]}
trees = {"b0_partial": partial["tree"], "94_complete_blocked": blocked["tree"],
         "0a2_final": receipt["candidate_tree"]}

error_programs = {name for name, record in old.items() if nested_errors(record)}
inspection_error_programs = {name for name, record in old.items() if record.get("error")}
adapter_rows = []
for name in sorted(error_programs):
    adapter_rows.append({
        "program": name,
        "original_nested_errors": nested_errors(old[name]),
        "original_snapshot_sha256": old[name].get("snapshot_sha256"),
        "final_snapshot_sha256": final[name]["snapshot_sha256"],
        "final_counts": {category: final[name]["checks"][category]
                         for category in ("union", "union_payload", "null")},
        "final_nested_errors": nested_errors(final[name]),
    })
inspection_rows = []
for name in sorted(inspection_error_programs):
    residuals = Counter(row["status"] for check in final[name]["checks"].values()
                        for row in check["unproved"])
    inspection_rows.append({
        "program": name, "original_error": old[name]["error"],
        "final_snapshot_sha256": final[name]["snapshot_sha256"],
        "final_inspection_completed": not final[name].get("error"),
        "final_nested_error_count": len(nested_errors(final[name])),
        "final_model_residual_entries_by_status": dict(residuals),
        "limit": "Completed inspection does not imply every model obligation is proved or explain the prior -9 exit.",
    })

original_changes = changed_checks(old, final, skip_inspection_errors=True)
prior_changes = changed_checks(prior, final)
adapter_totals = {category: {
    key: sum(final[name]["checks"][category][key] for name in error_programs)
    for key in ("obligations", "proved")}
    for category in ("union", "union_payload", "null")}
checks = {
    "historical_raw_record_hashes_match_preserved_receipts":
        sources["b0_partial"]["identity"]["sha256"] == partial["records_sha256"]
        and sources["94_complete_blocked"]["identity"] == blocked["files"]["records.jsonl"],
    "final_raw_record_hash_matches_completed_receipt_and_acceptance":
        sources["0a2_final"]["identity"] == receipt["evidence"]["records.jsonl"]
        and sources["0a2_final"]["identity"]["sha256"] == acceptance["records_sha256"],
    "each_actual_header_matches_its_own_source_commit": all(
        commits[name].startswith(source["header"]["commit"]) for name, source in sources.items()),
    "original_partial_status_and_count_preserved":
        partial["status"] == "interrupted_incomplete_failed_historical_attempt"
        and len(old) == partial["completed_program_records"] == 1865
        and partial["qualifies_release"] is False and partial["tool_exit_code"] == 130,
    "completed94_status_and_strict_failure_preserved":
        blocked["status"] == "complete_but_strict_storage_blocked"
        and len(prior) == blocked["programs"] == 2699
        and blocked["acceptance_checks"]["strict_storage_all_accepted"] is False,
    "all_original_partial_programs_retained_in_final": old.keys() <= final.keys(),
    "complete94_and_final_program_sets_equal": prior.keys() == final.keys() and len(final) == 2699,
    "original_eighteen_adapter_errors_four_programs_preserved":
        len(error_programs) == 4 and sum(len(nested_errors(old[name])) for name in error_programs) == 18,
    "only_original_comparable_changes_are_repaired_union_and_payload_checks":
        {(r["program"], r["check"]) for r in original_changes}
        == {(name, category) for name in error_programs for category in ("union", "union_payload")},
    "all_original_adapter_error_programs_complete_and_selected_checks_proved": all(
        not final[name].get("error") and not nested_errors(final[name])
        and all(not final[name]["checks"][category]["unproved"]
                and final[name]["checks"][category]["obligations"] == final[name]["checks"][category]["proved"]
                for category in ("union", "union_payload", "null")) for name in error_programs),
    "two_original_inspection_kills_complete_without_error_on_final_source":
        len(inspection_rows) == 2 and all(row["final_inspection_completed"]
                                        and row["final_nested_error_count"] == 0 for row in inspection_rows),
    "exactly_one94_to_final_check_dictionary_changes":
        [(row["program"], row["check"]) for row in prior_changes] == [(TARGET, "storage")],
    "old_storage_known_subtotal_and_three_unknowns_remain_visible":
        prior[TARGET]["checks"]["storage"]["obligations"] == prior[TARGET]["checks"]["storage"]["proved"] == 8
        and len(prior[TARGET]["checks"]["storage"]["unproved"]) == 3
        and all(row["obligations"] is None and row["status"] == "unsupported"
                for row in prior[TARGET]["checks"]["storage"]["unproved"]),
    "new_storage_target_is_fresh142_without_unknowns":
        final[TARGET]["checks"]["storage"]["obligations"] == final[TARGET]["checks"]["storage"]["proved"] == 142
        and final[TARGET]["checks"]["storage"]["unproved"] == [],
    "final_single_fresh_attempt_and_strict_storage_passed":
        receipt["status"] == "complete_and_strict_storage_accepted"
        and bool(receipt["checks"]) and all(receipt["checks"].values())
        and len(receipt["attempts"]) == 1 and receipt["attempts"][0]["result"]["resume"] is False
        and receipt["prior_checker_records_reused"] is False,
    "final_semantic_and_independent_reviews_passed_with_limits":
        semantic["status"] == "reviewed_with_explicit_model_limits"
        and bool(semantic["checks"]) and all(semantic["checks"].values())
        and independent["status"] == "accepted_with_explicit_model_limits"
        and bool(independent["checks"]) and all(independent["checks"].values()),
    "comparison_source_inputs_unchanged": all(identity(path) == inputs_before[name]
                                               for name, path in paths.items())
        and all(identity(source["path"]) == source["identity"] for source in sources.values()),
}

source_rows = {}
for name, source in sources.items():
    header = source["header"]
    source_rows[name] = {
        "commit": commits[name], "tree": trees[name], "records": source["identity"],
        "record_count": len(source["records"]),
        "actual_original_header_summary": {key: header[key] for key in
                                           ("commit", "inputs", "lean", "platform", "python")},
        "raw_header_line_sha256": source["raw_header_line_sha256"],
        "header_was_rewritten_or_reused": False,
    }
result = {
    "schema_version": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
    "status": "historical_failures_preserved_and_final_source_qualified" if all(checks.values()) else "historical_comparison_failed",
    "candidate_commit": commits["0a2_final"], "candidate_tree": trees["0a2_final"],
    "checks": checks, "sources": source_rows,
    "historical_outcomes": {
        "b0_partial": {"status": partial["status"], "qualifies_release": False,
                       "interrupted_exit": partial["tool_exit_code"], "records": len(old),
                       "expected_records": partial["expected_programs"],
                       "inspection_error_count": len(inspection_rows), "nested_adapter_error_count": 18},
        "94_complete_blocked": {"status": blocked["status"], "qualifies_release": False,
                                "attempts": blocked["attempts"],
                                "prefix_preserved_byte_for_byte": blocked["prefix_preserved_byte_for_byte"],
                                "known_storage_counts": blocked["known_storage_counts"],
                                "storage_gaps": blocked["storage_gaps"]},
        "0a2_final": {"status": receipt["status"], "independent_status": independent["status"],
                      "fresh_uninterrupted_attempts": 1,
                      "record_count": len(final), "strict_storage_selections": receipt["strict_storage_selections"],
                      "known_storage_counts": receipt["known_storage_counts"], "storage_gaps": receipt["storage_gaps"]},
    },
    "original_adapter_failure_comparison": {"programs": adapter_rows, "final_selected_proof_totals": adapter_totals,
                                            "exact_changed_check_pairs": [{"program": row["program"], "check": row["check"]}
                                                                          for row in original_changes]},
    "original_inspection_failure_comparison": inspection_rows,
    "complete94_to_final_exact_check_dictionary_changes": prior_changes,
    "compiler_or_checker_executions_performed": False,
    "records_or_headers_modified": False,
    "limits": [
        "The b0 attempt remains an incomplete failed census; its partial counts are not a full-corpus denominator.",
        "The complete 94f4 census remains blocked despite its known 25,682/25,682 subtotal; three unknown-count storage functions were not waived.",
        "Historical -9 exits retain unknown causes. Later successful inspections and RSS samples do not establish OOM or another cause.",
        "Exact dictionaries are compared without temporary-name or specialization normalization. Timing and source-specific snapshot hashes are not proof-result equality criteria.",
        "Each source keeps its own original header and raw record hash. The final census is a fresh execution, not a rewritten historical header or reused checker records.",
        "All other 94f4 proof dictionaries are unchanged, including the explicit complex union/payload, GC and Decimal model limits documented in the final semantic disposition.",
        "This comparison records existing accepted evidence; it does not independently grant proofs or authorize publication.",
    ],
    "evidence": {**inputs_before, "builder": identity(Path(__file__))},
}
target_path = OUT / "historical-attempt-comparison.json"
target_path.write_text(json.dumps(result, indent=2) + "\n")
if not all(checks.values()):
    print(json.dumps({"status": result["status"], "failed_checks": [k for k, v in checks.items() if not v]}))
    raise SystemExit(1)

lines = [
    "# Historical qualification attempts and the final census", "",
    f"Status: **{result['status']}**. This is a read-only data comparison on final proof source `{commits['0a2_final']}`, tree `{trees['0a2_final']}`. It executed no compiler or checker and changed no earlier record/header.", "",
    "| Source | Coverage | Retained outcome |", "|---|---:|---|",
    "| Original b0 | 1,865 / 2,699 programs | Interrupted incomplete failure; 18 nested adapter errors and two inspection -9 exits remain in the original records. |",
    "| 94f4 | 2,699 / 2,699 programs | Complete but strict storage blocked. The known 25,682/25,682 subtotal excluded three unsupported functions with unknown counts. |",
    "| Final 0a2f | 2,699 / 2,699 programs; 196 storage selections | One fresh uninterrupted attempt, full strict-storage acceptance at 25,816/25,816, and independent acceptance with explicit model limits. |", "",
    "The original four sparse-tag failure programs now complete with 126/126 union reads, 126/126 payload-bit obligations and 24/24 removed-null checks. All 18 original error dictionaries remain preserved. The two originally killed inspections also complete in the fresh final census; this does not explain the historical signals or imply every other model result in those programs is proved.", "",
    "Comparing every check dictionary in the complete 94f4 and final censuses finds exactly one change: `python_int_optional_tuple_keys.py` storage. Its earlier seven-function result had a known 8/8 subtotal plus three unsupported, unknown-count entries (`main.init`, `exercise`, and `read_nested`). Its fresh final result is 142/142 across the same seven functions with no unproved entry. Every other proof dictionary is exactly unchanged, without normalization.", "",
    "The 94f4 report process's -9 after 2,562 records and its supported same-source 137-record resume remain separate preserved receipts. The original b0 interruption remains exit 130. Neither history is represented as a successful uninterrupted attempt. Only the final 0a2f census is fresh and uninterrupted; no historical checker record or header was reused.", "",
    "The final semantic disposition separately retains 542 added union-read and 409 payload-bit obligations as unproved, three added GC obligations as rejected, and Decimal's unknown-count field-initialization limit. The earlier storage failure is resolved by a reviewed adapter repair and fresh execution, rather than by changing those historical outcomes.", "",
    "## Raw record identities", "",
    "| Source | Bytes | SHA256 |", "|---|---:|---|",
]
for name, source in source_rows.items():
    ident = source["records"]
    lines.append(f"| {name} | {ident['bytes']:,} | `{ident['sha256']}` |")
lines += ["", "The JSON companion preserves each original header's source/input summary and raw header-line hash, the exact old/new storage dictionaries, all 18 historical adapter errors, final selected proof results, prior failure receipts, production-source equivalence and final independent acceptance identities. Historical -9 causes remain unknown; no OOM attribution is made.", ""]
(OUT / "historical-attempt-comparison.md").write_text("\n".join(lines))
print(json.dumps({"status": result["status"], "checks": checks,
                  "final_selected_proof_totals": adapter_totals,
                  "complete94_to_final_changes": len(prior_changes), "output": identity(target_path)}))
