# Historical qualification attempts and the final census

Status: **historical_failures_preserved_and_final_source_qualified**. This is a read-only data comparison on final proof source `0a2fe77a580106c197face4d2904be80e3f85dbc`, tree `107460d5f89bdcf37f2741b233eac0568d82604a`. It executed no compiler or checker and changed no earlier record/header.

| Source | Coverage | Retained outcome |
|---|---:|---|
| Original b0 | 1,865 / 2,699 programs | Interrupted incomplete failure; 18 nested adapter errors and two inspection -9 exits remain in the original records. |
| 94f4 | 2,699 / 2,699 programs | Complete but strict storage blocked. The known 25,682/25,682 subtotal excluded three unsupported functions with unknown counts. |
| Final 0a2f | 2,699 / 2,699 programs; 196 storage selections | One fresh uninterrupted attempt, full strict-storage acceptance at 25,816/25,816, and independent acceptance with explicit model limits. |

The original four sparse-tag failure programs now complete with 126/126 union reads, 126/126 payload-bit obligations and 24/24 removed-null checks. All 18 original error dictionaries remain preserved. The two originally killed inspections also complete in the fresh final census; this does not explain the historical signals or imply every other model result in those programs is proved.

Comparing every check dictionary in the complete 94f4 and final censuses finds exactly one change: `python_int_optional_tuple_keys.py` storage. Its earlier seven-function result had a known 8/8 subtotal plus three unsupported, unknown-count entries (`main.init`, `exercise`, and `read_nested`). Its fresh final result is 142/142 across the same seven functions with no unproved entry. Every other proof dictionary is exactly unchanged, without normalization.

The 94f4 report process's -9 after 2,562 records and its supported same-source 137-record resume remain separate preserved receipts. The original b0 interruption remains exit 130. Neither history is represented as a successful uninterrupted attempt. Only the final 0a2f census is fresh and uninterrupted; no historical checker record or header was reused.

The final semantic disposition separately retains 542 added union-read and 409 payload-bit obligations as unproved, three added GC obligations as rejected, and Decimal's unknown-count field-initialization limit. The earlier storage failure is resolved by a reviewed adapter repair and fresh execution, rather than by changing those historical outcomes.

## Raw record identities

| Source | Bytes | SHA256 |
|---|---:|---|
| b0_partial | 1,618,782 | `662de211e3bb3eadcbbd50c98daa3c0e03dc870e5448e6ae2b04b4824521ee0d` |
| 94_complete_blocked | 2,361,743 | `396f4b02ede94afda93ecc796f1da3aa1d3cb022a78939c51c4fc34a22101bbe` |
| 0a2_final | 2,361,345 | `1184061f32713f1a8de978b8ceb87acea02bfe02ec411f366085276ed3baf33c` |

The JSON companion preserves each original header's source/input summary and raw header-line hash, the exact old/new storage dictionaries, all 18 historical adapter errors, final selected proof results, prior failure receipts, production-source equivalence and final independent acceptance identities. Historical -9 causes remain unknown; no OOM attribution is made.
