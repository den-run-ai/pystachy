"""Describe every retained IR/diagnostic difference without weakening the oracle."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def function_bodies(text):
    result = {}
    lines = text.splitlines(keepends=True)
    name = None
    body = []
    for line in lines:
        if name is None and line.startswith('define '):
            match = re.search(r'@([^ (]+)\(', line)
            if match:
                name = match.group(1)
                body = []
        if name is not None:
            body.append(line)
            if line.strip() == '}':
                result[name] = ''.join(body)
                name = None
    return result


parser = argparse.ArgumentParser()
parser.add_argument('directory', type=Path)
args = parser.parse_args()
root = args.directory
identity = json.loads((root / 'identity.json').read_text())
target = root / 'analysis.json'
assert not target.exists()
rows = []
seen = set()
transitions = Counter()
for i, case in enumerate(identity['corpus'], 1):
    directory = root / 'cases' / str(i)
    assert (directory / 'case').read_text().strip() == case['path']
    assert case['path'] not in seen
    seen.add(case['path'])
    assert sha(Path(identity['source']) / case['path']) == case['sha256']
    a, b = [int((directory / (side + '.status')).read_text()) for side in ('old', 'new')]
    transitions[f'{a}->{b}'] += 1
    report = (directory / 'report').read_text()
    row = {'case': case['path'], 'old_status': a, 'new_status': b, 'different': bool(report),
           'source_sha256': case['sha256']}
    if report:
        row['report'] = report
        row['retained_files'] = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)}
                                 for p in sorted(directory.iterdir()) if p.is_file()}
        old_ir, new_ir = directory / 'old.ll', directory / 'new.ll'
        if old_ir.exists() and new_ir.exists():
            old_text, new_text = old_ir.read_text(), new_ir.read_text()
            no_comments = lambda text: ''.join(line for line in text.splitlines(True)
                                               if not line.lstrip().startswith(';'))
            row['classification_only_equal_without_full_line_comments'] = no_comments(old_text) == no_comments(new_text)
            functions = [function_bodies(text) for text in (old_text, new_text)]
            names = set(functions[0]) | set(functions[1])
            row['functions'] = {
                'added': sorted(name for name in names if name not in functions[0]),
                'removed': sorted(name for name in names if name not in functions[1]),
                'changed': sorted(name for name in names if name in functions[0] and name in functions[1]
                                  and functions[0][name] != functions[1][name])}
    rows.append(row)
assert len(rows) == identity['corpus_count']
result = {'status': 'analyzed_requires_disposition', 'created_utc': datetime.now(timezone.utc).isoformat(),
          'source': identity['homes']['head']['source_sha'], 'baseline': identity['homes']['base']['source_sha'],
          'identity_sha256': sha(root / 'identity.json'), 'cases': len(rows),
          'differences': sum(row['different'] for row in rows),
          'status_transitions': dict(transitions),
          'newly_rejected': [row['case'] for row in rows if row['old_status'] == 0 and row['new_status'] != 0],
          'newly_accepted': [row['case'] for row in rows if row['old_status'] != 0 and row['new_status'] == 0],
          'unexpected_process_statuses': [row['case'] for row in rows if row['old_status'] not in (0, 1, 2)
                                           or row['new_status'] not in (0, 1, 2)],
          'note': 'Strict status, diagnostics and raw IR comparisons are unchanged. Comment removal is used only to describe differences; it does not accept them or change proof obligations.',
          'rows': rows}
target.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'rows'}))
