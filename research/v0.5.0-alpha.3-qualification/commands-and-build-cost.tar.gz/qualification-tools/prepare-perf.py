"""Bind retained fixed-point IR audit compilers to exact comparison source homes."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(root, *parts):
    return subprocess.check_output(['git', '-C', str(root), *parts], text=True).strip()


parser = argparse.ArgumentParser()
parser.add_argument('--ir-identity', type=Path, required=True)
parser.add_argument('--head-commit', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
audit = json.loads(args.ir_identity.read_text())
source = Path(audit['source'])
output = args.output.resolve()
assert not output.exists()
assert git(source, 'status', '--porcelain') == ''
assert git(source, 'rev-parse', args.head_commit + '^{tree}') == audit['homes']['head']['tree']
assert git(source, 'diff', '--name-only', audit['homes']['head']['source_sha'], args.head_commit) == ''
output.mkdir(parents=True)
result = {'status': 'incomplete', 'created_utc': datetime.now(timezone.utc).isoformat(),
          'source_repo': str(source), 'revisions': {},
          'ir_identity': str(args.ir_identity), 'ir_identity_sha256': sha(args.ir_identity),
          'note': 'Each compiler was built to a three-stage fixed point. Candidate and exact-main trees are identical; each executable reads its own complete source home.'}
for side, original in audit['homes'].items():
    revision = args.head_commit if side == 'head' else original['source_sha']
    old_home = Path(original['home'])
    assert git(old_home, 'status', '--porcelain') == ''
    assert git(old_home, 'rev-parse', 'HEAD^{tree}') == original['tree']
    assert sha(old_home / 'pystachy') == original['binary_sha256']
    home = output / side
    subprocess.run(['git', '-C', str(source), 'worktree', 'add', '--detach', str(home), revision], check=True)
    shutil.copy2(old_home / 'pystachy', home / 'pystachy')
    assert git(home, 'status', '--porcelain') == ''
    if side == 'base':
        row = dict(audit['baseline_provenance'])
    else:
        log = Path(audit['candidate_bootstrap_log'])
        row = {'built_source_sha': original['source_sha'],
               'source_changes_since_fixed_point': [],
               'original_identity': str(args.ir_identity),
               'original_identity_sha256': sha(args.ir_identity),
               'bootstrap': {'local_build_source_ref': original['source_sha'],
                             'published_source_ref': args.head_commit,
                             'identical_source_tree': original['tree'],
                             'log': str(log), 'log_sha256': audit['candidate_bootstrap_log_sha256'],
                             'files': audit['candidate_fixed_point']},
               'current_fixed_point_hashes': audit['candidate_fixed_point']}
    row.update(release_sha=revision, release_tree=git(home, 'rev-parse', 'HEAD^{tree}'),
               home=str(home), binary=str(home / 'pystachy'), source_binary=str(old_home / 'pystachy'),
               binary_sha256=sha(home / 'pystachy'),
               workloads={name: sha(home / name) for name in
                          ('bench/smoke/ml.py', 'bench/smoke/text.py', 'bench/smoke/identity.py')})
    assert row['binary_sha256'] == original['binary_sha256']
    assert sha(row['bootstrap']['log']) == row['bootstrap']['log_sha256']
    result['revisions'][side] = row
assert len(str(output / 'base')) == len(str(output / 'head'))
assert result['revisions']['base']['workloads'] == result['revisions']['head']['workloads']
prior = Path('/workspace/scratch/7dd0519bc14a/alpha2-build-memory')
for name in ('run.py', 'measure-command.py'):
    shutil.copy2(prior / name, output / name)
result['status'] = 'passed'
(output / 'identity.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': 'prepared', 'output': str(output), 'source': args.head_commit}))
