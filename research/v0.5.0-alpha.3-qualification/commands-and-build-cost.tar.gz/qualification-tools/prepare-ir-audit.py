"""Prepare a retained, faithful IR comparison using separate verified source homes."""
import argparse
from datetime import datetime, timezone
import difflib
import glob
import hashlib
import json
from pathlib import Path
import shlex
import shutil
import subprocess


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(root, *parts):
    return subprocess.check_output(['git', '-C', str(root), *parts], text=True).strip()


parser = argparse.ArgumentParser()
parser.add_argument('--source', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--baseline-identity', required=True, type=Path)
parser.add_argument('--baseline-key', default='head')
parser.add_argument('--bootstrap-receipt', required=True, type=Path)
args = parser.parse_args()
source, output = args.source.resolve(), args.output.resolve()
assert not output.exists(), output
assert git(source, 'status', '--porcelain') == ''
head = git(source, 'rev-parse', 'HEAD')
tree = git(source, 'rev-parse', 'HEAD^{tree}')
receipt = json.loads(args.bootstrap_receipt.read_text())
assert receipt['returncode'] == 0
assert receipt['commit'] == receipt['commit_after'] == head
assert receipt['tree'] == receipt['tree_after'] == tree
assert receipt['status_before'] == receipt['status_after'] == ''
log = args.bootstrap_receipt.with_suffix('.log')
text = log.read_text()
assert 'fixed point: stage1 == stage2 == stage3' in text
assert "fixed point: runtime.py's IR, rt1 == rt2 == rt3" in text
files = ['stage1.ll', 'stage2.ll', 'stage3.ll', 'rt1.ll', 'rt2.ll', 'rt3.ll']
fixed = {name: digest(source / 'build' / name) for name in files}
assert len({fixed[f'stage{i}.ll'] for i in (1, 2, 3)}) == 1
assert len({fixed[f'rt{i}.ll'] for i in (1, 2, 3)}) == 1
assert digest(source / 'pystachy') == digest(source / 'build/pystachy2')
baseline_all = json.loads(args.baseline_identity.read_text())
assert baseline_all['status'] == 'passed'
baseline = baseline_all['revisions'][args.baseline_key]
old_home = Path(baseline['home'])
assert git(old_home, 'status', '--porcelain') == ''
assert git(old_home, 'rev-parse', 'HEAD') == baseline['release_sha']
assert git(old_home, 'rev-parse', 'HEAD^{tree}') == baseline['release_tree']
assert digest(baseline['binary']) == baseline['binary_sha256']
assert digest(baseline['original_identity']) == baseline['original_identity_sha256']
assert digest(baseline['bootstrap']['log']) == baseline['bootstrap']['log_sha256']
assert git(old_home, 'diff', '--name-only', baseline['built_source_sha'],
           baseline['release_sha']).splitlines() == baseline['source_changes_since_fixed_point']
assert all(path.startswith('tools/') for path in baseline['source_changes_since_fixed_point'])
output.mkdir(parents=True)
homes = {}
for side, revision, binary in [('base', baseline['release_sha'], baseline['binary']),
                               ('head', head, str(source / 'pystachy'))]:
    home = output / side
    subprocess.run(['git', '-C', str(source), 'worktree', 'add', '--detach',
                    str(home), revision], check=True)
    shutil.copy2(binary, home / 'pystachy')
    assert git(home, 'status', '--porcelain') == ''
    homes[side] = {'source_sha': revision, 'tree': git(home, 'rev-parse', 'HEAD^{tree}'),
                   'home': str(home), 'binary_sha256': digest(home / 'pystachy')}
assert len(str(output / 'base')) == len(str(output / 'head'))
patterns = ['pystachy.py', 'runtime.py', 'tests/programs/*/*.py', 'tests/deviations/*.py',
            'bench/*.py', 'bench/pyperformance/*.py', 'tests/ir/*.py', 'tests/errors/*/*.py']
corpus = []
for pattern in patterns:
    for name in sorted(glob.glob(pattern, root_dir=source)):
        path = source / name
        if path.is_file():
            row = {'path': name, 'sha256': digest(path)}
            path_file = path.with_suffix('.path')
            if path_file.exists():
                row['path_file_sha256'] = digest(path_file)
            corpus.append(row)
assert len({row['path'] for row in corpus}) == len(corpus)
original = (source / 'tools/irsame.sh').read_text()
modified = original
replacements = [
    ('cd "$(dirname "$0")/.." || exit 1', f'cd {shlex.quote(str(source))} || exit 1'),
    ('SHOW=3\n', 'SHOW=99999\n'),
    ('T=$(mktemp -d "${TMPDIR:-/tmp}/pystachy-irsame.XXXXXX") || exit 1',
     f'T={shlex.quote(str(output / "cases"))}\nmkdir "$T" || exit 1\necho "Audit directory: $T"'),
    ("trap 'rm -rf \"$T\"' EXIT", "trap 'echo \"Retained audit directory: $T\"' EXIT"),
    ('same() {\n', 'same() {\n  printf \'%s\\n\' "$1" > "$2/case"\n'),
    ('  messages=0\n', '  printf \'%s\\n\' "$a" > "$2/old.status"\n'
                       '  printf \'%s\\n\' "$b" > "$2/new.status"\n  messages=0\n'),
    ('  rm -f "$2/old.ll" "$2/new.ll"\n',
     '  if [ -s "$2/report" ]; then\n'
     '    diff -u "$2/old.msg" "$2/new.msg" > "$2/messages.raw.diff" || :\n'
     '    if [ -f "$2/old.ll" ] && [ -f "$2/new.ll" ]; then\n'
     '      diff -u "$2/old.ll" "$2/new.ll" > "$2/ir.raw.diff" || :\n'
     '    fi\n'
     '  else\n    rm -f "$2/old.ll" "$2/new.ll"\n  fi\n')]
for before, after in replacements:
    assert modified.count(before) == 1, before
    modified = modified.replace(before, after)
audit = output / 'irsame-retained.sh'
audit.write_text(modified)
audit.chmod(0o755)
(output / 'irsame-retention-only.patch').write_text(''.join(difflib.unified_diff(
    original.splitlines(True), modified.splitlines(True), 'tools/irsame.sh', 'irsame-retained.sh')))
result = {'created_utc': datetime.now(timezone.utc).isoformat(), 'status': 'prepared',
          'source': str(source), 'homes': homes,
          'baseline_identity': str(args.baseline_identity),
          'baseline_identity_sha256': digest(args.baseline_identity),
          'baseline_provenance': baseline,
          'candidate_bootstrap_receipt': receipt,
          'candidate_bootstrap_receipt_sha256': digest(args.bootstrap_receipt),
          'candidate_bootstrap_log': str(log),
          'candidate_bootstrap_log_sha256': digest(log), 'candidate_fixed_point': fixed,
          'corpus': corpus, 'corpus_count': len(corpus),
          'maintained_oracle_sha256': digest(source / 'tools/irsame.sh'),
          'retained_oracle_sha256': digest(audit),
          'changes': 'Evidence retention and full reporting only; comparisons and diagnostic normalization unchanged.',
          'command': ['sh', str(audit), str(output / 'base/pystachy'), str(output / 'head/pystachy')]}
(output / 'identity.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': 'prepared', 'corpus_count': len(corpus), 'output': str(output)}))
