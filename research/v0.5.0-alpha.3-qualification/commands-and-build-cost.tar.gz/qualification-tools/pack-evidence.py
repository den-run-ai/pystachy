"""Preserve completed alpha.3 qualification evidence without executable caches."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "research-publish" / "initial-v2"
OUT.mkdir(parents=True, exist_ok=False)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def put(name, data):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data if isinstance(data, bytes) else data.encode())


def copy(source, target):
    put(target, (ROOT / source).read_bytes())


def bundle(name, paths):
    rows = []
    with (OUT / name).open("xb") as stream:
        with gzip.GzipFile(fileobj=stream, mode="wb", filename="", mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as archive:
                for path in sorted(set(paths), key=lambda p: str(p).encode()):
                    data = path.read_bytes()
                    relative = str(path.relative_to(ROOT))
                    info = tarfile.TarInfo(relative)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    archive.addfile(info, io.BytesIO(data))
                    rows.append({"path": relative, "bytes": len(data), "sha256": digest(data)})
    put(name + ".manifest.json.gz", gzip.compress((json.dumps(rows, indent=2) + "\n").encode(), mtime=0))


copy("evidence/ir-review/full-disposition.md", "ir/full-disposition.md")
copy("evidence/ir-review/accepted-ir-review.md", "ir/accepted-ir-review.md")
copy("evidence/ir-review/acceptance-diagnostics-review.md", "ir/acceptance-diagnostics-review.md")
copy("evidence/ir-review/original-input-disposition.md", "ir/original-input-disposition.md")
copy("evidence/enum-independent-review.md", "reviews/enum-repair.md")
copy("alpha3-integration-review.md", "reviews/integration.md")
copy("evidence/lean/adapter-repair/independent-review.md", "reviews/lean-adapter.md")
copy("evidence/lean/adapter-repair/independent-qualification-review.md", "reviews/lean-qualification.md")
copy("evidence/lean/adapter-repair/published-repair.json", "lean-repair.json")
copy("evidence/lean/adapter-repair/source-equivalence-b0-to-94f4.json", "source-equivalence.json")
copy("evidence/lean/adapter-repair/source-equivalence-b0-to-94f4.md", "source-equivalence.md")
copy("evidence/lean/interrupted-partial-census.json", "lean-original-interrupted.json")
copy("evidence/bootstrap.json", "bootstrap.json")
copy("evidence/bootstrap.log", "bootstrap.log")
copy("evidence/pr-checks.json", "integrated-pr-checks.json")

ir_names = {"case", "old.status", "new.status", "old.msg", "new.msg", "report",
            "ir.raw.diff", "messages.raw.diff", "old.normal.msg", "new.normal.msg",
            "closure_path_fixture.py"}
ir_paths = [p for p in (ROOT / "ir-audit/cases").rglob("*") if p.is_file() and p.name in ir_names]
ir_paths += [ROOT / "ir-audit" / name for name in ("identity.json", "analysis.json", "irsame-retained.sh")]
bundle("ir-retained-records.tar.gz", ir_paths)
bundle("ir-reviews-and-original-inputs.tar.gz", [p for directory in ("evidence/ir-review", "original-input-audit")
                                                for p in (ROOT / directory).rglob("*") if p.is_file()])
bundle("lean-original-and-repair.tar.gz", [p for p in (ROOT / "evidence/lean").rglob("*") if p.is_file()])
performance = [ROOT / "performance" / name for name in
               ("identity.json", "report.json", "run.py", "measure-command.py")]
performance += [p for p in (ROOT / "performance/raw").rglob("*") if p.is_file()]
other = [p for p in (ROOT / "qualification-tools").glob("*.py")]
other += [ROOT / "evidence" / n for n in ("bootstrap.json", "bootstrap.log", "ir-full.json", "ir-full.log",
                                         "prepare-original-input-audit.py", "run-original-input-audit.py")]
bundle("commands-and-build-cost.tar.gz", performance + other)

performance_report = json.loads((ROOT / "performance/report.json").read_text())
lines = ["# Bounded alpha.2 to alpha.3 build-cost comparison", "",
         "Three alternating paired builds per workload, one CPU, warm runtime cache and program cache disabled. "
         "Every output was checked against pinned CPython before accepting timings. These are build costs, "
         "not execution-speed measurements. The timing ranges overlap; the sample does not support a general speed claim.", "",
         "| Workload | Base median seconds | Candidate median seconds | Change | Peak child RSS change | Executable bytes change |",
         "| --- | ---: | ---: | ---: | ---: | ---: |"]
for row in performance_report["summary"]:
    wall = row["wall_s"]
    lines.append(f"| {row['workload']} | {wall['base_median']:.6f} | {wall['head_median']:.6f} | "
                 f"{wall['change_percent']:+.2f}% | {row['ru_maxrss_kib']['change_percent']:+.2f}% | "
                 f"{row['executable_bytes']['change_percent']:+.2f}% |")
lines += ["", "The archive retains every sample, output check, command, source/binary/tool identity, cache receipt, "
          "and the scope of the memory collector. Original results remain attributed to the tested b0bda81ec source.", ""]
put("build-cost.md", "\n".join(lines))

put("README.md", """# v0.5.0-alpha.3 qualification evidence

**Status: qualification in progress; this snapshot does not authorize publication.**

This research branch preserves completed evidence for [release PR #1494](https://github.com/den-run-ai/pystachy/pull/1494), the integrated [enum repair #1496](https://github.com/den-run-ai/pystachy/pull/1496), and the reviewed [proof-adapter repair #1498](https://github.com/den-run-ai/pystachy/pull/1498). It must not be merged into main.

## Source identities

| Role | Commit | Tree |
| --- | --- | --- |
| Published alpha.2 baseline | `80490143498d149d407343ba1cb7aedb1db2d2c5` | `717a8c9386ae9f5f6545cc3686a9e22282fc560c` |
| Integrated alpha.3 enum repair | `b0bda81ec2b9954c3c5e0f658c051439126a5c22` | `e027b37c888326e3d8a3e8b89522a6b397dcb86d` |
| Reviewed proof-adapter repair | `94f472d6de5350fc9481ecf3b9ec019d2ecdb4f2` | `51f6c150748b2d17945e4d1c6779d8080b6edd6a` |

The adapter repair changes four files under tools. It changes no compiler, runtime, corpus, or Lean theorem source. Existing executions retain their original source identity; the new full census uses the corrected committed source and fresh records.

## Completed evidence

| Gate | Result | Evidence |
| --- | --- | --- |
| Fresh bootstrap on integrated source | Compiler 959,093 IR lines and runtime 21,214 IR lines; three identical stages each | [Receipt](bootstrap.json), [log](bootstrap.log) |
| Full retained IR/diagnostic comparison | 4,771 cases; 562 changed records fully explained; zero new rejections or abnormal statuses | [Disposition](ir/full-disposition.md), retained records/review archives |
| Original-input compatibility supplement | 13 executions, 129 original source/helper/sidecar files; zero new rejections | [Disposition](ir/original-input-disposition.md) |
| Bounded build costs | Three paired samples for each of three workloads; correctness checked; overlapping timing ranges | [Results](build-cost.md), command archive |
| Integrated PR checks | CI and Lint pass on b0bda81ec; expected conditional archive job skipped | [Every job](integrated-pr-checks.json) |
| Proof-adapter regression tests | 49 tests pass; new tests fail on the original code; retained complex-decline snapshot now proves 21/21 union reads, 21/21 payload obligations and 4/4 removed checks | Lean repair archive and independent reviews |
| Independent source review | No blocking source/IR issue in reviewed scopes | [Enum](reviews/enum-repair.md), [integration](reviews/integration.md), [adapter](reviews/lean-adapter.md), [qualification](reviews/lean-qualification.md) |

## Incomplete original proof attempt

The first full census on b0bda81ec was intentionally interrupted after 1,865 of 2,699 programs when the reviewed checker repair was available. It retains two inspection subprocess exits of -9 and 18 nested adapter errors across four dynamic-complex programs. Its cause-of-kill remains unproven. It is **incomplete and failed**, and cannot qualify the release. Its observed strict-storage subset is 52 of 196 programs with 14,118/14,118 observed obligations; that subset is not presented as full storage coverage.

A fresh complete census started on 94f472d6 with one worker, all 2,699 programs, all 196 selected storage programs, and no resumed old records. Its results are not included in this snapshot. Existing bounded-model residuals, including complex nullability and three copy-helper GC obligations, remain explicit unproved results until dispositioned against the complete census.

## Remaining release gates

The corrected full census, semantic proof delta, exact-current PR checks/review, exact-main seven-workflow qualification, and public native/Docker/PyPI artifact verification must complete before release closure. Automated Codex review was quota-blocked and is not counted as review. No stable default is advanced by this alpha and no monitoring is scheduled.

## Retained records

Each archive has a manifest with every member's byte length and SHA256. `SHA256SUMS` identifies all published files. The IR archive preserves every case status/diagnostic plus complete raw differences; large reproducible full LLVM files and compiled executables/caches are excluded. Per-case records retain their hashes and source/compiler identities. Review and original-input archives preserve the detailed semantic dispositions and raw supplemental results. The original interrupted proof records and before/after repair evidence are preserved separately from the future corrected census.

Prepared with ChatGPT assistance. These are bounded tests and models, not a proof of whole-compiler or collector correctness.
""")
manifest = []
for path in sorted(OUT.rglob("*")):
    if path.is_file():
        data = path.read_bytes()
        manifest.append({"path": str(path.relative_to(OUT)), "bytes": len(data), "sha256": digest(data),
                         "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()})
put("SHA256SUMS", "".join(f"{row['sha256']}  {row['path']}\n" for row in manifest))
put("upload-manifest.json", json.dumps({"created_utc": datetime.now(timezone.utc).isoformat(),
                                       "root": str(OUT), "files": manifest}, indent=2) + "\n")
print(json.dumps({"root": str(OUT), "files": len(manifest), "bytes": sum(row["bytes"] for row in manifest),
                  "archives": [row for row in manifest if row["path"].endswith(".tar.gz")]}, indent=2))
