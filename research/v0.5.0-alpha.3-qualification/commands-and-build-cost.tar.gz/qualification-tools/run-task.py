"""Run one owned qualification command with a pinned, sanitized environment."""
import argparse
import datetime
import json
import os
from pathlib import Path
import resource
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--cache', type=Path)
parser.add_argument('--jobs', type=int, default=2)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ['--'] else args.command
assert command
args.output.parent.mkdir(parents=True, exist_ok=True)
assert not args.output.with_suffix('.json').exists()
old = Path('/workspace/scratch/c2b093657c17')
python = old / 'dev-venv/bin/python'
llvm = old / 'toolchains/llvm18/payload/usr/lib/llvm-18'
env = {k: v for k, v in os.environ.items()
       if not k.startswith('PYSTACHY_') and k not in ('PYTHONPATH', 'PYTHONOPTIMIZE')}
env['PATH'] = ':'.join([str(python.parent), str(llvm / 'bin'),
                        str(old / 'toolchains/lean-4.35.0-linux/bin'),
                        '/usr/local/bin', '/usr/bin', '/bin'])
env['PYSTACHY_LLVM'] = str(llvm / 'bin')
env['LD_LIBRARY_PATH'] = str(llvm / 'lib')
env['PYTHON'] = str(python)
env['PYSTACHY_JOBS'] = str(args.jobs)
if args.cache:
    env['PYSTACHY_CACHE'] = str(args.cache)
def git(*parts):
    return subprocess.check_output(['git', *parts], cwd=args.source, text=True).strip()
receipt = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'source': str(args.source), 'output': str(args.output), 'commit': git('rev-parse', 'HEAD'),
           'tree': git('rev-parse', 'HEAD^{tree}'), 'status_before': git('status', '--porcelain'),
           'command': command, 'python': str(python), 'llvm': str(llvm),
           'cache': str(args.cache) if args.cache else 'checkout build default',
           'jobs': args.jobs}
args.output.with_suffix('.started.json').write_text(json.dumps(receipt, indent=2) + '\n')
started = time.monotonic()
with args.output.open('x') as stream:
    result = subprocess.run(command, cwd=args.source, env=env, stdout=stream, stderr=subprocess.STDOUT)
receipt.update(returncode=result.returncode, seconds=round(time.monotonic()-started, 3),
               child_peak_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
               commit_after=git('rev-parse', 'HEAD'), tree_after=git('rev-parse', 'HEAD^{tree}'),
               status_after=git('status', '--porcelain'))
args.output.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
raise SystemExit(result.returncode)
