"""Preserve alpha.2 inputs omitted or modified by the alpha.3 corpus.

Preparation only: this script never invokes a compiler or modifies a checkout.
"""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

BASE = "80490143498d149d407343ba1cb7aedb1db2d2c5"
HEAD = "b0bda81ec2b9954c3c5e0f658c051439126a5c22"

DETAILS = {
    "tests/deviations/complex_pow.py": ("modified", "Comment-only update: complex numbers now exist, but negative float to fractional float power still follows the documented real-power deviation.", ["tests/deviations/complex_pow.py"]),
    "tests/deviations/devmods/cmp_declined.py": ("modified-helper", "Unsupported comparison annotation changes from complex to memoryview because complex is now supported. Preserve original helper and exercise its unchanged consumer; direct helper compilation alone does not exercise method calls.", ["tests/deviations/devmods/cmp_declined.py", "tests/deviations/dynany_cmp_declined_declarations.py"]),
    "tests/deviations/dynany_identity_boundary.py": ("modified", "Resolved typed-tuple and optional-list identity observations leave this deviation and gain differential coverage. Original observations must still compile; their outputs may intentionally improve.", ["tests/programs/inference/dynany_identity_vtuples.py", "tests/programs/inference/dynany_identity_optional_lists.py", "tests/deviations/dynany_identity_boundary.py"]),
    "tests/programs/upstream/upstream_datetime.py": ("modified", "Comment-only update records reflected-operator limitations as historical exclusions; executable adopted upstream assertions are unchanged.", ["tests/programs/upstream/upstream_datetime.py", "tests/programs/library/lib_datetime_reflected.py"]),
    "tests/programs/upstream/upstream_setcomps.py": ("modified", "Existing adopted statements remain; the candidate adds the newly supported None-valued set comprehension.", ["tests/programs/upstream/upstream_setcomps.py"]),
    "tests/errors/language/args_complex_called.py": ("deleted", "Complex is no longer an unsupported annotation; the old unsupported-annotation fixture is replaced by memoryview-based args_unsupported_called. The original collect(1, 'a') call must be audited without assuming it accepts, since a string may remain incompatible with typed complex varargs.", ["tests/errors/language/args_unsupported_called.py", "tests/emods/starunsupported.py"]),
    "tests/errors/language/kwargs_complex_called.py": ("deleted", "Complex is no longer an unsupported annotation; memoryview preserves the unsupported-annotation rejection fixture. Audit the original report('x', a=1) with its original complex helper to establish actual acceptance and diagnostics.", ["tests/errors/language/kwargs_unsupported_called.py", "tests/emods/starunsupported.py"]),
    "tests/errors/library/lib_datetime_reflected.py": ("deleted", "Previously rejected int * timedelta is supported by reflected numeric operations; the program fixture retains the exact original print call and adds float/reflected checks.", ["tests/programs/library/lib_datetime_reflected.py"]),
    "tests/errors/optimizations/opt_dict_key.py": ("deleted", "Optional string dictionary keys are now supported; the broader dict_none_keys fixture exercises typed str | None keys and operations.", ["tests/programs/containers/dict_none_keys.py"]),
    "tests/errors/optimizations/opt_none_unknown.py": ("deleted", "The provisional-None local now prints before later widening; the same executable source moves to a positive optional program fixture.", ["tests/programs/optional/opt_none_unknown.py"]),
    "tests/errors/optimizations/opt_scalar_key_type.py": ("deleted", "Optional integer dictionary keys are now supported; dict_none_keys exercises typed int | None keys and operations.", ["tests/programs/containers/dict_none_keys.py"]),
    "tests/errors/reflection/reflected_rand.py": ("renamed", "Error-to-program promotion for int & Bits.__rand__; only the first comment changes, so raw file hashes differ while the executable AST remains identical.", ["tests/programs/reflection/reflected_rand.py"]),
}
CONSUMER = "tests/deviations/dynany_cmp_declined_declarations.py"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def ast_digest(data):
    return digest(ast.dump(ast.parse(data.decode()), include_attributes=False).encode())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    repo, output = args.repo.resolve(), args.output.resolve()
    assert not output.exists(), output

    def git(*parts):
        return subprocess.check_output(["git", "-C", str(repo), *parts])

    def blob(revision, path):
        return git("show", revision + ":" + path)

    all_paths = git("ls-tree", "-r", "--name-only", BASE, "--", "tests").decode().splitlines()
    head_paths = set(git("ls-tree", "-r", "--name-only", HEAD).decode().splitlines())
    paths = set(DETAILS) | {CONSUMER}
    for path in tuple(paths):
        stem = path[:-3]
        paths.update(name for name in all_paths if name.startswith(stem + ".") and "/" not in name[len(stem) + 1:])
    # Preserve complete original local helper namespaces, not current replacements.
    paths.update(name for name in all_paths if name.startswith("tests/emods/") or name.startswith("tests/deviations/devmods/"))
    paths.add("tests/prepare_path.sh")
    inputs = output / "inputs"
    inputs.mkdir(parents=True)
    files = []
    for path in sorted(paths):
        data = blob(BASE, path)
        target = inputs / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        files.append({"path": path, "sha256": digest(data), "bytes": len(data), "git_blob": git("rev-parse", BASE + ":" + path).decode().strip()})

    rows = []
    for path, (kind, reason, replacements) in DETAILS.items():
        data = blob(BASE, path)
        sidecars = []
        for item in files:
            name = item["path"]
            if name != path and name.startswith(path[:-3] + "."):
                new = blob(HEAD, name) if name in head_paths else None
                sidecars.append({**item, "current_same_path_exists": new is not None,
                                 "current_sha256": digest(new) if new is not None else None,
                                 "same_bytes": new == blob(BASE, name) if new is not None else False})
        candidate_sources = []
        for replacement in replacements:
            new = blob(HEAD, replacement)
            candidate_sources.append({"path": replacement, "sha256": digest(new),
                                      "same_file_bytes": new == data,
                                      "same_executable_ast": ast_digest(new) == ast_digest(data)})
        rows.append({"path": path, "kind": kind, "baseline_sha256": digest(data),
                     "baseline_ast_sha256": ast_digest(data), "source_reason": reason,
                     "candidate_sources": candidate_sources, "original_sidecars": sidecars,
                     "execution_disposition": "pending; no compiler was run during preparation"})

    cases = [{"path": path, "role": "changed-helper-declaration" if kind == "modified-helper" else kind}
             for path, (kind, _, _) in DETAILS.items()]
    cases.append({"path": CONSUMER, "role": "unchanged-consumer-of-changed-helper"})
    manifest = {
        "status": "prepared-not-executed", "created_utc": datetime.now(timezone.utc).isoformat(),
        "baseline_sha": BASE, "candidate_sha": HEAD,
        "baseline_tree": git("rev-parse", BASE + "^{tree}").decode().strip(),
        "candidate_tree": git("rev-parse", HEAD + "^{tree}").decode().strip(),
        "repository": str(repo), "inputs": str(inputs), "inventory": rows, "cases": cases, "files": files,
        "case_count": len(cases), "input_file_count": len(files),
        "imports": [
            {"cases": ["tests/errors/language/args_complex_called.py", "tests/errors/language/kwargs_complex_called.py"],
             "sidecar_value": "tests", "module": "emods.starcomplex", "source": "tests/emods/starcomplex.py"},
            {"cases": [CONSUMER], "module": "devmods.cmp_declined", "source": "tests/deviations/devmods/cmp_declined.py",
             "resolution": "program directory tests/deviations is first; original namespace copied"}],
        "notes": [
            "There are four changed primary corpus files and one changed helper, not five changed primary cases.",
            "Six removed error inputs and one renamed error input are retained at their original paths.",
            "The renamed reflected_rand source has different bytes but an identical executable AST; the candidate corpus covers the promoted version.",
            "No original source or sidecar was rewritten, and no input was added to a production checkout.",
            "Source reasons are evidence-backed intent, not claimed execution results; actual transitions require the run script.",
        ],
    }
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"output": str(output), "cases": len(cases), "files": len(files), "status": manifest["status"]}))


if __name__ == "__main__":
    main()
