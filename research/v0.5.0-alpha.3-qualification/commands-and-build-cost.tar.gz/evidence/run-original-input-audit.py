"""Run preserved original inputs with independently pinned compiler source homes.

Run only after the main retained corpus finishes and the release owner authorizes it.
This supplements the maintained main oracle; it never changes its records.
"""
import argparse
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit", type=Path, required=True)
    parser.add_argument("--main-audit", type=Path, required=True)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--timeout", type=int, default=240)
    args = parser.parse_args()
    audit = args.audit.resolve()
    manifest_path = audit / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    if not args.execute:
        print(json.dumps({"status": "not-executed", "cases": manifest["case_count"],
                          "instruction": "After the main audit finishes and owner signals, add --execute."}))
        return
    main_path = args.main_audit.resolve() / "identity.json"
    identity = json.loads(main_path.read_text())
    assert identity["homes"]["base"]["source_sha"] == manifest["baseline_sha"]
    assert identity["homes"]["head"]["source_sha"] == manifest["candidate_sha"]
    for index, _ in enumerate(identity["corpus"], 1):
        case_dir = args.main_audit / "cases" / str(index)
        for name in ("case", "old.status", "new.status", "report"):
            assert (case_dir / name).exists(), ("Main audit incomplete", case_dir, name)
    inputs = Path(manifest["inputs"])
    for item in manifest["files"]:
        assert sha(inputs / item["path"]) == item["sha256"], item["path"]
    homes = {}
    for side in ("base", "head"):
        info = identity["homes"][side]
        home = Path(info["home"])
        binary = home / "pystachy"
        assert sha(binary) == info["binary_sha256"]
        actual = subprocess.check_output(["git", "-C", str(home), "rev-parse", "HEAD"], text=True).strip()
        assert actual == info["source_sha"]
        clean = subprocess.check_output(["git", "-C", str(home), "status", "--porcelain"], text=True)
        assert clean == ""
        homes[side] = {"home": str(home), "binary": str(binary), **info}
    output = audit / "results"
    output.mkdir(exist_ok=False)
    env = {key: value for key, value in os.environ.items() if not key.startswith("PYSTACHY_")}
    env["PYSTACHY_JOBS"] = "1"
    rows = []
    for index, case in enumerate(manifest["cases"], 1):
        directory = output / str(index)
        directory.mkdir()
        (directory / "case").write_text(case["path"] + "\n")
        case_env = dict(env)
        sidecar = (inputs / case["path"]).with_suffix(".path")
        if sidecar.exists():
            case_env["PYSTACHY_PATH"] = subprocess.check_output(
                ["sh", "tests/prepare_path.sh", case["path"], str(directory)], cwd=inputs, env=env, text=True).strip()
        else:
            case_env["PYSTACHY_PATH"] = ""
        results = {}
        for side, label in (("base", "old"), ("head", "new")):
            command = [homes[side]["binary"], "ir", case["path"], "-o", str(directory / (label + ".ll"))]
            started = time.monotonic()
            timed_out = False
            with (directory / (label + ".msg")).open("wb") as stream:
                try:
                    process = subprocess.run(command, cwd=inputs, env=case_env, stdout=stream,
                                             stderr=subprocess.STDOUT, timeout=args.timeout)
                    status = process.returncode
                except subprocess.TimeoutExpired:
                    status = None
                    timed_out = True
            (directory / (label + ".status")).write_text(str(status) + "\n")
            results[label] = {"command": command, "status": status, "timed_out": timed_out,
                              "elapsed_seconds": time.monotonic() - started}
        for suffix in ("msg", "ll"):
            old, new = directory / ("old." + suffix), directory / ("new." + suffix)
            if old.exists() and new.exists():
                diff = difflib.unified_diff(old.read_text().splitlines(True), new.read_text().splitlines(True),
                                            fromfile=old.name, tofile=new.name)
                (directory / (suffix + ".raw.diff")).write_text("".join(diff))
        old_status, new_status = results["old"]["status"], results["new"]["status"]
        row = {**case, "runs": results, "newly_rejected": old_status == 0 and new_status != 0,
               "newly_accepted": old_status not in (0, None) and new_status == 0,
               "status_transition": str(old_status) + "->" + str(new_status),
               "files": {p.name: {"sha256": sha(p), "bytes": p.stat().st_size} for p in sorted(directory.iterdir()) if p.is_file()},
               "disposition": "requires independent review of acceptance and complete raw diagnostics/IR"}
        rows.append(row)
        print(json.dumps({"case": case["path"], "transition": row["status_transition"]}), flush=True)
    for item in manifest["files"]:
        assert sha(inputs / item["path"]) == item["sha256"], item["path"]
    report = {"status": "compiled-requires-disposition", "completed_utc": datetime.now(timezone.utc).isoformat(),
              "manifest_sha256": sha(manifest_path), "main_identity_sha256": sha(main_path), "homes": homes,
              "cases": rows, "total": len(rows), "note": "Original inputs and helpers unchanged; no diagnostic or IR normalization; no runtime parity or proof claim."}
    (audit / "execution.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
