tests/deviations/devmods/cmp_declined.py:2: error: unsupported type annotation
