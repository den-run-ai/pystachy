tests/deviations/devmods/cmp_declined.py:8: error: __eq__ must return bool
