tests/errors/library/lib_datetime_reflected.py:6: error: reflected operator methods are not supported (int * timedelta calls timedelta.__rmul__)
