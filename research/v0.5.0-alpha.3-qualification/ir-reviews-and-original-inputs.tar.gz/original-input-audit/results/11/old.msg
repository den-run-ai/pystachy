tests/errors/optimizations/opt_scalar_key_type.py:2: error: dict keys must be int or str, not int | None (a key cannot be None)
