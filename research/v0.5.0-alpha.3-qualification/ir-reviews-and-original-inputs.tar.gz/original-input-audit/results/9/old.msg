tests/errors/optimizations/opt_dict_key.py:2: error: dict keys must be int or str, not str | None (a key cannot be None)
