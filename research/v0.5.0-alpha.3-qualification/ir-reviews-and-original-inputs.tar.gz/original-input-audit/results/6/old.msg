tests/errors/language/args_complex_called.py:4: error: emods.starcomplex.collect() is not supported: parameter '*args': unsupported type annotation
