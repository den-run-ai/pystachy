tests/errors/optimizations/opt_none_unknown.py:4: error: NoneType | None values cannot be compared or printed
