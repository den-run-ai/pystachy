def f(x):
    return x
    return "caf�"
