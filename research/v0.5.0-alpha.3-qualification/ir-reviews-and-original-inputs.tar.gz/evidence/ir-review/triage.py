"""Describe accepted IR differences without changing the retained oracle."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

ROOT = Path('/workspace/scratch/980402bc01c4/ir-audit')
OUT = Path('/workspace/scratch/980402bc01c4/evidence/ir-review')
analysis = json.loads((ROOT / 'analysis.json').read_text())
identity = json.loads((ROOT / 'identity.json').read_text())
oldhome = identity['homes']['base']['home']
newhome = identity['homes']['head']['home']
rx = re.compile(r'^(@s\.\d+ = private unnamed_addr global \{i64, i64, i64, )\[(\d+) x i8\](\} \{i64 )(\d+), i64 (\d+), i64 (\d+), \[(\d+) x i8\] c"(.*)"\}, align 8$')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def decoded(payload):
    out = bytearray()
    i = 0
    while i < len(payload):
        if payload[i] == '\\':
            assert re.fullmatch('[0-9a-fA-F]{2}', payload[i+1:i+3])
            out.append(int(payload[i+1:i+3], 16)); i += 3
        else:
            out.extend(payload[i].encode()); i += 1
    return bytes(out)


def literal_paths(text):
    lines, proofs = [], []
    for line in text.splitlines(True):
        if oldhome not in line:
            lines.append(line); continue
        m = rx.fullmatch(line.rstrip('\n'))
        if not m:
            return None, [{'unrecognized_path_line': line.rstrip()}]
        head,n1,brace,length,hashed,chars,n2,payload = m.groups()
        raw = decoded(payload)
        assert int(n1) == int(n2) == len(raw) and raw.endswith(b'\0')
        assert int(length) == len(raw) - 1 and hashed == '0' and int(chars) in (0,len(raw))
        adjusted = payload.replace(oldhome, newhome)
        n = len(decoded(adjusted)); c = n if int(chars) else 0
        lines.append(f'{head}[{n} x i8]{brace}{n-1}, i64 0, i64 {c}, [{n} x i8] c"{adjusted}"}}, align 8\n')
        suffixes = re.findall(re.escape(oldhome + '/lib/') + r'([^\s)\\"]+)', payload)
        if suffixes:
            for suffix in suffixes:
                a,b = Path(oldhome)/'lib'/suffix, Path(newhome)/'lib'/suffix
                proofs.append({'kind':'library-source', 'path':suffix, 'old_sha256':sha(a),
                               'new_sha256':sha(b),'identical_bytes':a.read_bytes()==b.read_bytes()})
        else:
            assert payload == oldhome + r'\00', payload
            proofs.append({'kind':'documented-compiler-home', 'old':oldhome, 'new':newhome})
    return ''.join(lines), proofs


rows = []
for index, item in enumerate(analysis['rows'], 1):
    if not item['different'] or item['old_status'] != 0 or item['new_status'] != 0:
        continue
    p = ROOT/'cases'/str(index)
    old,new = (p/'old.ll').read_text(),(p/'new.ll').read_text()
    adjusted,proofs = literal_paths(old)
    row = {'case_id':index,'case':item['case'],'source_sha256':item['source_sha256'],
           'old_status':0,'new_status':0,'path_proofs':proofs,
           'raw_ir_sha256':{'old':sha(p/'old.ll'),'new':sha(p/'new.ll')},
           'raw_ir_diff':str(p/'ir.raw.diff'),'functions':item.get('functions',{}),
           'classification':'requires-semantic-review'}
    same_sources = all(proof.get('identical_bytes',True) for proof in proofs)
    if adjusted == new and same_sources:
        row['classification'] = 'verified-checkout-path-literals-only'
        row['review_note'] = 'Whole IR identical after exact compiler-home replacements confined to validated LLVM string constants; string header lengths and referenced library input bytes verified. No instruction, diagnostic, or type change.'
    elif adjusted is not None:
        types = lambda t: [line for line in t.splitlines(True) if re.match(r'^%C\.[^ ]+ = type ',line)]
        strip = lambda t: ''.join(line for line in t.splitlines(True) if not re.match(r'^%C\.[^ ]+ = type ',line))
        a,b = types(adjusted),types(new)
        if strip(adjusted) == strip(new) and same_sources:
            added,removed = sorted(set(b)-set(a)),sorted(set(a)-set(b))
            rest = strip(new)
            referenced = [line for line in added+removed if line.split(' = ')[0] in rest]
            row.update(type_declarations_added=added,type_declarations_removed=removed,
                       changed_types_referenced_outside_declarations=referenced)
            if not referenced:
                row['classification'] = 'unused-class-type-declarations-only'
                row['review_note'] = 'After verified path literals, differences are only listed class type declarations, none referenced anywhere outside the declaration block. All instructions, constants, metadata and function bodies are byte-identical.'
    rows.append(row)
report={'status':'structural-triage-semantic-dispositions-pending','baseline':analysis['baseline'],
        'candidate':analysis['source'],'accepted_ir_differences':len(rows),
        'counts':dict(Counter(r['classification'] for r in rows)),'rows':rows}
(OUT/'accepted-ir-triage.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))
print(json.dumps([{'id':r['case_id'],'case':r['case'],'functions':r['functions']} for r in rows if r['classification']=='requires-semantic-review'],indent=2))
