from pathlib import Path
import json,re,hashlib,difflib,collections
root=Path('/workspace/scratch/980402bc01c4/ir-audit');out=Path('/workspace/scratch/980402bc01c4/evidence/ir-review')
data=json.loads((out/'accepted-ir-triage.json').read_text());ids=json.loads((root/'identity.json').read_text());oh=ids['homes']['base']['home'];nh=ids['homes']['head']['home']
views=out/'semantic-views';views.mkdir(exist_ok=True)
def sha(s):return hashlib.sha256(s.encode()).hexdigest()
def functions(text):
 result={};name=None
 for line in text.splitlines():
  if line.startswith('define '):name=re.search(r'@([^ (]+)',line)[1];lines=[]
  if name is not None:lines.append(line)
  if line=='}' and name is not None:result[name]='\n'.join(lines);name=None
 return result
def outside(text):
 lines=[];active=False
 for l in text.splitlines():
  if l.startswith('define '):active=True
  if not active:lines.append(l)
  if l=='}':active=False
 return '\n'.join(lines)
def resolver(text):
 strings={};meta={}
 for l in text.splitlines():
  m=re.fullmatch(r'(@s\.\d+) = (.+)',l)
  if m:strings[m[1]]=m[2]
  m=re.fullmatch(r'(!\d+) = (.+)',l)
  if m:meta[m[1]]=m[2]
 def ex(m):return '<'+re.sub(r'!\d+\b',ex,meta[m[0]])+'>'
 def resolve(s):
  s=re.sub(r'!\d+\b',lambda m:'!'+sha(ex(m))[:16],s)
  return re.sub(r'@s\.\d+\b',lambda m:'@S_'+sha(strings[m[0]])[:16],s)
 return resolve

def canonical(s,resolve,dead=False):
 removed=[]
 if dead:
  ls=[]
  for l in s.splitlines():
   m=re.fullmatch(r'  (%[\w.$-]+) = call ptr @(pys_dyn_int|pys_dyn_float|pys_dyn_bool)\((.*)\)',l)
   if m and len(re.findall(re.escape(m[1])+r'(?![\w.$-])',s))==1:
    removed.append(l);continue
   ls.append(l)
  s='\n'.join(ls)
 localdefs=set(re.findall(r'(%[\w.$-]+) = ',s))|set(re.findall(r'%[\w.$-]+',s.splitlines()[0]))|{'%'+m for m in re.findall(r'^([\w.$-]+):',s,re.M)}
 localdefs={n for n in localdefs if not n.startswith('%C.')}
 mapping={}
 def rename(m):
  if m[0] not in localdefs:return m[0]
  if m[0] not in mapping:mapping[m[0]]='%L'+str(len(mapping))
  return mapping[m[0]]
 s=re.sub(r'%[\w.$-]+',rename,s)
 def label(m):return rename(type('M',(),{'__getitem__':lambda self,k:'%'+m[1]})()) [1:]+':'
 s=re.sub(r'^([\w.$-]+):',label,s,flags=re.M)
 return resolve(s),removed
rows=[]
for row in data['rows']:
 if row['classification']!='requires-semantic-review':continue
 p=root/'cases'/str(row['case_id']);old=(p/'old.ll').read_text().replace(oh,nh);new=(p/'new.ll').read_text();of,nf=functions(old),functions(new);orr,nrr=resolver(old),resolver(new)
 report=[];eq=[];deads={};different=[]
 for name in sorted(set(of)&set(nf)):
  a,_=canonical(of[name],orr);b,_=canonical(nf[name],nrr)
  if a==b:
   if of[name]!=nf[name]:eq.append(name)
   continue
  a1,ad=canonical(of[name],orr,True);b1,bd=canonical(nf[name],nrr,True)
  if a1==b1:
   deads[name]={'old_removed':ad,'new_removed':bd};continue
  different.append(name)
  report.extend(difflib.unified_diff(a1.splitlines(),b1.splitlines(),fromfile='old/'+name,tofile='new/'+name,n=1))
 for name in sorted(set(of)-set(nf)):report.extend(['REMOVED FUNCTION '+name,of[name]])
 for name in sorted(set(nf)-set(of)):report.extend(['ADDED FUNCTION '+name,nf[name]])
 types=lambda t:{l.split(' = ')[0]:l.split(' = ')[1] for l in t.splitlines() if l.startswith('%C.') and ' = ' in l}
 ot,nt=types(old),types(new);typechanges={k:{'old':ot.get(k),'new':nt.get(k)} for k in set(ot)|set(nt) if ot.get(k)!=nt.get(k)}
 rawoutside=list(difflib.unified_diff(outside(old).splitlines(),outside(new).splitlines(),fromfile='old/global',tofile='new/global',n=1))
 (views/f"{row['case_id']}.functions.diff").write_text('\n'.join(report)+'\n');(views/f"{row['case_id']}.globals.diff").write_text('\n'.join(rawoutside)+'\n')
 r={'case_id':row['case_id'],'case':row['case'],'canonical_equal_functions':eq,'unused_numeric_box_calls_only':deads,'semantic_changed_functions':different,'removed_functions':sorted(set(of)-set(nf)),'added_functions':sorted(set(nf)-set(of)),'type_changes':typechanges,'function_view_lines':len(report),'global_view_lines':len(rawoutside)};rows.append(r)
(out/'semantic-inventory.json').write_text(json.dumps({'method':'Function-local bijective SSA names, exact string/metadata content hashes, validated equal-length checkout path literals. Explicit unused numeric boxing calls recorded separately; no other operation discarded. Views only; no retained IR changed.','rows':rows},indent=2)+'\n')
print(json.dumps({'rows':len(rows),'no_semantic_function_diffs':sum(not r['semantic_changed_functions'] and not r['removed_functions'] and not r['added_functions'] for r in rows),'semantic_function_diffs':sum(len(r['semantic_changed_functions']) for r in rows),'total_view_lines':sum(r['function_view_lines'] for r in rows)},indent=2))
