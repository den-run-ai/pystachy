from pathlib import Path
import json,re
ns={};exec(Path('/workspace/scratch/980402bc01c4/evidence/ir-review/semantic-views.py').read_text().split('rows=[]')[0],ns)
root,out,fn,res,can=[ns[n] for n in ['root','out','functions','resolver','canonical']];rows=[]
for r in json.loads((out/'semantic-inventory.json').read_text())['rows']:
 cid=r['case_id'];p=root/'cases'/str(cid);o=(p/'old.ll').read_text().replace(ns['oh'],ns['nh']);n=(p/'new.ll').read_text();of,nf=fn(o),fn(n);orr,nrr=res(o),res(n);proof=[];pending=[]
 for name in r['semantic_changed_functions']:
  aa,_=can(of[name],orr,True);bb,_=can(nf[name],nrr,True);a,b=aa.splitlines(),bb.splitlines()
  if len(a)!=len(b):pending.append(name);continue
  allocations={};found=[];bad=False
  for i,(x,y) in enumerate(zip(a,b)):
   if x==y:continue
   m=re.fullmatch(r'  (%L\d+) = call ptr @pys_alloc\(i64 (\d+)\)',x);q=re.fullmatch(r'  (%L\d+) = call ptr @pys_alloc\(i64 (\d+)\)',y)
   if m and q and m[1]==q[1] and int(q[2])==int(m[2])+8:
    s=re.fullmatch(r'  store i64 (\d+), ptr '+re.escape(m[1]),a[i+1])
    if s and int(m[2])==8*(int(s[1])+1) and a[i+1]==b[i+1]:
     allocations[m[1]]=int(s[1]);found.append({'kind':'VTuple-header-word','line':i+1,'old_bytes':int(m[2]),'new_bytes':int(q[2]),'count':int(s[1])});continue
   m=re.fullmatch(r'  (%L\d+) = getelementptr i64, ptr (%L\d+), i64 (\d+)',x);q=re.fullmatch(r'  (%L\d+) = getelementptr i64, ptr (%L\d+), i64 (\d+)',y)
   if m and q and m.groups()[:2]==q.groups()[:2] and int(q[3])==int(m[3])+1 and m[2] in allocations and 1<=int(m[3])<=allocations[m[2]]:
    found.append({'kind':'VTuple-item-address','line':i+1,'old_index':int(m[3]),'new_index':int(q[3]),'allocation':m[2]});continue
   m=re.fullmatch(r'  (%L\d+) = add i64 (%L\d+), 1',x);q=re.fullmatch(r'  (%L\d+) = add i64 (%L\d+), 2',y)
   if m and q and m.groups()[:2]==q.groups()[:2] and re.fullmatch(r'  %L\d+ = getelementptr i64, ptr %L\d+, i64 '+re.escape(m[1]),a[i+1]) and a[i+1]==b[i+1]:
    found.append({'kind':'VTuple-iteration-header-offset','line':i+1,'old_offset':1,'new_offset':2,'source_review_required':'The addressed object is the runtime-length tuple in this named function; iteration index/value/control flow is unchanged.'});continue
   bad=True;break
  if not bad:proof.append({'name':name,'changes':found,'exact_body_equal_after_listed_changes':True})
  else:pending.append(name)
 if proof:rows.append({'case_id':cid,'proven_functions':proof,'other_changed_functions':pending,'removed_functions':r['removed_functions'],'added_functions':r['added_functions']})
(out/'vtuple-layout-evidence.json').write_text(json.dumps({'method':'Every unequal pair of lines must be a proven VTuple allocation of (len+1)*8 -> (len+2)*8 with identical stored length, corresponding item GEP +1 into that allocation, or the individually reviewed VTuple iteration add1 -> add2 immediately consumed by unchanged GEP. No other opcode, operand or control-flow change is ignored; source/object provenance for iteration is reviewed separately. Local SSA names are bijective; exact literals/metadata are resolved.','rows':rows},indent=2)+'\n');print('cases',len(rows),'functions',sum(len(r['proven_functions']) for r in rows));print('fullcases',[r['case_id'] for r in rows if not r['other_changed_functions'] and not r['removed_functions'] and not r['added_functions']])
