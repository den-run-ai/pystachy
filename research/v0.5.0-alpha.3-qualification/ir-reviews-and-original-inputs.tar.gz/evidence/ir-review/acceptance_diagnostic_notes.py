"""Materialize independently reviewed alpha.3 acceptance/diagnostic dispositions.

Reads retained evidence and exact input source only. Never runs the compiler,
changes normalizers, grants a Lean result, or substitutes a runtime oracle.
"""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/workspace/scratch/980402bc01c4')
IR = ROOT / 'ir-audit'
SRC = ROOT / 'alpha3'
OUT = ROOT / 'evidence/ir-review'

# Each entry names the actual newly exercised behavior, after inspecting the
# retained complete old diagnostic, current input and its fixture purpose.
ACCEPT = {
129: ('comparison_decline', 'Ordinary rich comparison methods can decline and continue to the next comparison candidate.'),
130: ('comparison_decline', 'A dataclass custom ordering method declines while its generated equality remains available.'),
132: ('comparison_decline', 'An Enum ordering method rejects a different enum class through NotImplemented fallback.'),
133: ('comparison_decline', 'IntEnum decline fallback compares against promoting integers without truncating the integer operand.'),
134: ('comparison_decline', 'Different IntEnum classes exercise reflected candidate ordering and the integer fallback.'),
135: ('comparison_decline', 'IntEnum scalar and optional operands exercise numeric fallback after declined rich comparisons.'),
137: ('comparison_decline', 'A method catches AttributeError and declines; ordering with None then raises the comparison TypeError.'),
138: ('comparison_decline', 'An exception class may decline equality, preserving fallback identity semantics.'),
139: ('comparison_decline', 'Generic-class equality declines operands from a different specialization/class shape.'),
140: ('comparison_decline', 'Base/subclass and optional comparisons retain reflected-method priority after a decline.'),
141: ('comparison_decline', 'Missing __ne__ and explicitly declining __ne__ follow their distinct equality/identity fallback paths.'),
142: ('comparison_decline', 'Nested comparisons do not overwrite the surrounding method return-versus-decline state.'),
143: ('comparison_decline', 'Nullable objects and explicit None are compared from both operand orders.'),
144: ('comparison_decline', 'Runtime-selected declines retain reflected results or raise TypeError when ordering candidates are exhausted.'),
145: ('comparison_decline', 'StrEnum scalar and optional operands fall back to the string comparison value.'),
146: ('comparison_decline', 'A guarded subclass comparison calls the base method only for its compatible operand.'),
147: ('comparison_decline', 'Recursive tree comparisons retain ordinary boolean results alongside compile-time decline guards.'),
148: ('comparison_decline', 'Tuple membership/count/index use lenient runtime-class comparison dispatch with reflected fallback.'),
149: ('constructor_specialization', 'Imported alias names resolve a fixed-layout constructor dependency before hierarchy specialization.'),
150: ('constructor_specialization', 'Imported fixed-layout Child/Errors dependencies are demand-validated without evaluating unused invalid descendants.'),
151: ('constructor_specialization', 'Qualified imported annotation names resolve the same fixed-layout dependency.'),
152: ('constructor_specialization', 'Quoted imported aliases resolve the same fixed-layout constructor dependency.'),
153: ('constructor_specialization', 'A constructor specializes its variable-layout input while storing only the explicitly converted fixed integer field.'),
154: ('constructor_specialization', 'Nested imported constructor dependencies are resolved transitively before the demanded hierarchy is used.'),
157: ('constructor_specialization', 'An inherited constructor accepts variable inputs but always stores its explicitly annotated integer field.'),
158: ('constructor_specialization', 'A subclass constructor specializes independently while retaining its fixed annotated field layout.'),
159: ('constructor_specialization', 'Iterable constructor inputs share one class layout across list/tuple/generator inputs and base-typed dispatch.'),
170: ('constructor_specialization', 'Dynamic Any dispatch sees the same demanded fixed-layout constructor hierarchy as typed code.'),
171: ('constructor_specialization', 'Runtime class/isinstance checks recognize constructor-specialized objects as their Python class.'),
172: ('constructor_specialization', 'A fixed-layout child field refers to a base whose constructor needs specialization.'),
173: ('constructor_specialization', 'Direct fixed-layout inheritance and super-constructor calls accept Iterable inputs.'),
174: ('constructor_specialization', 'Imported hierarchy aliases preserve base-typed method dispatch and specialized constructors.'),
175: ('constructor_specialization', 'A recursively annotated fixed-layout base is inherited by a demanded leaf.'),
176: ('constructor_specialization', 'A child with a recursive optional field keeps one layout across string/int constructor inputs.'),
177: ('constructor_specialization', 'Imported recursive child aliases preserve runtime identity and leave dormant invalid descendants unused.'),
178: ('constructor_specialization', 'A quoted recursive child annotation resolves without forcing variable object layout.'),
286: ('numeric_protocols', 'Conversions dispatch on the runtime subclass and retain TypeError for None or objects lacking the required method.'),
287: ('numeric_protocols', 'Supported int/float/index and rounding protocols receive arguments in order and preserve their result checks.'),
289: ('numeric_protocols', 'Primitive-left arithmetic and bitwise operations call the supported reflected method with runtime subclass dispatch.'),
350: ('none_optional_keys', 'None and supported optional dictionary keys retain normal insertion, lookup, deletion and iteration behavior.'),
418: ('none_optional_keys', 'set[None] and frozenset[None] support their one possible element and normal empty-set operations.'),
419: ('none_optional_keys', 'None key/element types flow through functions, fields, nested containers and a generic type parameter.'),
422: ('none_optional_keys', 'Supported optional scalar and tuple set elements can hold and find None.'),
423: ('none_optional_keys', 'Set operations handle compatible None-only/optional element representations while keeping unsafe widening rejected.'),
467: ('identity_union_keys', 'Ordinary class-union dictionary keys use object identity hash/equality for every admitted class.'),
468: ('identity_union_keys', 'Dynamic-Any dictionaries preserve identity-only class-union key behavior.'),
469: ('identity_union_keys', 'None in nullable reference-union tables is guarded before payload access; missing None keys raise KeyError.'),
470: ('identity_union_keys', 'Class-union set elements use identity hashing and narrow correctly during iteration.'),
477: ('runtime_tuple_keys', 'Supported scalar runtime-length tuple keys share item/length hashes with equal fixed tuples.'),
478: ('runtime_tuple_keys', 'Runtime-length tuple set/frozenset elements compare equal across tuple construction paths.'),
702: ('generic_type_reflection', 'isinstance of dynamic generic-class values tests Python class membership without assuming one payload specialization.'),
703: ('generic_type_reflection', 'Non-opted-in imported helpers compare generic Python classes consistently for typed and Any operands.'),
704: ('generic_type_reflection', 'Template type identity preserves operand evaluation order and NameError before the class binding exists.'),
796: ('complex_default_laziness', 'Calls supply explicit complex values; an incompatible unused default is evaluated but is not implicitly accepted as an argument.'),
800: ('complex_default_laziness', 'Imported defaults retain definition-time side effects while explicit valid complex arguments compile.'),
999: ('comparison_decline', 'Any rich comparison dispatch uses the same reflected, identity and TypeError fallback rules as typed operands.'),
1013: ('complex_dynamic', 'Any may hold complex values and combine them with supported primitive numerical operands.'),
1014: ('complex_dynamic', 'Complex declines foreign objects before their comparison/reflected methods; absent arithmetic support still raises TypeError.'),
1015: ('complex_dynamic', 'Dynamic complex equality compares primitive real components with the supported exact numeric path.'),
1016: ('complex_dynamic', 'Direct complex __init__ calls evaluate supplied arguments, return None and preserve the object value.'),
1017: ('complex_dynamic', 'A bound dynamic complex __init__ call remains a no-op and preserves aliases and dictionary keys.'),
1018: ('complex_dynamic', 'Packed arguments to a dynamic complex initializer retain the same no-op behavior.'),
1019: ('complex_dynamic', 'A foreign left operand receives the correct dynamic TypeError when complex arithmetic declines it.'),
1020: ('complex_dynamic', 'Dynamic complex/foreign comparisons preserve NotImplemented fallback.'),
1021: ('complex_dynamic', 'Dynamic stores update ordinary real/imag fields but raise AttributeError for the read-only complex fields.'),
1022: ('complex_dynamic', 'Complex reference identity survives closed unions, Any, tuple extraction and generator transport.'),
1023: ('complex_dynamic', 'Dynamic promoting integers convert through the supported complex numeric path and retain overflow behavior.'),
1025: ('decimal_subset', 'Decimal and complex equality run through Any with the supported real-component comparison.'),
1593: ('numeric_protocols', 'A primitive int/float on the left calls timedelta.__rmul__.'),
1596: ('decimal_subset', 'The new bounded Decimal module supplies its declared construction, arithmetic, context, formatting and signal surface.'),
1597: ('decimal_subset', 'Decimal/complex equality covers real components, nonzero imaginary values and signaling NaNs.'),
1598: ('decimal_subset', 'Supported current/default/context copies use the documented Decimal context settings.'),
1599: ('decimal_subset', 'Extreme negative Decimal exponents convert without materializing enormous powers of ten.'),
1600: ('decimal_subset', 'Operand grids exercise the supported Decimal precision/rounding operations against recorded output.'),
1601: ('decimal_subset', 'Decimal integer conversions use promoting results while constructor/operator input boundaries remain explicit.'),
1602: ('decimal_subset', 'Decimal quotient/divmod/mod operations retain context exponent, overflow and clamping boundaries.'),
1603: ('decimal_subset', 'Decimal values participate in supported records, containers, keys, optional values and typed money arithmetic.'),
1604: ('decimal_subset', 'Decimal decline permits a foreign object comparison method to answer.'),
1617: ('numeric_protocols', 'Primitive-left IntEnum/IntFlag operations preserve ordinary numeric versus flag-result distinctions.'),
1623: ('comparison_decline', 'StrEnum comparison fallback uses the immutable string payload even after mutable _value_ changes.'),
1803: ('complex_typed', 'Complex literals/constructors support the documented arithmetic, parts, equality, hashing and representation.'),
1804: ('complex_typed', 'Typed complex operations remain valid when dynamic Any support is enabled in the module.'),
1805: ('complex_typed', 'Declining IntEnum/IntFlag comparisons interoperate with complex equality.'),
1806: ('complex_typed', 'Enum numeric values compare with complex values in both orders and tuple searches.'),
1807: ('complex_typed', 'Enum-owned equality/inequality and complex numeric comparison retain operand priority.'),
1808: ('complex_typed', 'Complex formatting accepts supported formats and retains its runtime ValueErrors.'),
1809: ('complex_typed', 'Complex initializer calls evaluate arguments without mutating values, aliases or hashes.'),
1810: ('complex_typed', 'Invalid complex constructor argument combinations remain runtime TypeErrors after ordered argument evaluation.'),
1811: ('complex_typed', 'Optional complex arithmetic/constructors guard None and raise TypeError instead of reading an absent payload.'),
1812: ('complex_typed', 'Optional complex equality and explicit None compare by identity in both operand orders.'),
1813: ('complex_typed', 'Declining foreign comparisons execute once in runtime subclass and tuple-search paths.'),
1814: ('complex_typed', 'Complex equality declines foreign objects before their own equality or identity fallback.'),
1815: ('complex_typed', 'Optional int/float/bool and complex equality compare real components and None correctly.'),
1816: ('complex_typed', 'Tuple searches use those same optional scalar/complex equality rules.'),
1817: ('complex_typed', 'Optional foreign objects and optional complex values guard None before invoking object equality.'),
1818: ('complex_typed', 'Complex string parsing supports its declared syntax and preserves runtime ValueErrors for invalid strings.'),
1819: ('complex_typed', 'Promoting integer/complex operations retain exact equality and overflow boundaries.'),
1820: ('complex_typed', 'Runtime-supplied IEEE exceptional complex values exercise the CPython-derived numerical routines.'),
1821: ('complex_typed', 'Base-typed foreign operands use runtime subclass equality and ordinary identity fallback.'),
1822: ('complex_typed', 'Tuple searches reflect a complex decline into the foreign object equality method.'),
1823: ('complex_typed', 'Complex/scalar tuple search follows equality of the real component when the imaginary part is zero.'),
1824: ('complex_typed', 'Closed unions compare supported container members structurally and complex members by numeric rules.'),
1825: ('complex_typed', 'Closed-union complex members retain IntEnum/IntFlag equality and nullable handling.'),
1826: ('complex_typed', 'Tuple membership/count/index recognize a shared complex object before NaN-sensitive equality.'),
1827: ('complex_typed', 'Nested closed-union descriptors keep complex and container representation boundaries distinct.'),
1828: ('complex_typed', 'Optional union and optional complex equality guard and compare None consistently.'),
1829: ('complex_typed', 'Closed-union complex members permit foreign reflected equality while retaining ordinary identity fallback.'),
1830: ('complex_typed', 'Complex references form supported class-reference unions and narrow by isinstance.'),
1831: ('complex_typed', 'Complex/class reference unions compare each member with its proper equality dispatch.'),
1832: ('complex_typed', 'Closed-union complex comparisons use runtime foreign subclass equality.'),
1833: ('complex_typed', 'Closed scalar-union tuple searches compare complex members with equal integer/float values.'),
1834: ('complex_typed', 'Complex members participate in supported scalar unions, narrowing, arithmetic, formatting and abs.'),
1835: ('complex_typed', 'Typed complex fields, defaults, records, collections, hashes and copies use the new reference representation.'),
1969: ('promoting_optional_tuple_keys', 'Optional fixed-shape tuple keys preserve wide integer storage through set algebra and cross-module container access.'),
1993: ('runtime_tuple_keys', 'Runtime-length tuple keys preserve the explicit 64-bit item boundary, including INT64_MIN hashing.'),
2163: ('provisional_none', 'Reads before a later type-defining loop store can describe the currently None-only local, then rejoin with its final type.'),
2164: ('provisional_none', 'A None-only provisional local can be printed before a later assignment fixes its type.'),
2213: ('numeric_protocols', 'Primitive int bitwise-and invokes the foreign object __rand__ method.'),
2542: ('extended_existing_fixture', 'The existing upstream set-comprehension fixture now includes the previously excluded None-element comprehension.'),
2571: ('documented_deviation', 'Separate equal imaginary literals retain the explicitly documented identity deviation; value equality is unchanged.'),
2573: ('documented_deviation', 'An invalid None-to-nonoptional complex union coercion raises the documented TypeError; retained IR contains the null guard and raise.'),
}

DIAG = {
2865: ('decline_boundary', 'Direct rich-method calls that can return NotImplemented remain rejected at the call site.'),
2866: ('decline_boundary', 'Decline exits through finally/with cleanup remain explicitly unsupported and rejected.'),
2867: ('decline_boundary', 'An unguarded direct super-method call that may return NotImplemented remains rejected.'),
2869: ('constructor_boundary', 'The earlier hierarchy rejection is removed, then the unsupported Annotated constructor parameter is rejected.'),
2871: ('constructor_boundary', 'The variable-layout dependency still prevents generic inheritance; the diagnostic now names the concrete annotation requirement.'),
2872: ('constructor_boundary', 'Demanding the invalid live subclass now reaches and rejects its missing field instead of stopping at the former hierarchy limitation.'),
2973: ('numeric_result_boundary', 'The newly supported float protocol still rejects an integer result from __float__.'),
2977: ('numeric_result_boundary', 'The newly supported int protocol still rejects a string result from __int__.'),
3059: ('key_type_boundary', 'Optional-key support does not admit float keys; rejection now identifies the unsupported key representation.'),
3112: ('key_type_boundary', 'None-only set construction succeeds, but a string lookup remains a rejected incompatible key type.'),
3113: ('key_type_boundary', 'None-only sets are supported; a union method that widens to an incompatible string element type remains rejected.'),
3114: ('key_type_boundary', 'Optional integer set creation succeeds; bool lookup remains explicitly rejected at this representation boundary.'),
3115: ('key_type_boundary', 'Optional integer sets are supported, but this mixed scalar set union remains rejected rather than silently changing representation.'),
3116: ('key_type_boundary', 'In-place union cannot widen a nonoptional string set into optional storage and remains rejected.'),
3170: ('key_type_boundary', 'A class union with custom equality/hash remains rejected, now with an explicit identity-only contract.'),
3174: ('key_type_boundary', 'Runtime-length integer tuple keys are supported; storing bool-bearing tuples still rejects identity/type-changing coercion.'),
3409: ('complex_default_boundary', 'A call that actually needs the incompatible integer default still rejects; explicit complex arguments remain separately supported.'),
3410: ('complex_default_boundary', 'An imported function called without its required compatible complex argument rejects its integer default.'),
3582: ('decline_boundary', 'Dynamic direct rich-method calls that may expose NotImplemented remain rejected.'),
3583: ('decline_boundary', 'Dynamic direct complex.__eq__ calls that would expose NotImplemented remain rejected.'),
3893: ('decimal_boundary', 'Decimal imports are supported, but direct equality calls exposing NotImplemented remain rejected.'),
3894: ('decimal_boundary', 'The bounded Decimal constructor still rejects construction from another Decimal.'),
3895: ('decimal_boundary', 'Decimal imports succeed, then the unimplemented exp method is rejected.'),
3896: ('decimal_boundary', 'Object-valued Decimal exponents remain outside the supported integer-power subset and are rejected.'),
4016: ('normaldist_rejection_order', 'NormalDist remains unsupported: reflected methods no longer cause the first rejection, but unannotated __setstate__ still does.'),
4107: ('complex_boundary', 'Complex literals are supported; a nonexistent x attribute remains rejected.'),
4108: ('decline_boundary', 'Direct complex.__eq__ returning NotImplemented is still rejected.'),
4109: ('complex_boundary', 'Complex construction is supported; floor division remains rejected.'),
4110: ('complex_boundary', 'Complex construction is supported; int(complex) remains rejected.'),
4111: ('complex_boundary', 'An integer is not implicitly accepted for a complex annotation; the new diagnostic suggests an explicit complex value.'),
4112: ('complex_boundary', 'Complex construction is supported; ordering remains rejected.'),
4113: ('complex_boundary', 'Compiler-private complex helper methods do not become public user methods.'),
4114: ('complex_boundary', 'Complex real/imag attributes remain read-only and direct assignment rejects.'),
4115: ('complex_boundary', 'General typed reflected arithmetic between two user objects remains unsupported.'),
4116: ('complex_boundary', 'sum of complex values remains outside the supported subset and rejects.'),
4117: ('complex_boundary', 'Reference unions still reject mixed native-reference and scalar/container representations.'),
4118: ('complex_boundary', 'Hashing this closed scalar union remains unsupported and rejects.'),
4119: ('complex_boundary', 'The unsupported closed-union list operation still requires explicit narrowing.'),
4120: ('complex_boundary', 'The int arm of this closed-union comparison cannot compare with the foreign object and remains rejected.'),
4121: ('complex_boundary', 'Closed-union ordering still requires explicit narrowing and remains rejected.'),
}

PATH_LIBRARY = {3563: 'functools.py', 3872: 'copy.py', 3874: 'copy.py', 3877: 'copy.py',
                3878: 'copy.py', 3879: 'copy.py', 3884: 'csv.py', 3935: 'functools.py',
                3947: 'functools.py', 3980: '_pystachy_itertools.py'}
DATETIME = {3890, 3892}
STATISTICS = {4009, 4010, 4011, 4012, 4013, 4014, 4015, 4017, 4018}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def file_record(path):
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': sha(raw), 'bytes': len(raw)}


def ast_hash(source):
    return sha(ast.dump(ast.parse(source), include_attributes=False).encode())


def function_at(source, line):
    found = []
    def scan(node, prefix=''):
        named = isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))
        name = (prefix + '.' + node.name if prefix else node.name) if named else prefix
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.lineno <= line <= node.end_lineno:
            found.append((node.end_lineno - node.lineno, name, node))
        for child in ast.iter_child_nodes(node):
            scan(child, name if named else prefix)
    scan(ast.parse(source))
    _, name, node = min(found, key=lambda item: item[0])
    lines = source.splitlines(keepends=True)
    body = ''.join(lines[node.lineno-1:node.end_lineno])
    return {'name': name, 'first_line': node.lineno, 'last_line': node.end_lineno,
            'body_sha256': sha(body.encode()),
            'ast_sha256': sha(ast.dump(node, include_attributes=False).encode())}


def library_record(name):
    b = (IR / 'base/lib' / name).read_bytes()
    h = (IR / 'head/lib' / name).read_bytes()
    return {'relative_path': 'lib/' + name,
            'baseline': file_record(IR / 'base/lib' / name),
            'candidate': file_record(IR / 'head/lib' / name),
            'bytes_equal': b == h, 'baseline_ast_sha256': ast_hash(b), 'candidate_ast_sha256': ast_hash(h)}


def main():
    analysis = json.loads((IR / 'analysis.json').read_text())
    baseline = analysis['baseline']
    base_paths = set(subprocess.check_output(['git', '-C', str(SRC), 'ls-tree', '-r', '--name-only', baseline], text=True).splitlines())
    libraries = {name: library_record(name) for name in
                 ('functools.py', 'copy.py', 'csv.py', 'datetime.py', 'enum.py', '_pystachy_itertools.py', 'statistics.py')}
    assert libraries['datetime.py']['baseline_ast_sha256'] == libraries['datetime.py']['candidate_ast_sha256']
    assert not libraries['statistics.py']['bytes_equal']
    stats_diff = subprocess.check_output(['git', '-C', str(SRC), 'diff', baseline, analysis['source'], '--', 'lib/statistics.py'], text=True)
    stats_diff_path = OUT / 'statistics-import-boundary.diff'
    stats_diff_path.write_text(stats_diff)
    rows = []
    for index, original in enumerate(analysis['rows'], 1):
        if not original['different'] or original['old_status'] != 1:
            continue
        directory = IR / 'cases' / str(index)
        source_path = SRC / original['case']
        source = source_path.read_text()
        assert sha(source_path.read_bytes()) == original['source_sha256']
        ast.parse(source)  # Syntax only, no imports or execution.
        old, new = (directory / 'old.msg').read_text(), (directory / 'new.msg').read_text()
        assert int((directory / 'old.status').read_text()) == original['old_status']
        assert int((directory / 'new.status').read_text()) == original['new_status']
        evidence = {name: file_record(directory / name) for name in
                    ('case', 'old.status', 'new.status', 'old.msg', 'new.msg', 'messages.raw.diff', 'report')}
        for name, record in evidence.items():
            expected = original['retained_files'][name]
            assert record['sha256'] == expected['sha256'] and record['bytes'] == expected['bytes']
        row = {'index': index, 'case': original['case'], 'old_status': original['old_status'],
               'new_status': original['new_status'], 'source': file_record(source_path),
               'old_message': old, 'new_message': new, 'evidence': evidence,
               'baseline_input_exists': original['case'] in base_paths,
               'runtime_or_lean_proof_granted_by_this_review': False}
        if row['baseline_input_exists']:
            old_source = subprocess.check_output(['git', '-C', str(SRC), 'show', baseline + ':' + original['case']])
            row['baseline_source_sha256'] = sha(old_source)
            row['baseline_input_bytes_equal'] = old_source == source_path.read_bytes()
        if original['new_status'] == 0:
            category, reason = ACCEPT[index]
            assert new == '' and (directory / 'new.ll').is_file()
            assert not original['case'].startswith('tests/errors/')
            row.update(category=category, reason=reason, disposition='expected_supported_case_or_documented_deviation')
            row['evidence']['new.ll'] = file_record(directory / 'new.ll')
            assert row['evidence']['new.ll']['sha256'] == original['retained_files']['new.ll']['sha256']
            oracle = source_path.with_suffix('.out')
            assert oracle.is_file()
            row['recorded_output'] = file_record(oracle)
            row['oracle_kind'] = ('documented hand-authored deviation' if '/deviations/' in original['case']
                                  else 'checked-in CPython-recorded output; not re-executed by this review')
            if source_path.with_suffix('.err').is_file():
                row['recorded_error_output'] = file_record(source_path.with_suffix('.err'))
            if index == 2573:
                ir = (directory / 'new.ll').read_text()
                body = ir.split('define internal ptr @f.widen(ptr %a0) {', 1)[1].split('\n}', 1)[0]
                assert 'icmp eq ptr' in body and 'null' in body and 'call void @pys_raise' in body
                row['retained_guard'] = {'function': 'f.widen', 'body_sha256': sha(body.encode()),
                                         'null_test_and_raise_present': True}
            if index == 2542:
                row['baseline_compatibility_note'] = 'Current fixture includes a newly added None set comprehension. This 1->0 is not a same-input status transition for the original alpha.2 fixture; original-input audit is separate.'
        else:
            assert original['new_status'] == 1 and original['case'].startswith('tests/errors/')
            want = source.splitlines()[0].removeprefix('# error: ')
            assert source.startswith('# error: ') and want in new
            assert len(new.splitlines()) == 1 and re.match(r'.+\.py:\d+: error: .+\n\Z', new)
            assert not (directory / 'new.ll').exists() and not (directory / 'old.ll').exists()
            row.update(disposition='expected_rejection_retained', expected_diagnostic_fragment=want,
                       expected_diagnostic_matches=True, candidate_diagnostic_is_one_line=True)
            normalized_old = old.replace(str(IR / 'base'), '<compiler-home>')
            normalized_new = new.replace(str(IR / 'head'), '<compiler-home>')
            row['diagnostics_equal_after_home_substitution'] = normalized_old == normalized_new
            if index in PATH_LIBRARY:
                lib = PATH_LIBRARY[index]
                assert libraries[lib]['bytes_equal'] and normalized_old == normalized_new
                category, reason = 'unchanged_library_home_path', 'The complete diagnostic is identical after compiler-home substitution and the referenced library file is byte-identical.'
                row['library_correspondence'] = libraries[lib]
            elif index in DATETIME:
                assert normalized_old == normalized_new
                category, reason = 'datetime_comment_only_library', 'The diagnostic text/line is unchanged after home substitution; datetime source has only the reviewed reflected-method comment change and identical full AST.'
                row['library_correspondence'] = libraries['datetime.py']
            elif index == 3914:
                assert normalized_old == normalized_new
                b = function_at((IR / 'base/lib/enum.py').read_text(), 54)
                h = function_at((IR / 'head/lib/enum.py').read_text(), 54)
                assert b['name'] == h['name'] == 'EnumType.__call__'
                assert b['body_sha256'] == h['body_sha256']
                category, reason = 'enum_missing_result_guard_unchanged', 'The enum library changed elsewhere, but EnumType.__call__ is byte-identical and still rejects an invalid _missing_ result with the same diagnostic.'
                row['library_correspondence'] = {**libraries['enum.py'], 'baseline_function': b, 'candidate_function': h}
            elif index in STATISTICS:
                bline = int(re.search(r'/lib/statistics\.py:(\d+): error:', old).group(1))
                hline = int(re.search(r'/lib/statistics\.py:(\d+): error:', new).group(1))
                b = function_at((IR / 'base/lib/statistics.py').read_text(), bline)
                h = function_at((IR / 'head/lib/statistics.py').read_text(), hline)
                assert hline == bline + 3 and b['name'] == h['name'] and b['body_sha256'] == h['body_sha256']
                shifted = re.sub(r'/lib/statistics\.py:(\d+)', lambda m: '/lib/statistics.py:' + str(int(m.group(1))-3), normalized_new)
                assert shifted == normalized_old
                category, reason = 'statistics_preserved_rejection_and_import_boundary', 'The rejecting function is byte-identical and every diagnostic location shifts by exactly +3. The library deliberately gates Decimal import to CPython, preserving its prior native unsupported-Decimal boundary; this is not a whole-file comment-only claim.'
                row['library_correspondence'] = {**libraries['statistics.py'], 'baseline_function': b, 'candidate_function': h,
                                                 'reviewed_diff': file_record(stats_diff_path), 'diagnostic_line_offset': 3}
            else:
                category, reason = DIAG[index]
            row.update(category=category, reason=reason)
        rows.append(row)
    assert len(rows) == 183
    assert sum(x['new_status'] == 0 for x in rows) == 121
    assert sum(x['new_status'] == 1 for x in rows) == 62
    assert set(ACCEPT) == {x['index'] for x in rows if x['new_status'] == 0}
    report = {
        'schema_version': 1, 'status': 'reviewed_no_blocking_findings',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'source_commit': analysis['source'], 'baseline_commit': baseline,
        'analysis': file_record(IR / 'analysis.json'), 'identity': file_record(IR / 'identity.json'),
        'review_script': file_record(Path(__file__)),
        'counts': {'reviewed_cases': len(rows), 'new_acceptances': 121, 'changed_rejections': 62,
                   'accepted_error_fixtures': 0, 'new_acceptance_new_inputs': 120,
                   'new_acceptance_modified_existing_inputs': 1,
                   'ordinary_positive_fixtures': 119, 'documented_deviations': 2},
        'categories': dict(sorted(Counter(row['category'] for row in rows).items())),
        'findings': [],
        'important_dispositions': [
            'All 62 changed error cases retain exit 1, one complete expected diagnostic, and no emitted LLVM file.',
            'No tests/errors case becomes accepted. New acceptance does not alone establish runtime correctness or a Lean proof.',
            'The 121 statuses concern current input bytes: 120 added fixtures and one changed pre-existing fixture; original alpha.2 input compatibility is independently checked by the other reviewer.',
            'Complex default cases pass explicit valid arguments; companion omitted-default cases remain rejected.',
            'Unused invalid constructor descendants stay lazy; the demanded invalid descendant still rejects for its missing field.',
            'Complex union None deviation has an explicit retained null test and runtime raise; literal identity deviation is already documented.',
            'Path-only descriptions require byte-identical referenced libraries. datetime is separately comment-only; enum and statistics receive explicit changed-library explanations.',
            'statistics changed its Decimal import to a CPython-only guard; nine +3-line diagnostic moves preserve byte-identical rejecting functions. NormalDist remains rejected at the next unsupported method.',
        ],
        'limitations': ['No compiler/runtime/Lean execution performed by this review.',
                        'This is acceptance and diagnostic disposition, not equivalence of newly generated IR.',
                        'The retained raw statuses, messages and IR are authoritative; descriptive path/line correspondence does not modify them.',
                        'Source is the integrated candidate b0bda81e, not the eventual main merge SHA; qualification must preserve the exact-tree/commit chain.'],
        'rows': rows,
    }
    destination = OUT / 'acceptance-diagnostic-review.json'
    destination.write_text(json.dumps(report, indent=2) + '\n')
    # Parent initially requested the plural filename; preserve an identical alias.
    (OUT / 'acceptance-diagnostics-review.json').write_bytes(destination.read_bytes())
    lines = [
        '# Alpha.3 acceptance and diagnostic review', '',
        '**No actionable blocker found in these 183 cases.**', '',
        f"Candidate `{analysis['source']}` versus alpha.2 `{baseline}`.", '',
        'This review covers all 121 rejected-to-accepted inputs and all 62 changed rejected-to-rejected diagnostics in the retained 4,771-case scan. It does not claim runtime or Lean qualification.', '',
        '## Findings and evidence boundaries', '',
    ]
    lines += ['- ' + note for note in report['important_dispositions']]
    lines += ['', '## Disposition counts', '', '| Category | Cases |', '|---|---:|']
    lines += [f'| {category} | {count} |' for category, count in report['categories'].items()]
    lines += ['', '## Per-case record', '',
              '`acceptance-diagnostic-review.json` contains every input path, unique case explanation, complete old/new diagnostics, input/sidecar/raw-evidence hashes, expected-message checks, baseline-input relationship and the relevant library/function correspondence. The plural filename is a byte-identical alias for the parent’s requested path.', '',
              'The raw evidence remains in `ir-audit/cases/INDEX`. No normalizer, source, compiler or prior evidence was modified. No heavy execution was started.', '']
    markdown = '\n'.join(lines)
    (OUT / 'acceptance-diagnostic-review.md').write_text(markdown)
    (OUT / 'acceptance-diagnostics-review.md').write_text(markdown)
    print(json.dumps({'status': report['status'], 'counts': report['counts'], 'categories': report['categories'], 'report': str(destination)}))


if __name__ == '__main__':
    main()
