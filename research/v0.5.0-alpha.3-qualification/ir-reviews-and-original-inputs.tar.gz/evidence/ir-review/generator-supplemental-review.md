# Supplemental generator identity review

Source: `b0bda81ec2b9954c3c5e0f658c051439126a5c22`; baseline: `80490143498d149d407343ba1cb7aedb1db2d2c5`.

No additional blocking finding in the reviewed generator identity paths. This is a targeted independent source/SSA review, not a second full per-line disposition or new execution evidence. The paired JSON preserves exact source/IR hashes, promise extents, identity store instructions and call-inventory differences.

## Case 1100: tests/programs/inference/dynany_identity_generator.py

- repeat, integer and objects retain their numeric binding companion for repeated yields; forward copies the inner companion to the outer scalar promise.
- The dynamic-yield wrapper keeps its original five-word promise because its yielded value is already boxed. Its scalar-to-dyn conversion uses the captured companion.
- Consumer next/default, unpacking, list/iteration and boxed-generator paths use gen_value/yield_snapshot; unpack keeps each item companion before resuming for the next item.

## Case 1101: tests/programs/inference/dynany_identity_generator_fresh.py

- fresh stores null on each fresh computed yield; no identity pointer from a previous suspension is reused as the new value.
- aliases materializes each binding companion before yield and reuses it for repeated yields. overwritten stores null for the intermediate fresh value, then restores the original binding companion.
- Every scalar producer has six promise words and writes identity at word five; consume reads the companion without changing its empty-tuple result or the printed numeric payload.

## Case 1944: tests/programs/numbers/python_int_generator_identity.py

- Global promoting-int ABI keeps its nine existing promise words and appends identity at word nine; GENVALP remains seven and GENRETP remains eight.
- The imported float generator also uses a ten-word frame under the program-wide promoting mode, so caller and imported producer agree on identity offset nine.
- wide.repeat boxes or reuses the same source numeric object for two yields; fresh has two separate wide values and null companion stores, permitting distinct first-consumer boxes.
- The dynamic-yield forward wrapper stays at nine words, with numeric-to-Any conversion checking the companion against the wide integer payload.

## Correspondence and limits

`generator_slots` appends identity after the pre-existing ABI extent. Lowering uses the same helper for frame allocation, zero initialization and identity writes. `gen_value`/`gen_words` use that offset for reads. `yield_snapshot` creates a private companion slot so a later resume cannot replace an earlier result’s companion. `gen_unpack` retains those result identities through deferred target assignment. `gen_next_value` chooses the corresponding box on both normal and default result paths.

Fresh computed values pass a null companion; existing aliases pass their box. `dyn_box` uses the private exact companion only for that same result and caches lazy boxing back into its private slot. The promoting-int path additionally validates the object’s type/payload identity before reuse.

The call-inventory changes in these three cases are confined to numeric identity boxing/reuse. Coroutine resume/suspend, cleanup, numeric operations and source-visible output call inventories do not show an additional changed call target or count. Inventory equality does not establish control-flow equivalence.

No generator-specific runtime suite, GC stress or additional Lean checks were run for this supplement. The independent accepted-IR review and the release qualification retain responsibility for their broader claims.
