from pathlib import Path
import re,json,hashlib,difflib
root=Path('/workspace/scratch/980402bc01c4/ir-audit');prev=Path('/workspace/scratch/9d370b13f051/ir-audit');out=Path('/workspace/scratch/980402bc01c4/evidence/ir-review');meta=json.loads((prev/'review-final.json').read_text());tri=json.loads((out/'accepted-ir-triage.json').read_text());pending={r['case_id']:r for r in tri['rows'] if r['classification']=='requires-semantic-review'}
rx=re.compile(r'^(@s\.\d+ = private unnamed_addr global \{i64, i64, i64, )\[(\d+) x i8\](\} \{i64 )(\d+), i64 (\d+), i64 (\d+), \[(\d+) x i8\] c"(.*)"\}, align 8$')
def dec(p):return bytes.fromhex(re.sub(r'\\([0-9A-Fa-f]{2})',lambda m:m[1],''.join(('\\'+f'{ord(c):02x}') if c!='\\' else c for c in ''))) if False else bytes(re.sub(r'\\([0-9A-Fa-f]{2})',lambda m:chr(int(m[1],16)),p),'latin1')
def adjust(text,home):
 lines=[];proofs=[]
 target='/workspace/scratch/980402bc01c4/ir-audit/head'
 for line in text.splitlines():
  if home not in line:lines.append(line);continue
  m=rx.fullmatch(line);assert m,line
  h,n1,b,l,ha,c,n2,p=m.groups();raw=dec(p);assert int(n1)==int(n2)==len(raw) and int(l)==len(raw)-1 and ha=='0' and int(c) in (0,len(raw))
  q=p.replace(home,target);n=len(dec(q));c2=n if int(c) else 0
  lines.append(f'{h}[{n} x i8]{b}{n-1}, i64 0, i64 {c2}, [{n} x i8] c"{q}"}}, align 8');proofs.append({'old_literal':p,'new_literal':q})
 return '\n'.join(lines)+'\n',proofs
rows=[]
for r in meta['cases']:
 cid=r['case_id']
 if cid not in pending or r['classification'] not in ['enum-comparison-dispatch','enum-field-layout','enum-type-layout-only']:continue
 p=root/'cases'/str(cid);v=prev/'cases'/str(cid)
 bo,bop=adjust((p/'old.ll').read_text(),'/workspace/scratch/980402bc01c4/ir-audit/base');bn,bnp=adjust((p/'new.ll').read_text(),'/workspace/scratch/980402bc01c4/ir-audit/head');po,pop=adjust((v/'old.ll').read_text(),meta['build_home_evidence']['old']);pn,pnp=adjust((v/'new.ll').read_text(),meta['build_home_evidence']['new'])
 assert bn==pn,('candidate_mismatch',cid)
 delta=list(difflib.unified_diff(bo.splitlines(),po.splitlines(),fromfile='alpha2',tofile='pre-enum-alpha3',n=1));(out/'semantic-views'/f'{cid}.pre-enum.diff').write_text('\n'.join(delta)+'\n')
 rows.append({'case_id':cid,'case':r['case'],'source_hash_matches':r['source_sha256']==pending[cid]['source_sha256'],'candidate_ir_exactly_equal_after_validated_home_literals':bn==pn,'baseline_ir_exactly_equal_after_validated_home_literals':bo==po,'pre_enum_delta_lines':len(delta),'prior_classification':r['classification'],'prior_note':r['review_note'],'prior_raw_sha256':r['ir_sha256'],'prior_raw_diff':r['raw_ir_diff'],'home_literal_validation':{'broad_old':bop,'broad_new':bnp,'prior_old':pop,'prior_new':pnp}})
(out/'prior-enum-equivalence.json').write_text(json.dumps({'method':'Exact whole retained IR equality after only validated known checkout-home string literal replacement and exact string-size recomputation; independent broader baseline delta retained where not identical. Prior review is used only for mathematically identical IR delta or for its verified matching second stage.','rows':rows},indent=2)+'\n')
print('cases',len(rows),'exact-both',sum(r['baseline_ir_exactly_equal_after_validated_home_literals'] for r in rows));print([(r['case_id'],r['pre_enum_delta_lines']) for r in rows])
