"""Bounded, explicit supplementary IR checks; never rewrites retained IR."""
import ast
from pathlib import Path
import json
import re
import difflib
import hashlib

ns = {}
exec(Path('/workspace/scratch/980402bc01c4/evidence/ir-review/semantic-views.py').read_text().split('rows=[]')[0], ns)
root, out, fn, res, can = [ns[n] for n in ['root', 'out', 'functions', 'resolver', 'canonical']]
sha = lambda s: hashlib.sha256(s.encode()).hexdigest()
inventory = {r['case_id']: r for r in json.loads((out/'semantic-inventory.json').read_text())['rows']}
result = {'method': 'Explicit symbol-reference, per-function mapping, source-AST and exact canonical body checks; no generic semantic normalization.'}

dead = []
for cid in [87,88,89,1743,1744,2674,1736,1737,1738,1739,1740,1741,2557,2558]:
    old = (root/'cases'/str(cid)/'old.ll').read_text()
    of = fn(old)
    removed = inventory[cid]['removed_functions']
    remainder = old
    for name in removed:
        remainder = remainder.replace(of[name], '')
    checks = []
    for name in removed:
        refs = re.findall('@'+re.escape(name)+r'(?![\w.$-])', remainder)
        assert not refs, (cid, name, refs)
        checks.append({'symbol': name, 'references_outside_removed_definitions': 0, 'body_sha256':sha(of[name])})
    dead.append({'case_id':cid, 'removed_functions':checks})
result['unreferenced_reflected_methods'] = dead

p = root/'cases'/'1236'
old = (p/'old.ll').read_text().replace(ns['oh'], ns['nh'])
new = (p/'new.ll').read_text()
mapping = {'m.Box-1.__radd__':'m.Box-1.__radd__.1', 'm.Box-2.__radd__':'m.Box-2.__radd__.1'}
for a,b in mapping.items():
    old = re.sub('@'+re.escape(a)+r'(?![\w.$-])', lambda m:b.join(['@','']), old)
of,nf=fn(old),fn(new)
assert set(of)==set(nf)
equal=[]
for name in sorted(of):
    a,_=can(of[name],res(old));b,_=can(nf[name],res(new))
    assert a==b, name
    equal.append(name)
result['reflected_specialization_rename']={'case_id':1236,'explicit_name_mapping':mapping,'all_function_bodies_equal_after_mapping':equal}

oldlib = Path(ns['oh'])/'lib/datetime.py'
newlib = Path(ns['nh'])/'lib/datetime.py'
a,b=oldlib.read_text(),newlib.read_text()
astold=ast.dump(ast.parse(a),include_attributes=False)
astnew=ast.dump(ast.parse(b),include_attributes=False)
assert astold==astnew
rows=[]
for cid in [1590,1594,2638]:
    p=root/'cases'/str(cid)
    assert (p/'old.ll').read_text().replace(ns['oh'],ns['nh'])==(p/'new.ll').read_text()
    rows.append(cid)
result['datetime_comment_only']={'case_ids':rows,'old_library_sha256':sha(a),'new_library_sha256':sha(b),'identical_ast_sha256':sha(astold),'full_library_diff':'\n'.join(difflib.unified_diff(a.splitlines(),b.splitlines(),fromfile=str(oldlib),tofile=str(newlib))),'whole_IR_equal_after_validated_checkout_literal':True}

new=(root/'cases'/'2369'/'new.ll').read_text()
consts=[]
for name in ['@dbi.$m9223372036854775808','@dbi.$m100']:
    refs=len(re.findall(re.escape(name)+r'(?![\w.$-])',new))
    assert refs==1,(name,refs)
    consts.append({'name':name,'references_including_definition':refs,'definition':next(l for l in new.splitlines() if l.startswith(name+' = '))})
result['unused_numeric_identity_globals']={'case_id':2369,'constants':consts}

toml=[]
for cid in [1736,1737,1738,1739,1740,1741,2557,2558]:
    pairs={}
    for side in ['old','new']:
        raw=(root/'cases'/str(cid)/(side+'.ll')).read_text().replace(ns['oh'],ns['nh'])
        rf=res(raw); fs=fn(raw)
        pairs[side]={name:sha(can(fs[name],rf,True)[0]) for name in inventory[cid]['semantic_changed_functions']}
    toml.append({'case_id':cid,'canonical_function_sha256':pairs})
reference=toml[0]['canonical_function_sha256']
for item in toml:
    item['functions_match_reference_case_1736']=all(h==reference[side][name] for side, values in item['canonical_function_sha256'].items() for name,h in values.items())
result['toml_shared_function_checks']=toml

(out/'supplementary-structural-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'dead_cases':len(dead),'reflected_rename_functions':len(equal),'datetime_cases':rows,'toml_exact_pairs':[(x['case_id'],x['functions_match_reference_case_1736']) for x in toml]},indent=2))
