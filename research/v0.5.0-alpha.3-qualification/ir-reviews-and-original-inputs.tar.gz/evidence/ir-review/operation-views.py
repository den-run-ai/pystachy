from pathlib import Path
import json,re,difflib,collections,hashlib
ns={};exec(Path('/workspace/scratch/980402bc01c4/evidence/ir-review/semantic-views.py').read_text().split('rows=[]')[0],ns)
root,out,functions,resolver=[ns[n] for n in ['root','out','functions','resolver']];rows=[]
for r in json.loads((out/'semantic-inventory.json').read_text())['rows']:
 p=root/'cases'/str(r['case_id']);old=(p/'old.ll').read_text().replace(ns['oh'],ns['nh']);new=(p/'new.ll').read_text();of,nf=functions(old),functions(new);orr,nrr=resolver(old),resolver(new)
 def shape(b,res):
  b=re.sub(r'%(?!C\.)[\w.$-]+','%VAR',b);b=re.sub(r'^[\w.$-]+:','LABEL:',b,flags=re.M);return res(b)
 view=[];func=[]
 for name in r['semantic_changed_functions']:
  a,b=shape(of[name],orr),shape(nf[name],nrr);df=list(difflib.unified_diff(a.splitlines(),b.splitlines(),fromfile='old/'+name,tofile='new/'+name,n=1));view.extend(df)
  if df:
   calls=lambda s:collections.Counter(re.findall(r'(?:call|invoke) (?:[^@\n]+)@([^ (]+)',s));ac,bc=calls(of[name]),calls(nf[name]);func.append({'name':name,'added_call_counts':dict(bc-ac),'removed_call_counts':dict(ac-bc),'shape_diff_sha256':hashlib.sha256('\n'.join(df).encode()).hexdigest(),'shape_diff_lines':len(df)})
 (out/'semantic-views'/f"{r['case_id']}.operations.diff").write_text('\n'.join(view)+'\n');rows.append({'case_id':r['case_id'],'case':r['case'],'functions':func,'view_lines':len(view)})
(out/'operation-inventory.json').write_text(json.dumps({'warning':'Viewing aid only; erased local identifiers are NOT an equivalence proof or acceptance normalization. Original retained IR and exact canonical function review remain authoritative.','rows':rows},indent=2)+'\n')
print('operation view total lines',sum(r['view_lines'] for r in rows))
