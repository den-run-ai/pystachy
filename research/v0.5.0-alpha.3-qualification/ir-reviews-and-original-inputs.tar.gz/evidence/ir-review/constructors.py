from pathlib import Path
import json,re,difflib
ns={};exec(Path('/workspace/scratch/980402bc01c4/evidence/ir-review/semantic-views.py').read_text().split('rows=[]')[0],ns)
root,out,fn,res,canon,outside=[ns[n] for n in ['root','out','functions','resolver','canonical','outside']]
ids=[160,164,166,167,168,169,1648,1650,1655,2419,2642,2643,2468];rows=[]
for cid in ids:
 p=root/'cases'/str(cid);old=(p/'old.ll').read_text().replace(ns['oh'],ns['nh']);new=(p/'new.ll').read_text();of,nf=fn(old),fn(new)
 cm={}
 for c in re.findall(r'^%C\.([^ ]+) = type ',old,re.M):
  if c.endswith('-1') and '%C.'+c[:-2]+' = type ' in new:cm[c]=c[:-2]
 def classes(s):
  for a,b in cm.items():
   s=s.replace('%C.'+a+' ', '%C.'+b+' ').replace('%C.'+a+',','%C.'+b+',').replace('!"'+a+'"','!"'+b+'"').replace('@m.'+a+'.','@m.'+b+'.')
  return s
 names={};om={}
 for name in of:
  newname=name
  for a,b in cm.items():newname=newname.replace('m.'+a+'.','m.'+b+'.')
  if newname not in nf and newname.endswith('.1') and newname[:-2] in nf:newname=newname[:-2]
  if newname!=name:names[name]=newname
 def allmaps(s):
  s=classes(s)
  for a,b in sorted(names.items(),key=lambda x:-len(x[0])):
   renamed=classes('@'+a)[1:]
   s=re.sub('@'+re.escape(renamed)+r'(?![\w.$-])',lambda m:'@'+b,s)
  return s
 old2=allmaps(old);of2=fn(old2);assert len(of2)==len(of)
 rr,ss=res(old2),res(new);equal=[];diff=[];view=[]
 for name in sorted(set(of2)&set(nf)):
  a,_=canon(of2[name],rr);b,_=canon(nf[name],ss)
  if a==b:equal.append(name)
  else:
   diff.append(name);view.extend(difflib.unified_diff(a.splitlines(),b.splitlines(),fromfile='old/'+name,tofile='new/'+name,n=1))
 assert set(of2)==set(nf),(cid,set(of2)^set(nf))
 (out/'semantic-views'/f'{cid}.constructor-remainder.diff').write_text('\n'.join(view)+'\n')
 rows.append({'case_id':cid,'class_name_mapping':cm,'function_name_mapping':names,'exact_function_equality_after_explicit_maps':equal,'remaining_changed_functions':diff,'remainder_lines':len(view)})
(out/'constructor-equivalence.json').write_text(json.dumps(rows,indent=2)+'\n');print([(r['case_id'],r['remaining_changed_functions'],r['remainder_lines']) for r in rows])
