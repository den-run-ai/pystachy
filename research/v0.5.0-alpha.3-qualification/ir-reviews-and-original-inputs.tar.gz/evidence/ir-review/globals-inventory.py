from pathlib import Path
import json,re,hashlib,collections
ns={};exec(Path('/workspace/scratch/980402bc01c4/evidence/ir-review/semantic-views.py').read_text().split('rows=[]')[0],ns)
root,out,resolve,outside=[ns[n] for n in ['root','out','resolver','outside']];rows=[]
for r in json.loads((out/'semantic-inventory.json').read_text())['rows']:
 cid=r['case_id'];p=root/'cases'/str(cid);o=(p/'old.ll').read_text().replace(ns['oh'],ns['nh']);n=(p/'new.ll').read_text();a,b=outside(o),outside(n);oa,nb=resolve(o),resolve(n)
 strings=lambda t:collections.Counter(m[1] for m in re.finditer(r'^@s\.\d+ = (.+)$',t,re.M))
 sg=lambda t,res:{l.split(' = ')[0]:res(l.split(' = ',1)[1]) for l in t.splitlines() if l.startswith('@') and not l.startswith('@s.')}
 x,y=sg(a,oa),sg(b,nb)
 changed={k:{'old':x.get(k),'new':y.get(k)} for k in set(x)|set(y) if x.get(k)!=y.get(k)}
 decl=lambda t:set(l for l in t.splitlines() if l.startswith('declare '))
 od,nd=decl(a),decl(b)
 rows.append({'case_id':cid,'new_string_definitions':list((strings(n)-strings(o)).elements()),'removed_string_definitions':list((strings(o)-strings(n)).elements()),'other_global_changes':changed,'added_declarations':sorted(nd-od),'removed_declarations':sorted(od-nd)})
(out/'globals-inventory.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:
 if r['other_global_changes'] or r['new_string_definitions'] or r['removed_string_definitions']:
  print(r['case_id'],'strings+',len(r['new_string_definitions']),'-',len(r['removed_string_definitions']),'globals',','.join(r['other_global_changes']))
