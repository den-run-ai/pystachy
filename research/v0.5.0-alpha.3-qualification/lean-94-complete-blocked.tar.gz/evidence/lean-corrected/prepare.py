"""Bind the committed adapter repair to unchanged, identified Lean executables."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys

OUT = Path(__file__).resolve().parent
REPO = OUT.parents[1] / "alpha3-lean-corrected"
EXPECTED = "94f472d6de5350fc9481ecf3b9ec019d2ecdb4f2"
TREE = "51f6c150748b2d17945e4d1c6779d8080b6edd6a"
BASE = "b0bda81ec2b9954c3c5e0f658c051439126a5c22"
ORIGIN = Path("/workspace/scratch/f0e0f1c84d2f/pystachy")
PRIOR = Path("/workspace/scratch/9d370b13f051")
REPAIR = OUT.parent / "lean/adapter-repair/frozen-repair.json"

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()

assert git(REPO, "rev-parse", "HEAD") == EXPECTED
assert git(REPO, "rev-parse", "HEAD^{tree}") == TREE
assert not git(REPO, "status", "--porcelain")
repair = json.loads(REPAIR.read_text())
assert repair["base_commit"] == BASE and repair["proposed_tree"] == TREE
repaired = {row["path"]: row for row in repair["files"]}
assert set(git(REPO, "diff", "--name-only", BASE, EXPECTED).splitlines()) == set(repaired)
for path, row in repaired.items():
    assert digest(REPO / path) == digest(row["frozen_copy"]) == row["sha256"], path

old_manifest_path = PRIOR / "enum-lean-evidence/final-checker-source-correspondence.json"
old_manifest = json.loads(old_manifest_path.read_text())
source_rows, changed = [], []
for row in old_manifest:
    path = row["path"]
    assert digest(ORIGIN / path) == row["sha256"], path
    current = digest(REPO / path)
    if current != row["sha256"]:
        assert path in {"tools/check_lean_guards.py", "tools/lean_report.py"}
        assert current == repaired[path]["sha256"]
        changed.append(path)
    source_rows.append({"path": path, "sha256": current,
                        "prior_sha256": row["sha256"],
                        "unchanged_from_binary_origin": current == row["sha256"]})
assert set(changed) == {"tools/check_lean_guards.py", "tools/lean_report.py"}
lean_sources = [row for row in source_rows if row["path"].startswith("tools/lean_boundary/")]
assert lean_sources and all(row["unchanged_from_binary_origin"] for row in lean_sources)

prior_bins = json.loads((PRIOR / "lean-checker-identity.json").read_text())["reused_executables"]
destination = REPO / "tools/lean_boundary/.lake/build/bin"
destination.mkdir(parents=True, exist_ok=True)
copied = {}
for name, row in prior_bins.items():
    source, target = Path(row["path"]), destination / name
    assert digest(source) == row["sha256"], name
    assert not target.exists(), target
    shutil.copy2(source, target)
    assert digest(target) == row["sha256"] and os.access(target, os.X_OK), name
    copied[name] = {"origin": str(source), "destination": str(target), "sha256": digest(target)}

sys.path.insert(0, str(REPO / "tools"))
import lean_report as r

paths = git(REPO, "ls-files", "--", *r.INPUTS["checkers"]).splitlines()
assert set(paths) == {row["path"] for row in source_rows}
inputs = r.inputs()
assert r.clean_inputs(inputs)
programs = r.corpus.corpus()
promoting = r.storage_corpus.select(programs)
assert len(programs) == 2699 and len(promoting) == 196
assert not git(REPO, "status", "--porcelain")
record = {
    "repo": str(REPO), "commit": EXPECTED, "tree": TREE,
    "python": platform.python_version(), "platform": sys.platform,
    "inputs": inputs, "programs": list(programs), "promoting": list(promoting),
    "expected_programs": len(programs), "expected_promoting": len(promoting),
    "checker_executables": r.checker_executables(r.boundary.DEFAULT_CHECKER, r.access.DEFAULT_CHECKER),
    "copied_executables": copied, "source_correspondence": source_rows,
    "unchanged_lean_source_count": len(lean_sources), "changed_adapter_inputs": changed,
    "origin_checkout_commit": git(ORIGIN, "rev-parse", "HEAD"),
    "origin_relevant_source_changes": git(ORIGIN, "status", "--porcelain", "--", *paths),
    "prior_identity_file": str(PRIOR / "lean-checker-identity.json"),
    "prior_identity_sha256": digest(PRIOR / "lean-checker-identity.json"),
    "prior_source_correspondence_sha256": digest(old_manifest_path),
    "frozen_repair_manifest": str(REPAIR), "frozen_repair_manifest_sha256": digest(REPAIR),
    "historical_interrupted_census": str(OUT.parent / "lean/interrupted-partial-census.json"),
    "fresh_full_records": True,
    "note": "Physical copies of identified Lean executables; every Lean package source and build configuration matches the binary origin. The two reviewed Python adapter/report changes are explicitly recorded. All 2699 programs will be inspected afresh with one worker; no records are resumed or copied.",
}
assert not record["origin_relevant_source_changes"]
(OUT / "prepared.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({key: record[key] for key in ("repo", "commit", "tree", "expected_programs", "expected_promoting", "unchanged_lean_source_count", "changed_adapter_inputs")}))
