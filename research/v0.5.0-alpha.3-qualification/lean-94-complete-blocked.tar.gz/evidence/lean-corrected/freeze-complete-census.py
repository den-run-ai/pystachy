"""Pure-data receipt for the completed, strictly blocked 94f4 census.

This script neither changes report records nor invokes a compiler or checker.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


raw = (OUT / "records.jsonl").read_bytes()
prefix = (OUT / "pre-resume-2562/records.jsonl").read_bytes()
assert raw.startswith(prefix)
rows = [json.loads(line) for line in raw.splitlines()]
old_rows = [json.loads(line) for line in prefix.splitlines()]
assert len(rows) == 2700 and len(old_rows) == 2563
assert len({r["program"] for r in rows[1:]}) == 2699
assert raw.endswith(b"\n") and prefix.endswith(b"\n")
acceptance = json.loads((OUT / "acceptance.json").read_text())
delta = json.loads((OUT / "delta-alpha2.json").read_text())
assert {k for k, v in acceptance["checks"].items() if not v} == {"strict_storage_all_accepted"}
receipt = json.loads((OUT / "run-20261115T072150Z.json").read_text())
assert (receipt["report_exit"], receipt["status_exit"], receipt["audit_exit"]) == (0, 0, 1)
assert not receipt["source_after"]
files = ["records.jsonl", "report.md", "acceptance.json", "delta-alpha2.json",
         "prepared.json", "qualification-source-equivalence.json",
         "run-20261115T061318Z.json", "run-20261115T061318Z.log",
         "run-20261115T072150Z.json", "run-20261115T072150Z.log",
         "pre-resume-2562/records.jsonl",
         "pre-resume-2562/failure-and-resume-preflight.json",
         "pre-resume-2562/source-revalidation.json", "pre-resume-2562/kill-diagnostics.json",
         "prepare.py", "run.py", "audit.py", "freeze-complete-census.py"]
summary = {
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "status": "complete_but_strict_storage_blocked",
    "commit": acceptance["commit"], "tree": acceptance["tree"],
    "programs": 2699, "strict_storage_selections": 196,
    "attempts": [
        {"receipt": "run-20261115T061318Z.json", "report_exit": -9,
         "completed_records": 2562, "kill_cause": "unknown",
         "secondary_failures": "status and audit lacked the not-yet-written final report"},
        {"receipt": "run-20261115T072150Z.json", "maintained_same_source_resume": True,
         "report_exit": 0, "status_exit": 0, "independent_audit_exit": 1,
         "appended_records": 137}],
    "prefix_preserved_byte_for_byte": True,
    "saved_prefix_bytes": len(prefix),
    "no_records_reused_from_original_b0_attempt": True,
    "acceptance_checks": acceptance["checks"],
    "storage_gaps": acceptance["storage_gaps"],
    "known_storage_counts": {
        k: acceptance["full_proof_totals"]["storage"][k]
        for k in ("functions", "obligations", "proved")},
    "known_counts_do_not_bound_unsupported_functions": True,
    "delta_summary": acceptance["delta_summary"],
    "new_residual_functions": delta["added_program_unproved"],
    "counted_gaps": {
        key: {"baseline": acceptance["baseline_proof_totals"][key]["obligations"]
                          - acceptance["baseline_proof_totals"][key]["proved"],
              "candidate": value["obligations"] - value["proved"]}
        for key, value in acceptance["full_proof_totals"].items()},
    "union_payload_listing": "The 409 added unproved payload-bit obligations belong to the same rejected closed-union functions as the 542 added union reads. The maintained report lists both under union, not as independent function rows.",
    "semantic_review_status": "pending; denominator-site attribution and final corrected-source qualification remain separate gates",
    "files": {name: identity(OUT / name) for name in files},
}
(OUT / "complete-blocked-census.json").write_text(json.dumps(summary, indent=2) + "\n")
(OUT / "owner-state.json").write_text(json.dumps({
    "phase": "complete_but_strict_storage_blocked", "owned_session": None,
    "completed_sessions": [44037, 51031], "completed_records": 2699,
    "source_commit": acceptance["commit"], "source_tree": acceptance["tree"],
    "preserved_receipt": "complete-blocked-census.json",
    "heavy_execution_owner": "/root/alpha3_publication for focused optional tuple storage repair",
    "next_steps": ["Preserve this failed strict-storage qualification unchanged.",
                   "Review all newly added residuals without granting proofs.",
                   "Wait for a sound, frozen checker repair before a fresh full census.",
                   "Keep denominator attribution pending the final checker source."]
}, indent=2) + "\n")
print(json.dumps({"status": summary["status"], "programs": 2699,
                  "prefix_preserved": True,
                  "receipt": identity(OUT / "complete-blocked-census.json")}))
