"""Read-only attribution of added complex union residuals to the conservative null domain.

Uses retained IR, census data and pure adapter domain parsing. No compiler, Lean
checker or runtime is executed, and every recorded rejection remains rejected.
"""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
REPO = ROOT / "alpha3-lean-corrected"
DEST = OUT / "added-complex-residual-review"
DEST.mkdir(exist_ok=True)
sys.path.insert(0, str(REPO / "tools"))
sys.path.insert(1, str(REPO))
import check_lean_guards as guards


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


delta = json.loads((OUT / "delta-alpha2.json").read_text())
records = {r["program"]: r for r in map(json.loads, (OUT / "records.jsonl").read_text().splitlines())
           if "program" in r}
ir_review = json.loads((ROOT / "evidence/ir-review/acceptance-diagnostic-review.json").read_text())
ir_rows = {r["case"]: r for r in ir_review["rows"]}
residuals = [r for r in delta["added_program_unproved"] if r["check"] == "union"]
notes = {
    "complex_union_none.py": "Previously reviewed main.init read uses f.widen's normal return. Its null arm raises and is unreachable thereafter; its normal arm returns a fresh box. This is an interprocedural return fact, not a caller-local null check.",
    "dynany_complex_union_identity.py": "Previously reviewed f.choose normal return is boxed and nonnull; the null arm raises. f.check transports this same pointer through a tuple; equality receives a load of that selected value. The model does not retain the required return-domain fact.",
    "complex_union_container_eq.py": "All main.init arguments to lists/dicts/search are freshly allocated union boxes. The first reads in lists/dicts/search inspect those nonoptional union arguments; the generated equality specialization receives the other boxed argument or its tuple round trip. The model admits null for the union wrapper because one member has the internal complex class spelling.",
    "complex_union_enum_eq.py": "The three calls to numbers receive fresh union boxes for int or complex values. Its first union-tag read inspects that parameter. The optional maybe helper is a separate function; its None inputs do not flow into numbers. The failure concerns the wrapper's conservative domain, before the IntEnum/IntFlag value comparisons.",
    "complex_union_identity.py": "The five calls to search receive fresh boxes from main.init. Its first failing pointer t12 is the unchanged pointer stored in and recovered from a one-element tuple containing x. The equality specialization receives a boxed search argument or its tuple round trip. The optional mixed helper is distinct and does not supply the rejected nonoptional specialization.",
    "complex_union_nested.py": "Both calls to show pass fresh union boxes, one for a complex instance and one for a list of complex instances. Its first failing tag load reads the same incoming wrapper after repr/list-print preparation. The descriptor distinguishes wrapper tags from nested container payloads; the conservative internal complex member adds null to the wrapper domain.",
    "complex_union_object_eq.py": "Both calls to numbers pass fresh int/complex union boxes. Its first tag read dispatches the v argument before foreign reflected equality. The optional helper accepts None separately; no None input is passed to numbers in this fixture.",
    "complex_union_tuple_search.py": "Every normal return of pick and fpick comes from pys_ubox, including both branches of each function. main.init stores the return in globals, round-trips it through a tuple, and then reads the tag. The rejected equality specializations receive the same boxed values. The adapter retains a nullable declared return domain despite these normal-return bodies.",
    "complex_unions.py": "The initial vals list contains six fresh union boxes. main.init's first failing pointer t46 is a reload of the current list element after describe/repr; describe does not replace that global. describe's parameter, fold's two value parameters, and numeric's parameters all originate from nonoptional boxed members at their recorded call sites. The two rejected equality specializations receive numeric's boxed arguments. Optional fold results and later optional iteration use separate null-sensitive paths; they do not establish a local guard at these first rejected sites.",
}
function_notes = {
    (2573, "@main.init"): "t3 is the normal return of f.widen. The null input arm raises and terminates; its normal return is a fresh box. This is a return-contract fact, not a caller-local guard.",
    (1022, "@f.check"): "t119 is a tuple round trip of selected, which stores f.choose's normal boxed return. The rejected site needs that interprocedural nonnull return and stored-pointer preservation fact.",
    (1824, "@f.lists"): "First tag read of input a0; main.init's three calls pass fresh boxes.",
    (1824, "@f.dicts"): "First tag read of input a0; main.init's two calls pass fresh boxes.",
    (1824, "@f.search"): "First tag read of input a0; main.init's four calls pass fresh boxes.",
    (1825, "@f.numbers"): "First tag read of input a0; three fresh-box calls, separately from optional maybe.",
    (1826, "@f.search"): "t12 is the pointer-to-integer-to-pointer round trip of x through a one-element tuple.",
    (1827, "@f.show"): "First failing tag read consumes the incoming nonoptional wrapper after representation formatting.",
    (1829, "@f.numbers"): "First tag read of input a0; int and complex call arguments are fresh boxes.",
    (1833, "@main.init"): "t20 is a tuple round trip of g.u, populated by the normal return of pick; all pick/fpick return arms box.",
    (1834, "@main.init"): "t46 reloads g.v, assigned from vals; the initial six list elements are fresh union boxes.",
    (1834, "@f.describe"): "First tag read of input a0, the current boxed vals element.",
    (1834, "@f.fold"): "First tag read of input a1, the nonoptional left argument; optional return is a distinct domain.",
    (1834, "@f.numeric"): "First tag read of input a0; all five numeric call sites pass fresh boxes.",
}
programs = []
for program in sorted({r["program"] for r in residuals}):
    rows = [r for r in residuals if r["program"] == program]
    case = ir_rows[program]
    case_id = case["index"]
    ir_path = ROOT / "ir-audit/cases" / str(case_id) / "new.ll"
    assert identity(ir_path)["sha256"] == case["evidence"]["new.ll"]["sha256"]
    source = REPO / program
    assert identity(source)["sha256"] == case["source"]["sha256"]
    ir = ir_path.read_text()
    functions = {m.group(1): m.group(0) for m in re.finditer(
        r"^define[^\n]*@([^ (]+)\([^\n]*\)[^\n]*\{\n.*?^\}", ir, re.M | re.S)}
    selected = {r["function"][1:] for r in rows} | {"main.init"}
    if case_id == 1833:
        selected |= {"f.pick", "f.fpick"}
    for symbol in tuple(selected):
        pattern = re.compile(r"\b(?:call|invoke)\b[^\n]*@" + re.escape(symbol) + r"\(")
        selected.update(fn for fn, body in functions.items() if pattern.search(body))
    assert selected <= functions.keys()
    excerpt = DEST / f"case-{case_id}-functions.ll"
    excerpt.write_text("\n\n".join(functions[fn] for fn in functions if fn in selected) + "\n")
    details = []
    for row in rows:
        expected_text, known = row["reason"].split(" needs ", 1)[1].split(" in ", 1)[1].split("; known: ", 1)
        expected = ast.literal_eval(expected_text)
        representation = "union[" + ",".join(tag.removeprefix("member:") for tag in expected) + "]"
        domain = guards.union_members(representation)
        assert domain == sorted(expected + ["null"])
        # The maintained report deliberately truncates diagnostic text. Validate
        # its actual retained prefix, never present reconstructed text as raw output.
        assert str(domain).startswith(known)
        assert (case_id, row["function"]) in function_notes or ".__eq__." in row["function"]
        detail = dict(row)
        detail.update({"reconstructed_declared_representation": representation,
                       "required_members_from_recorded_diagnostic": expected,
                       "adapter_domain_reconstruction": domain,
                       "recorded_known_text_matches_domain_prefix": True,
                       "recorded_diagnostic_may_be_truncated": not known.endswith("]"),
                       "retained_ir_function": row["function"],
                       "first_site_attribution": function_notes.get((case_id, row["function"]),
                           "Generated complex equality reads its second union argument's tag; the retained caller bodies forward a boxed argument or its tuple transport."),
                       "verdict_unchanged": "rejected"})
        details.append(detail)
    union = records[program]["checks"]["union"]
    payload = records[program]["checks"]["union_payload"]
    assert sum(r["obligations"] for r in rows) == union["obligations"] - union["proved"]
    programs.append({
        "program": program, "case": case_id, "source": identity(source),
        "oracle": identity(source.with_suffix(".out")) if source.with_suffix(".out").exists() else None,
        "full_retained_ir": identity(ir_path), "function_excerpts": identity(excerpt),
        "snapshot_sha256": records[program]["snapshot_sha256"],
        "rejected_union_reads": union["obligations"] - union["proved"],
        "unproved_payload_bits": payload["obligations"] - payload["proved"],
        "first_failure_disposition": notes[source.name],
        "functions": details,
    })

guards_lines = (REPO / "tools/check_lean_guards.py").read_text().splitlines()
report_lines = (REPO / "tools/lean_report.py").read_text().splitlines()
(DEST / "domain-and-counter-excerpts.py").write_text(
    "# check_lean_guards.py: the exact conservative domain parser\n" +
    "\n".join(guards_lines[31:70]) +
    "\n\n# check_lean_guards.py: common closed-union verdict counters\n" +
    "\n".join(guards_lines[2179:2189]) +
    "\n\n# lean_report.py: the shared function listing and separate payload counter\n" +
    "\n".join(report_lines[66:70]) + "\n" + "\n".join(report_lines[384:401]) + "\n")
result = {
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "status": "reviewed_first_failures_as_conservative_model_limits_all_verdicts_unchanged",
    "proof_commit": "94f472d6de5350fc9481ecf3b9ec019d2ecdb4f2",
    "proof_tree": "51f6c150748b2d17945e4d1c6779d8080b6edd6a",
    "ir_commit": "b0bda81ec2b9954c3c5e0f658c051439126a5c22",
    "programs": programs,
    "totals": {"programs": len(programs), "rejected_functions": len(residuals),
               "rejected_union_reads": sum(p["rejected_union_reads"] for p in programs),
               "unproved_payload_bits": sum(p["unproved_payload_bits"] for p in programs)},
    "findings": [
        "All 21 first retained diagnostics require the declared members without null; every retained known-domain text exactly matches a prefix of those members plus null.",
        "The adapter recognizes public complex as a nonnullable value representation but conservatively treats internal _pystachy_complex$complex as nullable. The reviewed reads concern a boxed closed-union wrapper; do not confuse wrapper nullability with the complex payload's separately guarded nullability.",
        "The exact callers, transports and normal-return constructors are retained. Several guarantees are interprocedural or require stored-pointer preservation; no caller-local dominating guard is claimed where none exists.",
        "The maintained guard checker charges payload obligations to the same closed-union function verdict, while lean_report deliberately lists those functions once under union. The 409 payload obligations remain unproved alongside 542 union reads.",
    ],
    "limits": [
        "This review explains the first failure per rejected function. It does not independently prove all later obligations in those functions.",
        "All 542 union reads and 409 payload obligations stay unproved; native fixture passes are runtime oracle evidence, not Lean proofs.",
        "Reconstructed complete domains are identified as reconstructions; the exact possibly truncated census diagnostic is retained separately.",
        "This read-only review executes no compiler, Lean checker or runtime, and changes no source, acceptance rule or census record.",
    ],
    "evidence": {name: identity(path) for name, path in {
        "records": OUT / "records.jsonl", "delta": OUT / "delta-alpha2.json",
        "guard_adapter": REPO / "tools/check_lean_guards.py",
        "report_adapter": REPO / "tools/lean_report.py",
        "source_equivalence": ROOT / "evidence/lean/adapter-repair/source-equivalence-b0-to-94f4.json",
        "runtime_box_contract": ROOT / "evidence/lean/complex-null-independent-review/runtime-box-contract.c",
        "native_coverage": ROOT / "evidence/ci/b0-native-coverage/all-residual-coverage.json",
        "prior_complex_none_review": ROOT / "evidence/lean/complex-null-independent-review/review.json",
        "prior_complex_identity_review": ROOT / "evidence/lean/complex-identity-independent-review/review.json",
        "counter_and_domain_excerpts": DEST / "domain-and-counter-excerpts.py",
        "review_script": Path(__file__),
    }.items()},
}
assert result["totals"] == {"programs": 9, "rejected_functions": 21,
                            "rejected_union_reads": 542, "unproved_payload_bits": 409}
(DEST / "review.json").write_text(json.dumps(result, indent=2) + "\n")
lines = ["# Added complex union residuals", "",
         "The completed 94f4 census adds **542 rejected union reads and 409 unproved payload-bit obligations in 21 functions across nine new fixtures**. Every verdict remains rejected. The maintained report lists the functions once under union because both counters use the same closed-union function result.", "",
         "Every retained first diagnostic requires the declared member set without null. Its recorded known-domain text matches those same members plus null. The adapter recognizes the public spelling `complex` as a nonnullable value representation, but the internal spelling `_pystachy_complex$complex` conservatively adds null. This concerns the union wrapper, distinct from a complex payload that the emitted code may separately check for null.", "",
         "| Fixture | Rejected functions | Union reads unproved | Payload bits unproved |",
         "|---|---:|---:|---:|"]
for p in programs:
    lines.append(f"| `{Path(p['program']).name}` | {len(p['functions'])} | {p['rejected_union_reads']} | {p['unproved_payload_bits']} |")
lines.extend(["", "## Source and emitted-IR disposition", ""])
for p in programs:
    lines.extend([f"### {Path(p['program']).name}", "", p["first_failure_disposition"], ""])
lines.extend(["## Evidence and limits", "",
              "`review.json` binds every source/oracle and raw LLVM hash, the exact residual row and first-site domain reconstruction, complete relevant emitted functions, the adapter/report source hashes, and the compiler/runtime source-equivalence receipt. Separate native CI evidence establishes successful recorded-oracle JIT and AOT executions of these fixtures. The complex-null deviation uses its handwritten TypeError oracle; that case is not a CPython parity claim.", "",
              "The retained runtime contract shows `pys_ubox` allocates through the nonnull allocator on normal return. The review traces the needed normal-return and pointer-transport facts in each fixture; it does not assert a local guard where the code depends on an interprocedural contract.", "",
              "Only each function's first reported failure is explained here. Neither this source/IR review nor the runtime passes discharge its later Lean obligations. The full 542 union reads and 409 payload obligations remain unproved. No compiler, Lean checker or runtime was executed for this review.", ""])
(DEST / "review.md").write_text("\n".join(lines))
print(json.dumps({"review": identity(DEST / "review.json"), "totals": result["totals"]}))
