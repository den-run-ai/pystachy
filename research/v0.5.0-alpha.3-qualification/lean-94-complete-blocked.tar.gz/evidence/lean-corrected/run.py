"""Run the frozen full census; only resume with the maintained identity checks."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
prepared = json.loads((OUT / "prepared.json").read_text())
REPO = Path(prepared["repo"])
PY = Path("/workspace/scratch/c2b093657c17/dev-venv/bin/python")
LLVM = Path("/workspace/scratch/c2b093657c17/toolchains/llvm18/payload/usr/lib/llvm-18")
LEAN = Path("/workspace/scratch/c2b093657c17/toolchains/lean-4.35.0-linux/bin")
resume = "--resume" in sys.argv[1:]
records = OUT / "records.jsonl"
report = OUT / "report.md"
env = {key: value for key, value in os.environ.items()
       if not key.startswith("PYSTACHY_") and key not in ("PYTHONPATH", "PYTHONOPTIMIZE")}
env.update(PATH=":".join([str(PY.parent), str(LLVM / "bin"), str(LEAN), "/usr/local/bin", "/usr/bin", "/bin"]),
           PYSTACHY_LLVM=str(LLVM / "bin"), LD_LIBRARY_PATH=str(LLVM / "lib"),
           PYTHON=str(PY), PYSTACHY_JOBS="1")

def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args], text=True).strip()

assert git("rev-parse", "HEAD") == prepared["commit"]
assert git("rev-parse", "HEAD^{tree}") == prepared["tree"]
assert not git("status", "--porcelain")
assert records.exists() if resume else not records.exists()
command = [str(PY), "tools/lean_report.py", "--jobs", "1", "--start-method", "spawn", "--timeout", "300",
           "--progress", "--output", str(report), "--records", str(records)]
if resume:
    command.append("--resume")
receipt = {"started_utc": datetime.now(timezone.utc).isoformat(), "commit": prepared["commit"],
           "tree": prepared["tree"], "command": command, "resume": resume, "cwd": str(REPO),
           "source_before": git("status", "--porcelain"), "jobs": 1}
stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
receipt_path = OUT / ("run-" + stamp + ".json")
log = OUT / ("run-" + stamp + ".log")
receipt["log"] = str(log)
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt), flush=True)
started = time.monotonic()
with log.open("x") as stream:
    result = subprocess.run(command, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT)
    receipt["report_exit"] = result.returncode
    status = subprocess.run([str(PY), "tools/lean_report.py", "--status", "--output", str(report)],
                            cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT)
    receipt["status_exit"] = status.returncode
    audit = subprocess.run([str(PY), str(OUT / "audit.py")], cwd=REPO, env=env,
                           stdout=stream, stderr=subprocess.STDOUT)
    receipt["audit_exit"] = audit.returncode
receipt.update(seconds=round(time.monotonic() - started, 3),
               child_peak_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
               commit_after=git("rev-parse", "HEAD"), tree_after=git("rev-parse", "HEAD^{tree}"),
               source_after=git("status", "--porcelain"))
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt), flush=True)
raise SystemExit(0 if receipt.get("report_exit") == receipt.get("status_exit") == receipt.get("audit_exit") == 0 else 1)
