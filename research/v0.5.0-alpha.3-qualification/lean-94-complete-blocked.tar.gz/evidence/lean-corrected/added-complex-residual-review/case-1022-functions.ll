define internal void @main.init() {
entry:
  store i1 true, ptr @g.Any.imp
  store i1 true, ptr @g.Iterator.imp
  %t2 = sitofp i64 1 to double
  %t3 = sitofp i64 2 to double
  %t4 = call ptr @f._pystachy_complex$_two(double %t2, double 0.0, i1 false, double %t3, double 0.0, i1 false, ptr null, ptr null, ptr null, ptr null)
  call void @f.check(ptr %t4)
  %t5 = call double @pys_float_str(ptr @s.0)
  %t6 = sitofp i64 0 to double
  %t7 = call ptr @f._pystachy_complex$_two(double %t5, double 0.0, i1 false, double %t6, double 0.0, i1 false, ptr null, ptr null, ptr null, ptr null)
  call void @f.check(ptr %t7)
  ret void
}

define internal i1 @m._pystachy_complex$complex.__eq__.1(ptr nonnull %a0, ptr %a1) {
entry:
  %self.2 = alloca ptr
  store ptr zeroinitializer, ptr %self.2
  %other.3 = alloca ptr
  store ptr zeroinitializer, ptr %other.3
  store ptr %a0, ptr %self.2
  store ptr %a1, ptr %other.3
  %t4 = load ptr, ptr %other.3
  %t5 = load i64, ptr %t4
  %t6 = icmp eq i64 %t5, 1
  br i1 %t6, label %L7, label %L8
L7:
  %t10 = load ptr, ptr %self.2
  %t11 = getelementptr %C._pystachy_complex$complex, ptr %t10, i32 0, i32 0
  %t12 = getelementptr %C._pystachy_complex$complex, ptr %t10, i32 0, i32 2
  %t13 = load double, ptr %t11, !tbaa !16
  %t14 = load ptr, ptr %t12, !tbaa !17
  %t15 = call ptr @pys_dyn_float_box(double %t13, ptr %t14)
  store ptr %t15, ptr %t12, !tbaa !17
  %t16 = load ptr, ptr %other.3
  %t19 = icmp eq ptr %t16, null
  br i1 %t19, label %L18, label %L17
L17:
  %t20 = getelementptr i64, ptr %t16, i64 1
  %t21 = load i64, ptr %t20
  %t22 = inttoptr i64 %t21 to ptr
  br label %L18
L18:
  %t23 = phi ptr [null, %L7], [%t22, %L17]
  %t24 = icmp eq ptr %t23, null
  br i1 %t24, label %L25, label %L26
L26:
  %t27 = getelementptr %C._pystachy_complex$complex, ptr %t23, i32 0, i32 0
  %t28 = getelementptr %C._pystachy_complex$complex, ptr %t23, i32 0, i32 2
  %t29 = load double, ptr %t27, !tbaa !16
  %t30 = load ptr, ptr %t28, !tbaa !17
  %t31 = call ptr @pys_dyn_float_box(double %t29, ptr %t30)
  store ptr %t31, ptr %t28, !tbaa !17
  %t32 = fcmp oeq double %t13, %t29
  br i1 %t32, label %L33, label %L34
L33:
  %t35 = load ptr, ptr %self.2
  %t36 = getelementptr %C._pystachy_complex$complex, ptr %t35, i32 0, i32 1
  %t37 = getelementptr %C._pystachy_complex$complex, ptr %t35, i32 0, i32 3
  %t38 = load double, ptr %t36, !tbaa !18
  %t39 = load ptr, ptr %t37, !tbaa !19
  %t40 = call ptr @pys_dyn_float_box(double %t38, ptr %t39)
  store ptr %t40, ptr %t37, !tbaa !19
  %t41 = load ptr, ptr %other.3
  %t44 = icmp eq ptr %t41, null
  br i1 %t44, label %L43, label %L42
L42:
  %t45 = getelementptr i64, ptr %t41, i64 1
  %t46 = load i64, ptr %t45
  %t47 = inttoptr i64 %t46 to ptr
  br label %L43
L43:
  %t48 = phi ptr [null, %L33], [%t47, %L42]
  %t49 = icmp eq ptr %t48, null
  br i1 %t49, label %L50, label %L51
L51:
  %t52 = getelementptr %C._pystachy_complex$complex, ptr %t48, i32 0, i32 1
  %t53 = getelementptr %C._pystachy_complex$complex, ptr %t48, i32 0, i32 3
  %t54 = load double, ptr %t52, !tbaa !18
  %t55 = load ptr, ptr %t53, !tbaa !19
  %t56 = call ptr @pys_dyn_float_box(double %t54, ptr %t55)
  store ptr %t56, ptr %t53, !tbaa !19
  %t57 = fcmp oeq double %t38, %t54
  br label %L34
L34:
  %t58 = phi i1 [%t32, %L26], [%t57, %L51]
  ret i1 %t58
L8:
  br label %L9
L9:
  %t59 = load ptr, ptr %self.2
  %t60 = getelementptr %C._pystachy_complex$complex, ptr %t59, i32 0, i32 1
  %t61 = getelementptr %C._pystachy_complex$complex, ptr %t59, i32 0, i32 3
  %t62 = load double, ptr %t60, !tbaa !18
  %t63 = fcmp oeq double %t62, 0.0
  br i1 %t63, label %L64, label %L65
L64:
  %t66 = load ptr, ptr %self.2
  %t67 = getelementptr %C._pystachy_complex$complex, ptr %t66, i32 0, i32 0
  %t68 = getelementptr %C._pystachy_complex$complex, ptr %t66, i32 0, i32 2
  %t69 = load double, ptr %t67, !tbaa !16
  %t70 = load ptr, ptr %t68, !tbaa !17
  %t71 = call ptr @pys_dyn_float_box(double %t69, ptr %t70)
  store ptr %t71, ptr %t68, !tbaa !17
  %t72 = load ptr, ptr %other.3
  %t73 = getelementptr i64, ptr %t72, i64 1
  %t74 = load i64, ptr %t73
  %t75 = call i64 @pys_cmp_if(i64 %t74, double %t69)
  %t76 = icmp eq i64 %t75, 2
  %t77 = sub i64 0, %t75
  %t78 = select i1 %t76, i64 2, i64 %t77
  %t79 = icmp eq i64 %t78, 0
  br label %L65
L65:
  %t80 = phi i1 [%t63, %L9], [%t79, %L64]
  ret i1 %t80
L25:
  call void @pys_raise(ptr @s.12, ptr @s.11)
  unreachable
L50:
  call void @pys_raise(ptr @s.12, ptr @s.13)
  unreachable
}

define internal void @f.check(ptr %a0) {
entry:
  %value.2 = alloca ptr
  store ptr zeroinitializer, ptr %value.2
  %selected.5 = alloca ptr
  store ptr zeroinitializer, ptr %selected.5
  %boxed.6 = alloca ptr
  store ptr zeroinitializer, ptr %boxed.6
  %restored.24 = alloca ptr
  store ptr zeroinitializer, ptr %restored.24
  %again.28 = alloca ptr
  store ptr zeroinitializer, ptr %again.28
  %items.82 = alloca ptr
  store ptr zeroinitializer, ptr %items.82
  %h.188 = alloca i64
  store i64 zeroinitializer, ptr %h.188
  %maybe.293 = alloca ptr
  store ptr zeroinitializer, ptr %maybe.293
  %values.323 = alloca ptr
  store ptr zeroinitializer, ptr %values.323
  %first.324 = alloca ptr
  store ptr zeroinitializer, ptr %first.324
  %second.344 = alloca ptr
  store ptr zeroinitializer, ptr %second.344
  %dynamic.411 = alloca ptr
  store ptr zeroinitializer, ptr %dynamic.411
  %t1 = call i64 @pys.recursion.enter()
  %t465 = sub i64 %t1, 1
  store ptr %a0, ptr %value.2
  %t3 = load ptr, ptr %value.2
  %t4 = call ptr @f.choose(ptr %t3)
  store ptr %t4, ptr %selected.5
  %t7 = load ptr, ptr %selected.5
  %t10 = icmp eq ptr %t7, null
  br i1 %t10, label %L8, label %L9
L9:
  %t13 = load i64, ptr %t7
  %t14 = icmp eq i64 %t13, 1
  br i1 %t14, label %L11, label %L12
L11:
  %t15 = getelementptr i64, ptr %t7, i64 1
  %t16 = load i64, ptr %t15
  %t17 = inttoptr i64 %t16 to ptr
  %t18 = call ptr @pys_dyn_ref(ptr @dt._pystachy_complex$complex, ptr %t17)
  br label %L8
L12:
  br label %L19
L19:
  %t20 = getelementptr i64, ptr %t7, i64 1
  %t21 = load i64, ptr %t20
  %t22 = call ptr @pys_dyn_int(i64 %t21)
  br label %L8
L8:
  %t23 = phi ptr [@pys_dyn_none_box, %entry], [%t18, %L11], [%t22, %L19]
  store ptr %t23, ptr %boxed.6
  %t25 = load ptr, ptr %boxed.6
  %t26 = call i64 @pys_dyn_unbox(ptr %t25, ptr @dt._pystachy_complex$complex)
  %t27 = inttoptr i64 %t26 to ptr
  store ptr %t27, ptr %restored.24
  %t29 = load ptr, ptr %restored.24
  %t30 = call ptr @pys_dyn_ref(ptr @dt._pystachy_complex$complex, ptr %t29)
  store ptr %t30, ptr %again.28
  %t31 = load ptr, ptr %boxed.6
  %t32 = load ptr, ptr %value.2
  %t33 = call ptr @pys_dyn_ref(ptr @dt._pystachy_complex$complex, ptr %t32)
  %t34 = load ptr, ptr %t31
  %t35 = icmp eq ptr %t31, %t33
  %t36 = load ptr, ptr %t33
  %t37 = icmp eq ptr %t34, %t36
  %t38 = getelementptr i64, ptr %t31, i64 1
  %t39 = load i64, ptr %t38
  %t40 = getelementptr i64, ptr %t33, i64 1
  %t41 = load i64, ptr %t40
  %t42 = icmp eq i64 %t39, %t41
  %t43 = icmp ne ptr %t34, @pys_dyntype_float
  %t44 = icmp ne ptr %t34, @pys_dyntype_int
  %t45 = getelementptr i64, ptr %t34, i64 5
  %t46 = load i64, ptr %t45
  %t47 = and i64 %t46, 8
  %t48 = icmp eq i64 %t47, 0
  %t49 = and i1 %t43, %t44
  %t50 = and i1 %t49, %t48
  %t51 = and i1 %t42, %t50
  %t52 = and i1 %t37, %t51
  %t53 = or i1 %t35, %t52
  %t54 = load ptr, ptr %restored.24
  %t55 = load ptr, ptr %value.2
  %t56 = icmp eq ptr %t54, %t55
  %t57 = load ptr, ptr %again.28
  %t58 = load ptr, ptr %boxed.6
  %t59 = load ptr, ptr %t57
  %t60 = icmp eq ptr %t57, %t58
  %t61 = load ptr, ptr %t58
  %t62 = icmp eq ptr %t59, %t61
  %t63 = getelementptr i64, ptr %t57, i64 1
  %t64 = load i64, ptr %t63
  %t65 = getelementptr i64, ptr %t58, i64 1
  %t66 = load i64, ptr %t65
  %t67 = icmp eq i64 %t64, %t66
  %t68 = icmp ne ptr %t59, @pys_dyntype_float
  %t69 = icmp ne ptr %t59, @pys_dyntype_int
  %t70 = getelementptr i64, ptr %t59, i64 5
  %t71 = load i64, ptr %t70
  %t72 = and i64 %t71, 8
  %t73 = icmp eq i64 %t72, 0
  %t74 = and i1 %t68, %t69
  %t75 = and i1 %t74, %t73
  %t76 = and i1 %t67, %t75
  %t77 = and i1 %t62, %t76
  %t78 = or i1 %t60, %t77
  call void @pys_write(ptr @s.7, i64 1)
  call void @pys_write(ptr @s.5, i64 1)
  %t79 = select i1 %t53, ptr @s.8, ptr @s.9
  call void @pys_write(ptr %t79, i64 1)
  call void @pys_write(ptr @s.5, i64 1)
  %t80 = select i1 %t56, ptr @s.8, ptr @s.9
  call void @pys_write(ptr %t80, i64 1)
  call void @pys_write(ptr @s.5, i64 1)
  %t81 = select i1 %t78, ptr @s.8, ptr @s.9
  call void @pys_write(ptr %t81, i64 1)
  call void @pys_write(ptr @s.6, i64 1)
  %t83 = load ptr, ptr %selected.5
  %t86 = icmp eq ptr %t83, null
  br i1 %t86, label %L84, label %L85
L85:
  %t89 = load i64, ptr %t83
  %t90 = icmp eq i64 %t89, 1
  br i1 %t90, label %L87, label %L88
L87:
  %t91 = getelementptr i64, ptr %t83, i64 1
  %t92 = load i64, ptr %t91
  %t93 = inttoptr i64 %t92 to ptr
  %t94 = call ptr @pys_dyn_ref(ptr @dt._pystachy_complex$complex, ptr %t93)
  br label %L84
L88:
  br label %L95
L95:
  %t96 = getelementptr i64, ptr %t83, i64 1
  %t97 = load i64, ptr %t96
  %t98 = call ptr @pys_dyn_int(i64 %t97)
  br label %L84
L84:
  %t99 = phi ptr [@pys_dyn_none_box, %L8], [%t94, %L87], [%t98, %L95]
  %t100 = call ptr @pys_alloc(i64 8)
  %t101 = ptrtoint ptr %t99 to i64
  %t102 = getelementptr i64, ptr %t100, i64 0
  store i64 %t101, ptr %t102
  %t103 = getelementptr i64, ptr %t100, i64 0
  %t104 = load i64, ptr %t103
  %t105 = inttoptr i64 %t104 to ptr
  %t106 = call ptr @pys_alloc(i64 8)
  %t107 = ptrtoint ptr %t105 to i64
  %t108 = getelementptr i64, ptr %t106, i64 0
  store i64 %t107, ptr %t108
  %t109 = call ptr @pys_vtuple_from(ptr %t106, i64 1)
  %t110 = call ptr @pys_dyn_ref(ptr @pys_dyntype_tuple, ptr %t109)
  store ptr %t110, ptr %items.82
  %t111 = load ptr, ptr %selected.5
  %t112 = load ptr, ptr %selected.5
  %t113 = call ptr @pys_alloc(i64 8)
  %t114 = ptrtoint ptr %t112 to i64
  %t115 = getelementptr i64, ptr %t113, i64 0
  store i64 %t114, ptr %t115
  %t117 = getelementptr i64, ptr %t113, i64 0
  %t118 = load i64, ptr %t117
  %t119 = inttoptr i64 %t118 to ptr
  %t120 = load i64, ptr %t119
  %t121 = icmp eq i64 %t120, 1
  %t122 = load i64, ptr %t111
  %t123 = icmp eq i64 %t122, 1
  %t124 = and i1 %t121, %t123
  br i1 %t124, label %L125, label %L126
L125:
  %t127 = getelementptr i64, ptr %t119, i64 1
  %t128 = load i64, ptr %t127
  %t129 = inttoptr i64 %t128 to ptr
  %t130 = getelementptr i64, ptr %t111, i64 1
  %t131 = load i64, ptr %t130
  %t132 = inttoptr i64 %t131 to ptr
  %t133 = icmp eq ptr %t129, %t132
  br i1 %t133, label %L116, label %L126
L126:
  %t137 = load i64, ptr %t119
  %t138 = icmp eq i64 %t137, 1
  br i1 %t138, label %L135, label %L136
L135:
  %t139 = getelementptr i64, ptr %t119, i64 1
  %t140 = load i64, ptr %t139
  %t141 = inttoptr i64 %t140 to ptr
  %t145 = icmp eq ptr %t141, null
  br i1 %t145, label %L142, label %L143
L142:
  br label %L144
L143:
  %t146 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t141, ptr %t111)
  br label %L144
L144:
  %t147 = phi i1 [false, %L142], [%t146, %L143]
  br label %L134
L136:
  br label %L148
L148:
  %t149 = getelementptr i64, ptr %t119, i64 1
  %t150 = load i64, ptr %t149
  %t154 = load i64, ptr %t111
  %t155 = icmp eq i64 %t154, 1
  br i1 %t155, label %L152, label %L153
L152:
  %t156 = getelementptr i64, ptr %t111, i64 1
  %t157 = load i64, ptr %t156
  %t158 = inttoptr i64 %t157 to ptr
  %t159 = icmp eq ptr %t158, null
  br i1 %t159, label %L160, label %L161
L160:
  br label %L162
L161:
  %t163 = getelementptr %C._pystachy_complex$complex, ptr %t158, i32 0, i32 0
  %t164 = load double, ptr %t163
  %t165 = getelementptr %C._pystachy_complex$complex, ptr %t158, i32 0, i32 1
  %t166 = load double, ptr %t165
  %t167 = fcmp oeq double %t166, 0.0
  %t168 = call i64 @pys_cmp_if(i64 %t150, double %t164)
  %t169 = icmp eq i64 %t168, 2
  %t170 = sub i64 0, %t168
  %t171 = select i1 %t169, i64 2, i64 %t170
  %t172 = icmp eq i64 %t171, 0
  %t173 = and i1 %t167, %t172
  br label %L162
L162:
  %t174 = phi i1 [false, %L160], [%t173, %L161]
  br label %L151
L153:
  br label %L175
L175:
  %t176 = getelementptr i64, ptr %t111, i64 1
  %t177 = load i64, ptr %t176
  %t178 = icmp eq i64 %t150, %t177
  br label %L151
L151:
  %t179 = phi i1 [%t174, %L162], [%t178, %L175]
  br label %L134
L134:
  %t180 = phi i1 [%t147, %L144], [%t179, %L151]
  br i1 %t180, label %L116, label %L181
L181:
  br label %L116
L116:
  %t182 = phi i1 [true, %L125], [true, %L134], [false, %L181]
  %t183 = load ptr, ptr %selected.5
  %t184 = call ptr @pys_alloc(i64 8)
  %t185 = ptrtoint ptr %t183 to i64
  %t186 = getelementptr i64, ptr %t184, i64 0
  store i64 %t185, ptr %t186
  %t187 = load ptr, ptr %selected.5
  store i64 0, ptr %h.188
  %t190 = getelementptr i64, ptr %t184, i64 0
  %t191 = load i64, ptr %t190
  %t192 = inttoptr i64 %t191 to ptr
  %t193 = load i64, ptr %t192
  %t194 = icmp eq i64 %t193, 1
  %t195 = load i64, ptr %t187
  %t196 = icmp eq i64 %t195, 1
  %t197 = and i1 %t194, %t196
  br i1 %t197, label %L198, label %L199
L198:
  %t200 = getelementptr i64, ptr %t192, i64 1
  %t201 = load i64, ptr %t200
  %t202 = inttoptr i64 %t201 to ptr
  %t203 = getelementptr i64, ptr %t187, i64 1
  %t204 = load i64, ptr %t203
  %t205 = inttoptr i64 %t204 to ptr
  %t206 = icmp eq ptr %t202, %t205
  br i1 %t206, label %L189, label %L199
L199:
  %t210 = load i64, ptr %t192
  %t211 = icmp eq i64 %t210, 1
  br i1 %t211, label %L208, label %L209
L208:
  %t212 = getelementptr i64, ptr %t192, i64 1
  %t213 = load i64, ptr %t212
  %t214 = inttoptr i64 %t213 to ptr
  %t218 = icmp eq ptr %t214, null
  br i1 %t218, label %L215, label %L216
L215:
  br label %L217
L216:
  %t219 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t214, ptr %t187)
  br label %L217
L217:
  %t220 = phi i1 [false, %L215], [%t219, %L216]
  br label %L207
L209:
  br label %L221
L221:
  %t222 = getelementptr i64, ptr %t192, i64 1
  %t223 = load i64, ptr %t222
  %t227 = load i64, ptr %t187
  %t228 = icmp eq i64 %t227, 1
  br i1 %t228, label %L225, label %L226
L225:
  %t229 = getelementptr i64, ptr %t187, i64 1
  %t230 = load i64, ptr %t229
  %t231 = inttoptr i64 %t230 to ptr
  %t232 = icmp eq ptr %t231, null
  br i1 %t232, label %L233, label %L234
L233:
  br label %L235
L234:
  %t236 = getelementptr %C._pystachy_complex$complex, ptr %t231, i32 0, i32 0
  %t237 = load double, ptr %t236
  %t238 = getelementptr %C._pystachy_complex$complex, ptr %t231, i32 0, i32 1
  %t239 = load double, ptr %t238
  %t240 = fcmp oeq double %t239, 0.0
  %t241 = call i64 @pys_cmp_if(i64 %t223, double %t237)
  %t242 = icmp eq i64 %t241, 2
  %t243 = sub i64 0, %t241
  %t244 = select i1 %t242, i64 2, i64 %t243
  %t245 = icmp eq i64 %t244, 0
  %t246 = and i1 %t240, %t245
  br label %L235
L235:
  %t247 = phi i1 [false, %L233], [%t246, %L234]
  br label %L224
L226:
  br label %L248
L248:
  %t249 = getelementptr i64, ptr %t187, i64 1
  %t250 = load i64, ptr %t249
  %t251 = icmp eq i64 %t223, %t250
  br label %L224
L224:
  %t252 = phi i1 [%t247, %L235], [%t251, %L248]
  br label %L207
L207:
  %t253 = phi i1 [%t220, %L217], [%t252, %L224]
  br i1 %t253, label %L189, label %L254
L254:
  br label %L255
L189:
  %t256 = load i64, ptr %h.188
  %t257 = add i64 %t256, 1
  store i64 %t257, ptr %h.188
  br label %L255
L255:
  %t258 = load i64, ptr %h.188
  %t259 = load ptr, ptr %boxed.6
  %t260 = load ptr, ptr %items.82
  %t261 = call i1 @dyn.contains(ptr %t260, ptr %t259)
  %t262 = load ptr, ptr %items.82
  %t263 = call ptr @pys_dyn_int(i64 0)
  %t264 = call ptr @dyn.getitem(ptr %t262, ptr %t263)
  %t265 = load ptr, ptr %value.2
  %t266 = call ptr @pys_dyn_ref(ptr @dt._pystachy_complex$complex, ptr %t265)
  %t267 = load ptr, ptr %t264
  %t268 = icmp eq ptr %t264, %t266
  %t269 = load ptr, ptr %t266
  %t270 = icmp eq ptr %t267, %t269
  %t271 = getelementptr i64, ptr %t264, i64 1
  %t272 = load i64, ptr %t271
  %t273 = getelementptr i64, ptr %t266, i64 1
  %t274 = load i64, ptr %t273
  %t275 = icmp eq i64 %t272, %t274
  %t276 = icmp ne ptr %t267, @pys_dyntype_float
  %t277 = icmp ne ptr %t267, @pys_dyntype_int
  %t278 = getelementptr i64, ptr %t267, i64 5
  %t279 = load i64, ptr %t278
  %t280 = and i64 %t279, 8
  %t281 = icmp eq i64 %t280, 0
  %t282 = and i1 %t276, %t277
  %t283 = and i1 %t282, %t281
  %t284 = and i1 %t275, %t283
  %t285 = and i1 %t270, %t284
  %t286 = or i1 %t268, %t285
  call void @pys_write(ptr @s.10, i64 1)
  call void @pys_write(ptr @s.5, i64 1)
  %t287 = select i1 %t182, ptr @s.8, ptr @s.9
  call void @pys_write(ptr %t287, i64 1)
  call void @pys_write(ptr @s.5, i64 1)
  %t288 = call ptr @pys_str_int(i64 %t258)
  call void @pys_write(ptr %t288, i64 1)
  call void @pys_write(ptr @s.5, i64 1)
  %t289 = select i1 %t261, ptr @s.8, ptr @s.9
  call void @pys_write(ptr %t289, i64 1)
  call void @pys_write(ptr @s.5, i64 1)
  %t290 = select i1 %t286, ptr @s.8, ptr @s.9
  call void @pys_write(ptr %t290, i64 1)
  call void @pys_write(ptr @s.6, i64 1)
  %t291 = load ptr, ptr %selected.5
  %t292 = call ptr @f.optional(ptr %t291)
  store ptr %t292, ptr %maybe.293
  %t294 = load ptr, ptr %maybe.293
  %t295 = load ptr, ptr %value.2
  %t296 = call ptr @pys_dyn_ref(ptr @dt._pystachy_complex$complex, ptr %t295)
  %t297 = load ptr, ptr %t294
  %t298 = icmp eq ptr %t294, %t296
  %t299 = load ptr, ptr %t296
  %t300 = icmp eq ptr %t297, %t299
  %t301 = getelementptr i64, ptr %t294, i64 1
  %t302 = load i64, ptr %t301
  %t303 = getelementptr i64, ptr %t296, i64 1
  %t304 = load i64, ptr %t303
  %t305 = icmp eq i64 %t302, %t304
  %t306 = icmp ne ptr %t297, @pys_dyntype_float
  %t307 = icmp ne ptr %t297, @pys_dyntype_int
  %t308 = getelementptr i64, ptr %t297, i64 5
  %t309 = load i64, ptr %t308
  %t310 = and i64 %t309, 8
  %t311 = icmp eq i64 %t310, 0
  %t312 = and i1 %t306, %t307
  %t313 = and i1 %t312, %t311
  %t314 = and i1 %t305, %t313
  %t315 = and i1 %t300, %t314
  %t316 = or i1 %t298, %t315
  %t317 = call ptr @f.optional(ptr null)
  %t318 = icmp eq ptr %t317, @pys_dyn_none_box
  call void @pys_write(ptr @s.14, i64 1)
  call void @pys_write(ptr @s.5, i64 1)
  %t319 = select i1 %t316, ptr @s.8, ptr @s.9
  call void @pys_write(ptr %t319, i64 1)
  call void @pys_write(ptr @s.5, i64 1)
  %t320 = select i1 %t318, ptr @s.8, ptr @s.9
  call void @pys_write(ptr %t320, i64 1)
  call void @pys_write(ptr @s.6, i64 1)
  %t321 = load ptr, ptr %restored.24
  %t322 = call ptr @f.repeat.1(ptr %t321)
  store ptr %t322, ptr %values.323
  %t325 = load ptr, ptr %values.323
  %t327 = call ptr @llvm.coro.promise(ptr %t325, i32 8, i1 false)
  %t328 = getelementptr i64, ptr %t327, i64 2
  %t329 = load i64, ptr %t328
  %t331 = icmp eq i64 %t329, 2
  br i1 %t331, label %L326, label %L330
L330:
  %t332 = icmp eq i64 %t329, 3
  br i1 %t332, label %L333, label %L334
L334:
  store i64 3, ptr %t328
  call void @llvm.coro.resume(ptr %t325)
  %t337 = load i64, ptr %t328
  %t339 = icmp eq i64 %t337, 2
  br i1 %t339, label %L326, label %L338
L338:
  %t340 = load i64, ptr %t327
  %t341 = inttoptr i64 %t340 to ptr
  br label %L342
L326:
  call void @pys_raise(ptr @s.17, ptr @s.16)
  unreachable
L342:
  %t343 = call ptr @pys_dyn_ref(ptr @dt._pystachy_complex$complex, ptr %t341)
  store ptr %t343, ptr %first.324
  %t345 = load ptr, ptr %values.323
  %t347 = call ptr @llvm.coro.promise(ptr %t345, i32 8, i1 false)
  %t348 = getelementptr i64, ptr %t347, i64 2
  %t349 = load i64, ptr %t348
  %t351 = icmp eq i64 %t349, 2
  br i1 %t351, label %L346, label %L350
L350:
  %t352 = icmp eq i64 %t349, 3
  br i1 %t352, label %L333, label %L353
L353:
  store i64 3, ptr %t348
  call void @llvm.coro.resume(ptr %t345)
  %t356 = load i64, ptr %t348
  %t358 = icmp eq i64 %t356, 2
  br i1 %t358, label %L346, label %L357
L357:
  %t359 = load i64, ptr %t347
  %t360 = inttoptr i64 %t359 to ptr
  br label %L361
L346:
  call void @pys_raise(ptr @s.17, ptr @s.16)
  unreachable
L361:
  %t362 = call ptr @pys_dyn_ref(ptr @dt._pystachy_complex$complex, ptr %t360)
  store ptr %t362, ptr %second.344
  %t363 = load ptr, ptr %first.324
  %t364 = load ptr, ptr %value.2
  %t365 = call ptr @pys_dyn_ref(ptr @dt._pystachy_complex$complex, ptr %t364)
  %t366 = load ptr, ptr %t363
  %t367 = icmp eq ptr %t363, %t365
  %t368 = load ptr, ptr %t365
  %t369 = icmp eq ptr %t366, %t368
  %t370 = getelementptr i64, ptr %t363, i64 1
  %t371 = load i64, ptr %t370
  %t372 = getelementptr i64, ptr %t365, i64 1
  %t373 = load i64, ptr %t372
  %t374 = icmp eq i64 %t371, %t373
  %t375 = icmp ne ptr %t366, @pys_dyntype_float
  %t376 = icmp ne ptr %t366, @pys_dyntype_int
  %t377 = getelementptr i64, ptr %t366, i64 5
  %t378 = load i64, ptr %t377
  %t379 = and i64 %t378, 8
  %t380 = icmp eq i64 %t379, 0
  %t381 = and i1 %t375, %t376
  %t382 = and i1 %t381, %t380
  %t383 = and i1 %t374, %t382
  %t384 = and i1 %t369, %t383
  %t385 = or i1 %t367, %t384
  %t386 = load ptr, ptr %second.344
  %t387 = load ptr, ptr %value.2
  %t388 = call ptr @pys_dyn_ref(ptr @dt._pystachy_complex$complex, ptr %t387)
  %t389 = load ptr, ptr %t386
  %t390 = icmp eq ptr %t386, %t388
  %t391 = load ptr, ptr %t388
  %t392 = icmp eq ptr %t389, %t391
  %t393 = getelementptr i64, ptr %t386, i64 1
  %t394 = load i64, ptr %t393
  %t395 = getelementptr i64, ptr %t388, i64 1
  %t396 = load i64, ptr %t395
  %t397 = icmp eq i64 %t394, %t396
  %t398 = icmp ne ptr %t389, @pys_dyntype_float
  %t399 = icmp ne ptr %t389, @pys_dyntype_int
  %t400 = getelementptr i64, ptr %t389, i64 5
  %t401 = load i64, ptr %t400
  %t402 = and i64 %t401, 8
  %t403 = icmp eq i64 %t402, 0
  %t404 = and i1 %t398, %t399
  %t405 = and i1 %t404, %t403
  %t406 = and i1 %t397, %t405
  %t407 = and i1 %t392, %t406
  %t408 = or i1 %t390, %t407
  call void @pys_write(ptr @s.18, i64 1)
  call void @pys_write(ptr @s.5, i64 1)
  %t409 = select i1 %t385, ptr @s.8, ptr @s.9
  call void @pys_write(ptr %t409, i64 1)
  call void @pys_write(ptr @s.5, i64 1)
  %t410 = select i1 %t408, ptr @s.8, ptr @s.9
  call void @pys_write(ptr %t410, i64 1)
  call void @pys_write(ptr @s.6, i64 1)
  %t412 = load ptr, ptr %restored.24
  %t413 = call ptr @f.repeat.1(ptr %t412)
  %t414 = call ptr @pys_dyn_ref(ptr @dt.generator.1, ptr %t413)
  store ptr %t414, ptr %dynamic.411
  %t415 = load ptr, ptr %dynamic.411
  %t416 = call ptr @dyn.nextvalue(ptr %t415)
  %t417 = load ptr, ptr %value.2
  %t418 = call ptr @pys_dyn_ref(ptr @dt._pystachy_complex$complex, ptr %t417)
  %t419 = load ptr, ptr %t416
  %t420 = icmp eq ptr %t416, %t418
  %t421 = load ptr, ptr %t418
  %t422 = icmp eq ptr %t419, %t421
  %t423 = getelementptr i64, ptr %t416, i64 1
  %t424 = load i64, ptr %t423
  %t425 = getelementptr i64, ptr %t418, i64 1
  %t426 = load i64, ptr %t425
  %t427 = icmp eq i64 %t424, %t426
  %t428 = icmp ne ptr %t419, @pys_dyntype_float
  %t429 = icmp ne ptr %t419, @pys_dyntype_int
  %t430 = getelementptr i64, ptr %t419, i64 5
  %t431 = load i64, ptr %t430
  %t432 = and i64 %t431, 8
  %t433 = icmp eq i64 %t432, 0
  %t434 = and i1 %t428, %t429
  %t435 = and i1 %t434, %t433
  %t436 = and i1 %t427, %t435
  %t437 = and i1 %t422, %t436
  %t438 = or i1 %t420, %t437
  %t439 = load ptr, ptr %dynamic.411
  %t440 = call ptr @dyn.nextvalue(ptr %t439)
  %t441 = load ptr, ptr %value.2
  %t442 = call ptr @pys_dyn_ref(ptr @dt._pystachy_complex$complex, ptr %t441)
  %t443 = load ptr, ptr %t440
  %t444 = icmp eq ptr %t440, %t442
  %t445 = load ptr, ptr %t442
  %t446 = icmp eq ptr %t443, %t445
  %t447 = getelementptr i64, ptr %t440, i64 1
  %t448 = load i64, ptr %t447
  %t449 = getelementptr i64, ptr %t442, i64 1
  %t450 = load i64, ptr %t449
  %t451 = icmp eq i64 %t448, %t450
  %t452 = icmp ne ptr %t443, @pys_dyntype_float
  %t453 = icmp ne ptr %t443, @pys_dyntype_int
  %t454 = getelementptr i64, ptr %t443, i64 5
  %t455 = load i64, ptr %t454
  %t456 = and i64 %t455, 8
  %t457 = icmp eq i64 %t456, 0
  %t458 = and i1 %t452, %t453
  %t459 = and i1 %t458, %t457
  %t460 = and i1 %t451, %t459
  %t461 = and i1 %t446, %t460
  %t462 = or i1 %t444, %t461
  call void @pys_write(ptr @s.21, i64 1)
  call void @pys_write(ptr @s.5, i64 1)
  %t463 = select i1 %t438, ptr @s.8, ptr @s.9
  call void @pys_write(ptr %t463, i64 1)
  call void @pys_write(ptr @s.5, i64 1)
  %t464 = select i1 %t462, ptr @s.8, ptr @s.9
  call void @pys_write(ptr %t464, i64 1)
  call void @pys_write(ptr @s.6, i64 1)
  store i64 %t465, ptr @pys_recursion_state, !tbaa !6
  ret void
  br label %L333
L333:
  call void @pys_raise(ptr @s.23, ptr @s.22)
  unreachable
}

define i32 @main(i32 %argc, ptr %argv) {
  %sb = call ptr @llvm.frameaddress.p0(i32 0)
  call void @pys_init(i32 %argc, ptr %argv, ptr %sb, ptr @pys.roots, i64 0)
  call void @main.init()
  call void @pys_finish()
  ret i32 0
}
