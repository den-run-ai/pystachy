define internal void @main.init() {
entry:
  %t2 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t2, double 0.0, double 2.0)
  %t3 = ptrtoint ptr %t2 to i64
  %t4 = call ptr @pys_ubox(i64 1, i64 %t3)
  call void @f.show(ptr %t4)
  %t5 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t5, double 0.0, double 1.0)
  %t6 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t6, double 0.0, double 0.0)
  %t7 = sitofp i64 2 to double
  %t8 = getelementptr %C._pystachy_complex$complex, ptr %t6, i32 0, i32 0
  %t9 = load double, ptr %t8
  %t10 = getelementptr %C._pystachy_complex$complex, ptr %t6, i32 0, i32 1
  %t11 = load double, ptr %t10
  %t12 = call ptr @f._pystachy_complex$_sum(double %t7, double 0.0, double %t9, double %t11)
  %t13 = call ptr @pys_list_new(i64 2)
  %t14 = ptrtoint ptr %t5 to i64
  call void @pys_list_append(ptr %t13, i64 %t14)
  %t15 = ptrtoint ptr %t12 to i64
  call void @pys_list_append(ptr %t13, i64 %t15)
  %t16 = ptrtoint ptr %t13 to i64
  %t17 = call ptr @pys_ubox(i64 2, i64 %t16)
  call void @f.show(ptr %t17)
  %t18 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t18, double 0.0, double 3.0)
  %t19 = call ptr @pys_list_new(i64 1)
  %t20 = ptrtoint ptr %t18 to i64
  call void @pys_list_append(ptr %t19, i64 %t20)
  %t21 = ptrtoint ptr %t19 to i64
  %t22 = call ptr @pys_ubox(i64 2, i64 %t21)
  call void @f.pair(ptr %t22)
  %t23 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t23, double 0.0, double 1.0)
  %t24 = sitofp i64 1 to double
  %t25 = getelementptr %C._pystachy_complex$complex, ptr %t23, i32 0, i32 0
  %t26 = load double, ptr %t25
  %t27 = getelementptr %C._pystachy_complex$complex, ptr %t23, i32 0, i32 1
  %t28 = load double, ptr %t27
  %t29 = call ptr @f._pystachy_complex$_diff(double %t24, double 0.0, double %t26, double %t28)
  %t30 = call ptr @pys_dict_new(i64 1, i64 1)
  %t31 = ptrtoint ptr @s.0 to i64
  %t32 = ptrtoint ptr %t29 to i64
  call void @pys_dict_set(ptr %t30, i64 %t31, i64 %t32)
  %t33 = ptrtoint ptr %t30 to i64
  %t34 = call ptr @pys_ubox(i64 3, i64 %t33)
  call void @f.pair(ptr %t34)
  %t35 = call ptr @pys_ubox(i64 4, i64 4)
  call void @f.pair(ptr %t35)
  ret void
}

define internal void @f.show(ptr %a0) {
entry:
  %x.2 = alloca ptr
  store ptr zeroinitializer, ptr %x.2
  %t1 = call i64 @pys.recursion.enter()
  %t53 = sub i64 %t1, 1
  store ptr %a0, ptr %x.2
  %t3 = load ptr, ptr %x.2
  %t4 = ptrtoint ptr %t3 to i64
  %t5 = call ptr @pys_repr(i64 %t4, ptr @s.3)
  %t6 = load ptr, ptr %x.2
  %t7 = call ptr @pys_list_new(i64 1)
  %t8 = ptrtoint ptr %t6 to i64
  call void @pys_list_append(ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %x.2
  %t10 = load ptr, ptr %x.2
  %t12 = load i64, ptr %t10
  %t15 = icmp eq i64 %t12, 1
  br i1 %t15, label %L14, label %L13
L14:
  %t16 = getelementptr i64, ptr %t10, i64 1
  %t17 = load i64, ptr %t16
  %t18 = inttoptr i64 %t17 to ptr
  %t22 = icmp eq ptr %t18, null
  br i1 %t22, label %L19, label %L20
L19:
  br label %L21
L20:
  %t23 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t18)
  br label %L21
L21:
  %t24 = phi ptr [@s.4, %L19], [%t23, %L20]
  br label %L11
L13:
  %t25 = getelementptr i64, ptr %t10, i64 1
  %t26 = load i64, ptr %t25
  %t27 = inttoptr i64 %t26 to ptr
  %t28 = ptrtoint ptr %t27 to i64
  %t29 = call ptr @pys_repr(i64 %t28, ptr @s.5)
  br label %L11
L11:
  %t30 = phi ptr [%t24, %L21], [%t29, %L13]
  call void @pys_write(ptr %t5, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t31 = ptrtoint ptr %t7 to i64
  %t32 = call ptr @pys_repr(i64 %t31, ptr @s.6)
  call void @pys_write(ptr %t32, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t34 = load i64, ptr %t9
  %t37 = icmp eq i64 %t34, 1
  br i1 %t37, label %L36, label %L35
L36:
  %t38 = getelementptr i64, ptr %t9, i64 1
  %t39 = load i64, ptr %t38
  %t40 = inttoptr i64 %t39 to ptr
  %t44 = icmp eq ptr %t40, null
  br i1 %t44, label %L41, label %L42
L41:
  br label %L43
L42:
  %t45 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t40)
  br label %L43
L43:
  %t46 = phi ptr [@s.4, %L41], [%t45, %L42]
  br label %L33
L35:
  %t47 = getelementptr i64, ptr %t9, i64 1
  %t48 = load i64, ptr %t47
  %t49 = inttoptr i64 %t48 to ptr
  %t50 = ptrtoint ptr %t49 to i64
  %t51 = call ptr @pys_repr(i64 %t50, ptr @s.5)
  br label %L33
L33:
  %t52 = phi ptr [%t46, %L43], [%t51, %L35]
  call void @pys_write(ptr %t52, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  call void @pys_write(ptr %t30, i64 1)
  call void @pys_write(ptr @s.2, i64 1)
  store i64 %t53, ptr @pys_recursion_state, !tbaa !6
  ret void
}

define i32 @main(i32 %argc, ptr %argv) {
  %sb = call ptr @llvm.frameaddress.p0(i32 0)
  call void @pys_init(i32 %argc, ptr %argv, ptr %sb, ptr @pys.roots, i64 0)
  call void @main.init()
  call void @pys_finish()
  ret i32 0
}
