define internal i1 @m._pystachy_complex$complex.__eq__.1(ptr nonnull %a0, ptr %a1) {
entry:
  %self.2 = alloca ptr
  store ptr zeroinitializer, ptr %self.2
  %other.3 = alloca ptr
  store ptr zeroinitializer, ptr %other.3
  store ptr %a0, ptr %self.2
  store ptr %a1, ptr %other.3
  %t4 = load ptr, ptr %other.3
  %t5 = load i64, ptr %t4
  %t6 = icmp eq i64 %t5, 1
  br i1 %t6, label %L7, label %L8
L7:
  %t10 = load ptr, ptr %self.2
  %t11 = getelementptr %C._pystachy_complex$complex, ptr %t10, i32 0, i32 0
  %t12 = load double, ptr %t11, !tbaa !16
  %t13 = load ptr, ptr %other.3
  %t16 = icmp eq ptr %t13, null
  br i1 %t16, label %L15, label %L14
L14:
  %t17 = getelementptr i64, ptr %t13, i64 1
  %t18 = load i64, ptr %t17
  %t19 = inttoptr i64 %t18 to ptr
  br label %L15
L15:
  %t20 = phi ptr [null, %L7], [%t19, %L14]
  %t21 = icmp eq ptr %t20, null
  br i1 %t21, label %L22, label %L23
L23:
  %t24 = getelementptr %C._pystachy_complex$complex, ptr %t20, i32 0, i32 0
  %t25 = load double, ptr %t24, !tbaa !16
  %t26 = fcmp oeq double %t12, %t25
  br i1 %t26, label %L27, label %L28
L27:
  %t29 = load ptr, ptr %self.2
  %t30 = getelementptr %C._pystachy_complex$complex, ptr %t29, i32 0, i32 1
  %t31 = load double, ptr %t30, !tbaa !17
  %t32 = load ptr, ptr %other.3
  %t35 = icmp eq ptr %t32, null
  br i1 %t35, label %L34, label %L33
L33:
  %t36 = getelementptr i64, ptr %t32, i64 1
  %t37 = load i64, ptr %t36
  %t38 = inttoptr i64 %t37 to ptr
  br label %L34
L34:
  %t39 = phi ptr [null, %L27], [%t38, %L33]
  %t40 = icmp eq ptr %t39, null
  br i1 %t40, label %L41, label %L42
L42:
  %t43 = getelementptr %C._pystachy_complex$complex, ptr %t39, i32 0, i32 1
  %t44 = load double, ptr %t43, !tbaa !17
  %t45 = fcmp oeq double %t31, %t44
  br label %L28
L28:
  %t46 = phi i1 [%t26, %L23], [%t45, %L42]
  ret i1 %t46
L8:
  br label %L9
L9:
  %t47 = load ptr, ptr %self.2
  %t48 = getelementptr %C._pystachy_complex$complex, ptr %t47, i32 0, i32 1
  %t49 = load double, ptr %t48, !tbaa !17
  %t50 = fcmp oeq double %t49, 0.0
  br i1 %t50, label %L51, label %L52
L51:
  %t53 = load ptr, ptr %self.2
  %t54 = getelementptr %C._pystachy_complex$complex, ptr %t53, i32 0, i32 0
  %t55 = load double, ptr %t54, !tbaa !16
  %t56 = load ptr, ptr %other.3
  %t57 = getelementptr i64, ptr %t56, i64 1
  %t58 = load i64, ptr %t57
  %t59 = call i64 @pys_cmp_if(i64 %t58, double %t55)
  %t60 = icmp eq i64 %t59, 2
  %t61 = sub i64 0, %t59
  %t62 = select i1 %t60, i64 2, i64 %t61
  %t63 = icmp eq i64 %t62, 0
  br label %L52
L52:
  %t64 = phi i1 [%t50, %L9], [%t63, %L51]
  ret i1 %t64
L22:
  call void @pys_raise(ptr @s.3, ptr @s.2)
  unreachable
L41:
  call void @pys_raise(ptr @s.3, ptr @s.4)
  unreachable
}

define internal i1 @m._pystachy_complex$complex.__eq__.2(ptr nonnull %a0, ptr %a1) {
entry:
  %self.2 = alloca ptr
  store ptr zeroinitializer, ptr %self.2
  %other.3 = alloca ptr
  store ptr zeroinitializer, ptr %other.3
  store ptr %a0, ptr %self.2
  store ptr %a1, ptr %other.3
  %t4 = load ptr, ptr %other.3
  %t5 = load i64, ptr %t4
  %t6 = icmp eq i64 %t5, 1
  br i1 %t6, label %L7, label %L8
L7:
  %t10 = load ptr, ptr %self.2
  %t11 = getelementptr %C._pystachy_complex$complex, ptr %t10, i32 0, i32 0
  %t12 = load double, ptr %t11, !tbaa !16
  %t13 = load ptr, ptr %other.3
  %t16 = icmp eq ptr %t13, null
  br i1 %t16, label %L15, label %L14
L14:
  %t17 = getelementptr i64, ptr %t13, i64 1
  %t18 = load i64, ptr %t17
  %t19 = inttoptr i64 %t18 to ptr
  br label %L15
L15:
  %t20 = phi ptr [null, %L7], [%t19, %L14]
  %t21 = icmp eq ptr %t20, null
  br i1 %t21, label %L22, label %L23
L23:
  %t24 = getelementptr %C._pystachy_complex$complex, ptr %t20, i32 0, i32 0
  %t25 = load double, ptr %t24, !tbaa !16
  %t26 = fcmp oeq double %t12, %t25
  br i1 %t26, label %L27, label %L28
L27:
  %t29 = load ptr, ptr %self.2
  %t30 = getelementptr %C._pystachy_complex$complex, ptr %t29, i32 0, i32 1
  %t31 = load double, ptr %t30, !tbaa !17
  %t32 = load ptr, ptr %other.3
  %t35 = icmp eq ptr %t32, null
  br i1 %t35, label %L34, label %L33
L33:
  %t36 = getelementptr i64, ptr %t32, i64 1
  %t37 = load i64, ptr %t36
  %t38 = inttoptr i64 %t37 to ptr
  br label %L34
L34:
  %t39 = phi ptr [null, %L27], [%t38, %L33]
  %t40 = icmp eq ptr %t39, null
  br i1 %t40, label %L41, label %L42
L42:
  %t43 = getelementptr %C._pystachy_complex$complex, ptr %t39, i32 0, i32 1
  %t44 = load double, ptr %t43, !tbaa !17
  %t45 = fcmp oeq double %t31, %t44
  br label %L28
L28:
  %t46 = phi i1 [%t26, %L23], [%t45, %L42]
  ret i1 %t46
L8:
  br label %L9
L9:
  %t47 = load ptr, ptr %self.2
  %t48 = getelementptr %C._pystachy_complex$complex, ptr %t47, i32 0, i32 1
  %t49 = load double, ptr %t48, !tbaa !17
  %t50 = fcmp oeq double %t49, 0.0
  br i1 %t50, label %L51, label %L52
L51:
  %t53 = load ptr, ptr %self.2
  %t54 = getelementptr %C._pystachy_complex$complex, ptr %t53, i32 0, i32 0
  %t55 = load double, ptr %t54, !tbaa !16
  %t56 = load ptr, ptr %other.3
  %t57 = getelementptr i64, ptr %t56, i64 1
  %t58 = load i64, ptr %t57
  %t59 = bitcast i64 %t58 to double
  %t60 = fcmp oeq double %t55, %t59
  br label %L52
L52:
  %t61 = phi i1 [%t50, %L9], [%t60, %L51]
  ret i1 %t61
L22:
  call void @pys_raise(ptr @s.3, ptr @s.2)
  unreachable
L41:
  call void @pys_raise(ptr @s.3, ptr @s.4)
  unreachable
}

define internal void @main.init() {
entry:
  %h.2 = alloca i64
  store i64 zeroinitializer, ptr %h.2
  %h.236 = alloca i64
  store i64 zeroinitializer, ptr %h.236
  store i64 0, ptr %h.2
  br label %L3
L3:
  %t7 = load i64, ptr %h.2
  %t8 = icmp slt i64 %t7, 2
  br i1 %t8, label %L4, label %L6
L4:
  store i64 %t7, ptr @g.k
  %t9 = load i64, ptr @g.k
  %t10 = call ptr @f.pick(i64 %t9)
  store ptr %t10, ptr @g.u
  %t11 = load i64, ptr @g.k
  %t12 = call ptr @f.fpick(i64 %t11)
  store ptr %t12, ptr @g.v
  %t13 = load ptr, ptr @g.u
  %t14 = call ptr @pys_alloc(i64 8)
  %t15 = ptrtoint ptr %t13 to i64
  %t16 = getelementptr i64, ptr %t14, i64 0
  store i64 %t15, ptr %t16
  %t18 = getelementptr i64, ptr %t14, i64 0
  %t19 = load i64, ptr %t18
  %t20 = inttoptr i64 %t19 to ptr
  %t24 = load i64, ptr %t20
  %t25 = icmp eq i64 %t24, 1
  br i1 %t25, label %L22, label %L23
L22:
  %t26 = getelementptr i64, ptr %t20, i64 1
  %t27 = load i64, ptr %t26
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = icmp eq ptr %t28, null
  br i1 %t29, label %L30, label %L31
L30:
  br label %L32
L31:
  %t33 = getelementptr %C._pystachy_complex$complex, ptr %t28, i32 0, i32 0
  %t34 = load double, ptr %t33
  %t35 = getelementptr %C._pystachy_complex$complex, ptr %t28, i32 0, i32 1
  %t36 = load double, ptr %t35
  %t37 = fcmp oeq double %t36, 0.0
  %t38 = sitofp i64 1 to double
  %t39 = fcmp oeq double %t34, %t38
  %t40 = and i1 %t37, %t39
  br label %L32
L32:
  %t41 = phi i1 [false, %L30], [%t40, %L31]
  br label %L21
L23:
  br label %L42
L42:
  %t43 = getelementptr i64, ptr %t20, i64 1
  %t44 = load i64, ptr %t43
  %t45 = icmp eq i64 %t44, 1
  br label %L21
L21:
  %t46 = phi i1 [%t41, %L32], [%t45, %L42]
  br i1 %t46, label %L17, label %L47
L47:
  br label %L17
L17:
  %t48 = phi i1 [true, %L21], [false, %L47]
  %t49 = load ptr, ptr @g.u
  %t51 = getelementptr i64, ptr @tc.0, i64 0
  %t52 = load i64, ptr %t51
  %t56 = load i64, ptr %t49
  %t57 = icmp eq i64 %t56, 1
  br i1 %t57, label %L54, label %L55
L54:
  %t58 = getelementptr i64, ptr %t49, i64 1
  %t59 = load i64, ptr %t58
  %t60 = inttoptr i64 %t59 to ptr
  %t61 = icmp eq ptr %t60, null
  br i1 %t61, label %L62, label %L63
L62:
  br label %L64
L63:
  %t65 = getelementptr %C._pystachy_complex$complex, ptr %t60, i32 0, i32 0
  %t66 = load double, ptr %t65
  %t67 = getelementptr %C._pystachy_complex$complex, ptr %t60, i32 0, i32 1
  %t68 = load double, ptr %t67
  %t69 = fcmp oeq double %t68, 0.0
  %t70 = call i64 @pys_cmp_if(i64 %t52, double %t66)
  %t71 = icmp eq i64 %t70, 2
  %t72 = sub i64 0, %t70
  %t73 = select i1 %t71, i64 2, i64 %t72
  %t74 = icmp eq i64 %t73, 0
  %t75 = and i1 %t69, %t74
  br label %L64
L64:
  %t76 = phi i1 [false, %L62], [%t75, %L63]
  br label %L53
L55:
  br label %L77
L77:
  %t78 = getelementptr i64, ptr %t49, i64 1
  %t79 = load i64, ptr %t78
  %t80 = icmp eq i64 %t52, %t79
  br label %L53
L53:
  %t81 = phi i1 [%t76, %L64], [%t80, %L77]
  br i1 %t81, label %L50, label %L82
L82:
  br label %L50
L50:
  %t83 = phi i1 [true, %L53], [false, %L82]
  %t84 = load ptr, ptr @g.u
  %t86 = getelementptr i64, ptr @tc.1, i64 0
  %t87 = load i64, ptr %t86
  %t88 = bitcast i64 %t87 to double
  %t92 = load i64, ptr %t84
  %t93 = icmp eq i64 %t92, 1
  br i1 %t93, label %L90, label %L91
L90:
  %t94 = getelementptr i64, ptr %t84, i64 1
  %t95 = load i64, ptr %t94
  %t96 = inttoptr i64 %t95 to ptr
  %t97 = icmp eq ptr %t96, null
  br i1 %t97, label %L98, label %L99
L98:
  br label %L100
L99:
  %t101 = getelementptr %C._pystachy_complex$complex, ptr %t96, i32 0, i32 0
  %t102 = load double, ptr %t101
  %t103 = getelementptr %C._pystachy_complex$complex, ptr %t96, i32 0, i32 1
  %t104 = load double, ptr %t103
  %t105 = fcmp oeq double %t102, %t88
  %t106 = fcmp oeq double %t104, 0.0
  %t107 = and i1 %t105, %t106
  br label %L100
L100:
  %t108 = phi i1 [false, %L98], [%t107, %L99]
  br label %L89
L91:
  br label %L109
L109:
  %t110 = getelementptr i64, ptr %t84, i64 1
  %t111 = load i64, ptr %t110
  %t112 = call i64 @pys_cmp_if(i64 %t111, double %t88)
  %t113 = icmp eq i64 %t112, 2
  %t114 = sub i64 0, %t112
  %t115 = select i1 %t113, i64 2, i64 %t114
  %t116 = icmp eq i64 %t115, 0
  br label %L89
L89:
  %t117 = phi i1 [%t108, %L100], [%t116, %L109]
  br i1 %t117, label %L85, label %L118
L118:
  %t119 = getelementptr i64, ptr @tc.1, i64 1
  %t120 = load i64, ptr %t119
  %t124 = load i64, ptr %t84
  %t125 = icmp eq i64 %t124, 1
  br i1 %t125, label %L122, label %L123
L122:
  %t126 = getelementptr i64, ptr %t84, i64 1
  %t127 = load i64, ptr %t126
  %t128 = inttoptr i64 %t127 to ptr
  %t129 = icmp eq ptr %t128, null
  br i1 %t129, label %L130, label %L131
L130:
  br label %L132
L131:
  %t133 = getelementptr %C._pystachy_complex$complex, ptr %t128, i32 0, i32 0
  %t134 = load double, ptr %t133
  %t135 = getelementptr %C._pystachy_complex$complex, ptr %t128, i32 0, i32 1
  %t136 = load double, ptr %t135
  %t137 = fcmp oeq double %t136, 0.0
  %t138 = call i64 @pys_cmp_if(i64 %t120, double %t134)
  %t139 = icmp eq i64 %t138, 2
  %t140 = sub i64 0, %t138
  %t141 = select i1 %t139, i64 2, i64 %t140
  %t142 = icmp eq i64 %t141, 0
  %t143 = and i1 %t137, %t142
  br label %L132
L132:
  %t144 = phi i1 [false, %L130], [%t143, %L131]
  br label %L121
L123:
  br label %L145
L145:
  %t146 = getelementptr i64, ptr %t84, i64 1
  %t147 = load i64, ptr %t146
  %t148 = icmp eq i64 %t120, %t147
  br label %L121
L121:
  %t149 = phi i1 [%t144, %L132], [%t148, %L145]
  br i1 %t149, label %L85, label %L150
L150:
  br label %L85
L85:
  %t151 = phi i1 [true, %L89], [true, %L121], [false, %L150]
  %t152 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t152, double 0.0, double 1.0)
  %t153 = load ptr, ptr @g.u
  %t154 = call ptr @pys_alloc(i64 8)
  %t155 = ptrtoint ptr %t153 to i64
  %t156 = getelementptr i64, ptr %t154, i64 0
  store i64 %t155, ptr %t156
  %t158 = getelementptr i64, ptr %t154, i64 0
  %t159 = load i64, ptr %t158
  %t160 = inttoptr i64 %t159 to ptr
  %t161 = load i64, ptr %t160
  %t162 = icmp eq i64 %t161, 1
  br i1 %t162, label %L163, label %L164
L163:
  %t165 = getelementptr i64, ptr %t160, i64 1
  %t166 = load i64, ptr %t165
  %t167 = inttoptr i64 %t166 to ptr
  %t168 = icmp eq ptr %t167, %t152
  br i1 %t168, label %L157, label %L164
L164:
  %t169 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t152, ptr %t160)
  br i1 %t169, label %L157, label %L170
L170:
  br label %L157
L157:
  %t171 = phi i1 [true, %L163], [true, %L164], [false, %L170]
  %t172 = load ptr, ptr @g.u
  %t173 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t173, double 0.0, double 1.0)
  %t174 = call ptr @pys_alloc(i64 16)
  %t175 = ptrtoint ptr %t173 to i64
  %t176 = getelementptr i64, ptr %t174, i64 0
  store i64 %t175, ptr %t176
  %t177 = getelementptr i64, ptr %t174, i64 1
  store i64 2, ptr %t177
  %t179 = getelementptr i64, ptr %t174, i64 0
  %t180 = load i64, ptr %t179
  %t181 = inttoptr i64 %t180 to ptr
  %t182 = icmp eq ptr %t181, null
  %t183 = load i64, ptr %t172
  %t184 = icmp eq i64 %t183, 1
  br i1 %t184, label %L185, label %L186
L185:
  %t187 = getelementptr i64, ptr %t172, i64 1
  %t188 = load i64, ptr %t187
  %t189 = inttoptr i64 %t188 to ptr
  %t190 = icmp eq ptr %t181, %t189
  br i1 %t190, label %L178, label %L186
L186:
  %t194 = icmp eq ptr %t181, null
  br i1 %t194, label %L191, label %L192
L191:
  br label %L193
L192:
  %t195 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t181, ptr %t172)
  br label %L193
L193:
  %t196 = phi i1 [false, %L191], [%t195, %L192]
  br i1 %t196, label %L178, label %L197
L197:
  %t198 = getelementptr i64, ptr %t174, i64 1
  %t199 = load i64, ptr %t198
  %t203 = load i64, ptr %t172
  %t204 = icmp eq i64 %t203, 1
  br i1 %t204, label %L201, label %L202
L201:
  %t205 = getelementptr i64, ptr %t172, i64 1
  %t206 = load i64, ptr %t205
  %t207 = inttoptr i64 %t206 to ptr
  %t208 = icmp eq ptr %t207, null
  br i1 %t208, label %L209, label %L210
L209:
  br label %L211
L210:
  %t212 = getelementptr %C._pystachy_complex$complex, ptr %t207, i32 0, i32 0
  %t213 = load double, ptr %t212
  %t214 = getelementptr %C._pystachy_complex$complex, ptr %t207, i32 0, i32 1
  %t215 = load double, ptr %t214
  %t216 = fcmp oeq double %t215, 0.0
  %t217 = call i64 @pys_cmp_if(i64 %t199, double %t213)
  %t218 = icmp eq i64 %t217, 2
  %t219 = sub i64 0, %t217
  %t220 = select i1 %t218, i64 2, i64 %t219
  %t221 = icmp eq i64 %t220, 0
  %t222 = and i1 %t216, %t221
  br label %L211
L211:
  %t223 = phi i1 [false, %L209], [%t222, %L210]
  br label %L200
L202:
  br label %L224
L224:
  %t225 = getelementptr i64, ptr %t172, i64 1
  %t226 = load i64, ptr %t225
  %t227 = icmp eq i64 %t199, %t226
  br label %L200
L200:
  %t228 = phi i1 [%t223, %L211], [%t227, %L224]
  br i1 %t228, label %L178, label %L229
L229:
  br label %L178
L178:
  %t230 = phi i1 [true, %L185], [true, %L193], [true, %L200], [false, %L229]
  %t231 = load ptr, ptr @g.u
  %t232 = call ptr @pys_alloc(i64 16)
  %t233 = ptrtoint ptr %t231 to i64
  %t234 = getelementptr i64, ptr %t232, i64 0
  store i64 %t233, ptr %t234
  %t235 = getelementptr i64, ptr %t232, i64 1
  store i64 2, ptr %t235
  store i64 0, ptr %h.236
  %t238 = getelementptr i64, ptr %t232, i64 0
  %t239 = load i64, ptr %t238
  %t240 = inttoptr i64 %t239 to ptr
  %t244 = load i64, ptr %t240
  %t245 = icmp eq i64 %t244, 1
  br i1 %t245, label %L242, label %L243
L242:
  %t246 = getelementptr i64, ptr %t240, i64 1
  %t247 = load i64, ptr %t246
  %t248 = inttoptr i64 %t247 to ptr
  %t249 = icmp eq ptr %t248, null
  br i1 %t249, label %L250, label %L251
L250:
  br label %L252
L251:
  %t253 = getelementptr %C._pystachy_complex$complex, ptr %t248, i32 0, i32 0
  %t254 = load double, ptr %t253
  %t255 = getelementptr %C._pystachy_complex$complex, ptr %t248, i32 0, i32 1
  %t256 = load double, ptr %t255
  %t257 = fcmp oeq double %t256, 0.0
  %t258 = sitofp i64 1 to double
  %t259 = fcmp oeq double %t254, %t258
  %t260 = and i1 %t257, %t259
  br label %L252
L252:
  %t261 = phi i1 [false, %L250], [%t260, %L251]
  br label %L241
L243:
  br label %L262
L262:
  %t263 = getelementptr i64, ptr %t240, i64 1
  %t264 = load i64, ptr %t263
  %t265 = icmp eq i64 %t264, 1
  br label %L241
L241:
  %t266 = phi i1 [%t261, %L252], [%t265, %L262]
  br i1 %t266, label %L237, label %L267
L267:
  br label %L268
L237:
  %t269 = load i64, ptr %h.236
  %t270 = add i64 %t269, 1
  store i64 %t270, ptr %h.236
  br label %L268
L268:
  %t272 = getelementptr i64, ptr %t232, i64 1
  %t273 = load i64, ptr %t272
  %t274 = icmp eq i64 %t273, 1
  br i1 %t274, label %L271, label %L275
L275:
  br label %L276
L271:
  %t277 = load i64, ptr %h.236
  %t278 = add i64 %t277, 1
  store i64 %t278, ptr %h.236
  br label %L276
L276:
  %t279 = load i64, ptr %h.236
  %t280 = load ptr, ptr @g.v
  %t281 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t281, double 0.0, double 2.0)
  %t282 = call ptr @pys_alloc(i64 16)
  %t283 = bitcast double 2.5 to i64
  %t284 = getelementptr i64, ptr %t282, i64 0
  store i64 %t283, ptr %t284
  %t285 = ptrtoint ptr %t281 to i64
  %t286 = getelementptr i64, ptr %t282, i64 1
  store i64 %t285, ptr %t286
  %t288 = getelementptr i64, ptr %t282, i64 0
  %t289 = load i64, ptr %t288
  %t290 = bitcast i64 %t289 to double
  %t294 = load i64, ptr %t280
  %t295 = icmp eq i64 %t294, 1
  br i1 %t295, label %L292, label %L293
L292:
  %t296 = getelementptr i64, ptr %t280, i64 1
  %t297 = load i64, ptr %t296
  %t298 = inttoptr i64 %t297 to ptr
  %t299 = icmp eq ptr %t298, null
  br i1 %t299, label %L300, label %L301
L300:
  br label %L302
L301:
  %t303 = getelementptr %C._pystachy_complex$complex, ptr %t298, i32 0, i32 0
  %t304 = load double, ptr %t303
  %t305 = getelementptr %C._pystachy_complex$complex, ptr %t298, i32 0, i32 1
  %t306 = load double, ptr %t305
  %t307 = fcmp oeq double %t304, %t290
  %t308 = fcmp oeq double %t306, 0.0
  %t309 = and i1 %t307, %t308
  br label %L302
L302:
  %t310 = phi i1 [false, %L300], [%t309, %L301]
  br label %L291
L293:
  br label %L311
L311:
  %t312 = getelementptr i64, ptr %t280, i64 1
  %t313 = load i64, ptr %t312
  %t314 = bitcast i64 %t313 to double
  %t315 = fcmp oeq double %t290, %t314
  br label %L291
L291:
  %t316 = phi i1 [%t310, %L302], [%t315, %L311]
  br i1 %t316, label %L287, label %L317
L317:
  %t318 = getelementptr i64, ptr %t282, i64 1
  %t319 = load i64, ptr %t318
  %t320 = inttoptr i64 %t319 to ptr
  %t321 = icmp eq ptr %t320, null
  %t322 = load i64, ptr %t280
  %t323 = icmp eq i64 %t322, 1
  br i1 %t323, label %L324, label %L325
L324:
  %t326 = getelementptr i64, ptr %t280, i64 1
  %t327 = load i64, ptr %t326
  %t328 = inttoptr i64 %t327 to ptr
  %t329 = icmp eq ptr %t320, %t328
  br i1 %t329, label %L287, label %L325
L325:
  %t333 = icmp eq ptr %t320, null
  br i1 %t333, label %L330, label %L331
L330:
  br label %L332
L331:
  %t334 = call i1 @m._pystachy_complex$complex.__eq__.2(ptr %t320, ptr %t280)
  br label %L332
L332:
  %t335 = phi i1 [false, %L330], [%t334, %L331]
  br i1 %t335, label %L287, label %L336
L336:
  br label %L287
L287:
  %t337 = phi i1 [true, %L291], [true, %L324], [true, %L332], [false, %L336]
  %t338 = load ptr, ptr @g.v
  %t339 = call ptr @pys_alloc(i64 8)
  %t340 = ptrtoint ptr %t338 to i64
  %t341 = getelementptr i64, ptr %t339, i64 0
  store i64 %t340, ptr %t341
  %t343 = getelementptr i64, ptr %t339, i64 0
  %t344 = load i64, ptr %t343
  %t345 = inttoptr i64 %t344 to ptr
  %t349 = load i64, ptr %t345
  %t350 = icmp eq i64 %t349, 1
  br i1 %t350, label %L347, label %L348
L347:
  %t351 = getelementptr i64, ptr %t345, i64 1
  %t352 = load i64, ptr %t351
  %t353 = inttoptr i64 %t352 to ptr
  %t354 = icmp eq ptr %t353, null
  br i1 %t354, label %L355, label %L356
L355:
  br label %L357
L356:
  %t358 = getelementptr %C._pystachy_complex$complex, ptr %t353, i32 0, i32 0
  %t359 = load double, ptr %t358
  %t360 = getelementptr %C._pystachy_complex$complex, ptr %t353, i32 0, i32 1
  %t361 = load double, ptr %t360
  %t362 = fcmp oeq double %t359, 2.5
  %t363 = fcmp oeq double %t361, 0.0
  %t364 = and i1 %t362, %t363
  br label %L357
L357:
  %t365 = phi i1 [false, %L355], [%t364, %L356]
  br label %L346
L348:
  br label %L366
L366:
  %t367 = getelementptr i64, ptr %t345, i64 1
  %t368 = load i64, ptr %t367
  %t369 = bitcast i64 %t368 to double
  %t370 = fcmp oeq double %t369, 2.5
  br label %L346
L346:
  %t371 = phi i1 [%t365, %L357], [%t370, %L366]
  br i1 %t371, label %L342, label %L372
L372:
  br label %L342
L342:
  %t373 = phi i1 [true, %L346], [false, %L372]
  %t374 = select i1 %t48, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t374, i64 1)
  call void @pys_write(ptr @s.0, i64 1)
  %t375 = select i1 %t83, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t375, i64 1)
  call void @pys_write(ptr @s.0, i64 1)
  %t376 = select i1 %t151, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t376, i64 1)
  call void @pys_write(ptr @s.0, i64 1)
  %t377 = select i1 %t171, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t377, i64 1)
  call void @pys_write(ptr @s.0, i64 1)
  %t378 = select i1 %t230, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t378, i64 1)
  call void @pys_write(ptr @s.0, i64 1)
  %t379 = call ptr @pys_str_int(i64 %t279)
  call void @pys_write(ptr %t379, i64 1)
  call void @pys_write(ptr @s.0, i64 1)
  %t380 = select i1 %t337, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t380, i64 1)
  call void @pys_write(ptr @s.0, i64 1)
  %t381 = select i1 %t373, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t381, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  br label %L5
L5:
  %t382 = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %t7, i64 1)
  %t383 = extractvalue {i64, i1} %t382, 0
  %t384 = extractvalue {i64, i1} %t382, 1
  store i64 %t383, ptr %h.2
  br i1 %t384, label %L6, label %L3
L6:
  ret void
}

define internal ptr @f.pick(i64 %a0) {
entry:
  %k.2 = alloca i64
  store i64 zeroinitializer, ptr %k.2
  store i64 %a0, ptr %k.2
  %t3 = load i64, ptr %k.2
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %L5, label %L6
L5:
  %t8 = call ptr @pys_ubox(i64 2, i64 1)
  br label %L7
L6:
  %t9 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t9, double 0.0, double 0.0)
  %t10 = sitofp i64 1 to double
  %t11 = getelementptr %C._pystachy_complex$complex, ptr %t9, i32 0, i32 0
  %t12 = load double, ptr %t11
  %t13 = getelementptr %C._pystachy_complex$complex, ptr %t9, i32 0, i32 1
  %t14 = load double, ptr %t13
  %t15 = call ptr @f._pystachy_complex$_sum(double %t10, double 0.0, double %t12, double %t14)
  %t16 = ptrtoint ptr %t15 to i64
  %t17 = call ptr @pys_ubox(i64 1, i64 %t16)
  br label %L7
L7:
  %t18 = phi ptr [%t8, %L5], [%t17, %L6]
  ret ptr %t18
}

define internal ptr @f.fpick(i64 %a0) {
entry:
  %k.2 = alloca i64
  store i64 zeroinitializer, ptr %k.2
  store i64 %a0, ptr %k.2
  %t3 = load i64, ptr %k.2
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %L5, label %L6
L5:
  %t8 = bitcast double 2.5 to i64
  %t9 = call ptr @pys_ubox(i64 3, i64 %t8)
  br label %L7
L6:
  %t10 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t10, double 0.0, double 2.0)
  %t11 = ptrtoint ptr %t10 to i64
  %t12 = call ptr @pys_ubox(i64 1, i64 %t11)
  br label %L7
L7:
  %t13 = phi ptr [%t9, %L5], [%t12, %L6]
  ret ptr %t13
}

define i32 @main(i32 %argc, ptr %argv) {
  %sb = call ptr @llvm.frameaddress.p0(i32 0)
  call void @pys_init(i32 %argc, ptr %argv, ptr %sb, ptr @pys.roots, i64 2)
  call void @main.init()
  call void @pys_finish()
  ret i32 0
}
