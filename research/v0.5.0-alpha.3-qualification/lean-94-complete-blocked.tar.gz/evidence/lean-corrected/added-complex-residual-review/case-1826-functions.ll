define internal void @main.init() {
entry:
  %t2 = call double @pys_float_str(ptr @s.0)
  store double %t2, ptr @g.nan
  %t3 = load double, ptr @g.nan
  %t4 = call ptr @f._pystachy_complex$_two(double %t3, double 0.0, i1 false, double 0.0, double 0.0, i1 false)
  store ptr %t4, ptr @g.c
  %t5 = load ptr, ptr @g.c
  %t6 = icmp eq ptr %t5, null
  br i1 %t6, label %L7, label %L8
L8:
  %t9 = ptrtoint ptr %t5 to i64
  %t10 = call ptr @pys_ubox(i64 1, i64 %t9)
  %t11 = call ptr @pys_ubox(i64 2, i64 1)
  call void @f.search(ptr %t10, ptr %t11)
  %t12 = load ptr, ptr @g.c
  %t15 = ptrtoint ptr %t12 to i64
  %t16 = call ptr @pys_ubox(i64 1, i64 %t15)
  %t17 = load ptr, ptr @g.c
  %t20 = ptrtoint ptr %t17 to i64
  %t21 = call ptr @pys_ubox(i64 1, i64 %t20)
  call void @f.search(ptr %t16, ptr %t21)
  %t22 = load ptr, ptr @g.c
  %t25 = ptrtoint ptr %t22 to i64
  %t26 = call ptr @pys_ubox(i64 1, i64 %t25)
  %t27 = load double, ptr @g.nan
  %t28 = call ptr @f._pystachy_complex$_two(double %t27, double 0.0, i1 false, double 0.0, double 0.0, i1 false)
  %t29 = ptrtoint ptr %t28 to i64
  %t30 = call ptr @pys_ubox(i64 1, i64 %t29)
  call void @f.search(ptr %t26, ptr %t30)
  %t31 = sitofp i64 1 to double
  %t32 = sitofp i64 2 to double
  %t33 = call ptr @f._pystachy_complex$_two(double %t31, double 0.0, i1 false, double %t32, double 0.0, i1 false)
  %t34 = ptrtoint ptr %t33 to i64
  %t35 = call ptr @pys_ubox(i64 1, i64 %t34)
  %t36 = sitofp i64 1 to double
  %t37 = sitofp i64 2 to double
  %t38 = call ptr @f._pystachy_complex$_two(double %t36, double 0.0, i1 false, double %t37, double 0.0, i1 false)
  %t39 = ptrtoint ptr %t38 to i64
  %t40 = call ptr @pys_ubox(i64 1, i64 %t39)
  call void @f.search(ptr %t35, ptr %t40)
  %t41 = call ptr @pys_ubox(i64 2, i64 3)
  %t42 = call ptr @pys_ubox(i64 2, i64 3)
  call void @f.search(ptr %t41, ptr %t42)
  %t43 = load ptr, ptr @g.c
  %t44 = ptrtoint ptr %t43 to i64
  %t45 = call ptr @pys_ubox(i64 1, i64 %t44)
  %t46 = icmp eq ptr %t43, null
  %t47 = select i1 %t46, ptr null, ptr %t45
  %t48 = load ptr, ptr @g.c
  call void @f.mixed(ptr %t47, ptr %t48)
  %t49 = load ptr, ptr @g.c
  call void @f.mixed(ptr null, ptr %t49)
  %t50 = call ptr @pys_ubox(i64 2, i64 5)
  %t51 = load ptr, ptr @g.c
  call void @f.mixed(ptr %t50, ptr %t51)
  ret void
  br label %L7
L7:
  call void @pys_raise(ptr @s.2, ptr @s.1)
  unreachable
}

define internal i1 @m._pystachy_complex$complex.__eq__.1(ptr nonnull %a0, ptr %a1) {
entry:
  %self.2 = alloca ptr
  store ptr zeroinitializer, ptr %self.2
  %other.3 = alloca ptr
  store ptr zeroinitializer, ptr %other.3
  store ptr %a0, ptr %self.2
  store ptr %a1, ptr %other.3
  %t4 = load ptr, ptr %other.3
  %t5 = load i64, ptr %t4
  %t6 = icmp eq i64 %t5, 1
  br i1 %t6, label %L7, label %L8
L7:
  %t10 = load ptr, ptr %self.2
  %t11 = getelementptr %C._pystachy_complex$complex, ptr %t10, i32 0, i32 0
  %t12 = load double, ptr %t11, !tbaa !16
  %t13 = load ptr, ptr %other.3
  %t16 = icmp eq ptr %t13, null
  br i1 %t16, label %L15, label %L14
L14:
  %t17 = getelementptr i64, ptr %t13, i64 1
  %t18 = load i64, ptr %t17
  %t19 = inttoptr i64 %t18 to ptr
  br label %L15
L15:
  %t20 = phi ptr [null, %L7], [%t19, %L14]
  %t21 = icmp eq ptr %t20, null
  br i1 %t21, label %L22, label %L23
L23:
  %t24 = getelementptr %C._pystachy_complex$complex, ptr %t20, i32 0, i32 0
  %t25 = load double, ptr %t24, !tbaa !16
  %t26 = fcmp oeq double %t12, %t25
  br i1 %t26, label %L27, label %L28
L27:
  %t29 = load ptr, ptr %self.2
  %t30 = getelementptr %C._pystachy_complex$complex, ptr %t29, i32 0, i32 1
  %t31 = load double, ptr %t30, !tbaa !17
  %t32 = load ptr, ptr %other.3
  %t35 = icmp eq ptr %t32, null
  br i1 %t35, label %L34, label %L33
L33:
  %t36 = getelementptr i64, ptr %t32, i64 1
  %t37 = load i64, ptr %t36
  %t38 = inttoptr i64 %t37 to ptr
  br label %L34
L34:
  %t39 = phi ptr [null, %L27], [%t38, %L33]
  %t40 = icmp eq ptr %t39, null
  br i1 %t40, label %L41, label %L42
L42:
  %t43 = getelementptr %C._pystachy_complex$complex, ptr %t39, i32 0, i32 1
  %t44 = load double, ptr %t43, !tbaa !17
  %t45 = fcmp oeq double %t31, %t44
  br label %L28
L28:
  %t46 = phi i1 [%t26, %L23], [%t45, %L42]
  ret i1 %t46
L8:
  br label %L9
L9:
  %t47 = load ptr, ptr %self.2
  %t48 = getelementptr %C._pystachy_complex$complex, ptr %t47, i32 0, i32 1
  %t49 = load double, ptr %t48, !tbaa !17
  %t50 = fcmp oeq double %t49, 0.0
  br i1 %t50, label %L51, label %L52
L51:
  %t53 = load ptr, ptr %self.2
  %t54 = getelementptr %C._pystachy_complex$complex, ptr %t53, i32 0, i32 0
  %t55 = load double, ptr %t54, !tbaa !16
  %t56 = load ptr, ptr %other.3
  %t57 = getelementptr i64, ptr %t56, i64 1
  %t58 = load i64, ptr %t57
  %t59 = call i64 @pys_cmp_if(i64 %t58, double %t55)
  %t60 = icmp eq i64 %t59, 2
  %t61 = sub i64 0, %t59
  %t62 = select i1 %t60, i64 2, i64 %t61
  %t63 = icmp eq i64 %t62, 0
  br label %L52
L52:
  %t64 = phi i1 [%t50, %L9], [%t63, %L51]
  ret i1 %t64
L22:
  call void @pys_raise(ptr @s.6, ptr @s.5)
  unreachable
L41:
  call void @pys_raise(ptr @s.6, ptr @s.7)
  unreachable
}

define internal void @f.search(ptr %a0, ptr %a1) {
entry:
  %x.2 = alloca ptr
  store ptr zeroinitializer, ptr %x.2
  %y.3 = alloca ptr
  store ptr zeroinitializer, ptr %y.3
  %h.81 = alloca i64
  store i64 zeroinitializer, ptr %h.81
  %h.372 = alloca i64
  store i64 zeroinitializer, ptr %h.372
  store ptr %a0, ptr %x.2
  store ptr %a1, ptr %y.3
  %t4 = load ptr, ptr %x.2
  %t5 = load ptr, ptr %x.2
  %t6 = call ptr @pys_alloc(i64 8)
  %t7 = ptrtoint ptr %t5 to i64
  %t8 = getelementptr i64, ptr %t6, i64 0
  store i64 %t7, ptr %t8
  %t10 = getelementptr i64, ptr %t6, i64 0
  %t11 = load i64, ptr %t10
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = load i64, ptr %t12
  %t14 = icmp eq i64 %t13, 1
  %t15 = load i64, ptr %t4
  %t16 = icmp eq i64 %t15, 1
  %t17 = and i1 %t14, %t16
  br i1 %t17, label %L18, label %L19
L18:
  %t20 = getelementptr i64, ptr %t12, i64 1
  %t21 = load i64, ptr %t20
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = getelementptr i64, ptr %t4, i64 1
  %t24 = load i64, ptr %t23
  %t25 = inttoptr i64 %t24 to ptr
  %t26 = icmp eq ptr %t22, %t25
  br i1 %t26, label %L9, label %L19
L19:
  %t30 = load i64, ptr %t12
  %t31 = icmp eq i64 %t30, 1
  br i1 %t31, label %L28, label %L29
L28:
  %t32 = getelementptr i64, ptr %t12, i64 1
  %t33 = load i64, ptr %t32
  %t34 = inttoptr i64 %t33 to ptr
  %t38 = icmp eq ptr %t34, null
  br i1 %t38, label %L35, label %L36
L35:
  br label %L37
L36:
  %t39 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t34, ptr %t4)
  br label %L37
L37:
  %t40 = phi i1 [false, %L35], [%t39, %L36]
  br label %L27
L29:
  br label %L41
L41:
  %t42 = getelementptr i64, ptr %t12, i64 1
  %t43 = load i64, ptr %t42
  %t47 = load i64, ptr %t4
  %t48 = icmp eq i64 %t47, 1
  br i1 %t48, label %L45, label %L46
L45:
  %t49 = getelementptr i64, ptr %t4, i64 1
  %t50 = load i64, ptr %t49
  %t51 = inttoptr i64 %t50 to ptr
  %t52 = icmp eq ptr %t51, null
  br i1 %t52, label %L53, label %L54
L53:
  br label %L55
L54:
  %t56 = getelementptr %C._pystachy_complex$complex, ptr %t51, i32 0, i32 0
  %t57 = load double, ptr %t56
  %t58 = getelementptr %C._pystachy_complex$complex, ptr %t51, i32 0, i32 1
  %t59 = load double, ptr %t58
  %t60 = fcmp oeq double %t59, 0.0
  %t61 = call i64 @pys_cmp_if(i64 %t43, double %t57)
  %t62 = icmp eq i64 %t61, 2
  %t63 = sub i64 0, %t61
  %t64 = select i1 %t62, i64 2, i64 %t63
  %t65 = icmp eq i64 %t64, 0
  %t66 = and i1 %t60, %t65
  br label %L55
L55:
  %t67 = phi i1 [false, %L53], [%t66, %L54]
  br label %L44
L46:
  br label %L68
L68:
  %t69 = getelementptr i64, ptr %t4, i64 1
  %t70 = load i64, ptr %t69
  %t71 = icmp eq i64 %t43, %t70
  br label %L44
L44:
  %t72 = phi i1 [%t67, %L55], [%t71, %L68]
  br label %L27
L27:
  %t73 = phi i1 [%t40, %L37], [%t72, %L44]
  br i1 %t73, label %L9, label %L74
L74:
  br label %L9
L9:
  %t75 = phi i1 [true, %L18], [true, %L27], [false, %L74]
  %t76 = load ptr, ptr %x.2
  %t77 = call ptr @pys_alloc(i64 8)
  %t78 = ptrtoint ptr %t76 to i64
  %t79 = getelementptr i64, ptr %t77, i64 0
  store i64 %t78, ptr %t79
  %t80 = load ptr, ptr %x.2
  store i64 0, ptr %h.81
  %t83 = getelementptr i64, ptr %t77, i64 0
  %t84 = load i64, ptr %t83
  %t85 = inttoptr i64 %t84 to ptr
  %t86 = load i64, ptr %t85
  %t87 = icmp eq i64 %t86, 1
  %t88 = load i64, ptr %t80
  %t89 = icmp eq i64 %t88, 1
  %t90 = and i1 %t87, %t89
  br i1 %t90, label %L91, label %L92
L91:
  %t93 = getelementptr i64, ptr %t85, i64 1
  %t94 = load i64, ptr %t93
  %t95 = inttoptr i64 %t94 to ptr
  %t96 = getelementptr i64, ptr %t80, i64 1
  %t97 = load i64, ptr %t96
  %t98 = inttoptr i64 %t97 to ptr
  %t99 = icmp eq ptr %t95, %t98
  br i1 %t99, label %L82, label %L92
L92:
  %t103 = load i64, ptr %t85
  %t104 = icmp eq i64 %t103, 1
  br i1 %t104, label %L101, label %L102
L101:
  %t105 = getelementptr i64, ptr %t85, i64 1
  %t106 = load i64, ptr %t105
  %t107 = inttoptr i64 %t106 to ptr
  %t111 = icmp eq ptr %t107, null
  br i1 %t111, label %L108, label %L109
L108:
  br label %L110
L109:
  %t112 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t107, ptr %t80)
  br label %L110
L110:
  %t113 = phi i1 [false, %L108], [%t112, %L109]
  br label %L100
L102:
  br label %L114
L114:
  %t115 = getelementptr i64, ptr %t85, i64 1
  %t116 = load i64, ptr %t115
  %t120 = load i64, ptr %t80
  %t121 = icmp eq i64 %t120, 1
  br i1 %t121, label %L118, label %L119
L118:
  %t122 = getelementptr i64, ptr %t80, i64 1
  %t123 = load i64, ptr %t122
  %t124 = inttoptr i64 %t123 to ptr
  %t125 = icmp eq ptr %t124, null
  br i1 %t125, label %L126, label %L127
L126:
  br label %L128
L127:
  %t129 = getelementptr %C._pystachy_complex$complex, ptr %t124, i32 0, i32 0
  %t130 = load double, ptr %t129
  %t131 = getelementptr %C._pystachy_complex$complex, ptr %t124, i32 0, i32 1
  %t132 = load double, ptr %t131
  %t133 = fcmp oeq double %t132, 0.0
  %t134 = call i64 @pys_cmp_if(i64 %t116, double %t130)
  %t135 = icmp eq i64 %t134, 2
  %t136 = sub i64 0, %t134
  %t137 = select i1 %t135, i64 2, i64 %t136
  %t138 = icmp eq i64 %t137, 0
  %t139 = and i1 %t133, %t138
  br label %L128
L128:
  %t140 = phi i1 [false, %L126], [%t139, %L127]
  br label %L117
L119:
  br label %L141
L141:
  %t142 = getelementptr i64, ptr %t80, i64 1
  %t143 = load i64, ptr %t142
  %t144 = icmp eq i64 %t116, %t143
  br label %L117
L117:
  %t145 = phi i1 [%t140, %L128], [%t144, %L141]
  br label %L100
L100:
  %t146 = phi i1 [%t113, %L110], [%t145, %L117]
  br i1 %t146, label %L82, label %L147
L147:
  br label %L148
L82:
  %t149 = load i64, ptr %h.81
  %t150 = add i64 %t149, 1
  store i64 %t150, ptr %h.81
  br label %L148
L148:
  %t151 = load i64, ptr %h.81
  %t152 = load ptr, ptr %y.3
  %t153 = load ptr, ptr %x.2
  %t154 = call ptr @pys_alloc(i64 16)
  %t155 = ptrtoint ptr %t152 to i64
  %t156 = getelementptr i64, ptr %t154, i64 0
  store i64 %t155, ptr %t156
  %t157 = ptrtoint ptr %t153 to i64
  %t158 = getelementptr i64, ptr %t154, i64 1
  store i64 %t157, ptr %t158
  %t159 = load ptr, ptr %x.2
  %t161 = getelementptr i64, ptr %t154, i64 0
  %t162 = load i64, ptr %t161
  %t163 = inttoptr i64 %t162 to ptr
  %t164 = load i64, ptr %t163
  %t165 = icmp eq i64 %t164, 1
  %t166 = load i64, ptr %t159
  %t167 = icmp eq i64 %t166, 1
  %t168 = and i1 %t165, %t167
  br i1 %t168, label %L169, label %L170
L169:
  %t171 = getelementptr i64, ptr %t163, i64 1
  %t172 = load i64, ptr %t171
  %t173 = inttoptr i64 %t172 to ptr
  %t174 = getelementptr i64, ptr %t159, i64 1
  %t175 = load i64, ptr %t174
  %t176 = inttoptr i64 %t175 to ptr
  %t177 = icmp eq ptr %t173, %t176
  br i1 %t177, label %L160, label %L170
L170:
  %t181 = load i64, ptr %t163
  %t182 = icmp eq i64 %t181, 1
  br i1 %t182, label %L179, label %L180
L179:
  %t183 = getelementptr i64, ptr %t163, i64 1
  %t184 = load i64, ptr %t183
  %t185 = inttoptr i64 %t184 to ptr
  %t189 = icmp eq ptr %t185, null
  br i1 %t189, label %L186, label %L187
L186:
  br label %L188
L187:
  %t190 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t185, ptr %t159)
  br label %L188
L188:
  %t191 = phi i1 [false, %L186], [%t190, %L187]
  br label %L178
L180:
  br label %L192
L192:
  %t193 = getelementptr i64, ptr %t163, i64 1
  %t194 = load i64, ptr %t193
  %t198 = load i64, ptr %t159
  %t199 = icmp eq i64 %t198, 1
  br i1 %t199, label %L196, label %L197
L196:
  %t200 = getelementptr i64, ptr %t159, i64 1
  %t201 = load i64, ptr %t200
  %t202 = inttoptr i64 %t201 to ptr
  %t203 = icmp eq ptr %t202, null
  br i1 %t203, label %L204, label %L205
L204:
  br label %L206
L205:
  %t207 = getelementptr %C._pystachy_complex$complex, ptr %t202, i32 0, i32 0
  %t208 = load double, ptr %t207
  %t209 = getelementptr %C._pystachy_complex$complex, ptr %t202, i32 0, i32 1
  %t210 = load double, ptr %t209
  %t211 = fcmp oeq double %t210, 0.0
  %t212 = call i64 @pys_cmp_if(i64 %t194, double %t208)
  %t213 = icmp eq i64 %t212, 2
  %t214 = sub i64 0, %t212
  %t215 = select i1 %t213, i64 2, i64 %t214
  %t216 = icmp eq i64 %t215, 0
  %t217 = and i1 %t211, %t216
  br label %L206
L206:
  %t218 = phi i1 [false, %L204], [%t217, %L205]
  br label %L195
L197:
  br label %L219
L219:
  %t220 = getelementptr i64, ptr %t159, i64 1
  %t221 = load i64, ptr %t220
  %t222 = icmp eq i64 %t194, %t221
  br label %L195
L195:
  %t223 = phi i1 [%t218, %L206], [%t222, %L219]
  br label %L178
L178:
  %t224 = phi i1 [%t191, %L188], [%t223, %L195]
  br i1 %t224, label %L160, label %L225
L225:
  %t226 = getelementptr i64, ptr %t154, i64 1
  %t227 = load i64, ptr %t226
  %t228 = inttoptr i64 %t227 to ptr
  %t229 = load i64, ptr %t228
  %t230 = icmp eq i64 %t229, 1
  %t231 = load i64, ptr %t159
  %t232 = icmp eq i64 %t231, 1
  %t233 = and i1 %t230, %t232
  br i1 %t233, label %L234, label %L235
L234:
  %t236 = getelementptr i64, ptr %t228, i64 1
  %t237 = load i64, ptr %t236
  %t238 = inttoptr i64 %t237 to ptr
  %t239 = getelementptr i64, ptr %t159, i64 1
  %t240 = load i64, ptr %t239
  %t241 = inttoptr i64 %t240 to ptr
  %t242 = icmp eq ptr %t238, %t241
  br i1 %t242, label %L160, label %L235
L235:
  %t246 = load i64, ptr %t228
  %t247 = icmp eq i64 %t246, 1
  br i1 %t247, label %L244, label %L245
L244:
  %t248 = getelementptr i64, ptr %t228, i64 1
  %t249 = load i64, ptr %t248
  %t250 = inttoptr i64 %t249 to ptr
  %t254 = icmp eq ptr %t250, null
  br i1 %t254, label %L251, label %L252
L251:
  br label %L253
L252:
  %t255 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t250, ptr %t159)
  br label %L253
L253:
  %t256 = phi i1 [false, %L251], [%t255, %L252]
  br label %L243
L245:
  br label %L257
L257:
  %t258 = getelementptr i64, ptr %t228, i64 1
  %t259 = load i64, ptr %t258
  %t263 = load i64, ptr %t159
  %t264 = icmp eq i64 %t263, 1
  br i1 %t264, label %L261, label %L262
L261:
  %t265 = getelementptr i64, ptr %t159, i64 1
  %t266 = load i64, ptr %t265
  %t267 = inttoptr i64 %t266 to ptr
  %t268 = icmp eq ptr %t267, null
  br i1 %t268, label %L269, label %L270
L269:
  br label %L271
L270:
  %t272 = getelementptr %C._pystachy_complex$complex, ptr %t267, i32 0, i32 0
  %t273 = load double, ptr %t272
  %t274 = getelementptr %C._pystachy_complex$complex, ptr %t267, i32 0, i32 1
  %t275 = load double, ptr %t274
  %t276 = fcmp oeq double %t275, 0.0
  %t277 = call i64 @pys_cmp_if(i64 %t259, double %t273)
  %t278 = icmp eq i64 %t277, 2
  %t279 = sub i64 0, %t277
  %t280 = select i1 %t278, i64 2, i64 %t279
  %t281 = icmp eq i64 %t280, 0
  %t282 = and i1 %t276, %t281
  br label %L271
L271:
  %t283 = phi i1 [false, %L269], [%t282, %L270]
  br label %L260
L262:
  br label %L284
L284:
  %t285 = getelementptr i64, ptr %t159, i64 1
  %t286 = load i64, ptr %t285
  %t287 = icmp eq i64 %t259, %t286
  br label %L260
L260:
  %t288 = phi i1 [%t283, %L271], [%t287, %L284]
  br label %L243
L243:
  %t289 = phi i1 [%t256, %L253], [%t288, %L260]
  br i1 %t289, label %L160, label %L290
L290:
  call void @pys_raise(ptr @s.9, ptr @s.8)
  unreachable
L160:
  %t291 = phi i64 [0, %L169], [0, %L178], [1, %L234], [1, %L243]
  %t292 = load ptr, ptr %x.2
  %t293 = load ptr, ptr %y.3
  %t294 = call ptr @pys_alloc(i64 8)
  %t295 = ptrtoint ptr %t293 to i64
  %t296 = getelementptr i64, ptr %t294, i64 0
  store i64 %t295, ptr %t296
  %t298 = getelementptr i64, ptr %t294, i64 0
  %t299 = load i64, ptr %t298
  %t300 = inttoptr i64 %t299 to ptr
  %t301 = load i64, ptr %t300
  %t302 = icmp eq i64 %t301, 1
  %t303 = load i64, ptr %t292
  %t304 = icmp eq i64 %t303, 1
  %t305 = and i1 %t302, %t304
  br i1 %t305, label %L306, label %L307
L306:
  %t308 = getelementptr i64, ptr %t300, i64 1
  %t309 = load i64, ptr %t308
  %t310 = inttoptr i64 %t309 to ptr
  %t311 = getelementptr i64, ptr %t292, i64 1
  %t312 = load i64, ptr %t311
  %t313 = inttoptr i64 %t312 to ptr
  %t314 = icmp eq ptr %t310, %t313
  br i1 %t314, label %L297, label %L307
L307:
  %t318 = load i64, ptr %t300
  %t319 = icmp eq i64 %t318, 1
  br i1 %t319, label %L316, label %L317
L316:
  %t320 = getelementptr i64, ptr %t300, i64 1
  %t321 = load i64, ptr %t320
  %t322 = inttoptr i64 %t321 to ptr
  %t326 = icmp eq ptr %t322, null
  br i1 %t326, label %L323, label %L324
L323:
  br label %L325
L324:
  %t327 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t322, ptr %t292)
  br label %L325
L325:
  %t328 = phi i1 [false, %L323], [%t327, %L324]
  br label %L315
L317:
  br label %L329
L329:
  %t330 = getelementptr i64, ptr %t300, i64 1
  %t331 = load i64, ptr %t330
  %t335 = load i64, ptr %t292
  %t336 = icmp eq i64 %t335, 1
  br i1 %t336, label %L333, label %L334
L333:
  %t337 = getelementptr i64, ptr %t292, i64 1
  %t338 = load i64, ptr %t337
  %t339 = inttoptr i64 %t338 to ptr
  %t340 = icmp eq ptr %t339, null
  br i1 %t340, label %L341, label %L342
L341:
  br label %L343
L342:
  %t344 = getelementptr %C._pystachy_complex$complex, ptr %t339, i32 0, i32 0
  %t345 = load double, ptr %t344
  %t346 = getelementptr %C._pystachy_complex$complex, ptr %t339, i32 0, i32 1
  %t347 = load double, ptr %t346
  %t348 = fcmp oeq double %t347, 0.0
  %t349 = call i64 @pys_cmp_if(i64 %t331, double %t345)
  %t350 = icmp eq i64 %t349, 2
  %t351 = sub i64 0, %t349
  %t352 = select i1 %t350, i64 2, i64 %t351
  %t353 = icmp eq i64 %t352, 0
  %t354 = and i1 %t348, %t353
  br label %L343
L343:
  %t355 = phi i1 [false, %L341], [%t354, %L342]
  br label %L332
L334:
  br label %L356
L356:
  %t357 = getelementptr i64, ptr %t292, i64 1
  %t358 = load i64, ptr %t357
  %t359 = icmp eq i64 %t331, %t358
  br label %L332
L332:
  %t360 = phi i1 [%t355, %L343], [%t359, %L356]
  br label %L315
L315:
  %t361 = phi i1 [%t328, %L325], [%t360, %L332]
  br i1 %t361, label %L297, label %L362
L362:
  br label %L297
L297:
  %t363 = phi i1 [true, %L306], [true, %L315], [false, %L362]
  %t364 = load ptr, ptr %x.2
  %t365 = load ptr, ptr %y.3
  %t366 = call ptr @pys_alloc(i64 16)
  %t367 = ptrtoint ptr %t364 to i64
  %t368 = getelementptr i64, ptr %t366, i64 0
  store i64 %t367, ptr %t368
  %t369 = ptrtoint ptr %t365 to i64
  %t370 = getelementptr i64, ptr %t366, i64 1
  store i64 %t369, ptr %t370
  %t371 = load ptr, ptr %y.3
  store i64 0, ptr %h.372
  %t374 = getelementptr i64, ptr %t366, i64 0
  %t375 = load i64, ptr %t374
  %t376 = inttoptr i64 %t375 to ptr
  %t377 = load i64, ptr %t376
  %t378 = icmp eq i64 %t377, 1
  %t379 = load i64, ptr %t371
  %t380 = icmp eq i64 %t379, 1
  %t381 = and i1 %t378, %t380
  br i1 %t381, label %L382, label %L383
L382:
  %t384 = getelementptr i64, ptr %t376, i64 1
  %t385 = load i64, ptr %t384
  %t386 = inttoptr i64 %t385 to ptr
  %t387 = getelementptr i64, ptr %t371, i64 1
  %t388 = load i64, ptr %t387
  %t389 = inttoptr i64 %t388 to ptr
  %t390 = icmp eq ptr %t386, %t389
  br i1 %t390, label %L373, label %L383
L383:
  %t394 = load i64, ptr %t376
  %t395 = icmp eq i64 %t394, 1
  br i1 %t395, label %L392, label %L393
L392:
  %t396 = getelementptr i64, ptr %t376, i64 1
  %t397 = load i64, ptr %t396
  %t398 = inttoptr i64 %t397 to ptr
  %t402 = icmp eq ptr %t398, null
  br i1 %t402, label %L399, label %L400
L399:
  br label %L401
L400:
  %t403 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t398, ptr %t371)
  br label %L401
L401:
  %t404 = phi i1 [false, %L399], [%t403, %L400]
  br label %L391
L393:
  br label %L405
L405:
  %t406 = getelementptr i64, ptr %t376, i64 1
  %t407 = load i64, ptr %t406
  %t411 = load i64, ptr %t371
  %t412 = icmp eq i64 %t411, 1
  br i1 %t412, label %L409, label %L410
L409:
  %t413 = getelementptr i64, ptr %t371, i64 1
  %t414 = load i64, ptr %t413
  %t415 = inttoptr i64 %t414 to ptr
  %t416 = icmp eq ptr %t415, null
  br i1 %t416, label %L417, label %L418
L417:
  br label %L419
L418:
  %t420 = getelementptr %C._pystachy_complex$complex, ptr %t415, i32 0, i32 0
  %t421 = load double, ptr %t420
  %t422 = getelementptr %C._pystachy_complex$complex, ptr %t415, i32 0, i32 1
  %t423 = load double, ptr %t422
  %t424 = fcmp oeq double %t423, 0.0
  %t425 = call i64 @pys_cmp_if(i64 %t407, double %t421)
  %t426 = icmp eq i64 %t425, 2
  %t427 = sub i64 0, %t425
  %t428 = select i1 %t426, i64 2, i64 %t427
  %t429 = icmp eq i64 %t428, 0
  %t430 = and i1 %t424, %t429
  br label %L419
L419:
  %t431 = phi i1 [false, %L417], [%t430, %L418]
  br label %L408
L410:
  br label %L432
L432:
  %t433 = getelementptr i64, ptr %t371, i64 1
  %t434 = load i64, ptr %t433
  %t435 = icmp eq i64 %t407, %t434
  br label %L408
L408:
  %t436 = phi i1 [%t431, %L419], [%t435, %L432]
  br label %L391
L391:
  %t437 = phi i1 [%t404, %L401], [%t436, %L408]
  br i1 %t437, label %L373, label %L438
L438:
  br label %L439
L373:
  %t440 = load i64, ptr %h.372
  %t441 = add i64 %t440, 1
  store i64 %t441, ptr %h.372
  br label %L439
L439:
  %t443 = getelementptr i64, ptr %t366, i64 1
  %t444 = load i64, ptr %t443
  %t445 = inttoptr i64 %t444 to ptr
  %t446 = load i64, ptr %t445
  %t447 = icmp eq i64 %t446, 1
  %t448 = load i64, ptr %t371
  %t449 = icmp eq i64 %t448, 1
  %t450 = and i1 %t447, %t449
  br i1 %t450, label %L451, label %L452
L451:
  %t453 = getelementptr i64, ptr %t445, i64 1
  %t454 = load i64, ptr %t453
  %t455 = inttoptr i64 %t454 to ptr
  %t456 = getelementptr i64, ptr %t371, i64 1
  %t457 = load i64, ptr %t456
  %t458 = inttoptr i64 %t457 to ptr
  %t459 = icmp eq ptr %t455, %t458
  br i1 %t459, label %L442, label %L452
L452:
  %t463 = load i64, ptr %t445
  %t464 = icmp eq i64 %t463, 1
  br i1 %t464, label %L461, label %L462
L461:
  %t465 = getelementptr i64, ptr %t445, i64 1
  %t466 = load i64, ptr %t465
  %t467 = inttoptr i64 %t466 to ptr
  %t471 = icmp eq ptr %t467, null
  br i1 %t471, label %L468, label %L469
L468:
  br label %L470
L469:
  %t472 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t467, ptr %t371)
  br label %L470
L470:
  %t473 = phi i1 [false, %L468], [%t472, %L469]
  br label %L460
L462:
  br label %L474
L474:
  %t475 = getelementptr i64, ptr %t445, i64 1
  %t476 = load i64, ptr %t475
  %t480 = load i64, ptr %t371
  %t481 = icmp eq i64 %t480, 1
  br i1 %t481, label %L478, label %L479
L478:
  %t482 = getelementptr i64, ptr %t371, i64 1
  %t483 = load i64, ptr %t482
  %t484 = inttoptr i64 %t483 to ptr
  %t485 = icmp eq ptr %t484, null
  br i1 %t485, label %L486, label %L487
L486:
  br label %L488
L487:
  %t489 = getelementptr %C._pystachy_complex$complex, ptr %t484, i32 0, i32 0
  %t490 = load double, ptr %t489
  %t491 = getelementptr %C._pystachy_complex$complex, ptr %t484, i32 0, i32 1
  %t492 = load double, ptr %t491
  %t493 = fcmp oeq double %t492, 0.0
  %t494 = call i64 @pys_cmp_if(i64 %t476, double %t490)
  %t495 = icmp eq i64 %t494, 2
  %t496 = sub i64 0, %t494
  %t497 = select i1 %t495, i64 2, i64 %t496
  %t498 = icmp eq i64 %t497, 0
  %t499 = and i1 %t493, %t498
  br label %L488
L488:
  %t500 = phi i1 [false, %L486], [%t499, %L487]
  br label %L477
L479:
  br label %L501
L501:
  %t502 = getelementptr i64, ptr %t371, i64 1
  %t503 = load i64, ptr %t502
  %t504 = icmp eq i64 %t476, %t503
  br label %L477
L477:
  %t505 = phi i1 [%t500, %L488], [%t504, %L501]
  br label %L460
L460:
  %t506 = phi i1 [%t473, %L470], [%t505, %L477]
  br i1 %t506, label %L442, label %L507
L507:
  br label %L508
L442:
  %t509 = load i64, ptr %h.372
  %t510 = add i64 %t509, 1
  store i64 %t510, ptr %h.372
  br label %L508
L508:
  %t511 = load i64, ptr %h.372
  %t512 = select i1 %t75, ptr @s.10, ptr @s.11
  call void @pys_write(ptr %t512, i64 1)
  call void @pys_write(ptr @s.3, i64 1)
  %t513 = call ptr @pys_str_int(i64 %t151)
  call void @pys_write(ptr %t513, i64 1)
  call void @pys_write(ptr @s.3, i64 1)
  %t514 = call ptr @pys_str_int(i64 %t291)
  call void @pys_write(ptr %t514, i64 1)
  call void @pys_write(ptr @s.3, i64 1)
  %t515 = select i1 %t363, ptr @s.10, ptr @s.11
  call void @pys_write(ptr %t515, i64 1)
  call void @pys_write(ptr @s.3, i64 1)
  %t516 = call ptr @pys_str_int(i64 %t511)
  call void @pys_write(ptr %t516, i64 1)
  call void @pys_write(ptr @s.4, i64 1)
  ret void
}

define i32 @main(i32 %argc, ptr %argv) {
  %sb = call ptr @llvm.frameaddress.p0(i32 0)
  call void @pys_init(i32 %argc, ptr %argv, ptr %sb, ptr @pys.roots, i64 1)
  call void @main.init()
  call void @pys_finish()
  ret i32 0
}
