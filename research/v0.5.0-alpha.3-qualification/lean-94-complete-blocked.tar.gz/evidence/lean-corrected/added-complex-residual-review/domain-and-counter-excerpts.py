# check_lean_guards.py: the exact conservative domain parser
    "read, boxed and stored in split union locals only as their box's member, and removed null checks "
    "redundant in the before-pass graph in the access model (fields, tracked globals, closure cells "
    "and write effects) or the finite-tag model. The Python adapters (their dominance and call-graph "
    "analyses included), inspection fidelity (split slot records included), the field checker's "
    "initialization proof, IR operand and container item types, runtime callbacks' arguments, the "
    "classes table, runtime effect contracts and union tag/layout ABI are trusted. Does not prove "
    "reconstruction from other tag sources, closure cells, GC, lifetime, pass equivalence or "
    "source/LLVM semantics. Unsupported forms fail closed."
)


def union_members(typ):
    optional = typ.startswith("opt[") and typ.endswith("]")
    if optional:
        typ = typ[4:-1]
    if not typ.startswith("union[") or not typ.endswith("]"):
        return None
    body, level, start, parts = typ[6:-1], 0, 0, []
    for pos, char in enumerate(body):
        if char == "[":
            level += 1
        elif char == "]":
            level -= 1
        elif char == "," and level == 0:
            parts.append(body[start:pos])
            start = pos + 1
        boundary.require(level >= 0, "unbalanced union type")
    parts.append(body[start:])
    boundary.require(level == 0 and len(parts) >= 2 and len(set(parts)) == len(parts)
                     and all(parts), "invalid union type")
    # Class/file union members may themselves be null. Conservatively retain null
    # unless every member belongs to a known nonnullable value representation.
    value = {"int", "float", "bool", "str", "bytes", "big", "complex"}
    nullable = optional or any(p not in value and not p.startswith(
        ("list[", "dict[", "set[", "frozenset[", "tuple[")) for p in parts)
    return sorted(["member:" + part for part in parts] + ([NULL] if nullable else []))


def field_word(classes, layouts, cls, index):

# check_lean_guards.py: common closed-union verdict counters
            "proved_union_returns": len(returns),
            "removed_checks": sum(r["reported_rewrites"] for r in snapshot["nullcheck_evidence"]),
            "proved_union_reads": sum(r.get("obligations", 0) for r in records if r["status"] == "accepted"
                                      and r.get("scope") == "closed-union guards"),
            "payload_obligations": sum(r.get("payload_obligations", 0) for r in records
                                       if r.get("scope") == "closed-union guards"),
            "proved_payload_obligations": sum(r.get("payload_obligations", 0) for r in records
                                              if r["status"] == "accepted" and r.get("scope") == "closed-union guards"),
            "proved_removed_checks": sum(r.get("obligations", 0) for r in records if r["status"] == "accepted"
                                         and r.get("scope") == REMOVALS),

# lean_report.py: the shared function listing and separate payload counter
)
# (union payload bits are proved with their function's union reads: one list names both)
LISTED_WITH = {"union_payload": "union"}
# What a report's counts are made from, as git pathspecs (a `*` also matches `/`): a change to

def guard_checks(snapshot, checker, access_checker):
    results, contracts = fields.check_all(snapshot, checker)
    report, _ = guards.check_all(snapshot, checker, access_checker, field_results=(results, contracts))
    removals = [r for r in report["records"] if r.get("scope") == guards.REMOVALS]
    unions = [r for r in report["records"] if r.get("scope") != guards.REMOVALS]
    return {
        "null": counted(len(removals), report["removed_checks"], report["proved_removed_checks"], removals,
                        "obligations"),
        "union": counted(len(unions), report["union_reads"], report["proved_union_reads"], unions,
                         "obligations"),
        "union_payload": counted(sum(r.get("payload_obligations", 0) > 0 for r in unions),
                                 report["payload_obligations"], report["proved_payload_obligations"], [], ""),
        "fields": counted(len(results), sum(r.get("obligations", 0) for r in results),
                          sum(r.get("obligations", 0) for r in results if r["status"] == "accepted"),
                          results, "obligations"),
    }
