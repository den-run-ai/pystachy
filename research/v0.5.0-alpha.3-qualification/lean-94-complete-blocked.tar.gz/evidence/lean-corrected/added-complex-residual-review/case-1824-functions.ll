define internal void @main.init() {
entry:
  %t2 = call ptr @pys_list_new_atomic(i64 1)
  call void @pys_list_append(ptr %t2, i64 1)
  %t3 = ptrtoint ptr %t2 to i64
  %t4 = call ptr @pys_ubox(i64 1, i64 %t3)
  %t5 = call ptr @pys_list_new_atomic(i64 1)
  %t6 = bitcast double 1.0 to i64
  call void @pys_list_append(ptr %t5, i64 %t6)
  call void @f.lists(ptr %t4, ptr %t5)
  %t7 = call ptr @pys_list_new_atomic(i64 1)
  call void @pys_list_append(ptr %t7, i64 2)
  %t8 = ptrtoint ptr %t7 to i64
  %t9 = call ptr @pys_ubox(i64 1, i64 %t8)
  %t10 = call ptr @pys_list_new_atomic(i64 1)
  %t11 = bitcast double 1.0 to i64
  call void @pys_list_append(ptr %t10, i64 %t11)
  call void @f.lists(ptr %t9, ptr %t10)
  %t12 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t12, double 0.0, double 1.0)
  %t13 = ptrtoint ptr %t12 to i64
  %t14 = call ptr @pys_ubox(i64 2, i64 %t13)
  %t15 = call ptr @pys_list_new_atomic(i64 1)
  %t16 = bitcast double 1.0 to i64
  call void @pys_list_append(ptr %t15, i64 %t16)
  call void @f.lists(ptr %t14, ptr %t15)
  %t17 = call ptr @pys_dict_new_atomic(i64 1, i64 1)
  %t18 = ptrtoint ptr @s.0 to i64
  call void @pys_dict_set(ptr %t17, i64 %t18, i64 1)
  %t19 = ptrtoint ptr %t17 to i64
  %t20 = call ptr @pys_ubox(i64 3, i64 %t19)
  %t21 = call ptr @pys_dict_new_atomic(i64 1, i64 1)
  %t22 = ptrtoint ptr @s.0 to i64
  %t23 = bitcast double 1.0 to i64
  call void @pys_dict_set(ptr %t21, i64 %t22, i64 %t23)
  call void @f.dicts(ptr %t20, ptr %t21)
  %t24 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t24, double 0.0, double 0.0)
  %t25 = sitofp i64 1 to double
  %t26 = getelementptr %C._pystachy_complex$complex, ptr %t24, i32 0, i32 0
  %t27 = load double, ptr %t26
  %t28 = getelementptr %C._pystachy_complex$complex, ptr %t24, i32 0, i32 1
  %t29 = load double, ptr %t28
  %t30 = call ptr @f._pystachy_complex$_sum(double %t25, double 0.0, double %t27, double %t29)
  %t31 = ptrtoint ptr %t30 to i64
  %t32 = call ptr @pys_ubox(i64 2, i64 %t31)
  %t33 = call ptr @pys_dict_new_atomic(i64 1, i64 1)
  %t34 = ptrtoint ptr @s.0 to i64
  %t35 = bitcast double 1.0 to i64
  call void @pys_dict_set(ptr %t33, i64 %t34, i64 %t35)
  call void @f.dicts(ptr %t32, ptr %t33)
  %t36 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t36, double 0.0, double 1.0)
  %t37 = ptrtoint ptr %t36 to i64
  %t38 = call ptr @pys_ubox(i64 2, i64 %t37)
  %t39 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t39, double 0.0, double 1.0)
  %t40 = ptrtoint ptr %t39 to i64
  %t41 = call ptr @pys_ubox(i64 2, i64 %t40)
  call void @f.search(ptr %t38, ptr %t41)
  %t42 = call ptr @pys_list_new_atomic(i64 1)
  call void @pys_list_append(ptr %t42, i64 1)
  %t43 = ptrtoint ptr %t42 to i64
  %t44 = call ptr @pys_ubox(i64 1, i64 %t43)
  %t45 = call ptr @pys_list_new_atomic(i64 1)
  call void @pys_list_append(ptr %t45, i64 1)
  %t46 = ptrtoint ptr %t45 to i64
  %t47 = call ptr @pys_ubox(i64 1, i64 %t46)
  call void @f.search(ptr %t44, ptr %t47)
  %t48 = call ptr @pys_list_new_atomic(i64 1)
  call void @pys_list_append(ptr %t48, i64 1)
  %t49 = ptrtoint ptr %t48 to i64
  %t50 = call ptr @pys_ubox(i64 1, i64 %t49)
  %t51 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t51, double 0.0, double 2.0)
  %t52 = ptrtoint ptr %t51 to i64
  %t53 = call ptr @pys_ubox(i64 2, i64 %t52)
  call void @f.search(ptr %t50, ptr %t53)
  %t54 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t54, double 0.0, double 2.0)
  %t55 = ptrtoint ptr %t54 to i64
  %t56 = call ptr @pys_ubox(i64 2, i64 %t55)
  %t57 = call ptr @pys_list_new_atomic(i64 1)
  call void @pys_list_append(ptr %t57, i64 1)
  %t58 = ptrtoint ptr %t57 to i64
  %t59 = call ptr @pys_ubox(i64 1, i64 %t58)
  call void @f.search(ptr %t56, ptr %t59)
  ret void
}

define internal void @f.lists(ptr %a0, ptr %a1) {
entry:
  %x.2 = alloca ptr
  store ptr zeroinitializer, ptr %x.2
  %y.3 = alloca ptr
  store ptr zeroinitializer, ptr %y.3
  %t1 = call i64 @pys.recursion.enter()
  %t72 = sub i64 %t1, 1
  store ptr %a0, ptr %x.2
  store ptr %a1, ptr %y.3
  %t4 = load ptr, ptr %x.2
  %t5 = load ptr, ptr %y.3
  %t9 = load i64, ptr %t4
  %t10 = icmp eq i64 %t9, 2
  br i1 %t10, label %L7, label %L8
L7:
  br label %L6
L8:
  br label %L11
L11:
  %t12 = getelementptr i64, ptr %t4, i64 1
  %t13 = load i64, ptr %t12
  %t14 = inttoptr i64 %t13 to ptr
  %t15 = ptrtoint ptr %t14 to i64
  %t16 = ptrtoint ptr %t5 to i64
  %t17 = call i64 @pys_eq_pair(i64 %t15, i64 %t16, ptr @s.3, ptr @s.4)
  %t18 = icmp ne i64 %t17, 0
  br label %L6
L6:
  %t19 = phi i1 [false, %L7], [%t18, %L11]
  %t20 = load ptr, ptr %y.3
  %t21 = load ptr, ptr %x.2
  %t25 = load i64, ptr %t21
  %t26 = icmp eq i64 %t25, 2
  br i1 %t26, label %L23, label %L24
L23:
  br label %L22
L24:
  br label %L27
L27:
  %t28 = getelementptr i64, ptr %t21, i64 1
  %t29 = load i64, ptr %t28
  %t30 = inttoptr i64 %t29 to ptr
  %t31 = ptrtoint ptr %t20 to i64
  %t32 = ptrtoint ptr %t30 to i64
  %t33 = call i64 @pys_eq_pair(i64 %t31, i64 %t32, ptr @s.4, ptr @s.3)
  %t34 = icmp ne i64 %t33, 0
  br label %L22
L22:
  %t35 = phi i1 [false, %L23], [%t34, %L27]
  %t36 = load ptr, ptr %x.2
  %t37 = load ptr, ptr %y.3
  %t41 = load i64, ptr %t36
  %t42 = icmp eq i64 %t41, 2
  br i1 %t42, label %L39, label %L40
L39:
  br label %L38
L40:
  br label %L43
L43:
  %t44 = getelementptr i64, ptr %t36, i64 1
  %t45 = load i64, ptr %t44
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = ptrtoint ptr %t46 to i64
  %t48 = ptrtoint ptr %t37 to i64
  %t49 = call i64 @pys_eq_pair(i64 %t47, i64 %t48, ptr @s.3, ptr @s.4)
  %t50 = icmp eq i64 %t49, 0
  br label %L38
L38:
  %t51 = phi i1 [true, %L39], [%t50, %L43]
  %t52 = load ptr, ptr %y.3
  %t53 = load ptr, ptr %x.2
  %t57 = load i64, ptr %t53
  %t58 = icmp eq i64 %t57, 2
  br i1 %t58, label %L55, label %L56
L55:
  br label %L54
L56:
  br label %L59
L59:
  %t60 = getelementptr i64, ptr %t53, i64 1
  %t61 = load i64, ptr %t60
  %t62 = inttoptr i64 %t61 to ptr
  %t63 = ptrtoint ptr %t52 to i64
  %t64 = ptrtoint ptr %t62 to i64
  %t65 = call i64 @pys_eq_pair(i64 %t63, i64 %t64, ptr @s.4, ptr @s.3)
  %t66 = icmp eq i64 %t65, 0
  br label %L54
L54:
  %t67 = phi i1 [true, %L55], [%t66, %L59]
  %t68 = select i1 %t19, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t68, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t69 = select i1 %t35, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t69, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t70 = select i1 %t51, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t70, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t71 = select i1 %t67, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t71, i64 1)
  call void @pys_write(ptr @s.2, i64 1)
  store i64 %t72, ptr @pys_recursion_state, !tbaa !6
  ret void
}

define internal void @f.dicts(ptr %a0, ptr %a1) {
entry:
  %x.2 = alloca ptr
  store ptr zeroinitializer, ptr %x.2
  %y.3 = alloca ptr
  store ptr zeroinitializer, ptr %y.3
  %t1 = call i64 @pys.recursion.enter()
  %t55 = sub i64 %t1, 1
  store ptr %a0, ptr %x.2
  store ptr %a1, ptr %y.3
  %t4 = load ptr, ptr %x.2
  %t5 = load ptr, ptr %y.3
  %t9 = load i64, ptr %t4
  %t10 = icmp eq i64 %t9, 2
  br i1 %t10, label %L7, label %L8
L7:
  br label %L6
L8:
  br label %L11
L11:
  %t12 = getelementptr i64, ptr %t4, i64 1
  %t13 = load i64, ptr %t12
  %t14 = inttoptr i64 %t13 to ptr
  %t15 = ptrtoint ptr %t14 to i64
  %t16 = ptrtoint ptr %t5 to i64
  %t17 = call i64 @pys_eq_pair(i64 %t15, i64 %t16, ptr @s.7, ptr @s.8)
  %t18 = icmp ne i64 %t17, 0
  br label %L6
L6:
  %t19 = phi i1 [false, %L7], [%t18, %L11]
  %t20 = load ptr, ptr %y.3
  %t21 = load ptr, ptr %x.2
  %t25 = load i64, ptr %t21
  %t26 = icmp eq i64 %t25, 2
  br i1 %t26, label %L23, label %L24
L23:
  br label %L22
L24:
  br label %L27
L27:
  %t28 = getelementptr i64, ptr %t21, i64 1
  %t29 = load i64, ptr %t28
  %t30 = inttoptr i64 %t29 to ptr
  %t31 = ptrtoint ptr %t20 to i64
  %t32 = ptrtoint ptr %t30 to i64
  %t33 = call i64 @pys_eq_pair(i64 %t31, i64 %t32, ptr @s.8, ptr @s.7)
  %t34 = icmp ne i64 %t33, 0
  br label %L22
L22:
  %t35 = phi i1 [false, %L23], [%t34, %L27]
  %t36 = load ptr, ptr %x.2
  %t37 = load ptr, ptr %y.3
  %t41 = load i64, ptr %t36
  %t42 = icmp eq i64 %t41, 2
  br i1 %t42, label %L39, label %L40
L39:
  br label %L38
L40:
  br label %L43
L43:
  %t44 = getelementptr i64, ptr %t36, i64 1
  %t45 = load i64, ptr %t44
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = ptrtoint ptr %t46 to i64
  %t48 = ptrtoint ptr %t37 to i64
  %t49 = call i64 @pys_eq_pair(i64 %t47, i64 %t48, ptr @s.7, ptr @s.8)
  %t50 = icmp eq i64 %t49, 0
  br label %L38
L38:
  %t51 = phi i1 [true, %L39], [%t50, %L43]
  %t52 = select i1 %t19, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t52, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t53 = select i1 %t35, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t53, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t54 = select i1 %t51, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t54, i64 1)
  call void @pys_write(ptr @s.2, i64 1)
  store i64 %t55, ptr @pys_recursion_state, !tbaa !6
  ret void
}

define internal i1 @m._pystachy_complex$complex.__eq__.1(ptr nonnull %a0, ptr %a1) {
entry:
  %self.2 = alloca ptr
  store ptr zeroinitializer, ptr %self.2
  %other.3 = alloca ptr
  store ptr zeroinitializer, ptr %other.3
  store ptr %a0, ptr %self.2
  store ptr %a1, ptr %other.3
  %t4 = load ptr, ptr %other.3
  %t5 = load i64, ptr %t4
  %t6 = icmp eq i64 %t5, 2
  br i1 %t6, label %L7, label %L8
L7:
  %t10 = load ptr, ptr %self.2
  %t11 = getelementptr %C._pystachy_complex$complex, ptr %t10, i32 0, i32 0
  %t12 = load double, ptr %t11, !tbaa !16
  %t13 = load ptr, ptr %other.3
  %t16 = icmp eq ptr %t13, null
  br i1 %t16, label %L15, label %L14
L14:
  %t17 = getelementptr i64, ptr %t13, i64 1
  %t18 = load i64, ptr %t17
  %t19 = inttoptr i64 %t18 to ptr
  br label %L15
L15:
  %t20 = phi ptr [null, %L7], [%t19, %L14]
  %t21 = icmp eq ptr %t20, null
  br i1 %t21, label %L22, label %L23
L23:
  %t24 = getelementptr %C._pystachy_complex$complex, ptr %t20, i32 0, i32 0
  %t25 = load double, ptr %t24, !tbaa !16
  %t26 = fcmp oeq double %t12, %t25
  br i1 %t26, label %L27, label %L28
L27:
  %t29 = load ptr, ptr %self.2
  %t30 = getelementptr %C._pystachy_complex$complex, ptr %t29, i32 0, i32 1
  %t31 = load double, ptr %t30, !tbaa !17
  %t32 = load ptr, ptr %other.3
  %t35 = icmp eq ptr %t32, null
  br i1 %t35, label %L34, label %L33
L33:
  %t36 = getelementptr i64, ptr %t32, i64 1
  %t37 = load i64, ptr %t36
  %t38 = inttoptr i64 %t37 to ptr
  br label %L34
L34:
  %t39 = phi ptr [null, %L27], [%t38, %L33]
  %t40 = icmp eq ptr %t39, null
  br i1 %t40, label %L41, label %L42
L42:
  %t43 = getelementptr %C._pystachy_complex$complex, ptr %t39, i32 0, i32 1
  %t44 = load double, ptr %t43, !tbaa !17
  %t45 = fcmp oeq double %t31, %t44
  br label %L28
L28:
  %t46 = phi i1 [%t26, %L23], [%t45, %L42]
  ret i1 %t46
L8:
  br label %L9
L9:
  store i1 true, ptr @d.declined
  ret i1 false
L22:
  call void @pys_raise(ptr @s.10, ptr @s.9)
  unreachable
L41:
  call void @pys_raise(ptr @s.10, ptr @s.11)
  unreachable
}

define internal void @f.search(ptr %a0, ptr %a1) {
entry:
  %x.2 = alloca ptr
  store ptr zeroinitializer, ptr %x.2
  %y.3 = alloca ptr
  store ptr zeroinitializer, ptr %y.3
  %h.132 = alloca i64
  store i64 zeroinitializer, ptr %h.132
  store ptr %a0, ptr %x.2
  store ptr %a1, ptr %y.3
  %t4 = load ptr, ptr %x.2
  %t5 = load ptr, ptr %y.3
  %t9 = load i64, ptr %t4
  %t10 = icmp eq i64 %t9, 2
  br i1 %t10, label %L7, label %L8
L7:
  %t11 = getelementptr i64, ptr %t4, i64 1
  %t12 = load i64, ptr %t11
  %t13 = inttoptr i64 %t12 to ptr
  %t17 = icmp eq ptr %t13, null
  br i1 %t17, label %L14, label %L15
L14:
  br label %L16
L15:
  store i1 false, ptr @d.declined
  %t18 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t13, ptr %t5)
  %t21 = load i1, ptr @d.declined
  br i1 %t21, label %L19, label %L20
L20:
  br label %L16
L19:
  store i1 false, ptr @d.declined
  %t25 = icmp eq ptr %t13, null
  br i1 %t25, label %L22, label %L23
L22:
  call void @pys_raise(ptr @s.13, ptr @s.12)
  unreachable
L23:
  br label %L24
L24:
  %t26 = phi i1 [false, %L23]
  br label %L16
L16:
  %t27 = phi i1 [false, %L14], [%t18, %L20], [%t26, %L24]
  br label %L6
L8:
  br label %L28
L28:
  %t29 = getelementptr i64, ptr %t4, i64 1
  %t30 = load i64, ptr %t29
  %t31 = inttoptr i64 %t30 to ptr
  %t35 = load i64, ptr %t5
  %t36 = icmp eq i64 %t35, 2
  br i1 %t36, label %L33, label %L34
L33:
  br label %L32
L34:
  br label %L37
L37:
  %t38 = getelementptr i64, ptr %t5, i64 1
  %t39 = load i64, ptr %t38
  %t40 = inttoptr i64 %t39 to ptr
  %t41 = ptrtoint ptr %t31 to i64
  %t42 = ptrtoint ptr %t40 to i64
  %t43 = call i64 @pys_eq(i64 %t41, i64 %t42, ptr @s.3)
  %t44 = icmp ne i64 %t43, 0
  br label %L32
L32:
  %t45 = phi i1 [false, %L33], [%t44, %L37]
  br label %L6
L6:
  %t46 = phi i1 [%t27, %L16], [%t45, %L32]
  %t47 = load ptr, ptr %x.2
  %t48 = load ptr, ptr %y.3
  %t49 = call ptr @pys_alloc(i64 8)
  %t50 = ptrtoint ptr %t48 to i64
  %t51 = getelementptr i64, ptr %t49, i64 0
  store i64 %t50, ptr %t51
  %t53 = getelementptr i64, ptr %t49, i64 0
  %t54 = load i64, ptr %t53
  %t55 = inttoptr i64 %t54 to ptr
  %t56 = load i64, ptr %t55
  %t57 = icmp eq i64 %t56, 2
  %t58 = load i64, ptr %t47
  %t59 = icmp eq i64 %t58, 2
  %t60 = and i1 %t57, %t59
  br i1 %t60, label %L61, label %L62
L61:
  %t63 = getelementptr i64, ptr %t55, i64 1
  %t64 = load i64, ptr %t63
  %t65 = inttoptr i64 %t64 to ptr
  %t66 = getelementptr i64, ptr %t47, i64 1
  %t67 = load i64, ptr %t66
  %t68 = inttoptr i64 %t67 to ptr
  %t69 = icmp eq ptr %t65, %t68
  br i1 %t69, label %L52, label %L62
L62:
  %t70 = load i64, ptr %t55
  %t71 = icmp eq i64 %t70, 1
  %t72 = load i64, ptr %t47
  %t73 = icmp eq i64 %t72, 1
  %t74 = and i1 %t71, %t73
  br i1 %t74, label %L75, label %L76
L75:
  %t77 = getelementptr i64, ptr %t55, i64 1
  %t78 = load i64, ptr %t77
  %t79 = inttoptr i64 %t78 to ptr
  %t80 = getelementptr i64, ptr %t47, i64 1
  %t81 = load i64, ptr %t80
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = icmp eq ptr %t79, %t82
  br i1 %t83, label %L52, label %L76
L76:
  %t87 = load i64, ptr %t55
  %t88 = icmp eq i64 %t87, 2
  br i1 %t88, label %L85, label %L86
L85:
  %t89 = getelementptr i64, ptr %t55, i64 1
  %t90 = load i64, ptr %t89
  %t91 = inttoptr i64 %t90 to ptr
  %t95 = icmp eq ptr %t91, null
  br i1 %t95, label %L92, label %L93
L92:
  br label %L94
L93:
  store i1 false, ptr @d.declined
  %t96 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t91, ptr %t47)
  %t99 = load i1, ptr @d.declined
  br i1 %t99, label %L97, label %L98
L98:
  br label %L94
L97:
  store i1 false, ptr @d.declined
  %t103 = icmp eq ptr %t91, null
  br i1 %t103, label %L100, label %L101
L100:
  call void @pys_raise(ptr @s.13, ptr @s.12)
  unreachable
L101:
  br label %L102
L102:
  %t104 = phi i1 [false, %L101]
  br label %L94
L94:
  %t105 = phi i1 [false, %L92], [%t96, %L98], [%t104, %L102]
  br label %L84
L86:
  br label %L106
L106:
  %t107 = getelementptr i64, ptr %t55, i64 1
  %t108 = load i64, ptr %t107
  %t109 = inttoptr i64 %t108 to ptr
  %t113 = load i64, ptr %t47
  %t114 = icmp eq i64 %t113, 2
  br i1 %t114, label %L111, label %L112
L111:
  br label %L110
L112:
  br label %L115
L115:
  %t116 = getelementptr i64, ptr %t47, i64 1
  %t117 = load i64, ptr %t116
  %t118 = inttoptr i64 %t117 to ptr
  %t119 = ptrtoint ptr %t109 to i64
  %t120 = ptrtoint ptr %t118 to i64
  %t121 = call i64 @pys_eq(i64 %t119, i64 %t120, ptr @s.3)
  %t122 = icmp ne i64 %t121, 0
  br label %L110
L110:
  %t123 = phi i1 [false, %L111], [%t122, %L115]
  br label %L84
L84:
  %t124 = phi i1 [%t105, %L94], [%t123, %L110]
  br i1 %t124, label %L52, label %L125
L125:
  br label %L52
L52:
  %t126 = phi i1 [true, %L61], [true, %L75], [true, %L84], [false, %L125]
  %t127 = load ptr, ptr %y.3
  %t128 = call ptr @pys_alloc(i64 8)
  %t129 = ptrtoint ptr %t127 to i64
  %t130 = getelementptr i64, ptr %t128, i64 0
  store i64 %t129, ptr %t130
  %t131 = load ptr, ptr %x.2
  store i64 0, ptr %h.132
  %t134 = getelementptr i64, ptr %t128, i64 0
  %t135 = load i64, ptr %t134
  %t136 = inttoptr i64 %t135 to ptr
  %t137 = load i64, ptr %t136
  %t138 = icmp eq i64 %t137, 2
  %t139 = load i64, ptr %t131
  %t140 = icmp eq i64 %t139, 2
  %t141 = and i1 %t138, %t140
  br i1 %t141, label %L142, label %L143
L142:
  %t144 = getelementptr i64, ptr %t136, i64 1
  %t145 = load i64, ptr %t144
  %t146 = inttoptr i64 %t145 to ptr
  %t147 = getelementptr i64, ptr %t131, i64 1
  %t148 = load i64, ptr %t147
  %t149 = inttoptr i64 %t148 to ptr
  %t150 = icmp eq ptr %t146, %t149
  br i1 %t150, label %L133, label %L143
L143:
  %t151 = load i64, ptr %t136
  %t152 = icmp eq i64 %t151, 1
  %t153 = load i64, ptr %t131
  %t154 = icmp eq i64 %t153, 1
  %t155 = and i1 %t152, %t154
  br i1 %t155, label %L156, label %L157
L156:
  %t158 = getelementptr i64, ptr %t136, i64 1
  %t159 = load i64, ptr %t158
  %t160 = inttoptr i64 %t159 to ptr
  %t161 = getelementptr i64, ptr %t131, i64 1
  %t162 = load i64, ptr %t161
  %t163 = inttoptr i64 %t162 to ptr
  %t164 = icmp eq ptr %t160, %t163
  br i1 %t164, label %L133, label %L157
L157:
  %t168 = load i64, ptr %t136
  %t169 = icmp eq i64 %t168, 2
  br i1 %t169, label %L166, label %L167
L166:
  %t170 = getelementptr i64, ptr %t136, i64 1
  %t171 = load i64, ptr %t170
  %t172 = inttoptr i64 %t171 to ptr
  %t176 = icmp eq ptr %t172, null
  br i1 %t176, label %L173, label %L174
L173:
  br label %L175
L174:
  store i1 false, ptr @d.declined
  %t177 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t172, ptr %t131)
  %t180 = load i1, ptr @d.declined
  br i1 %t180, label %L178, label %L179
L179:
  br label %L175
L178:
  store i1 false, ptr @d.declined
  %t184 = icmp eq ptr %t172, null
  br i1 %t184, label %L181, label %L182
L181:
  call void @pys_raise(ptr @s.13, ptr @s.12)
  unreachable
L182:
  br label %L183
L183:
  %t185 = phi i1 [false, %L182]
  br label %L175
L175:
  %t186 = phi i1 [false, %L173], [%t177, %L179], [%t185, %L183]
  br label %L165
L167:
  br label %L187
L187:
  %t188 = getelementptr i64, ptr %t136, i64 1
  %t189 = load i64, ptr %t188
  %t190 = inttoptr i64 %t189 to ptr
  %t194 = load i64, ptr %t131
  %t195 = icmp eq i64 %t194, 2
  br i1 %t195, label %L192, label %L193
L192:
  br label %L191
L193:
  br label %L196
L196:
  %t197 = getelementptr i64, ptr %t131, i64 1
  %t198 = load i64, ptr %t197
  %t199 = inttoptr i64 %t198 to ptr
  %t200 = ptrtoint ptr %t190 to i64
  %t201 = ptrtoint ptr %t199 to i64
  %t202 = call i64 @pys_eq(i64 %t200, i64 %t201, ptr @s.3)
  %t203 = icmp ne i64 %t202, 0
  br label %L191
L191:
  %t204 = phi i1 [false, %L192], [%t203, %L196]
  br label %L165
L165:
  %t205 = phi i1 [%t186, %L175], [%t204, %L191]
  br i1 %t205, label %L133, label %L206
L206:
  br label %L207
L133:
  %t208 = load i64, ptr %h.132
  %t209 = add i64 %t208, 1
  store i64 %t209, ptr %h.132
  br label %L207
L207:
  %t210 = load i64, ptr %h.132
  %t211 = load ptr, ptr %y.3
  %t212 = load ptr, ptr %x.2
  %t213 = call ptr @pys_alloc(i64 16)
  %t214 = ptrtoint ptr %t211 to i64
  %t215 = getelementptr i64, ptr %t213, i64 0
  store i64 %t214, ptr %t215
  %t216 = ptrtoint ptr %t212 to i64
  %t217 = getelementptr i64, ptr %t213, i64 1
  store i64 %t216, ptr %t217
  %t218 = load ptr, ptr %x.2
  %t220 = getelementptr i64, ptr %t213, i64 0
  %t221 = load i64, ptr %t220
  %t222 = inttoptr i64 %t221 to ptr
  %t223 = load i64, ptr %t222
  %t224 = icmp eq i64 %t223, 2
  %t225 = load i64, ptr %t218
  %t226 = icmp eq i64 %t225, 2
  %t227 = and i1 %t224, %t226
  br i1 %t227, label %L228, label %L229
L228:
  %t230 = getelementptr i64, ptr %t222, i64 1
  %t231 = load i64, ptr %t230
  %t232 = inttoptr i64 %t231 to ptr
  %t233 = getelementptr i64, ptr %t218, i64 1
  %t234 = load i64, ptr %t233
  %t235 = inttoptr i64 %t234 to ptr
  %t236 = icmp eq ptr %t232, %t235
  br i1 %t236, label %L219, label %L229
L229:
  %t237 = load i64, ptr %t222
  %t238 = icmp eq i64 %t237, 1
  %t239 = load i64, ptr %t218
  %t240 = icmp eq i64 %t239, 1
  %t241 = and i1 %t238, %t240
  br i1 %t241, label %L242, label %L243
L242:
  %t244 = getelementptr i64, ptr %t222, i64 1
  %t245 = load i64, ptr %t244
  %t246 = inttoptr i64 %t245 to ptr
  %t247 = getelementptr i64, ptr %t218, i64 1
  %t248 = load i64, ptr %t247
  %t249 = inttoptr i64 %t248 to ptr
  %t250 = icmp eq ptr %t246, %t249
  br i1 %t250, label %L219, label %L243
L243:
  %t254 = load i64, ptr %t222
  %t255 = icmp eq i64 %t254, 2
  br i1 %t255, label %L252, label %L253
L252:
  %t256 = getelementptr i64, ptr %t222, i64 1
  %t257 = load i64, ptr %t256
  %t258 = inttoptr i64 %t257 to ptr
  %t262 = icmp eq ptr %t258, null
  br i1 %t262, label %L259, label %L260
L259:
  br label %L261
L260:
  store i1 false, ptr @d.declined
  %t263 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t258, ptr %t218)
  %t266 = load i1, ptr @d.declined
  br i1 %t266, label %L264, label %L265
L265:
  br label %L261
L264:
  store i1 false, ptr @d.declined
  %t270 = icmp eq ptr %t258, null
  br i1 %t270, label %L267, label %L268
L267:
  call void @pys_raise(ptr @s.13, ptr @s.12)
  unreachable
L268:
  br label %L269
L269:
  %t271 = phi i1 [false, %L268]
  br label %L261
L261:
  %t272 = phi i1 [false, %L259], [%t263, %L265], [%t271, %L269]
  br label %L251
L253:
  br label %L273
L273:
  %t274 = getelementptr i64, ptr %t222, i64 1
  %t275 = load i64, ptr %t274
  %t276 = inttoptr i64 %t275 to ptr
  %t280 = load i64, ptr %t218
  %t281 = icmp eq i64 %t280, 2
  br i1 %t281, label %L278, label %L279
L278:
  br label %L277
L279:
  br label %L282
L282:
  %t283 = getelementptr i64, ptr %t218, i64 1
  %t284 = load i64, ptr %t283
  %t285 = inttoptr i64 %t284 to ptr
  %t286 = ptrtoint ptr %t276 to i64
  %t287 = ptrtoint ptr %t285 to i64
  %t288 = call i64 @pys_eq(i64 %t286, i64 %t287, ptr @s.3)
  %t289 = icmp ne i64 %t288, 0
  br label %L277
L277:
  %t290 = phi i1 [false, %L278], [%t289, %L282]
  br label %L251
L251:
  %t291 = phi i1 [%t272, %L261], [%t290, %L277]
  br i1 %t291, label %L219, label %L292
L292:
  %t293 = getelementptr i64, ptr %t213, i64 1
  %t294 = load i64, ptr %t293
  %t295 = inttoptr i64 %t294 to ptr
  %t296 = load i64, ptr %t295
  %t297 = icmp eq i64 %t296, 2
  %t298 = load i64, ptr %t218
  %t299 = icmp eq i64 %t298, 2
  %t300 = and i1 %t297, %t299
  br i1 %t300, label %L301, label %L302
L301:
  %t303 = getelementptr i64, ptr %t295, i64 1
  %t304 = load i64, ptr %t303
  %t305 = inttoptr i64 %t304 to ptr
  %t306 = getelementptr i64, ptr %t218, i64 1
  %t307 = load i64, ptr %t306
  %t308 = inttoptr i64 %t307 to ptr
  %t309 = icmp eq ptr %t305, %t308
  br i1 %t309, label %L219, label %L302
L302:
  %t310 = load i64, ptr %t295
  %t311 = icmp eq i64 %t310, 1
  %t312 = load i64, ptr %t218
  %t313 = icmp eq i64 %t312, 1
  %t314 = and i1 %t311, %t313
  br i1 %t314, label %L315, label %L316
L315:
  %t317 = getelementptr i64, ptr %t295, i64 1
  %t318 = load i64, ptr %t317
  %t319 = inttoptr i64 %t318 to ptr
  %t320 = getelementptr i64, ptr %t218, i64 1
  %t321 = load i64, ptr %t320
  %t322 = inttoptr i64 %t321 to ptr
  %t323 = icmp eq ptr %t319, %t322
  br i1 %t323, label %L219, label %L316
L316:
  %t327 = load i64, ptr %t295
  %t328 = icmp eq i64 %t327, 2
  br i1 %t328, label %L325, label %L326
L325:
  %t329 = getelementptr i64, ptr %t295, i64 1
  %t330 = load i64, ptr %t329
  %t331 = inttoptr i64 %t330 to ptr
  %t335 = icmp eq ptr %t331, null
  br i1 %t335, label %L332, label %L333
L332:
  br label %L334
L333:
  store i1 false, ptr @d.declined
  %t336 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t331, ptr %t218)
  %t339 = load i1, ptr @d.declined
  br i1 %t339, label %L337, label %L338
L338:
  br label %L334
L337:
  store i1 false, ptr @d.declined
  %t343 = icmp eq ptr %t331, null
  br i1 %t343, label %L340, label %L341
L340:
  call void @pys_raise(ptr @s.13, ptr @s.12)
  unreachable
L341:
  br label %L342
L342:
  %t344 = phi i1 [false, %L341]
  br label %L334
L334:
  %t345 = phi i1 [false, %L332], [%t336, %L338], [%t344, %L342]
  br label %L324
L326:
  br label %L346
L346:
  %t347 = getelementptr i64, ptr %t295, i64 1
  %t348 = load i64, ptr %t347
  %t349 = inttoptr i64 %t348 to ptr
  %t353 = load i64, ptr %t218
  %t354 = icmp eq i64 %t353, 2
  br i1 %t354, label %L351, label %L352
L351:
  br label %L350
L352:
  br label %L355
L355:
  %t356 = getelementptr i64, ptr %t218, i64 1
  %t357 = load i64, ptr %t356
  %t358 = inttoptr i64 %t357 to ptr
  %t359 = ptrtoint ptr %t349 to i64
  %t360 = ptrtoint ptr %t358 to i64
  %t361 = call i64 @pys_eq(i64 %t359, i64 %t360, ptr @s.3)
  %t362 = icmp ne i64 %t361, 0
  br label %L350
L350:
  %t363 = phi i1 [false, %L351], [%t362, %L355]
  br label %L324
L324:
  %t364 = phi i1 [%t345, %L334], [%t363, %L350]
  br i1 %t364, label %L219, label %L365
L365:
  call void @pys_raise(ptr @s.15, ptr @s.14)
  unreachable
L219:
  %t366 = phi i64 [0, %L228], [0, %L242], [0, %L251], [1, %L301], [1, %L315], [1, %L324]
  %t367 = load ptr, ptr %y.3
  %t368 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t368, double 0.0, double 2.0)
  %t369 = load ptr, ptr %x.2
  %t370 = call ptr @pys_alloc(i64 16)
  %t371 = ptrtoint ptr %t368 to i64
  %t372 = getelementptr i64, ptr %t370, i64 0
  store i64 %t371, ptr %t372
  %t373 = ptrtoint ptr %t369 to i64
  %t374 = getelementptr i64, ptr %t370, i64 1
  store i64 %t373, ptr %t374
  %t376 = getelementptr i64, ptr %t370, i64 0
  %t377 = load i64, ptr %t376
  %t378 = inttoptr i64 %t377 to ptr
  %t379 = icmp eq ptr %t378, null
  %t380 = load i64, ptr %t367
  %t381 = icmp eq i64 %t380, 2
  br i1 %t381, label %L382, label %L383
L382:
  %t384 = getelementptr i64, ptr %t367, i64 1
  %t385 = load i64, ptr %t384
  %t386 = inttoptr i64 %t385 to ptr
  %t387 = icmp eq ptr %t378, %t386
  br i1 %t387, label %L375, label %L383
L383:
  %t391 = icmp eq ptr %t378, null
  br i1 %t391, label %L388, label %L389
L388:
  br label %L390
L389:
  store i1 false, ptr @d.declined
  %t392 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t378, ptr %t367)
  %t395 = load i1, ptr @d.declined
  br i1 %t395, label %L393, label %L394
L394:
  br label %L390
L393:
  store i1 false, ptr @d.declined
  %t399 = icmp eq ptr %t378, null
  br i1 %t399, label %L396, label %L397
L396:
  call void @pys_raise(ptr @s.13, ptr @s.12)
  unreachable
L397:
  br label %L398
L398:
  %t400 = phi i1 [false, %L397]
  br label %L390
L390:
  %t401 = phi i1 [false, %L388], [%t392, %L394], [%t400, %L398]
  br i1 %t401, label %L375, label %L402
L402:
  %t403 = getelementptr i64, ptr %t370, i64 1
  %t404 = load i64, ptr %t403
  %t405 = inttoptr i64 %t404 to ptr
  %t406 = load i64, ptr %t405
  %t407 = icmp eq i64 %t406, 2
  %t408 = load i64, ptr %t367
  %t409 = icmp eq i64 %t408, 2
  %t410 = and i1 %t407, %t409
  br i1 %t410, label %L411, label %L412
L411:
  %t413 = getelementptr i64, ptr %t405, i64 1
  %t414 = load i64, ptr %t413
  %t415 = inttoptr i64 %t414 to ptr
  %t416 = getelementptr i64, ptr %t367, i64 1
  %t417 = load i64, ptr %t416
  %t418 = inttoptr i64 %t417 to ptr
  %t419 = icmp eq ptr %t415, %t418
  br i1 %t419, label %L375, label %L412
L412:
  %t420 = load i64, ptr %t405
  %t421 = icmp eq i64 %t420, 1
  %t422 = load i64, ptr %t367
  %t423 = icmp eq i64 %t422, 1
  %t424 = and i1 %t421, %t423
  br i1 %t424, label %L425, label %L426
L425:
  %t427 = getelementptr i64, ptr %t405, i64 1
  %t428 = load i64, ptr %t427
  %t429 = inttoptr i64 %t428 to ptr
  %t430 = getelementptr i64, ptr %t367, i64 1
  %t431 = load i64, ptr %t430
  %t432 = inttoptr i64 %t431 to ptr
  %t433 = icmp eq ptr %t429, %t432
  br i1 %t433, label %L375, label %L426
L426:
  %t437 = load i64, ptr %t405
  %t438 = icmp eq i64 %t437, 2
  br i1 %t438, label %L435, label %L436
L435:
  %t439 = getelementptr i64, ptr %t405, i64 1
  %t440 = load i64, ptr %t439
  %t441 = inttoptr i64 %t440 to ptr
  %t445 = icmp eq ptr %t441, null
  br i1 %t445, label %L442, label %L443
L442:
  br label %L444
L443:
  store i1 false, ptr @d.declined
  %t446 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t441, ptr %t367)
  %t449 = load i1, ptr @d.declined
  br i1 %t449, label %L447, label %L448
L448:
  br label %L444
L447:
  store i1 false, ptr @d.declined
  %t453 = icmp eq ptr %t441, null
  br i1 %t453, label %L450, label %L451
L450:
  call void @pys_raise(ptr @s.13, ptr @s.12)
  unreachable
L451:
  br label %L452
L452:
  %t454 = phi i1 [false, %L451]
  br label %L444
L444:
  %t455 = phi i1 [false, %L442], [%t446, %L448], [%t454, %L452]
  br label %L434
L436:
  br label %L456
L456:
  %t457 = getelementptr i64, ptr %t405, i64 1
  %t458 = load i64, ptr %t457
  %t459 = inttoptr i64 %t458 to ptr
  %t463 = load i64, ptr %t367
  %t464 = icmp eq i64 %t463, 2
  br i1 %t464, label %L461, label %L462
L461:
  br label %L460
L462:
  br label %L465
L465:
  %t466 = getelementptr i64, ptr %t367, i64 1
  %t467 = load i64, ptr %t466
  %t468 = inttoptr i64 %t467 to ptr
  %t469 = ptrtoint ptr %t459 to i64
  %t470 = ptrtoint ptr %t468 to i64
  %t471 = call i64 @pys_eq(i64 %t469, i64 %t470, ptr @s.3)
  %t472 = icmp ne i64 %t471, 0
  br label %L460
L460:
  %t473 = phi i1 [false, %L461], [%t472, %L465]
  br label %L434
L434:
  %t474 = phi i1 [%t455, %L444], [%t473, %L460]
  br i1 %t474, label %L375, label %L475
L475:
  br label %L375
L375:
  %t476 = phi i1 [true, %L382], [true, %L390], [true, %L411], [true, %L425], [true, %L434], [false, %L475]
  %t477 = select i1 %t46, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t477, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t478 = select i1 %t126, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t478, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t479 = call ptr @pys_str_int(i64 %t210)
  call void @pys_write(ptr %t479, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t480 = call ptr @pys_str_int(i64 %t366)
  call void @pys_write(ptr %t480, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t481 = select i1 %t476, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t481, i64 1)
  call void @pys_write(ptr @s.2, i64 1)
  ret void
}

define i32 @main(i32 %argc, ptr %argv) {
  %sb = call ptr @llvm.frameaddress.p0(i32 0)
  call void @pys_init(i32 %argc, ptr %argv, ptr %sb, ptr @pys.roots, i64 0)
  call void @main.init()
  call void @pys_finish()
  ret i32 0
}
