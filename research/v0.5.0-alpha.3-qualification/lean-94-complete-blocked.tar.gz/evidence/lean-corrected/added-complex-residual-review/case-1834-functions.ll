define internal void @main.init() {
entry:
  %h.29 = alloca i64
  store i64 zeroinitializer, ptr %h.29
  %h.574 = alloca i64
  store i64 zeroinitializer, ptr %h.574
  %h.672 = alloca i64
  store i64 zeroinitializer, ptr %h.672
  %h.674 = alloca i64
  store i64 zeroinitializer, ptr %h.674
  %t.686 = alloca ptr
  store ptr zeroinitializer, ptr %t.686
  %h.718 = alloca i64
  store i64 zeroinitializer, ptr %h.718
  %h.720 = alloca i64
  store i64 zeroinitializer, ptr %h.720
  %t.732 = alloca ptr
  store ptr zeroinitializer, ptr %t.732
  store i1 true, ptr @g.Optional.imp
  %t2 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t2, double 0.0, double 4.0)
  %t3 = sitofp i64 3 to double
  %t4 = getelementptr %C._pystachy_complex$complex, ptr %t2, i32 0, i32 0
  %t5 = load double, ptr %t4
  %t6 = getelementptr %C._pystachy_complex$complex, ptr %t2, i32 0, i32 1
  %t7 = load double, ptr %t6
  %t8 = call ptr @f._pystachy_complex$_diff(double %t3, double 0.0, double %t5, double %t7)
  %t9 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t9, double 0.0, double 0.0)
  %t10 = call ptr @pys_ubox(i64 1, i64 1)
  %t11 = zext i1 true to i64
  %t12 = call ptr @pys_ubox(i64 2, i64 %t11)
  %t13 = bitcast double 2.5 to i64
  %t14 = call ptr @pys_ubox(i64 3, i64 %t13)
  %t15 = ptrtoint ptr %t8 to i64
  %t16 = call ptr @pys_ubox(i64 4, i64 %t15)
  %t17 = ptrtoint ptr @s.0 to i64
  %t18 = call ptr @pys_ubox(i64 5, i64 %t17)
  %t19 = ptrtoint ptr %t9 to i64
  %t20 = call ptr @pys_ubox(i64 4, i64 %t19)
  %t21 = call ptr @pys_list_new(i64 6)
  %t22 = ptrtoint ptr %t10 to i64
  call void @pys_list_append(ptr %t21, i64 %t22)
  %t23 = ptrtoint ptr %t12 to i64
  call void @pys_list_append(ptr %t21, i64 %t23)
  %t24 = ptrtoint ptr %t14 to i64
  call void @pys_list_append(ptr %t21, i64 %t24)
  %t25 = ptrtoint ptr %t16 to i64
  call void @pys_list_append(ptr %t21, i64 %t25)
  %t26 = ptrtoint ptr %t18 to i64
  call void @pys_list_append(ptr %t21, i64 %t26)
  %t27 = ptrtoint ptr %t20 to i64
  call void @pys_list_append(ptr %t21, i64 %t27)
  store ptr %t21, ptr @g.vals
  %t28 = load ptr, ptr @g.vals
  store i64 0, ptr %h.29
  %t30 = load i64, ptr %t28
  br label %L31
L31:
  %t34 = load i64, ptr %h.29
  %t35 = load i64, ptr %t28
  %t36 = icmp slt i64 %t34, %t35
  br i1 %t36, label %L37, label %L33
L37:
  %t760 = getelementptr inbounds {i64, i64, ptr}, ptr %t28, i64 0, i32 2
  %t761 = load ptr, ptr %t760, !tbaa !18
  %t762 = getelementptr inbounds i64, ptr %t761, i64 %t34
  %t38 = load i64, ptr %t762, !tbaa !19
  %t39 = inttoptr i64 %t38 to ptr
  store ptr %t39, ptr @g.v
  %t40 = load ptr, ptr @g.v
  %t41 = call ptr @f.describe(ptr %t40)
  %t42 = load ptr, ptr @g.v
  %t43 = load ptr, ptr @g.v
  %t44 = ptrtoint ptr %t43 to i64
  %t45 = call ptr @pys_repr(i64 %t44, ptr @s.3)
  %t46 = load ptr, ptr @g.v
  %t48 = load i64, ptr %t46
  %t51 = icmp eq i64 %t48, 4
  br i1 %t51, label %L50, label %L49
L50:
  %t52 = getelementptr i64, ptr %t46, i64 1
  %t53 = load i64, ptr %t52
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %L56, label %L57
L56:
  %t58 = call i1 @m._pystachy_complex$complex.__bool__(ptr %t54)
  br label %L57
L57:
  %t59 = phi i1 [false, %L50], [%t58, %L56]
  br label %L47
L49:
  %t62 = icmp eq i64 %t48, 2
  br i1 %t62, label %L61, label %L60
L61:
  %t63 = getelementptr i64, ptr %t46, i64 1
  %t64 = load i64, ptr %t63
  %t65 = trunc i64 %t64 to i1
  br label %L47
L60:
  %t68 = icmp eq i64 %t48, 3
  br i1 %t68, label %L67, label %L66
L67:
  %t69 = getelementptr i64, ptr %t46, i64 1
  %t70 = load i64, ptr %t69
  %t71 = bitcast i64 %t70 to double
  %t72 = fcmp une double %t71, 0.0
  br label %L47
L66:
  %t75 = icmp eq i64 %t48, 1
  br i1 %t75, label %L74, label %L73
L74:
  %t76 = getelementptr i64, ptr %t46, i64 1
  %t77 = load i64, ptr %t76
  %t78 = icmp ne i64 %t77, 0
  br label %L47
L73:
  %t79 = getelementptr i64, ptr %t46, i64 1
  %t80 = load i64, ptr %t79
  %t81 = inttoptr i64 %t80 to ptr
  %t82 = load i64, ptr %t81
  %t83 = icmp ne i64 %t82, 0
  br label %L47
L47:
  %t84 = phi i1 [%t59, %L57], [%t65, %L61], [%t72, %L67], [%t78, %L74], [%t83, %L73]
  call void @pys_write(ptr %t41, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t86 = load i64, ptr %t42
  %t89 = icmp eq i64 %t86, 4
  br i1 %t89, label %L88, label %L87
L88:
  %t90 = getelementptr i64, ptr %t42, i64 1
  %t91 = load i64, ptr %t90
  %t92 = inttoptr i64 %t91 to ptr
  %t96 = icmp eq ptr %t92, null
  br i1 %t96, label %L93, label %L94
L93:
  br label %L95
L94:
  %t97 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t92)
  br label %L95
L95:
  %t98 = phi ptr [@s.4, %L93], [%t97, %L94]
  br label %L85
L87:
  %t101 = icmp eq i64 %t86, 2
  br i1 %t101, label %L100, label %L99
L100:
  %t102 = getelementptr i64, ptr %t42, i64 1
  %t103 = load i64, ptr %t102
  %t104 = trunc i64 %t103 to i1
  %t105 = select i1 %t104, ptr @s.5, ptr @s.6
  br label %L85
L99:
  %t108 = icmp eq i64 %t86, 3
  br i1 %t108, label %L107, label %L106
L107:
  %t109 = getelementptr i64, ptr %t42, i64 1
  %t110 = load i64, ptr %t109
  %t111 = bitcast i64 %t110 to double
  %t112 = call ptr @pys_str_float(double %t111)
  br label %L85
L106:
  %t115 = icmp eq i64 %t86, 1
  br i1 %t115, label %L114, label %L113
L114:
  %t116 = getelementptr i64, ptr %t42, i64 1
  %t117 = load i64, ptr %t116
  %t118 = call ptr @pys_str_int(i64 %t117)
  br label %L85
L113:
  %t119 = getelementptr i64, ptr %t42, i64 1
  %t120 = load i64, ptr %t119
  %t121 = inttoptr i64 %t120 to ptr
  br label %L85
L85:
  %t122 = phi ptr [%t98, %L95], [%t105, %L100], [%t112, %L107], [%t118, %L114], [%t121, %L113]
  call void @pys_write(ptr %t122, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  call void @pys_write(ptr %t45, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t123 = select i1 %t84, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t123, i64 1)
  call void @pys_write(ptr @s.2, i64 1)
  br label %L32
L32:
  %t124 = add i64 %t34, 1
  store i64 %t124, ptr %h.29
  br label %L31
L33:
  %t125 = load ptr, ptr @g.vals
  %t126 = ptrtoint ptr %t125 to i64
  %t127 = call ptr @pys_repr(i64 %t126, ptr @s.7)
  call void @pys_write(ptr %t127, i64 1)
  call void @pys_write(ptr @s.2, i64 1)
  %t128 = call ptr @pys_ubox(i64 1, i64 1)
  %t129 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t129, double 0.0, double 2.0)
  %t130 = ptrtoint ptr %t129 to i64
  %t131 = call ptr @pys_ubox(i64 4, i64 %t130)
  %t132 = call ptr @f.fold(ptr @s.8, ptr %t128, ptr %t131)
  %t133 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t133, double 0.0, double 1.0)
  %t134 = ptrtoint ptr %t133 to i64
  %t135 = call ptr @pys_ubox(i64 4, i64 %t134)
  %t136 = bitcast double 2.5 to i64
  %t137 = call ptr @pys_ubox(i64 3, i64 %t136)
  %t138 = call ptr @f.fold(ptr @s.9, ptr %t135, ptr %t137)
  %t139 = call ptr @pys_ubox(i64 1, i64 2)
  %t140 = call ptr @pys_ubox(i64 1, i64 3)
  %t141 = call ptr @f.fold(ptr @s.8, ptr %t139, ptr %t140)
  %t142 = call ptr @pys_ubox(i64 1, i64 1)
  %t143 = call ptr @pys_ubox(i64 1, i64 2)
  %t144 = call ptr @f.fold(ptr @s.10, ptr %t142, ptr %t143)
  %t145 = bitcast double 1.5 to i64
  %t146 = call ptr @pys_ubox(i64 3, i64 %t145)
  %t147 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t147, double 0.0, double 1.0)
  %t148 = sitofp i64 1 to double
  %t149 = getelementptr %C._pystachy_complex$complex, ptr %t147, i32 0, i32 0
  %t150 = load double, ptr %t149
  %t151 = getelementptr %C._pystachy_complex$complex, ptr %t147, i32 0, i32 1
  %t152 = load double, ptr %t151
  %t153 = call ptr @f._pystachy_complex$_sum(double %t148, double 0.0, double %t150, double %t152)
  %t154 = ptrtoint ptr %t153 to i64
  %t155 = call ptr @pys_ubox(i64 4, i64 %t154)
  %t156 = call ptr @f.fold(ptr @s.9, ptr %t146, ptr %t155)
  %t159 = icmp eq ptr %t132, null
  br i1 %t159, label %L157, label %L158
L158:
  %t160 = load i64, ptr %t132
  %t163 = icmp eq i64 %t160, 4
  br i1 %t163, label %L162, label %L161
L162:
  %t164 = getelementptr i64, ptr %t132, i64 1
  %t165 = load i64, ptr %t164
  %t166 = inttoptr i64 %t165 to ptr
  %t170 = icmp eq ptr %t166, null
  br i1 %t170, label %L167, label %L168
L167:
  br label %L169
L168:
  %t171 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t166)
  br label %L169
L169:
  %t172 = phi ptr [@s.4, %L167], [%t171, %L168]
  br label %L157
L161:
  %t175 = icmp eq i64 %t160, 2
  br i1 %t175, label %L174, label %L173
L174:
  %t176 = getelementptr i64, ptr %t132, i64 1
  %t177 = load i64, ptr %t176
  %t178 = trunc i64 %t177 to i1
  %t179 = select i1 %t178, ptr @s.5, ptr @s.6
  br label %L157
L173:
  %t182 = icmp eq i64 %t160, 3
  br i1 %t182, label %L181, label %L180
L181:
  %t183 = getelementptr i64, ptr %t132, i64 1
  %t184 = load i64, ptr %t183
  %t185 = bitcast i64 %t184 to double
  %t186 = call ptr @pys_str_float(double %t185)
  br label %L157
L180:
  %t189 = icmp eq i64 %t160, 1
  br i1 %t189, label %L188, label %L187
L188:
  %t190 = getelementptr i64, ptr %t132, i64 1
  %t191 = load i64, ptr %t190
  %t192 = call ptr @pys_str_int(i64 %t191)
  br label %L157
L187:
  %t193 = getelementptr i64, ptr %t132, i64 1
  %t194 = load i64, ptr %t193
  %t195 = inttoptr i64 %t194 to ptr
  br label %L157
L157:
  %t196 = phi ptr [@s.4, %L33], [%t172, %L169], [%t179, %L174], [%t186, %L181], [%t192, %L188], [%t195, %L187]
  call void @pys_write(ptr %t196, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t199 = icmp eq ptr %t138, null
  br i1 %t199, label %L197, label %L198
L198:
  %t200 = load i64, ptr %t138
  %t203 = icmp eq i64 %t200, 4
  br i1 %t203, label %L202, label %L201
L202:
  %t204 = getelementptr i64, ptr %t138, i64 1
  %t205 = load i64, ptr %t204
  %t206 = inttoptr i64 %t205 to ptr
  %t210 = icmp eq ptr %t206, null
  br i1 %t210, label %L207, label %L208
L207:
  br label %L209
L208:
  %t211 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t206)
  br label %L209
L209:
  %t212 = phi ptr [@s.4, %L207], [%t211, %L208]
  br label %L197
L201:
  %t215 = icmp eq i64 %t200, 2
  br i1 %t215, label %L214, label %L213
L214:
  %t216 = getelementptr i64, ptr %t138, i64 1
  %t217 = load i64, ptr %t216
  %t218 = trunc i64 %t217 to i1
  %t219 = select i1 %t218, ptr @s.5, ptr @s.6
  br label %L197
L213:
  %t222 = icmp eq i64 %t200, 3
  br i1 %t222, label %L221, label %L220
L221:
  %t223 = getelementptr i64, ptr %t138, i64 1
  %t224 = load i64, ptr %t223
  %t225 = bitcast i64 %t224 to double
  %t226 = call ptr @pys_str_float(double %t225)
  br label %L197
L220:
  %t229 = icmp eq i64 %t200, 1
  br i1 %t229, label %L228, label %L227
L228:
  %t230 = getelementptr i64, ptr %t138, i64 1
  %t231 = load i64, ptr %t230
  %t232 = call ptr @pys_str_int(i64 %t231)
  br label %L197
L227:
  %t233 = getelementptr i64, ptr %t138, i64 1
  %t234 = load i64, ptr %t233
  %t235 = inttoptr i64 %t234 to ptr
  br label %L197
L197:
  %t236 = phi ptr [@s.4, %L157], [%t212, %L209], [%t219, %L214], [%t226, %L221], [%t232, %L228], [%t235, %L227]
  call void @pys_write(ptr %t236, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t239 = icmp eq ptr %t141, null
  br i1 %t239, label %L237, label %L238
L238:
  %t240 = load i64, ptr %t141
  %t243 = icmp eq i64 %t240, 4
  br i1 %t243, label %L242, label %L241
L242:
  %t244 = getelementptr i64, ptr %t141, i64 1
  %t245 = load i64, ptr %t244
  %t246 = inttoptr i64 %t245 to ptr
  %t250 = icmp eq ptr %t246, null
  br i1 %t250, label %L247, label %L248
L247:
  br label %L249
L248:
  %t251 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t246)
  br label %L249
L249:
  %t252 = phi ptr [@s.4, %L247], [%t251, %L248]
  br label %L237
L241:
  %t255 = icmp eq i64 %t240, 2
  br i1 %t255, label %L254, label %L253
L254:
  %t256 = getelementptr i64, ptr %t141, i64 1
  %t257 = load i64, ptr %t256
  %t258 = trunc i64 %t257 to i1
  %t259 = select i1 %t258, ptr @s.5, ptr @s.6
  br label %L237
L253:
  %t262 = icmp eq i64 %t240, 3
  br i1 %t262, label %L261, label %L260
L261:
  %t263 = getelementptr i64, ptr %t141, i64 1
  %t264 = load i64, ptr %t263
  %t265 = bitcast i64 %t264 to double
  %t266 = call ptr @pys_str_float(double %t265)
  br label %L237
L260:
  %t269 = icmp eq i64 %t240, 1
  br i1 %t269, label %L268, label %L267
L268:
  %t270 = getelementptr i64, ptr %t141, i64 1
  %t271 = load i64, ptr %t270
  %t272 = call ptr @pys_str_int(i64 %t271)
  br label %L237
L267:
  %t273 = getelementptr i64, ptr %t141, i64 1
  %t274 = load i64, ptr %t273
  %t275 = inttoptr i64 %t274 to ptr
  br label %L237
L237:
  %t276 = phi ptr [@s.4, %L197], [%t252, %L249], [%t259, %L254], [%t266, %L261], [%t272, %L268], [%t275, %L267]
  call void @pys_write(ptr %t276, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t279 = icmp eq ptr %t144, null
  br i1 %t279, label %L277, label %L278
L278:
  %t280 = load i64, ptr %t144
  %t283 = icmp eq i64 %t280, 4
  br i1 %t283, label %L282, label %L281
L282:
  %t284 = getelementptr i64, ptr %t144, i64 1
  %t285 = load i64, ptr %t284
  %t286 = inttoptr i64 %t285 to ptr
  %t290 = icmp eq ptr %t286, null
  br i1 %t290, label %L287, label %L288
L287:
  br label %L289
L288:
  %t291 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t286)
  br label %L289
L289:
  %t292 = phi ptr [@s.4, %L287], [%t291, %L288]
  br label %L277
L281:
  %t295 = icmp eq i64 %t280, 2
  br i1 %t295, label %L294, label %L293
L294:
  %t296 = getelementptr i64, ptr %t144, i64 1
  %t297 = load i64, ptr %t296
  %t298 = trunc i64 %t297 to i1
  %t299 = select i1 %t298, ptr @s.5, ptr @s.6
  br label %L277
L293:
  %t302 = icmp eq i64 %t280, 3
  br i1 %t302, label %L301, label %L300
L301:
  %t303 = getelementptr i64, ptr %t144, i64 1
  %t304 = load i64, ptr %t303
  %t305 = bitcast i64 %t304 to double
  %t306 = call ptr @pys_str_float(double %t305)
  br label %L277
L300:
  %t309 = icmp eq i64 %t280, 1
  br i1 %t309, label %L308, label %L307
L308:
  %t310 = getelementptr i64, ptr %t144, i64 1
  %t311 = load i64, ptr %t310
  %t312 = call ptr @pys_str_int(i64 %t311)
  br label %L277
L307:
  %t313 = getelementptr i64, ptr %t144, i64 1
  %t314 = load i64, ptr %t313
  %t315 = inttoptr i64 %t314 to ptr
  br label %L277
L277:
  %t316 = phi ptr [@s.4, %L237], [%t292, %L289], [%t299, %L294], [%t306, %L301], [%t312, %L308], [%t315, %L307]
  call void @pys_write(ptr %t316, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t319 = icmp eq ptr %t156, null
  br i1 %t319, label %L317, label %L318
L318:
  %t320 = load i64, ptr %t156
  %t323 = icmp eq i64 %t320, 4
  br i1 %t323, label %L322, label %L321
L322:
  %t324 = getelementptr i64, ptr %t156, i64 1
  %t325 = load i64, ptr %t324
  %t326 = inttoptr i64 %t325 to ptr
  %t330 = icmp eq ptr %t326, null
  br i1 %t330, label %L327, label %L328
L327:
  br label %L329
L328:
  %t331 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t326)
  br label %L329
L329:
  %t332 = phi ptr [@s.4, %L327], [%t331, %L328]
  br label %L317
L321:
  %t335 = icmp eq i64 %t320, 2
  br i1 %t335, label %L334, label %L333
L334:
  %t336 = getelementptr i64, ptr %t156, i64 1
  %t337 = load i64, ptr %t336
  %t338 = trunc i64 %t337 to i1
  %t339 = select i1 %t338, ptr @s.5, ptr @s.6
  br label %L317
L333:
  %t342 = icmp eq i64 %t320, 3
  br i1 %t342, label %L341, label %L340
L341:
  %t343 = getelementptr i64, ptr %t156, i64 1
  %t344 = load i64, ptr %t343
  %t345 = bitcast i64 %t344 to double
  %t346 = call ptr @pys_str_float(double %t345)
  br label %L317
L340:
  %t349 = icmp eq i64 %t320, 1
  br i1 %t349, label %L348, label %L347
L348:
  %t350 = getelementptr i64, ptr %t156, i64 1
  %t351 = load i64, ptr %t350
  %t352 = call ptr @pys_str_int(i64 %t351)
  br label %L317
L347:
  %t353 = getelementptr i64, ptr %t156, i64 1
  %t354 = load i64, ptr %t353
  %t355 = inttoptr i64 %t354 to ptr
  br label %L317
L317:
  %t356 = phi ptr [@s.4, %L277], [%t332, %L329], [%t339, %L334], [%t346, %L341], [%t352, %L348], [%t355, %L347]
  call void @pys_write(ptr %t356, i64 1)
  call void @pys_write(ptr @s.2, i64 1)
  %t357 = call ptr @pys_ubox(i64 1, i64 1)
  %t358 = call ptr @pys_ubox(i64 1, i64 1)
  call void @f.numeric(ptr %t357, ptr %t358)
  %t359 = bitcast double 2.5 to i64
  %t360 = call ptr @pys_ubox(i64 3, i64 %t359)
  %t361 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t361, double 0.0, double 3.0)
  %t362 = ptrtoint ptr %t361 to i64
  %t363 = call ptr @pys_ubox(i64 4, i64 %t362)
  call void @f.numeric(ptr %t360, ptr %t363)
  %t364 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t364, double 0.0, double 4.0)
  %t365 = sitofp i64 3 to double
  %t366 = getelementptr %C._pystachy_complex$complex, ptr %t364, i32 0, i32 0
  %t367 = load double, ptr %t366
  %t368 = getelementptr %C._pystachy_complex$complex, ptr %t364, i32 0, i32 1
  %t369 = load double, ptr %t368
  %t370 = call ptr @f._pystachy_complex$_diff(double %t365, double 0.0, double %t367, double %t369)
  %t371 = ptrtoint ptr %t370 to i64
  %t372 = call ptr @pys_ubox(i64 4, i64 %t371)
  %t373 = call ptr @pys_ubox(i64 1, i64 1)
  call void @f.numeric(ptr %t372, ptr %t373)
  %t374 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t374, double 0.0, double 0.0)
  %t375 = sitofp i64 1 to double
  %t376 = getelementptr %C._pystachy_complex$complex, ptr %t374, i32 0, i32 0
  %t377 = load double, ptr %t376
  %t378 = getelementptr %C._pystachy_complex$complex, ptr %t374, i32 0, i32 1
  %t379 = load double, ptr %t378
  %t380 = call ptr @f._pystachy_complex$_sum(double %t375, double 0.0, double %t377, double %t379)
  %t381 = ptrtoint ptr %t380 to i64
  %t382 = call ptr @pys_ubox(i64 4, i64 %t381)
  %t383 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t383, double 0.0, double 0.0)
  %t384 = getelementptr %C._pystachy_complex$complex, ptr %t383, i32 0, i32 0
  %t385 = load double, ptr %t384
  %t386 = getelementptr %C._pystachy_complex$complex, ptr %t383, i32 0, i32 1
  %t387 = load double, ptr %t386
  %t388 = call ptr @f._pystachy_complex$_sum(double 1.0, double 0.0, double %t385, double %t387)
  %t389 = ptrtoint ptr %t388 to i64
  %t390 = call ptr @pys_ubox(i64 4, i64 %t389)
  call void @f.numeric(ptr %t382, ptr %t390)
  %t391 = call ptr @f._pystachy_complex$_two(double 2.5, double 0.0, i1 false, double 0.0, double 0.0, i1 false)
  %t392 = ptrtoint ptr %t391 to i64
  %t393 = call ptr @pys_ubox(i64 4, i64 %t392)
  %t394 = ptrtoint ptr @s.0 to i64
  %t395 = call ptr @pys_ubox(i64 5, i64 %t394)
  call void @f.numeric(ptr %t393, ptr %t395)
  store ptr null, ptr @g.final_value
  %t396 = load ptr, ptr @g.final_value
  %t397 = load ptr, ptr @g.final_value
  %t398 = icmp eq ptr %t397, null
  %t399 = load ptr, ptr @g.final_value
  %t400 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t400, double 0.0, double 1.0)
  store i1 false, ptr @d.declined
  %t401 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t400, ptr %t399)
  %t402 = xor i1 %t401, true
  %t405 = load i1, ptr @d.declined
  br i1 %t405, label %L404, label %L403
L403:
  br label %L406
L404:
  store i1 false, ptr @d.declined
  br label %L406
L406:
  %t407 = phi i1 [%t402, %L403], [true, %L404]
  %t410 = icmp eq ptr %t396, null
  br i1 %t410, label %L408, label %L409
L409:
  %t411 = load i64, ptr %t396
  %t414 = icmp eq i64 %t411, 4
  br i1 %t414, label %L413, label %L412
L413:
  %t415 = getelementptr i64, ptr %t396, i64 1
  %t416 = load i64, ptr %t415
  %t417 = inttoptr i64 %t416 to ptr
  %t421 = icmp eq ptr %t417, null
  br i1 %t421, label %L418, label %L419
L418:
  br label %L420
L419:
  %t422 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t417)
  br label %L420
L420:
  %t423 = phi ptr [@s.4, %L418], [%t422, %L419]
  br label %L408
L412:
  %t426 = icmp eq i64 %t411, 2
  br i1 %t426, label %L425, label %L424
L425:
  %t427 = getelementptr i64, ptr %t396, i64 1
  %t428 = load i64, ptr %t427
  %t429 = trunc i64 %t428 to i1
  %t430 = select i1 %t429, ptr @s.5, ptr @s.6
  br label %L408
L424:
  %t433 = icmp eq i64 %t411, 3
  br i1 %t433, label %L432, label %L431
L432:
  %t434 = getelementptr i64, ptr %t396, i64 1
  %t435 = load i64, ptr %t434
  %t436 = bitcast i64 %t435 to double
  %t437 = call ptr @pys_str_float(double %t436)
  br label %L408
L431:
  %t440 = icmp eq i64 %t411, 1
  br i1 %t440, label %L439, label %L438
L439:
  %t441 = getelementptr i64, ptr %t396, i64 1
  %t442 = load i64, ptr %t441
  %t443 = call ptr @pys_str_int(i64 %t442)
  br label %L408
L438:
  %t444 = getelementptr i64, ptr %t396, i64 1
  %t445 = load i64, ptr %t444
  %t446 = inttoptr i64 %t445 to ptr
  br label %L408
L408:
  %t447 = phi ptr [@s.4, %L406], [%t423, %L420], [%t430, %L425], [%t437, %L432], [%t443, %L439], [%t446, %L438]
  call void @pys_write(ptr %t447, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t448 = select i1 %t398, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t448, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t449 = select i1 %t407, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t449, i64 1)
  call void @pys_write(ptr @s.2, i64 1)
  %t450 = call ptr @f._pystachy_complex$_two(double 1.0, double 0.0, i1 false, double 2.0, double 0.0, i1 false)
  %t451 = ptrtoint ptr %t450 to i64
  %t452 = call ptr @pys_ubox(i64 4, i64 %t451)
  store ptr %t452, ptr @g.final_value
  %t453 = load ptr, ptr @g.final_value
  %t454 = icmp ne ptr %t453, null
  br i1 %t454, label %L455, label %L456
L455:
  %t458 = load ptr, ptr @g.final_value
  %t459 = load ptr, ptr @g.final_value
  %t462 = icmp eq ptr %t459, null
  br i1 %t462, label %L460, label %L461
L461:
  %t463 = load i64, ptr %t459
  %t466 = icmp eq i64 %t463, 4
  br i1 %t466, label %L465, label %L464
L465:
  %t467 = getelementptr i64, ptr %t459, i64 1
  %t468 = load i64, ptr %t467
  %t469 = inttoptr i64 %t468 to ptr
  %t473 = icmp eq ptr %t469, null
  br i1 %t473, label %L470, label %L471
L470:
  br label %L472
L471:
  %t474 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t469)
  br label %L472
L472:
  %t475 = phi ptr [@s.4, %L470], [%t474, %L471]
  br label %L460
L464:
  %t478 = icmp eq i64 %t463, 2
  br i1 %t478, label %L477, label %L476
L477:
  %t479 = getelementptr i64, ptr %t459, i64 1
  %t480 = load i64, ptr %t479
  %t481 = trunc i64 %t480 to i1
  %t482 = select i1 %t481, ptr @s.5, ptr @s.6
  br label %L460
L476:
  %t485 = icmp eq i64 %t463, 3
  br i1 %t485, label %L484, label %L483
L484:
  %t486 = getelementptr i64, ptr %t459, i64 1
  %t487 = load i64, ptr %t486
  %t488 = bitcast i64 %t487 to double
  %t489 = call ptr @pys_str_float(double %t488)
  br label %L460
L483:
  %t492 = icmp eq i64 %t463, 1
  br i1 %t492, label %L491, label %L490
L491:
  %t493 = getelementptr i64, ptr %t459, i64 1
  %t494 = load i64, ptr %t493
  %t495 = call ptr @pys_str_int(i64 %t494)
  br label %L460
L490:
  %t496 = getelementptr i64, ptr %t459, i64 1
  %t497 = load i64, ptr %t496
  %t498 = inttoptr i64 %t497 to ptr
  br label %L460
L460:
  %t499 = phi ptr [@s.4, %L455], [%t475, %L472], [%t482, %L477], [%t489, %L484], [%t495, %L491], [%t498, %L490]
  %t500 = load ptr, ptr @g.final_value
  %t501 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t501, double 0.0, double 2.0)
  %t502 = sitofp i64 1 to double
  %t503 = getelementptr %C._pystachy_complex$complex, ptr %t501, i32 0, i32 0
  %t504 = load double, ptr %t503
  %t505 = getelementptr %C._pystachy_complex$complex, ptr %t501, i32 0, i32 1
  %t506 = load double, ptr %t505
  %t507 = call ptr @f._pystachy_complex$_sum(double %t502, double 0.0, double %t504, double %t506)
  store i1 false, ptr @d.declined
  %t508 = call i1 @m._pystachy_complex$complex.__eq__.1(ptr %t507, ptr %t500)
  %t511 = load i1, ptr @d.declined
  br i1 %t511, label %L510, label %L509
L509:
  br label %L512
L510:
  store i1 false, ptr @d.declined
  br label %L512
L512:
  %t513 = phi i1 [%t508, %L509], [false, %L510]
  %t516 = icmp eq ptr %t458, null
  br i1 %t516, label %L514, label %L515
L515:
  %t517 = load i64, ptr %t458
  %t520 = icmp eq i64 %t517, 4
  br i1 %t520, label %L519, label %L518
L519:
  %t521 = getelementptr i64, ptr %t458, i64 1
  %t522 = load i64, ptr %t521
  %t523 = inttoptr i64 %t522 to ptr
  %t527 = icmp eq ptr %t523, null
  br i1 %t527, label %L524, label %L525
L524:
  br label %L526
L525:
  %t528 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t523)
  br label %L526
L526:
  %t529 = phi ptr [@s.4, %L524], [%t528, %L525]
  br label %L514
L518:
  %t532 = icmp eq i64 %t517, 2
  br i1 %t532, label %L531, label %L530
L531:
  %t533 = getelementptr i64, ptr %t458, i64 1
  %t534 = load i64, ptr %t533
  %t535 = trunc i64 %t534 to i1
  %t536 = select i1 %t535, ptr @s.5, ptr @s.6
  br label %L514
L530:
  %t539 = icmp eq i64 %t517, 3
  br i1 %t539, label %L538, label %L537
L538:
  %t540 = getelementptr i64, ptr %t458, i64 1
  %t541 = load i64, ptr %t540
  %t542 = bitcast i64 %t541 to double
  %t543 = call ptr @pys_str_float(double %t542)
  br label %L514
L537:
  %t546 = icmp eq i64 %t517, 1
  br i1 %t546, label %L545, label %L544
L545:
  %t547 = getelementptr i64, ptr %t458, i64 1
  %t548 = load i64, ptr %t547
  %t549 = call ptr @pys_str_int(i64 %t548)
  br label %L514
L544:
  %t550 = getelementptr i64, ptr %t458, i64 1
  %t551 = load i64, ptr %t550
  %t552 = inttoptr i64 %t551 to ptr
  br label %L514
L514:
  %t553 = phi ptr [@s.4, %L512], [%t529, %L526], [%t536, %L531], [%t543, %L538], [%t549, %L545], [%t552, %L544]
  call void @pys_write(ptr %t553, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  call void @pys_write(ptr %t499, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t554 = select i1 %t513, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t554, i64 1)
  call void @pys_write(ptr @s.2, i64 1)
  br label %L457
L456:
  br label %L457
L457:
  store ptr null, ptr @g.maybe
  %t555 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t555, double 0.0, double 0.0)
  %t556 = sitofp i64 2 to double
  %t557 = getelementptr %C._pystachy_complex$complex, ptr %t555, i32 0, i32 0
  %t558 = load double, ptr %t557
  %t559 = getelementptr %C._pystachy_complex$complex, ptr %t555, i32 0, i32 1
  %t560 = load double, ptr %t559
  %t561 = call ptr @f._pystachy_complex$_sum(double %t556, double 0.0, double %t558, double %t560)
  %t562 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t562, double 0.0, double 1.0)
  %t563 = call ptr @pys_ubox(i64 1, i64 2)
  %t564 = ptrtoint ptr %t561 to i64
  %t565 = call ptr @pys_ubox(i64 4, i64 %t564)
  %t566 = ptrtoint ptr %t562 to i64
  %t567 = call ptr @pys_ubox(i64 4, i64 %t566)
  %t568 = call ptr @pys_list_new(i64 4)
  %t569 = ptrtoint ptr null to i64
  call void @pys_list_append(ptr %t568, i64 %t569)
  %t570 = ptrtoint ptr %t563 to i64
  call void @pys_list_append(ptr %t568, i64 %t570)
  %t571 = ptrtoint ptr %t565 to i64
  call void @pys_list_append(ptr %t568, i64 %t571)
  %t572 = ptrtoint ptr %t567 to i64
  call void @pys_list_append(ptr %t568, i64 %t572)
  store ptr %t568, ptr @g.xs
  %t573 = load ptr, ptr @g.xs
  store i64 0, ptr %h.574
  %t575 = load i64, ptr %t573
  br label %L576
L576:
  %t579 = load i64, ptr %h.574
  %t580 = load i64, ptr %t573
  %t581 = icmp slt i64 %t579, %t580
  br i1 %t581, label %L582, label %L578
L582:
  %t763 = getelementptr inbounds {i64, i64, ptr}, ptr %t573, i64 0, i32 2
  %t764 = load ptr, ptr %t763, !tbaa !18
  %t765 = getelementptr inbounds i64, ptr %t764, i64 %t579
  %t583 = load i64, ptr %t765, !tbaa !19
  %t584 = inttoptr i64 %t583 to ptr
  store ptr %t584, ptr @g.x
  %t585 = load ptr, ptr @g.x
  store ptr %t585, ptr @g.maybe
  %t586 = load ptr, ptr @g.maybe
  %t587 = load ptr, ptr @g.maybe
  %t591 = icmp eq ptr %t587, null
  br i1 %t591, label %L589, label %L590
L589:
  br label %L588
L590:
  %t594 = load i64, ptr %t587
  %t595 = icmp eq i64 %t594, 4
  br i1 %t595, label %L592, label %L593
L592:
  %t596 = getelementptr i64, ptr %t587, i64 1
  %t597 = load i64, ptr %t596
  %t598 = inttoptr i64 %t597 to ptr
  %t599 = icmp eq ptr %t598, null
  br i1 %t599, label %L600, label %L601
L600:
  br label %L602
L601:
  %t603 = getelementptr %C._pystachy_complex$complex, ptr %t598, i32 0, i32 0
  %t604 = load double, ptr %t603
  %t605 = getelementptr %C._pystachy_complex$complex, ptr %t598, i32 0, i32 1
  %t606 = load double, ptr %t605
  %t607 = fcmp oeq double %t606, 0.0
  %t608 = sitofp i64 2 to double
  %t609 = fcmp oeq double %t604, %t608
  %t610 = and i1 %t607, %t609
  br label %L602
L602:
  %t611 = phi i1 [false, %L600], [%t610, %L601]
  br label %L588
L593:
  br label %L612
L612:
  %t613 = getelementptr i64, ptr %t587, i64 1
  %t614 = load i64, ptr %t613
  %t615 = icmp eq i64 %t614, 2
  br label %L588
L588:
  %t616 = phi i1 [false, %L589], [%t611, %L602], [%t615, %L612]
  %t617 = load ptr, ptr @g.maybe
  %t620 = icmp eq ptr %t617, null
  br i1 %t620, label %L618, label %L619
L619:
  %t621 = load i64, ptr %t617
  %t624 = icmp eq i64 %t621, 4
  br i1 %t624, label %L623, label %L622
L623:
  %t625 = getelementptr i64, ptr %t617, i64 1
  %t626 = load i64, ptr %t625
  %t627 = inttoptr i64 %t626 to ptr
  %t631 = icmp eq ptr %t627, null
  br i1 %t631, label %L628, label %L629
L628:
  br label %L630
L629:
  %t632 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t627)
  br label %L630
L630:
  %t633 = phi ptr [@s.4, %L628], [%t632, %L629]
  br label %L618
L622:
  %t634 = getelementptr i64, ptr %t617, i64 1
  %t635 = load i64, ptr %t634
  %t636 = call ptr @pys_str_int(i64 %t635)
  br label %L618
L618:
  %t637 = phi ptr [@s.4, %L588], [%t633, %L630], [%t636, %L622]
  %t640 = icmp eq ptr %t586, null
  br i1 %t640, label %L638, label %L639
L639:
  %t641 = load i64, ptr %t586
  %t644 = icmp eq i64 %t641, 4
  br i1 %t644, label %L643, label %L642
L643:
  %t645 = getelementptr i64, ptr %t586, i64 1
  %t646 = load i64, ptr %t645
  %t647 = inttoptr i64 %t646 to ptr
  %t651 = icmp eq ptr %t647, null
  br i1 %t651, label %L648, label %L649
L648:
  br label %L650
L649:
  %t652 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t647)
  br label %L650
L650:
  %t653 = phi ptr [@s.4, %L648], [%t652, %L649]
  br label %L638
L642:
  %t654 = getelementptr i64, ptr %t586, i64 1
  %t655 = load i64, ptr %t654
  %t656 = call ptr @pys_str_int(i64 %t655)
  br label %L638
L638:
  %t657 = phi ptr [@s.4, %L618], [%t653, %L650], [%t656, %L642]
  call void @pys_write(ptr %t657, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t658 = select i1 %t616, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t658, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  call void @pys_write(ptr %t637, i64 1)
  call void @pys_write(ptr @s.2, i64 1)
  br label %L577
L577:
  %t659 = add i64 %t579, 1
  store i64 %t659, ptr %h.574
  br label %L576
L578:
  %t660 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t660, double 0.0, double 2.0)
  %t661 = call ptr @pys_ubox(i64 1, i64 1)
  %t662 = ptrtoint ptr %t660 to i64
  %t663 = call ptr @pys_ubox(i64 4, i64 %t662)
  %t664 = call ptr @pys_dict_new(i64 1, i64 2)
  %t665 = ptrtoint ptr @s.15 to i64
  %t666 = ptrtoint ptr %t661 to i64
  call void @pys_dict_set(ptr %t664, i64 %t665, i64 %t666)
  %t667 = ptrtoint ptr @s.16 to i64
  %t668 = ptrtoint ptr %t663 to i64
  call void @pys_dict_set(ptr %t664, i64 %t667, i64 %t668)
  store ptr %t664, ptr @g.table
  %t669 = load ptr, ptr @g.table
  %t670 = call ptr @pys_list_new_atomic(i64 0)
  %t671 = load ptr, ptr @g.table
  store i64 0, ptr %h.672
  %t673 = load i64, ptr %t671
  store i64 0, ptr %h.674
  br label %L675
L675:
  %t678 = load i64, ptr %h.672
  %t679 = load i64, ptr %h.674
  %t680 = call i64 @pys_dict_next(ptr %t671, i64 %t679, i64 %t673, i64 %t678)
  %t681 = add i64 %t680, 1
  %t682 = icmp sge i64 %t680, 0
  br i1 %t682, label %L683, label %L677
L683:
  store i64 %t681, ptr %h.674
  %t684 = call i64 @pys_dict_val(ptr %t671, i64 %t680)
  %t685 = inttoptr i64 %t684 to ptr
  store ptr %t685, ptr %t.686
  %t687 = load ptr, ptr %t.686
  %t691 = load i64, ptr %t687
  %t692 = icmp eq i64 %t691, 4
  br i1 %t692, label %L689, label %L690
L689:
  %t693 = getelementptr i64, ptr %t687, i64 1
  %t694 = load i64, ptr %t693
  %t695 = inttoptr i64 %t694 to ptr
  %t696 = icmp eq ptr %t695, null
  br i1 %t696, label %L697, label %L698
L697:
  br label %L699
L698:
  %t700 = getelementptr %C._pystachy_complex$complex, ptr %t695, i32 0, i32 0
  %t701 = load double, ptr %t700
  %t702 = getelementptr %C._pystachy_complex$complex, ptr %t695, i32 0, i32 1
  %t703 = load double, ptr %t702
  %t704 = fcmp oeq double %t703, 0.0
  %t705 = sitofp i64 1 to double
  %t706 = fcmp oeq double %t701, %t705
  %t707 = and i1 %t704, %t706
  br label %L699
L699:
  %t708 = phi i1 [false, %L697], [%t707, %L698]
  br label %L688
L690:
  br label %L709
L709:
  %t710 = getelementptr i64, ptr %t687, i64 1
  %t711 = load i64, ptr %t710
  %t712 = icmp eq i64 %t711, 1
  br label %L688
L688:
  %t713 = phi i1 [%t708, %L699], [%t712, %L709]
  %t714 = zext i1 %t713 to i64
  call void @pys_list_append(ptr %t670, i64 %t714)
  br label %L676
L676:
  %t715 = add i64 %t678, 1
  store i64 %t715, ptr %h.672
  br label %L675
L677:
  %t716 = call ptr @pys_list_new(i64 0)
  %t717 = load ptr, ptr @g.table
  store i64 0, ptr %h.718
  %t719 = load i64, ptr %t717
  store i64 0, ptr %h.720
  br label %L721
L721:
  %t724 = load i64, ptr %h.718
  %t725 = load i64, ptr %h.720
  %t726 = call i64 @pys_dict_next(ptr %t717, i64 %t725, i64 %t719, i64 %t724)
  %t727 = add i64 %t726, 1
  %t728 = icmp sge i64 %t726, 0
  br i1 %t728, label %L729, label %L723
L729:
  store i64 %t727, ptr %h.720
  %t730 = call i64 @pys_dict_val(ptr %t717, i64 %t726)
  %t731 = inttoptr i64 %t730 to ptr
  store ptr %t731, ptr %t.732
  %t733 = load ptr, ptr %t.732
  %t735 = load i64, ptr %t733
  %t738 = icmp eq i64 %t735, 4
  br i1 %t738, label %L737, label %L736
L737:
  %t739 = getelementptr i64, ptr %t733, i64 1
  %t740 = load i64, ptr %t739
  %t741 = inttoptr i64 %t740 to ptr
  %t745 = icmp eq ptr %t741, null
  br i1 %t745, label %L742, label %L743
L742:
  br label %L744
L743:
  %t746 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t741)
  br label %L744
L744:
  %t747 = phi ptr [@s.4, %L742], [%t746, %L743]
  br label %L734
L736:
  %t748 = getelementptr i64, ptr %t733, i64 1
  %t749 = load i64, ptr %t748
  %t750 = call ptr @pys_str_int(i64 %t749)
  br label %L734
L734:
  %t751 = phi ptr [%t747, %L744], [%t750, %L736]
  %t752 = ptrtoint ptr %t751 to i64
  call void @pys_list_append(ptr %t716, i64 %t752)
  br label %L722
L722:
  %t753 = add i64 %t724, 1
  store i64 %t753, ptr %h.718
  br label %L721
L723:
  %t754 = ptrtoint ptr %t669 to i64
  %t755 = call ptr @pys_repr(i64 %t754, ptr @s.17)
  call void @pys_write(ptr %t755, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t756 = ptrtoint ptr %t670 to i64
  %t757 = call ptr @pys_repr(i64 %t756, ptr @s.18)
  call void @pys_write(ptr %t757, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t758 = ptrtoint ptr %t716 to i64
  %t759 = call ptr @pys_repr(i64 %t758, ptr @s.19)
  call void @pys_write(ptr %t759, i64 1)
  call void @pys_write(ptr @s.2, i64 1)
  ret void
}

define internal ptr @f.describe(ptr %a0) {
entry:
  %v.2 = alloca ptr
  store ptr zeroinitializer, ptr %v.2
  store ptr %a0, ptr %v.2
  %t3 = load ptr, ptr %v.2
  %t4 = load i64, ptr %t3
  %t5 = icmp eq i64 %t4, 2
  br i1 %t5, label %L6, label %L7
L6:
  %t9 = load ptr, ptr %v.2
  %t10 = getelementptr i64, ptr %t9, i64 1
  %t11 = load i64, ptr %t10
  %t12 = trunc i64 %t11 to i1
  %t13 = select i1 %t12, ptr @s.5, ptr @s.6
  %t14 = call ptr @pys_str_add(ptr @s.20, ptr %t13)
  ret ptr %t14
L7:
  br label %L8
L8:
  %t15 = load ptr, ptr %v.2
  %t16 = load i64, ptr %t15
  %t17 = icmp eq i64 %t16, 1
  br i1 %t17, label %L18, label %L19
L18:
  %t21 = load ptr, ptr %v.2
  %t22 = getelementptr i64, ptr %t21, i64 1
  %t23 = load i64, ptr %t22
  %t24 = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %t23, i64 1)
  %t25 = extractvalue {i64, i1} %t24, 0
  %t26 = extractvalue {i64, i1} %t24, 1
  br i1 %t26, label %L27, label %L28
L28:
  %t29 = call ptr @pys_str_int(i64 %t25)
  %t30 = call ptr @pys_str_add(ptr @s.21, ptr %t29)
  ret ptr %t30
L19:
  br label %L20
L20:
  %t31 = load ptr, ptr %v.2
  %t32 = load i64, ptr %t31
  %t33 = icmp eq i64 %t32, 3
  br i1 %t33, label %L34, label %L35
L34:
  %t37 = load ptr, ptr %v.2
  %t38 = getelementptr i64, ptr %t37, i64 1
  %t39 = load i64, ptr %t38
  %t40 = bitcast i64 %t39 to double
  %t41 = sitofp i64 2 to double
  %t42 = fmul double %t40, %t41
  %t43 = call ptr @pys_str_float(double %t42)
  %t44 = call ptr @pys_str_add(ptr @s.22, ptr %t43)
  ret ptr %t44
L35:
  br label %L36
L36:
  %t45 = load ptr, ptr %v.2
  %t46 = load i64, ptr %t45
  %t47 = icmp eq i64 %t46, 4
  br i1 %t47, label %L48, label %L49
L48:
  %t51 = load ptr, ptr %v.2
  %t54 = icmp eq ptr %t51, null
  br i1 %t54, label %L53, label %L52
L52:
  %t55 = getelementptr i64, ptr %t51, i64 1
  %t56 = load i64, ptr %t55
  %t57 = inttoptr i64 %t56 to ptr
  br label %L53
L53:
  %t58 = phi ptr [null, %L48], [%t57, %L52]
  %t59 = icmp eq ptr %t58, null
  br i1 %t59, label %L60, label %L61
L61:
  %t62 = call ptr @m._pystachy_complex$complex.conjugate(ptr %t58)
  %t66 = icmp eq ptr %t62, null
  br i1 %t66, label %L63, label %L64
L63:
  br label %L65
L64:
  %t67 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t62)
  br label %L65
L65:
  %t68 = phi ptr [@s.4, %L63], [%t67, %L64]
  %t69 = call ptr @pys_str_add(ptr @s.23, ptr %t68)
  ret ptr %t69
L49:
  br label %L50
L50:
  %t70 = load ptr, ptr %v.2
  %t71 = getelementptr i64, ptr %t70, i64 1
  %t72 = load i64, ptr %t71
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = call ptr @pys_str_upper(ptr %t73)
  %t75 = call ptr @pys_str_add(ptr @s.24, ptr %t74)
  ret ptr %t75
L27:
  call void @pys_raise(ptr @s.26, ptr @s.25)
  unreachable
L60:
  call void @pys_raise(ptr @s.13, ptr @s.27)
  unreachable
}

define internal ptr @f.fold(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %op.2 = alloca ptr
  store ptr zeroinitializer, ptr %op.2
  %left.3 = alloca ptr
  store ptr zeroinitializer, ptr %left.3
  %right.4 = alloca ptr
  store ptr zeroinitializer, ptr %right.4
  store ptr %a0, ptr %op.2
  store ptr %a1, ptr %left.3
  store ptr %a2, ptr %right.4
  %t5 = load ptr, ptr %left.3
  %t6 = load i64, ptr %t5
  %t7 = icmp eq i64 %t6, 2
  %t8 = icmp eq i64 %t6, 1
  %t9 = or i1 %t7, %t8
  br i1 %t9, label %L10, label %L11
L10:
  %t12 = load ptr, ptr %right.4
  %t13 = load i64, ptr %t12
  %t14 = icmp eq i64 %t13, 2
  %t15 = icmp eq i64 %t13, 1
  %t16 = or i1 %t14, %t15
  br label %L11
L11:
  %t17 = phi i1 [%t9, %entry], [%t16, %L10]
  br i1 %t17, label %L18, label %L19
L18:
  %t21 = load ptr, ptr %op.2
  %t22 = ptrtoint ptr %t21 to i64
  %t23 = ptrtoint ptr @s.8 to i64
  %t24 = call i64 @pys_eq(i64 %t22, i64 %t23, ptr @s.0)
  %t25 = icmp ne i64 %t24, 0
  br i1 %t25, label %L26, label %L27
L26:
  %t29 = load ptr, ptr %left.3
  %t30 = load ptr, ptr %right.4
  %t34 = load i64, ptr %t29
  %t35 = icmp eq i64 %t34, 2
  br i1 %t35, label %L32, label %L33
L32:
  %t36 = getelementptr i64, ptr %t29, i64 1
  %t37 = load i64, ptr %t36
  %t38 = trunc i64 %t37 to i1
  %t42 = load i64, ptr %t30
  %t43 = icmp eq i64 %t42, 2
  br i1 %t43, label %L40, label %L41
L40:
  %t44 = getelementptr i64, ptr %t30, i64 1
  %t45 = load i64, ptr %t44
  %t46 = trunc i64 %t45 to i1
  %t47 = zext i1 %t38 to i64
  %t48 = zext i1 %t46 to i64
  %t49 = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %t47, i64 %t48)
  %t50 = extractvalue {i64, i1} %t49, 0
  %t51 = extractvalue {i64, i1} %t49, 1
  br i1 %t51, label %L52, label %L53
L53:
  br label %L39
L41:
  br label %L54
L54:
  %t55 = getelementptr i64, ptr %t30, i64 1
  %t56 = load i64, ptr %t55
  %t57 = zext i1 %t38 to i64
  %t58 = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %t57, i64 %t56)
  %t59 = extractvalue {i64, i1} %t58, 0
  %t60 = extractvalue {i64, i1} %t58, 1
  br i1 %t60, label %L52, label %L61
L61:
  br label %L39
L39:
  %t62 = phi i64 [%t50, %L53], [%t59, %L61]
  br label %L31
L33:
  br label %L63
L63:
  %t64 = getelementptr i64, ptr %t29, i64 1
  %t65 = load i64, ptr %t64
  %t69 = load i64, ptr %t30
  %t70 = icmp eq i64 %t69, 2
  br i1 %t70, label %L67, label %L68
L67:
  %t71 = getelementptr i64, ptr %t30, i64 1
  %t72 = load i64, ptr %t71
  %t73 = trunc i64 %t72 to i1
  %t74 = zext i1 %t73 to i64
  %t75 = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %t65, i64 %t74)
  %t76 = extractvalue {i64, i1} %t75, 0
  %t77 = extractvalue {i64, i1} %t75, 1
  br i1 %t77, label %L52, label %L78
L78:
  br label %L66
L68:
  br label %L79
L79:
  %t80 = getelementptr i64, ptr %t30, i64 1
  %t81 = load i64, ptr %t80
  %t82 = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %t65, i64 %t81)
  %t83 = extractvalue {i64, i1} %t82, 0
  %t84 = extractvalue {i64, i1} %t82, 1
  br i1 %t84, label %L52, label %L85
L85:
  br label %L66
L66:
  %t86 = phi i64 [%t76, %L78], [%t83, %L85]
  br label %L31
L31:
  %t87 = phi i64 [%t62, %L39], [%t86, %L66]
  %t88 = call ptr @pys_ubox(i64 1, i64 %t87)
  br label %L28
L27:
  %t89 = load ptr, ptr %left.3
  %t90 = load ptr, ptr %right.4
  %t94 = load i64, ptr %t89
  %t95 = icmp eq i64 %t94, 2
  br i1 %t95, label %L92, label %L93
L92:
  %t96 = getelementptr i64, ptr %t89, i64 1
  %t97 = load i64, ptr %t96
  %t98 = trunc i64 %t97 to i1
  %t102 = load i64, ptr %t90
  %t103 = icmp eq i64 %t102, 2
  br i1 %t103, label %L100, label %L101
L100:
  %t104 = getelementptr i64, ptr %t90, i64 1
  %t105 = load i64, ptr %t104
  %t106 = trunc i64 %t105 to i1
  %t107 = zext i1 %t98 to i64
  %t108 = zext i1 %t106 to i64
  %t109 = call {i64, i1} @llvm.ssub.with.overflow.i64(i64 %t107, i64 %t108)
  %t110 = extractvalue {i64, i1} %t109, 0
  %t111 = extractvalue {i64, i1} %t109, 1
  br i1 %t111, label %L52, label %L112
L112:
  br label %L99
L101:
  br label %L113
L113:
  %t114 = getelementptr i64, ptr %t90, i64 1
  %t115 = load i64, ptr %t114
  %t116 = zext i1 %t98 to i64
  %t117 = call {i64, i1} @llvm.ssub.with.overflow.i64(i64 %t116, i64 %t115)
  %t118 = extractvalue {i64, i1} %t117, 0
  %t119 = extractvalue {i64, i1} %t117, 1
  br i1 %t119, label %L52, label %L120
L120:
  br label %L99
L99:
  %t121 = phi i64 [%t110, %L112], [%t118, %L120]
  br label %L91
L93:
  br label %L122
L122:
  %t123 = getelementptr i64, ptr %t89, i64 1
  %t124 = load i64, ptr %t123
  %t128 = load i64, ptr %t90
  %t129 = icmp eq i64 %t128, 2
  br i1 %t129, label %L126, label %L127
L126:
  %t130 = getelementptr i64, ptr %t90, i64 1
  %t131 = load i64, ptr %t130
  %t132 = trunc i64 %t131 to i1
  %t133 = zext i1 %t132 to i64
  %t134 = call {i64, i1} @llvm.ssub.with.overflow.i64(i64 %t124, i64 %t133)
  %t135 = extractvalue {i64, i1} %t134, 0
  %t136 = extractvalue {i64, i1} %t134, 1
  br i1 %t136, label %L52, label %L137
L137:
  br label %L125
L127:
  br label %L138
L138:
  %t139 = getelementptr i64, ptr %t90, i64 1
  %t140 = load i64, ptr %t139
  %t141 = call {i64, i1} @llvm.ssub.with.overflow.i64(i64 %t124, i64 %t140)
  %t142 = extractvalue {i64, i1} %t141, 0
  %t143 = extractvalue {i64, i1} %t141, 1
  br i1 %t143, label %L52, label %L144
L144:
  br label %L125
L125:
  %t145 = phi i64 [%t135, %L137], [%t142, %L144]
  br label %L91
L91:
  %t146 = phi i64 [%t121, %L99], [%t145, %L125]
  %t147 = call ptr @pys_ubox(i64 1, i64 %t146)
  br label %L28
L28:
  %t148 = phi ptr [%t88, %L31], [%t147, %L91]
  ret ptr %t148
L19:
  br label %L20
L20:
  %t149 = load ptr, ptr %op.2
  %t150 = ptrtoint ptr %t149 to i64
  %t151 = ptrtoint ptr @s.8 to i64
  %t152 = call i64 @pys_eq(i64 %t150, i64 %t151, ptr @s.0)
  %t153 = icmp ne i64 %t152, 0
  br i1 %t153, label %L154, label %L155
L154:
  %t156 = load ptr, ptr %left.3
  %t157 = load i64, ptr %t156
  %t158 = icmp eq i64 %t157, 2
  %t159 = icmp eq i64 %t157, 3
  %t160 = or i1 %t158, %t159
  %t161 = icmp eq i64 %t157, 1
  %t162 = or i1 %t160, %t161
  br label %L155
L155:
  %t163 = phi i1 [%t153, %L20], [%t162, %L154]
  br i1 %t163, label %L164, label %L165
L164:
  %t166 = load ptr, ptr %right.4
  %t167 = load i64, ptr %t166
  %t168 = icmp eq i64 %t167, 4
  br label %L165
L165:
  %t169 = phi i1 [%t163, %L155], [%t168, %L164]
  br i1 %t169, label %L170, label %L171
L170:
  %t173 = load ptr, ptr %left.3
  %t174 = load ptr, ptr %right.4
  %t177 = icmp eq ptr %t174, null
  br i1 %t177, label %L176, label %L175
L175:
  %t178 = getelementptr i64, ptr %t174, i64 1
  %t179 = load i64, ptr %t178
  %t180 = inttoptr i64 %t179 to ptr
  br label %L176
L176:
  %t181 = phi ptr [null, %L170], [%t180, %L175]
  %t185 = load i64, ptr %t173
  %t186 = icmp eq i64 %t185, 2
  br i1 %t186, label %L183, label %L184
L183:
  %t187 = getelementptr i64, ptr %t173, i64 1
  %t188 = load i64, ptr %t187
  %t189 = trunc i64 %t188 to i1
  %t190 = icmp eq ptr %t181, null
  br i1 %t190, label %L191, label %L192
L192:
  %t193 = uitofp i1 %t189 to double
  %t194 = getelementptr %C._pystachy_complex$complex, ptr %t181, i32 0, i32 0
  %t195 = load double, ptr %t194
  %t196 = getelementptr %C._pystachy_complex$complex, ptr %t181, i32 0, i32 1
  %t197 = load double, ptr %t196
  %t198 = call ptr @f._pystachy_complex$_sum(double %t193, double 0.0, double %t195, double %t197)
  br label %L182
L184:
  %t201 = load i64, ptr %t173
  %t202 = icmp eq i64 %t201, 3
  br i1 %t202, label %L199, label %L200
L199:
  %t203 = getelementptr i64, ptr %t173, i64 1
  %t204 = load i64, ptr %t203
  %t205 = bitcast i64 %t204 to double
  %t206 = icmp eq ptr %t181, null
  br i1 %t206, label %L207, label %L208
L208:
  %t209 = getelementptr %C._pystachy_complex$complex, ptr %t181, i32 0, i32 0
  %t210 = load double, ptr %t209
  %t211 = getelementptr %C._pystachy_complex$complex, ptr %t181, i32 0, i32 1
  %t212 = load double, ptr %t211
  %t213 = call ptr @f._pystachy_complex$_sum(double %t205, double 0.0, double %t210, double %t212)
  br label %L182
L200:
  br label %L214
L214:
  %t215 = getelementptr i64, ptr %t173, i64 1
  %t216 = load i64, ptr %t215
  %t217 = icmp eq ptr %t181, null
  br i1 %t217, label %L218, label %L219
L219:
  %t220 = sitofp i64 %t216 to double
  %t221 = getelementptr %C._pystachy_complex$complex, ptr %t181, i32 0, i32 0
  %t222 = load double, ptr %t221
  %t223 = getelementptr %C._pystachy_complex$complex, ptr %t181, i32 0, i32 1
  %t224 = load double, ptr %t223
  %t225 = call ptr @f._pystachy_complex$_sum(double %t220, double 0.0, double %t222, double %t224)
  br label %L182
L182:
  %t226 = phi ptr [%t198, %L192], [%t213, %L208], [%t225, %L219]
  %t227 = ptrtoint ptr %t226 to i64
  %t228 = call ptr @pys_ubox(i64 4, i64 %t227)
  %t229 = icmp eq ptr %t226, null
  %t230 = select i1 %t229, ptr null, ptr %t228
  ret ptr %t230
L171:
  %t231 = load ptr, ptr %op.2
  %t232 = ptrtoint ptr %t231 to i64
  %t233 = ptrtoint ptr @s.8 to i64
  %t234 = call i64 @pys_eq(i64 %t232, i64 %t233, ptr @s.0)
  %t235 = icmp ne i64 %t234, 0
  br i1 %t235, label %L236, label %L237
L236:
  %t238 = load ptr, ptr %left.3
  %t239 = load i64, ptr %t238
  %t240 = icmp eq i64 %t239, 4
  br label %L237
L237:
  %t241 = phi i1 [%t235, %L171], [%t240, %L236]
  br i1 %t241, label %L242, label %L243
L242:
  %t244 = load ptr, ptr %right.4
  %t245 = load i64, ptr %t244
  %t246 = icmp eq i64 %t245, 2
  %t247 = icmp eq i64 %t245, 3
  %t248 = or i1 %t246, %t247
  %t249 = icmp eq i64 %t245, 1
  %t250 = or i1 %t248, %t249
  br label %L243
L243:
  %t251 = phi i1 [%t241, %L237], [%t250, %L242]
  br i1 %t251, label %L252, label %L253
L252:
  %t255 = load ptr, ptr %left.3
  %t258 = icmp eq ptr %t255, null
  br i1 %t258, label %L257, label %L256
L256:
  %t259 = getelementptr i64, ptr %t255, i64 1
  %t260 = load i64, ptr %t259
  %t261 = inttoptr i64 %t260 to ptr
  br label %L257
L257:
  %t262 = phi ptr [null, %L252], [%t261, %L256]
  %t263 = load ptr, ptr %right.4
  %t267 = load i64, ptr %t263
  %t268 = icmp eq i64 %t267, 2
  br i1 %t268, label %L265, label %L266
L265:
  %t269 = getelementptr i64, ptr %t263, i64 1
  %t270 = load i64, ptr %t269
  %t271 = trunc i64 %t270 to i1
  %t272 = icmp eq ptr %t262, null
  br i1 %t272, label %L273, label %L274
L274:
  %t275 = getelementptr %C._pystachy_complex$complex, ptr %t262, i32 0, i32 0
  %t276 = load double, ptr %t275
  %t277 = getelementptr %C._pystachy_complex$complex, ptr %t262, i32 0, i32 1
  %t278 = load double, ptr %t277
  %t279 = uitofp i1 %t271 to double
  %t280 = call ptr @f._pystachy_complex$_sum(double %t276, double %t278, double %t279, double 0.0)
  br label %L264
L266:
  %t283 = load i64, ptr %t263
  %t284 = icmp eq i64 %t283, 3
  br i1 %t284, label %L281, label %L282
L281:
  %t285 = getelementptr i64, ptr %t263, i64 1
  %t286 = load i64, ptr %t285
  %t287 = bitcast i64 %t286 to double
  %t288 = icmp eq ptr %t262, null
  br i1 %t288, label %L289, label %L290
L290:
  %t291 = getelementptr %C._pystachy_complex$complex, ptr %t262, i32 0, i32 0
  %t292 = load double, ptr %t291
  %t293 = getelementptr %C._pystachy_complex$complex, ptr %t262, i32 0, i32 1
  %t294 = load double, ptr %t293
  %t295 = call ptr @f._pystachy_complex$_sum(double %t292, double %t294, double %t287, double 0.0)
  br label %L264
L282:
  br label %L296
L296:
  %t297 = getelementptr i64, ptr %t263, i64 1
  %t298 = load i64, ptr %t297
  %t299 = icmp eq ptr %t262, null
  br i1 %t299, label %L300, label %L301
L301:
  %t302 = getelementptr %C._pystachy_complex$complex, ptr %t262, i32 0, i32 0
  %t303 = load double, ptr %t302
  %t304 = getelementptr %C._pystachy_complex$complex, ptr %t262, i32 0, i32 1
  %t305 = load double, ptr %t304
  %t306 = sitofp i64 %t298 to double
  %t307 = call ptr @f._pystachy_complex$_sum(double %t303, double %t305, double %t306, double 0.0)
  br label %L264
L264:
  %t308 = phi ptr [%t280, %L274], [%t295, %L290], [%t307, %L301]
  %t309 = ptrtoint ptr %t308 to i64
  %t310 = call ptr @pys_ubox(i64 4, i64 %t309)
  %t311 = icmp eq ptr %t308, null
  %t312 = select i1 %t311, ptr null, ptr %t310
  ret ptr %t312
L253:
  %t313 = load ptr, ptr %op.2
  %t314 = ptrtoint ptr %t313 to i64
  %t315 = ptrtoint ptr @s.9 to i64
  %t316 = call i64 @pys_eq(i64 %t314, i64 %t315, ptr @s.0)
  %t317 = icmp ne i64 %t316, 0
  br i1 %t317, label %L318, label %L319
L318:
  %t320 = load ptr, ptr %left.3
  %t321 = load i64, ptr %t320
  %t322 = icmp eq i64 %t321, 2
  %t323 = icmp eq i64 %t321, 3
  %t324 = or i1 %t322, %t323
  %t325 = icmp eq i64 %t321, 1
  %t326 = or i1 %t324, %t325
  br label %L319
L319:
  %t327 = phi i1 [%t317, %L253], [%t326, %L318]
  br i1 %t327, label %L328, label %L329
L328:
  %t330 = load ptr, ptr %right.4
  %t331 = load i64, ptr %t330
  %t332 = icmp eq i64 %t331, 4
  br label %L329
L329:
  %t333 = phi i1 [%t327, %L319], [%t332, %L328]
  br i1 %t333, label %L334, label %L335
L334:
  %t337 = load ptr, ptr %left.3
  %t338 = load ptr, ptr %right.4
  %t341 = icmp eq ptr %t338, null
  br i1 %t341, label %L340, label %L339
L339:
  %t342 = getelementptr i64, ptr %t338, i64 1
  %t343 = load i64, ptr %t342
  %t344 = inttoptr i64 %t343 to ptr
  br label %L340
L340:
  %t345 = phi ptr [null, %L334], [%t344, %L339]
  %t349 = load i64, ptr %t337
  %t350 = icmp eq i64 %t349, 2
  br i1 %t350, label %L347, label %L348
L347:
  %t351 = getelementptr i64, ptr %t337, i64 1
  %t352 = load i64, ptr %t351
  %t353 = trunc i64 %t352 to i1
  %t354 = icmp eq ptr %t345, null
  br i1 %t354, label %L355, label %L356
L356:
  %t357 = uitofp i1 %t353 to double
  %t358 = getelementptr %C._pystachy_complex$complex, ptr %t345, i32 0, i32 0
  %t359 = load double, ptr %t358
  %t360 = getelementptr %C._pystachy_complex$complex, ptr %t345, i32 0, i32 1
  %t361 = load double, ptr %t360
  %t362 = call ptr @f._pystachy_complex$_diff(double %t357, double 0.0, double %t359, double %t361)
  br label %L346
L348:
  %t365 = load i64, ptr %t337
  %t366 = icmp eq i64 %t365, 3
  br i1 %t366, label %L363, label %L364
L363:
  %t367 = getelementptr i64, ptr %t337, i64 1
  %t368 = load i64, ptr %t367
  %t369 = bitcast i64 %t368 to double
  %t370 = icmp eq ptr %t345, null
  br i1 %t370, label %L371, label %L372
L372:
  %t373 = getelementptr %C._pystachy_complex$complex, ptr %t345, i32 0, i32 0
  %t374 = load double, ptr %t373
  %t375 = getelementptr %C._pystachy_complex$complex, ptr %t345, i32 0, i32 1
  %t376 = load double, ptr %t375
  %t377 = call ptr @f._pystachy_complex$_diff(double %t369, double 0.0, double %t374, double %t376)
  br label %L346
L364:
  br label %L378
L378:
  %t379 = getelementptr i64, ptr %t337, i64 1
  %t380 = load i64, ptr %t379
  %t381 = icmp eq ptr %t345, null
  br i1 %t381, label %L382, label %L383
L383:
  %t384 = sitofp i64 %t380 to double
  %t385 = getelementptr %C._pystachy_complex$complex, ptr %t345, i32 0, i32 0
  %t386 = load double, ptr %t385
  %t387 = getelementptr %C._pystachy_complex$complex, ptr %t345, i32 0, i32 1
  %t388 = load double, ptr %t387
  %t389 = call ptr @f._pystachy_complex$_diff(double %t384, double 0.0, double %t386, double %t388)
  br label %L346
L346:
  %t390 = phi ptr [%t362, %L356], [%t377, %L372], [%t389, %L383]
  %t391 = ptrtoint ptr %t390 to i64
  %t392 = call ptr @pys_ubox(i64 4, i64 %t391)
  %t393 = icmp eq ptr %t390, null
  %t394 = select i1 %t393, ptr null, ptr %t392
  ret ptr %t394
L335:
  %t395 = load ptr, ptr %op.2
  %t396 = ptrtoint ptr %t395 to i64
  %t397 = ptrtoint ptr @s.9 to i64
  %t398 = call i64 @pys_eq(i64 %t396, i64 %t397, ptr @s.0)
  %t399 = icmp ne i64 %t398, 0
  br i1 %t399, label %L400, label %L401
L400:
  %t402 = load ptr, ptr %left.3
  %t403 = load i64, ptr %t402
  %t404 = icmp eq i64 %t403, 4
  br label %L401
L401:
  %t405 = phi i1 [%t399, %L335], [%t404, %L400]
  br i1 %t405, label %L406, label %L407
L406:
  %t408 = load ptr, ptr %right.4
  %t409 = load i64, ptr %t408
  %t410 = icmp eq i64 %t409, 2
  %t411 = icmp eq i64 %t409, 3
  %t412 = or i1 %t410, %t411
  %t413 = icmp eq i64 %t409, 1
  %t414 = or i1 %t412, %t413
  br label %L407
L407:
  %t415 = phi i1 [%t405, %L401], [%t414, %L406]
  br i1 %t415, label %L416, label %L417
L416:
  %t419 = load ptr, ptr %left.3
  %t422 = icmp eq ptr %t419, null
  br i1 %t422, label %L421, label %L420
L420:
  %t423 = getelementptr i64, ptr %t419, i64 1
  %t424 = load i64, ptr %t423
  %t425 = inttoptr i64 %t424 to ptr
  br label %L421
L421:
  %t426 = phi ptr [null, %L416], [%t425, %L420]
  %t427 = load ptr, ptr %right.4
  %t431 = load i64, ptr %t427
  %t432 = icmp eq i64 %t431, 2
  br i1 %t432, label %L429, label %L430
L429:
  %t433 = getelementptr i64, ptr %t427, i64 1
  %t434 = load i64, ptr %t433
  %t435 = trunc i64 %t434 to i1
  %t436 = icmp eq ptr %t426, null
  br i1 %t436, label %L437, label %L438
L438:
  %t439 = getelementptr %C._pystachy_complex$complex, ptr %t426, i32 0, i32 0
  %t440 = load double, ptr %t439
  %t441 = getelementptr %C._pystachy_complex$complex, ptr %t426, i32 0, i32 1
  %t442 = load double, ptr %t441
  %t443 = uitofp i1 %t435 to double
  %t444 = call ptr @f._pystachy_complex$_diff(double %t440, double %t442, double %t443, double 0.0)
  br label %L428
L430:
  %t447 = load i64, ptr %t427
  %t448 = icmp eq i64 %t447, 3
  br i1 %t448, label %L445, label %L446
L445:
  %t449 = getelementptr i64, ptr %t427, i64 1
  %t450 = load i64, ptr %t449
  %t451 = bitcast i64 %t450 to double
  %t452 = icmp eq ptr %t426, null
  br i1 %t452, label %L453, label %L454
L454:
  %t455 = getelementptr %C._pystachy_complex$complex, ptr %t426, i32 0, i32 0
  %t456 = load double, ptr %t455
  %t457 = getelementptr %C._pystachy_complex$complex, ptr %t426, i32 0, i32 1
  %t458 = load double, ptr %t457
  %t459 = call ptr @f._pystachy_complex$_diff(double %t456, double %t458, double %t451, double 0.0)
  br label %L428
L446:
  br label %L460
L460:
  %t461 = getelementptr i64, ptr %t427, i64 1
  %t462 = load i64, ptr %t461
  %t463 = icmp eq ptr %t426, null
  br i1 %t463, label %L464, label %L465
L465:
  %t466 = getelementptr %C._pystachy_complex$complex, ptr %t426, i32 0, i32 0
  %t467 = load double, ptr %t466
  %t468 = getelementptr %C._pystachy_complex$complex, ptr %t426, i32 0, i32 1
  %t469 = load double, ptr %t468
  %t470 = sitofp i64 %t462 to double
  %t471 = call ptr @f._pystachy_complex$_diff(double %t467, double %t469, double %t470, double 0.0)
  br label %L428
L428:
  %t472 = phi ptr [%t444, %L438], [%t459, %L454], [%t471, %L465]
  %t473 = ptrtoint ptr %t472 to i64
  %t474 = call ptr @pys_ubox(i64 4, i64 %t473)
  %t475 = icmp eq ptr %t472, null
  %t476 = select i1 %t475, ptr null, ptr %t474
  ret ptr %t476
L417:
  br label %L418
L418:
  br label %L336
L336:
  br label %L254
L254:
  br label %L172
L172:
  ret ptr null
L52:
  call void @pys_raise(ptr @s.26, ptr @s.25)
  unreachable
L191:
  call void @pys_raise(ptr @s.29, ptr @s.28)
  unreachable
L207:
  call void @pys_raise(ptr @s.29, ptr @s.30)
  unreachable
L218:
  call void @pys_raise(ptr @s.29, ptr @s.31)
  unreachable
L273:
  call void @pys_raise(ptr @s.29, ptr @s.32)
  unreachable
L289:
  call void @pys_raise(ptr @s.29, ptr @s.33)
  unreachable
L300:
  call void @pys_raise(ptr @s.29, ptr @s.34)
  unreachable
L355:
  call void @pys_raise(ptr @s.29, ptr @s.35)
  unreachable
L371:
  call void @pys_raise(ptr @s.29, ptr @s.36)
  unreachable
L382:
  call void @pys_raise(ptr @s.29, ptr @s.37)
  unreachable
L437:
  call void @pys_raise(ptr @s.29, ptr @s.38)
  unreachable
L453:
  call void @pys_raise(ptr @s.29, ptr @s.39)
  unreachable
L464:
  call void @pys_raise(ptr @s.29, ptr @s.40)
  unreachable
}

define internal i1 @m._pystachy_complex$complex.__eq__.2(ptr nonnull %a0, ptr %a1) {
entry:
  %self.2 = alloca ptr
  store ptr zeroinitializer, ptr %self.2
  %other.3 = alloca ptr
  store ptr zeroinitializer, ptr %other.3
  store ptr %a0, ptr %self.2
  store ptr %a1, ptr %other.3
  %t4 = load ptr, ptr %other.3
  %t5 = load i64, ptr %t4
  %t6 = icmp eq i64 %t5, 4
  br i1 %t6, label %L7, label %L8
L7:
  %t10 = load ptr, ptr %self.2
  %t11 = getelementptr %C._pystachy_complex$complex, ptr %t10, i32 0, i32 0
  %t12 = load double, ptr %t11, !tbaa !16
  %t13 = load ptr, ptr %other.3
  %t16 = icmp eq ptr %t13, null
  br i1 %t16, label %L15, label %L14
L14:
  %t17 = getelementptr i64, ptr %t13, i64 1
  %t18 = load i64, ptr %t17
  %t19 = inttoptr i64 %t18 to ptr
  br label %L15
L15:
  %t20 = phi ptr [null, %L7], [%t19, %L14]
  %t21 = icmp eq ptr %t20, null
  br i1 %t21, label %L22, label %L23
L23:
  %t24 = getelementptr %C._pystachy_complex$complex, ptr %t20, i32 0, i32 0
  %t25 = load double, ptr %t24, !tbaa !16
  %t26 = fcmp oeq double %t12, %t25
  br i1 %t26, label %L27, label %L28
L27:
  %t29 = load ptr, ptr %self.2
  %t30 = getelementptr %C._pystachy_complex$complex, ptr %t29, i32 0, i32 1
  %t31 = load double, ptr %t30, !tbaa !17
  %t32 = load ptr, ptr %other.3
  %t35 = icmp eq ptr %t32, null
  br i1 %t35, label %L34, label %L33
L33:
  %t36 = getelementptr i64, ptr %t32, i64 1
  %t37 = load i64, ptr %t36
  %t38 = inttoptr i64 %t37 to ptr
  br label %L34
L34:
  %t39 = phi ptr [null, %L27], [%t38, %L33]
  %t40 = icmp eq ptr %t39, null
  br i1 %t40, label %L41, label %L42
L42:
  %t43 = getelementptr %C._pystachy_complex$complex, ptr %t39, i32 0, i32 1
  %t44 = load double, ptr %t43, !tbaa !17
  %t45 = fcmp oeq double %t31, %t44
  br label %L28
L28:
  %t46 = phi i1 [%t26, %L23], [%t45, %L42]
  ret i1 %t46
L8:
  br label %L9
L9:
  %t47 = load ptr, ptr %self.2
  %t48 = getelementptr %C._pystachy_complex$complex, ptr %t47, i32 0, i32 1
  %t49 = load double, ptr %t48, !tbaa !17
  %t50 = fcmp oeq double %t49, 0.0
  br i1 %t50, label %L51, label %L52
L51:
  %t53 = load ptr, ptr %self.2
  %t54 = getelementptr %C._pystachy_complex$complex, ptr %t53, i32 0, i32 0
  %t55 = load double, ptr %t54, !tbaa !16
  %t56 = load ptr, ptr %other.3
  %t57 = bitcast double %t55 to i64
  %t58 = call ptr @pys_ubox(i64 3, i64 %t57)
  %t59 = ptrtoint ptr %t58 to i64
  %t60 = ptrtoint ptr %t56 to i64
  %t61 = call i64 @pys_eq(i64 %t59, i64 %t60, ptr @s.41)
  %t62 = icmp ne i64 %t61, 0
  br label %L52
L52:
  %t63 = phi i1 [%t50, %L9], [%t62, %L51]
  ret i1 %t63
L22:
  call void @pys_raise(ptr @s.13, ptr @s.12)
  unreachable
L41:
  call void @pys_raise(ptr @s.13, ptr @s.14)
  unreachable
}

define internal i1 @m._pystachy_complex$complex.__eq__.3(ptr nonnull %a0, ptr %a1) {
entry:
  %self.2 = alloca ptr
  store ptr zeroinitializer, ptr %self.2
  %other.3 = alloca ptr
  store ptr zeroinitializer, ptr %other.3
  store ptr %a0, ptr %self.2
  store ptr %a1, ptr %other.3
  %t4 = load ptr, ptr %other.3
  %t5 = load i64, ptr %t4
  %t6 = icmp eq i64 %t5, 4
  br i1 %t6, label %L7, label %L8
L7:
  %t10 = load ptr, ptr %self.2
  %t11 = getelementptr %C._pystachy_complex$complex, ptr %t10, i32 0, i32 0
  %t12 = load double, ptr %t11, !tbaa !16
  %t13 = load ptr, ptr %other.3
  %t16 = icmp eq ptr %t13, null
  br i1 %t16, label %L15, label %L14
L14:
  %t17 = getelementptr i64, ptr %t13, i64 1
  %t18 = load i64, ptr %t17
  %t19 = inttoptr i64 %t18 to ptr
  br label %L15
L15:
  %t20 = phi ptr [null, %L7], [%t19, %L14]
  %t21 = icmp eq ptr %t20, null
  br i1 %t21, label %L22, label %L23
L23:
  %t24 = getelementptr %C._pystachy_complex$complex, ptr %t20, i32 0, i32 0
  %t25 = load double, ptr %t24, !tbaa !16
  %t26 = fcmp oeq double %t12, %t25
  br i1 %t26, label %L27, label %L28
L27:
  %t29 = load ptr, ptr %self.2
  %t30 = getelementptr %C._pystachy_complex$complex, ptr %t29, i32 0, i32 1
  %t31 = load double, ptr %t30, !tbaa !17
  %t32 = load ptr, ptr %other.3
  %t35 = icmp eq ptr %t32, null
  br i1 %t35, label %L34, label %L33
L33:
  %t36 = getelementptr i64, ptr %t32, i64 1
  %t37 = load i64, ptr %t36
  %t38 = inttoptr i64 %t37 to ptr
  br label %L34
L34:
  %t39 = phi ptr [null, %L27], [%t38, %L33]
  %t40 = icmp eq ptr %t39, null
  br i1 %t40, label %L41, label %L42
L42:
  %t43 = getelementptr %C._pystachy_complex$complex, ptr %t39, i32 0, i32 1
  %t44 = load double, ptr %t43, !tbaa !17
  %t45 = fcmp oeq double %t31, %t44
  br label %L28
L28:
  %t46 = phi i1 [%t26, %L23], [%t45, %L42]
  ret i1 %t46
L8:
  br label %L9
L9:
  %t47 = load ptr, ptr %other.3
  %t48 = load i64, ptr %t47
  %t49 = icmp eq i64 %t48, 1
  br i1 %t49, label %L50, label %L51
L50:
  %t53 = load ptr, ptr %self.2
  %t54 = getelementptr %C._pystachy_complex$complex, ptr %t53, i32 0, i32 1
  %t55 = load double, ptr %t54, !tbaa !17
  %t56 = fcmp oeq double %t55, 0.0
  br i1 %t56, label %L57, label %L58
L57:
  %t59 = load ptr, ptr %self.2
  %t60 = getelementptr %C._pystachy_complex$complex, ptr %t59, i32 0, i32 0
  %t61 = load double, ptr %t60, !tbaa !16
  %t62 = load ptr, ptr %other.3
  %t63 = getelementptr i64, ptr %t62, i64 1
  %t64 = load i64, ptr %t63
  %t65 = call i64 @pys_cmp_if(i64 %t64, double %t61)
  %t66 = icmp eq i64 %t65, 2
  %t67 = sub i64 0, %t65
  %t68 = select i1 %t66, i64 2, i64 %t67
  %t69 = icmp eq i64 %t68, 0
  br label %L58
L58:
  %t70 = phi i1 [%t56, %L50], [%t69, %L57]
  ret i1 %t70
L51:
  br label %L52
L52:
  store i1 true, ptr @d.declined
  ret i1 false
L22:
  call void @pys_raise(ptr @s.13, ptr @s.12)
  unreachable
L41:
  call void @pys_raise(ptr @s.13, ptr @s.14)
  unreachable
}

define internal void @f.numeric(ptr %a0, ptr %a1) {
entry:
  %v.2 = alloca ptr
  store ptr zeroinitializer, ptr %v.2
  %w.3 = alloca ptr
  store ptr zeroinitializer, ptr %w.3
  %t1 = call i64 @pys.recursion.enter()
  %t791 = sub i64 %t1, 1
  store ptr %a0, ptr %v.2
  store ptr %a1, ptr %w.3
  %t4 = load ptr, ptr %v.2
  %t8 = load i64, ptr %t4
  %t9 = icmp eq i64 %t8, 4
  br i1 %t9, label %L6, label %L7
L6:
  %t10 = getelementptr i64, ptr %t4, i64 1
  %t11 = load i64, ptr %t10
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = icmp eq ptr %t12, null
  br i1 %t13, label %L14, label %L15
L14:
  br label %L16
L15:
  %t17 = getelementptr %C._pystachy_complex$complex, ptr %t12, i32 0, i32 0
  %t18 = load double, ptr %t17
  %t19 = getelementptr %C._pystachy_complex$complex, ptr %t12, i32 0, i32 1
  %t20 = load double, ptr %t19
  %t21 = fcmp oeq double %t20, 0.0
  %t22 = sitofp i64 1 to double
  %t23 = fcmp oeq double %t18, %t22
  %t24 = and i1 %t21, %t23
  br label %L16
L16:
  %t25 = phi i1 [false, %L14], [%t24, %L15]
  br label %L5
L7:
  %t28 = load i64, ptr %t4
  %t29 = icmp eq i64 %t28, 3
  br i1 %t29, label %L26, label %L27
L26:
  %t30 = getelementptr i64, ptr %t4, i64 1
  %t31 = load i64, ptr %t30
  %t32 = bitcast i64 %t31 to double
  %t33 = sitofp i64 1 to double
  %t34 = fcmp oeq double %t32, %t33
  br label %L5
L27:
  br label %L35
L35:
  %t36 = getelementptr i64, ptr %t4, i64 1
  %t37 = load i64, ptr %t36
  %t38 = icmp eq i64 %t37, 1
  br label %L5
L5:
  %t39 = phi i1 [%t25, %L16], [%t34, %L26], [%t38, %L35]
  %t40 = load ptr, ptr %v.2
  %t41 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t41, double 0.0, double 2.0)
  %t42 = call i1 @m._pystachy_complex$complex.__eq__.2(ptr %t41, ptr %t40)
  %t43 = xor i1 %t42, true
  %t44 = load ptr, ptr %v.2
  %t48 = load i64, ptr %t44
  %t49 = icmp eq i64 %t48, 4
  br i1 %t49, label %L46, label %L47
L46:
  %t50 = getelementptr i64, ptr %t44, i64 1
  %t51 = load i64, ptr %t50
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = icmp eq ptr %t52, null
  br i1 %t53, label %L54, label %L55
L54:
  br label %L56
L55:
  %t57 = getelementptr %C._pystachy_complex$complex, ptr %t52, i32 0, i32 0
  %t58 = load double, ptr %t57
  %t59 = getelementptr %C._pystachy_complex$complex, ptr %t52, i32 0, i32 1
  %t60 = load double, ptr %t59
  %t61 = fcmp oeq double %t60, 0.0
  %t62 = sitofp i64 1 to double
  %t63 = fcmp oeq double %t58, %t62
  %t64 = and i1 %t61, %t63
  br label %L56
L56:
  %t65 = phi i1 [false, %L54], [%t64, %L55]
  br label %L45
L47:
  %t68 = load i64, ptr %t44
  %t69 = icmp eq i64 %t68, 3
  br i1 %t69, label %L66, label %L67
L66:
  %t70 = getelementptr i64, ptr %t44, i64 1
  %t71 = load i64, ptr %t70
  %t72 = bitcast i64 %t71 to double
  %t73 = sitofp i64 1 to double
  %t74 = fcmp oeq double %t73, %t72
  br label %L45
L67:
  br label %L75
L75:
  %t76 = getelementptr i64, ptr %t44, i64 1
  %t77 = load i64, ptr %t76
  %t78 = icmp eq i64 1, %t77
  br label %L45
L45:
  %t79 = phi i1 [%t65, %L56], [%t74, %L66], [%t78, %L75]
  %t80 = load ptr, ptr %v.2
  %t84 = load i64, ptr %t80
  %t85 = icmp eq i64 %t84, 4
  br i1 %t85, label %L82, label %L83
L82:
  br label %L81
L83:
  %t88 = load i64, ptr %t80
  %t89 = icmp eq i64 %t88, 3
  br i1 %t89, label %L86, label %L87
L86:
  br label %L81
L87:
  br label %L90
L90:
  br label %L81
L81:
  %t91 = phi i1 [false, %L82], [false, %L86], [false, %L90]
  %t92 = load ptr, ptr %v.2
  %t93 = load ptr, ptr %w.3
  %t97 = load i64, ptr %t92
  %t98 = icmp eq i64 %t97, 4
  br i1 %t98, label %L95, label %L96
L95:
  %t99 = getelementptr i64, ptr %t92, i64 1
  %t100 = load i64, ptr %t99
  %t101 = inttoptr i64 %t100 to ptr
  %t105 = icmp eq ptr %t101, null
  br i1 %t105, label %L102, label %L103
L102:
  br label %L104
L103:
  store i1 false, ptr @d.declined
  %t106 = call i1 @m._pystachy_complex$complex.__eq__.3(ptr %t101, ptr %t93)
  %t109 = load i1, ptr @d.declined
  br i1 %t109, label %L107, label %L108
L108:
  br label %L104
L107:
  store i1 false, ptr @d.declined
  %t113 = icmp eq ptr %t101, null
  br i1 %t113, label %L110, label %L111
L110:
  call void @pys_raise(ptr @s.43, ptr @s.42)
  unreachable
L111:
  br label %L112
L112:
  %t114 = phi i1 [false, %L111]
  br label %L104
L104:
  %t115 = phi i1 [false, %L102], [%t106, %L108], [%t114, %L112]
  br label %L94
L96:
  %t118 = load i64, ptr %t92
  %t119 = icmp eq i64 %t118, 3
  br i1 %t119, label %L116, label %L117
L116:
  %t120 = getelementptr i64, ptr %t92, i64 1
  %t121 = load i64, ptr %t120
  %t122 = bitcast i64 %t121 to double
  %t126 = load i64, ptr %t93
  %t127 = icmp eq i64 %t126, 4
  br i1 %t127, label %L124, label %L125
L124:
  %t128 = getelementptr i64, ptr %t93, i64 1
  %t129 = load i64, ptr %t128
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = icmp eq ptr %t130, null
  br i1 %t131, label %L132, label %L133
L132:
  br label %L134
L133:
  %t135 = getelementptr %C._pystachy_complex$complex, ptr %t130, i32 0, i32 0
  %t136 = load double, ptr %t135
  %t137 = getelementptr %C._pystachy_complex$complex, ptr %t130, i32 0, i32 1
  %t138 = load double, ptr %t137
  %t139 = fcmp oeq double %t136, %t122
  %t140 = fcmp oeq double %t138, 0.0
  %t141 = and i1 %t139, %t140
  br label %L134
L134:
  %t142 = phi i1 [false, %L132], [%t141, %L133]
  br label %L123
L125:
  %t145 = load i64, ptr %t93
  %t146 = icmp eq i64 %t145, 1
  br i1 %t146, label %L143, label %L144
L143:
  %t147 = getelementptr i64, ptr %t93, i64 1
  %t148 = load i64, ptr %t147
  %t149 = call i64 @pys_cmp_if(i64 %t148, double %t122)
  %t150 = icmp eq i64 %t149, 2
  %t151 = sub i64 0, %t149
  %t152 = select i1 %t150, i64 2, i64 %t151
  %t153 = icmp eq i64 %t152, 0
  br label %L123
L144:
  br label %L154
L154:
  br label %L123
L123:
  %t155 = phi i1 [%t142, %L134], [%t153, %L143], [false, %L154]
  br label %L94
L117:
  br label %L156
L156:
  %t157 = getelementptr i64, ptr %t92, i64 1
  %t158 = load i64, ptr %t157
  %t162 = load i64, ptr %t93
  %t163 = icmp eq i64 %t162, 4
  br i1 %t163, label %L160, label %L161
L160:
  %t164 = getelementptr i64, ptr %t93, i64 1
  %t165 = load i64, ptr %t164
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = icmp eq ptr %t166, null
  br i1 %t167, label %L168, label %L169
L168:
  br label %L170
L169:
  %t171 = getelementptr %C._pystachy_complex$complex, ptr %t166, i32 0, i32 0
  %t172 = load double, ptr %t171
  %t173 = getelementptr %C._pystachy_complex$complex, ptr %t166, i32 0, i32 1
  %t174 = load double, ptr %t173
  %t175 = fcmp oeq double %t174, 0.0
  %t176 = call i64 @pys_cmp_if(i64 %t158, double %t172)
  %t177 = icmp eq i64 %t176, 2
  %t178 = sub i64 0, %t176
  %t179 = select i1 %t177, i64 2, i64 %t178
  %t180 = icmp eq i64 %t179, 0
  %t181 = and i1 %t175, %t180
  br label %L170
L170:
  %t182 = phi i1 [false, %L168], [%t181, %L169]
  br label %L159
L161:
  %t185 = load i64, ptr %t93
  %t186 = icmp eq i64 %t185, 1
  br i1 %t186, label %L183, label %L184
L183:
  %t187 = getelementptr i64, ptr %t93, i64 1
  %t188 = load i64, ptr %t187
  %t189 = icmp eq i64 %t158, %t188
  br label %L159
L184:
  br label %L190
L190:
  br label %L159
L159:
  %t191 = phi i1 [%t182, %L170], [%t189, %L183], [false, %L190]
  br label %L94
L94:
  %t192 = phi i1 [%t115, %L104], [%t155, %L123], [%t191, %L159]
  %t193 = load ptr, ptr %w.3
  %t194 = load ptr, ptr %v.2
  %t198 = load i64, ptr %t193
  %t199 = icmp eq i64 %t198, 4
  br i1 %t199, label %L196, label %L197
L196:
  %t200 = getelementptr i64, ptr %t193, i64 1
  %t201 = load i64, ptr %t200
  %t202 = inttoptr i64 %t201 to ptr
  %t206 = icmp eq ptr %t202, null
  br i1 %t206, label %L203, label %L204
L203:
  br label %L205
L204:
  %t207 = call i1 @m._pystachy_complex$complex.__eq__.2(ptr %t202, ptr %t194)
  %t208 = xor i1 %t207, true
  br label %L205
L205:
  %t209 = phi i1 [true, %L203], [%t208, %L204]
  br label %L195
L197:
  %t212 = load i64, ptr %t193
  %t213 = icmp eq i64 %t212, 1
  br i1 %t213, label %L210, label %L211
L210:
  %t214 = getelementptr i64, ptr %t193, i64 1
  %t215 = load i64, ptr %t214
  %t219 = load i64, ptr %t194
  %t220 = icmp eq i64 %t219, 4
  br i1 %t220, label %L217, label %L218
L217:
  %t221 = getelementptr i64, ptr %t194, i64 1
  %t222 = load i64, ptr %t221
  %t223 = inttoptr i64 %t222 to ptr
  %t224 = icmp eq ptr %t223, null
  br i1 %t224, label %L225, label %L226
L225:
  %t228 = xor i1 false, true
  br label %L227
L226:
  %t229 = getelementptr %C._pystachy_complex$complex, ptr %t223, i32 0, i32 0
  %t230 = load double, ptr %t229
  %t231 = getelementptr %C._pystachy_complex$complex, ptr %t223, i32 0, i32 1
  %t232 = load double, ptr %t231
  %t233 = fcmp oeq double %t232, 0.0
  %t234 = call i64 @pys_cmp_if(i64 %t215, double %t230)
  %t235 = icmp eq i64 %t234, 2
  %t236 = sub i64 0, %t234
  %t237 = select i1 %t235, i64 2, i64 %t236
  %t238 = icmp eq i64 %t237, 0
  %t239 = and i1 %t233, %t238
  %t240 = xor i1 %t239, true
  br label %L227
L227:
  %t241 = phi i1 [%t228, %L225], [%t240, %L226]
  br label %L216
L218:
  %t244 = load i64, ptr %t194
  %t245 = icmp eq i64 %t244, 3
  br i1 %t245, label %L242, label %L243
L242:
  %t246 = getelementptr i64, ptr %t194, i64 1
  %t247 = load i64, ptr %t246
  %t248 = bitcast i64 %t247 to double
  %t249 = call i64 @pys_cmp_if(i64 %t215, double %t248)
  %t250 = icmp ne i64 %t249, 0
  br label %L216
L243:
  br label %L251
L251:
  %t252 = getelementptr i64, ptr %t194, i64 1
  %t253 = load i64, ptr %t252
  %t254 = icmp ne i64 %t215, %t253
  br label %L216
L216:
  %t255 = phi i1 [%t241, %L227], [%t250, %L242], [%t254, %L251]
  br label %L195
L211:
  br label %L256
L256:
  %t257 = getelementptr i64, ptr %t193, i64 1
  %t258 = load i64, ptr %t257
  %t259 = inttoptr i64 %t258 to ptr
  %t263 = load i64, ptr %t194
  %t264 = icmp eq i64 %t263, 4
  br i1 %t264, label %L261, label %L262
L261:
  br label %L260
L262:
  %t267 = load i64, ptr %t194
  %t268 = icmp eq i64 %t267, 3
  br i1 %t268, label %L265, label %L266
L265:
  br label %L260
L266:
  br label %L269
L269:
  br label %L260
L260:
  %t270 = phi i1 [true, %L261], [true, %L265], [true, %L269]
  br label %L195
L195:
  %t271 = phi i1 [%t209, %L205], [%t255, %L216], [%t270, %L260]
  %t272 = load ptr, ptr %v.2
  %t276 = load i64, ptr %t272
  %t277 = icmp eq i64 %t276, 4
  br i1 %t277, label %L274, label %L275
L274:
  %t278 = getelementptr i64, ptr %t272, i64 1
  %t279 = load i64, ptr %t278
  %t280 = inttoptr i64 %t279 to ptr
  %t281 = icmp eq ptr %t280, null
  br i1 %t281, label %L282, label %L283
L282:
  br label %L284
L283:
  %t285 = getelementptr %C._pystachy_complex$complex, ptr %t280, i32 0, i32 0
  %t286 = load double, ptr %t285
  %t287 = getelementptr %C._pystachy_complex$complex, ptr %t280, i32 0, i32 1
  %t288 = load double, ptr %t287
  %t289 = fcmp oeq double %t286, 2.5
  %t290 = fcmp oeq double %t288, 0.0
  %t291 = and i1 %t289, %t290
  br label %L284
L284:
  %t292 = phi i1 [false, %L282], [%t291, %L283]
  br label %L273
L275:
  %t295 = load i64, ptr %t272
  %t296 = icmp eq i64 %t295, 3
  br i1 %t296, label %L293, label %L294
L293:
  %t297 = getelementptr i64, ptr %t272, i64 1
  %t298 = load i64, ptr %t297
  %t299 = bitcast i64 %t298 to double
  %t300 = fcmp oeq double %t299, 2.5
  br label %L273
L294:
  br label %L301
L301:
  %t302 = getelementptr i64, ptr %t272, i64 1
  %t303 = load i64, ptr %t302
  %t304 = call i64 @pys_cmp_if(i64 %t303, double 2.5)
  %t305 = icmp eq i64 %t304, 0
  br label %L273
L273:
  %t306 = phi i1 [%t292, %L284], [%t300, %L293], [%t305, %L301]
  %t307 = select i1 %t39, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t307, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t308 = select i1 %t43, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t308, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t309 = select i1 %t79, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t309, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t310 = select i1 %t91, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t310, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t311 = select i1 %t192, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t311, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t312 = select i1 %t271, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t312, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t313 = select i1 %t306, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t313, i64 1)
  call void @pys_write(ptr @s.2, i64 1)
  %t314 = load ptr, ptr %v.2
  %t318 = load i64, ptr %t314
  %t319 = icmp eq i64 %t318, 4
  br i1 %t319, label %L316, label %L317
L316:
  %t320 = getelementptr i64, ptr %t314, i64 1
  %t321 = load i64, ptr %t320
  %t322 = inttoptr i64 %t321 to ptr
  %t323 = icmp eq ptr %t322, null
  br i1 %t323, label %L324, label %L325
L325:
  %t326 = call ptr @m._pystachy_complex$complex.__neg__(ptr %t322)
  %t343 = ptrtoint ptr %t326 to i64
  %t344 = call ptr @pys_ubox(i64 4, i64 %t343)
  br label %L315
L317:
  %t329 = load i64, ptr %t314
  %t330 = icmp eq i64 %t329, 3
  br i1 %t330, label %L327, label %L328
L327:
  %t331 = getelementptr i64, ptr %t314, i64 1
  %t332 = load i64, ptr %t331
  %t333 = bitcast i64 %t332 to double
  %t334 = fneg double %t333
  %t345 = bitcast double %t334 to i64
  %t346 = call ptr @pys_ubox(i64 3, i64 %t345)
  br label %L315
L328:
  br label %L335
L335:
  %t336 = getelementptr i64, ptr %t314, i64 1
  %t337 = load i64, ptr %t336
  %t338 = call {i64, i1} @llvm.ssub.with.overflow.i64(i64 0, i64 %t337)
  %t339 = extractvalue {i64, i1} %t338, 0
  %t340 = extractvalue {i64, i1} %t338, 1
  br i1 %t340, label %L341, label %L342
L342:
  %t347 = call ptr @pys_ubox(i64 1, i64 %t339)
  br label %L315
L315:
  %t348 = phi ptr [%t344, %L325], [%t346, %L327], [%t347, %L342]
  %t349 = load ptr, ptr %v.2
  %t353 = load i64, ptr %t349
  %t354 = icmp eq i64 %t353, 4
  br i1 %t354, label %L351, label %L352
L351:
  %t355 = getelementptr i64, ptr %t349, i64 1
  %t356 = load i64, ptr %t355
  %t357 = inttoptr i64 %t356 to ptr
  %t358 = icmp eq ptr %t357, null
  br i1 %t358, label %L359, label %L360
L360:
  %t361 = getelementptr %C._pystachy_complex$complex, ptr %t357, i32 0, i32 0
  %t362 = load double, ptr %t361
  %t363 = getelementptr %C._pystachy_complex$complex, ptr %t357, i32 0, i32 1
  %t364 = load double, ptr %t363
  %t365 = sitofp i64 2 to double
  %t366 = call ptr @f._pystachy_complex$_prod(double %t362, double %t364, double %t365, double 0.0)
  %t383 = ptrtoint ptr %t366 to i64
  %t384 = call ptr @pys_ubox(i64 4, i64 %t383)
  br label %L350
L352:
  %t369 = load i64, ptr %t349
  %t370 = icmp eq i64 %t369, 3
  br i1 %t370, label %L367, label %L368
L367:
  %t371 = getelementptr i64, ptr %t349, i64 1
  %t372 = load i64, ptr %t371
  %t373 = bitcast i64 %t372 to double
  %t374 = sitofp i64 2 to double
  %t375 = fmul double %t373, %t374
  %t385 = bitcast double %t375 to i64
  %t386 = call ptr @pys_ubox(i64 3, i64 %t385)
  br label %L350
L368:
  br label %L376
L376:
  %t377 = getelementptr i64, ptr %t349, i64 1
  %t378 = load i64, ptr %t377
  %t379 = call {i64, i1} @llvm.smul.with.overflow.i64(i64 %t378, i64 2)
  %t380 = extractvalue {i64, i1} %t379, 0
  %t381 = extractvalue {i64, i1} %t379, 1
  br i1 %t381, label %L341, label %L382
L382:
  %t387 = call ptr @pys_ubox(i64 1, i64 %t380)
  br label %L350
L350:
  %t388 = phi ptr [%t384, %L360], [%t386, %L367], [%t387, %L382]
  %t389 = load ptr, ptr %v.2
  %t393 = load i64, ptr %t389
  %t394 = icmp eq i64 %t393, 4
  br i1 %t394, label %L391, label %L392
L391:
  %t395 = getelementptr i64, ptr %t389, i64 1
  %t396 = load i64, ptr %t395
  %t397 = inttoptr i64 %t396 to ptr
  %t398 = icmp eq ptr %t397, null
  br i1 %t398, label %L399, label %L400
L400:
  %t401 = getelementptr %C._pystachy_complex$complex, ptr %t397, i32 0, i32 0
  %t402 = load double, ptr %t401
  %t403 = getelementptr %C._pystachy_complex$complex, ptr %t397, i32 0, i32 1
  %t404 = load double, ptr %t403
  %t405 = sitofp i64 2 to double
  %t406 = call ptr @f._pystachy_complex$_pow(double %t402, double %t404, double %t405, double 0.0)
  %t420 = ptrtoint ptr %t406 to i64
  %t421 = call ptr @pys_ubox(i64 4, i64 %t420)
  br label %L390
L392:
  %t409 = load i64, ptr %t389
  %t410 = icmp eq i64 %t409, 3
  br i1 %t410, label %L407, label %L408
L407:
  %t411 = getelementptr i64, ptr %t389, i64 1
  %t412 = load i64, ptr %t411
  %t413 = bitcast i64 %t412 to double
  %t414 = sitofp i64 2 to double
  %t415 = call double @pys_fpow(double %t413, double %t414)
  %t422 = bitcast double %t415 to i64
  %t423 = call ptr @pys_ubox(i64 3, i64 %t422)
  br label %L390
L408:
  br label %L416
L416:
  %t417 = getelementptr i64, ptr %t389, i64 1
  %t418 = load i64, ptr %t417
  %t419 = call i64 @pys_pow(i64 %t418, i64 2)
  %t424 = call ptr @pys_ubox(i64 1, i64 %t419)
  br label %L390
L390:
  %t425 = phi ptr [%t421, %L400], [%t423, %L407], [%t424, %L416]
  %t426 = load ptr, ptr %v.2
  %t430 = load i64, ptr %t426
  %t431 = icmp eq i64 %t430, 4
  br i1 %t431, label %L428, label %L429
L428:
  %t432 = getelementptr i64, ptr %t426, i64 1
  %t433 = load i64, ptr %t432
  %t434 = inttoptr i64 %t433 to ptr
  %t435 = icmp eq ptr %t434, null
  br i1 %t435, label %L436, label %L437
L437:
  %t438 = getelementptr %C._pystachy_complex$complex, ptr %t434, i32 0, i32 0
  %t439 = load double, ptr %t438
  %t440 = getelementptr %C._pystachy_complex$complex, ptr %t434, i32 0, i32 1
  %t441 = load double, ptr %t440
  %t442 = sitofp i64 2 to double
  %t443 = call ptr @f._pystachy_complex$_quot(double %t439, double %t441, double %t442, double 0.0)
  %t457 = ptrtoint ptr %t443 to i64
  %t458 = call ptr @pys_ubox(i64 4, i64 %t457)
  br label %L427
L429:
  %t446 = load i64, ptr %t426
  %t447 = icmp eq i64 %t446, 3
  br i1 %t447, label %L444, label %L445
L444:
  %t448 = getelementptr i64, ptr %t426, i64 1
  %t449 = load i64, ptr %t448
  %t450 = bitcast i64 %t449 to double
  %t451 = sitofp i64 2 to double
  %t452 = call double @pys_fdiv(double %t450, double %t451)
  %t459 = bitcast double %t452 to i64
  %t460 = call ptr @pys_ubox(i64 3, i64 %t459)
  br label %L427
L445:
  br label %L453
L453:
  %t454 = getelementptr i64, ptr %t426, i64 1
  %t455 = load i64, ptr %t454
  %t456 = call double @pys_idiv(i64 %t455, i64 2)
  %t461 = bitcast double %t456 to i64
  %t462 = call ptr @pys_ubox(i64 3, i64 %t461)
  br label %L427
L427:
  %t463 = phi ptr [%t458, %L437], [%t460, %L444], [%t462, %L453]
  %t464 = load ptr, ptr %v.2
  %t465 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t465, double 0.0, double 1.0)
  %t469 = load i64, ptr %t464
  %t470 = icmp eq i64 %t469, 4
  br i1 %t470, label %L467, label %L468
L467:
  %t471 = getelementptr i64, ptr %t464, i64 1
  %t472 = load i64, ptr %t471
  %t473 = inttoptr i64 %t472 to ptr
  %t474 = icmp eq ptr %t473, null
  br i1 %t474, label %L475, label %L476
L476:
  %t477 = getelementptr %C._pystachy_complex$complex, ptr %t473, i32 0, i32 0
  %t478 = load double, ptr %t477
  %t479 = getelementptr %C._pystachy_complex$complex, ptr %t473, i32 0, i32 1
  %t480 = load double, ptr %t479
  %t481 = getelementptr %C._pystachy_complex$complex, ptr %t465, i32 0, i32 0
  %t482 = load double, ptr %t481
  %t483 = getelementptr %C._pystachy_complex$complex, ptr %t465, i32 0, i32 1
  %t484 = load double, ptr %t483
  %t485 = call ptr @f._pystachy_complex$_sum(double %t478, double %t480, double %t482, double %t484)
  br label %L466
L468:
  %t488 = load i64, ptr %t464
  %t489 = icmp eq i64 %t488, 3
  br i1 %t489, label %L486, label %L487
L486:
  %t490 = getelementptr i64, ptr %t464, i64 1
  %t491 = load i64, ptr %t490
  %t492 = bitcast i64 %t491 to double
  %t493 = getelementptr %C._pystachy_complex$complex, ptr %t465, i32 0, i32 0
  %t494 = load double, ptr %t493
  %t495 = getelementptr %C._pystachy_complex$complex, ptr %t465, i32 0, i32 1
  %t496 = load double, ptr %t495
  %t497 = call ptr @f._pystachy_complex$_sum(double %t492, double 0.0, double %t494, double %t496)
  br label %L466
L487:
  br label %L498
L498:
  %t499 = getelementptr i64, ptr %t464, i64 1
  %t500 = load i64, ptr %t499
  %t501 = sitofp i64 %t500 to double
  %t502 = getelementptr %C._pystachy_complex$complex, ptr %t465, i32 0, i32 0
  %t503 = load double, ptr %t502
  %t504 = getelementptr %C._pystachy_complex$complex, ptr %t465, i32 0, i32 1
  %t505 = load double, ptr %t504
  %t506 = call ptr @f._pystachy_complex$_sum(double %t501, double 0.0, double %t503, double %t505)
  br label %L466
L466:
  %t507 = phi ptr [%t485, %L476], [%t497, %L486], [%t506, %L498]
  %t508 = load ptr, ptr %v.2
  %t512 = load i64, ptr %t508
  %t513 = icmp eq i64 %t512, 4
  br i1 %t513, label %L510, label %L511
L510:
  %t514 = getelementptr i64, ptr %t508, i64 1
  %t515 = load i64, ptr %t514
  %t516 = inttoptr i64 %t515 to ptr
  %t517 = icmp eq ptr %t516, null
  br i1 %t517, label %L518, label %L519
L519:
  %t523 = call double @m._pystachy_complex$complex.__abs__(ptr %t516)
  %t541 = bitcast double %t523 to i64
  %t542 = call ptr @pys_ubox(i64 3, i64 %t541)
  br label %L509
L511:
  %t526 = load i64, ptr %t508
  %t527 = icmp eq i64 %t526, 3
  br i1 %t527, label %L524, label %L525
L524:
  %t528 = getelementptr i64, ptr %t508, i64 1
  %t529 = load i64, ptr %t528
  %t530 = bitcast i64 %t529 to double
  %t531 = call double @fabs(double %t530)
  %t543 = bitcast double %t531 to i64
  %t544 = call ptr @pys_ubox(i64 3, i64 %t543)
  br label %L509
L525:
  br label %L532
L532:
  %t533 = getelementptr i64, ptr %t508, i64 1
  %t534 = load i64, ptr %t533
  %t535 = icmp slt i64 %t534, 0
  %t536 = call {i64, i1} @llvm.ssub.with.overflow.i64(i64 0, i64 %t534)
  %t537 = extractvalue {i64, i1} %t536, 0
  %t538 = extractvalue {i64, i1} %t536, 1
  br i1 %t538, label %L341, label %L539
L539:
  %t540 = select i1 %t535, i64 %t537, i64 %t534
  %t545 = call ptr @pys_ubox(i64 1, i64 %t540)
  br label %L509
L509:
  %t546 = phi ptr [%t542, %L519], [%t544, %L524], [%t545, %L539]
  %t547 = load ptr, ptr %v.2
  %t548 = load i64, ptr %t547
  %t551 = icmp eq i64 %t548, 4
  br i1 %t551, label %L549, label %L550
L549:
  %t552 = getelementptr i64, ptr %t547, i64 1
  %t553 = load i64, ptr %t552
  %t554 = inttoptr i64 %t553 to ptr
  br label %L555
L550:
  %t558 = icmp eq i64 %t548, 3
  br i1 %t558, label %L556, label %L557
L556:
  %t559 = getelementptr i64, ptr %t547, i64 1
  %t560 = load i64, ptr %t559
  %t561 = bitcast i64 %t560 to double
  br label %L562
L557:
  br label %L563
L563:
  %t564 = getelementptr i64, ptr %t547, i64 1
  %t565 = load i64, ptr %t564
  br label %L566
L555:
  br label %L567
L562:
  br label %L567
L566:
  br label %L567
L567:
  %t568 = phi ptr [@pys.refl.c._pystachy_complex$complex, %L555], [@pys.refl.b.float, %L562], [@pys.refl.b.int, %L566]
  %t569 = load ptr, ptr %t568
  %t571 = load i64, ptr %t348
  %t574 = icmp eq i64 %t571, 4
  br i1 %t574, label %L573, label %L572
L573:
  %t575 = getelementptr i64, ptr %t348, i64 1
  %t576 = load i64, ptr %t575
  %t577 = inttoptr i64 %t576 to ptr
  %t581 = icmp eq ptr %t577, null
  br i1 %t581, label %L578, label %L579
L578:
  br label %L580
L579:
  %t582 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t577)
  br label %L580
L580:
  %t583 = phi ptr [@s.4, %L578], [%t582, %L579]
  br label %L570
L572:
  %t586 = icmp eq i64 %t571, 3
  br i1 %t586, label %L585, label %L584
L585:
  %t587 = getelementptr i64, ptr %t348, i64 1
  %t588 = load i64, ptr %t587
  %t589 = bitcast i64 %t588 to double
  %t590 = call ptr @pys_str_float(double %t589)
  br label %L570
L584:
  %t591 = getelementptr i64, ptr %t348, i64 1
  %t592 = load i64, ptr %t591
  %t593 = call ptr @pys_str_int(i64 %t592)
  br label %L570
L570:
  %t594 = phi ptr [%t583, %L580], [%t590, %L585], [%t593, %L584]
  call void @pys_write(ptr %t594, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t596 = load i64, ptr %t388
  %t599 = icmp eq i64 %t596, 4
  br i1 %t599, label %L598, label %L597
L598:
  %t600 = getelementptr i64, ptr %t388, i64 1
  %t601 = load i64, ptr %t600
  %t602 = inttoptr i64 %t601 to ptr
  %t606 = icmp eq ptr %t602, null
  br i1 %t606, label %L603, label %L604
L603:
  br label %L605
L604:
  %t607 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t602)
  br label %L605
L605:
  %t608 = phi ptr [@s.4, %L603], [%t607, %L604]
  br label %L595
L597:
  %t611 = icmp eq i64 %t596, 3
  br i1 %t611, label %L610, label %L609
L610:
  %t612 = getelementptr i64, ptr %t388, i64 1
  %t613 = load i64, ptr %t612
  %t614 = bitcast i64 %t613 to double
  %t615 = call ptr @pys_str_float(double %t614)
  br label %L595
L609:
  %t616 = getelementptr i64, ptr %t388, i64 1
  %t617 = load i64, ptr %t616
  %t618 = call ptr @pys_str_int(i64 %t617)
  br label %L595
L595:
  %t619 = phi ptr [%t608, %L605], [%t615, %L610], [%t618, %L609]
  call void @pys_write(ptr %t619, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t621 = load i64, ptr %t425
  %t624 = icmp eq i64 %t621, 4
  br i1 %t624, label %L623, label %L622
L623:
  %t625 = getelementptr i64, ptr %t425, i64 1
  %t626 = load i64, ptr %t625
  %t627 = inttoptr i64 %t626 to ptr
  %t631 = icmp eq ptr %t627, null
  br i1 %t631, label %L628, label %L629
L628:
  br label %L630
L629:
  %t632 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t627)
  br label %L630
L630:
  %t633 = phi ptr [@s.4, %L628], [%t632, %L629]
  br label %L620
L622:
  %t636 = icmp eq i64 %t621, 3
  br i1 %t636, label %L635, label %L634
L635:
  %t637 = getelementptr i64, ptr %t425, i64 1
  %t638 = load i64, ptr %t637
  %t639 = bitcast i64 %t638 to double
  %t640 = call ptr @pys_str_float(double %t639)
  br label %L620
L634:
  %t641 = getelementptr i64, ptr %t425, i64 1
  %t642 = load i64, ptr %t641
  %t643 = call ptr @pys_str_int(i64 %t642)
  br label %L620
L620:
  %t644 = phi ptr [%t633, %L630], [%t640, %L635], [%t643, %L634]
  call void @pys_write(ptr %t644, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t646 = load i64, ptr %t463
  %t649 = icmp eq i64 %t646, 4
  br i1 %t649, label %L648, label %L647
L648:
  %t650 = getelementptr i64, ptr %t463, i64 1
  %t651 = load i64, ptr %t650
  %t652 = inttoptr i64 %t651 to ptr
  %t656 = icmp eq ptr %t652, null
  br i1 %t656, label %L653, label %L654
L653:
  br label %L655
L654:
  %t657 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t652)
  br label %L655
L655:
  %t658 = phi ptr [@s.4, %L653], [%t657, %L654]
  br label %L645
L647:
  %t659 = getelementptr i64, ptr %t463, i64 1
  %t660 = load i64, ptr %t659
  %t661 = bitcast i64 %t660 to double
  %t662 = call ptr @pys_str_float(double %t661)
  br label %L645
L645:
  %t663 = phi ptr [%t658, %L655], [%t662, %L647]
  call void @pys_write(ptr %t663, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t667 = icmp eq ptr %t507, null
  br i1 %t667, label %L664, label %L665
L664:
  br label %L666
L665:
  %t668 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t507)
  br label %L666
L666:
  %t669 = phi ptr [@s.4, %L664], [%t668, %L665]
  call void @pys_write(ptr %t669, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t671 = load i64, ptr %t546
  %t674 = icmp eq i64 %t671, 3
  br i1 %t674, label %L673, label %L672
L673:
  %t675 = getelementptr i64, ptr %t546, i64 1
  %t676 = load i64, ptr %t675
  %t677 = bitcast i64 %t676 to double
  %t678 = call ptr @pys_str_float(double %t677)
  br label %L670
L672:
  %t679 = getelementptr i64, ptr %t546, i64 1
  %t680 = load i64, ptr %t679
  %t681 = call ptr @pys_str_int(i64 %t680)
  br label %L670
L670:
  %t682 = phi ptr [%t678, %L673], [%t681, %L672]
  call void @pys_write(ptr %t682, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  call void @pys_write(ptr %t569, i64 1)
  call void @pys_write(ptr @s.2, i64 1)
  %t683 = load ptr, ptr %v.2
  %t687 = load i64, ptr %t683
  %t688 = icmp eq i64 %t687, 4
  br i1 %t688, label %L684, label %L685
L684:
  %t689 = getelementptr i64, ptr %t683, i64 1
  %t690 = load i64, ptr %t689
  %t691 = inttoptr i64 %t690 to ptr
  %t692 = call ptr @m._pystachy_complex$complex.__format__(ptr %t691, ptr @s.48)
  br label %L686
L685:
  %t693 = ptrtoint ptr %t683 to i64
  %t694 = call ptr @pys_format(i64 %t693, ptr @s.49, ptr @s.48)
  br label %L686
L686:
  %t695 = phi ptr [%t692, %L684], [%t694, %L685]
  %t696 = load ptr, ptr %v.2
  %t700 = load i64, ptr %t696
  %t701 = icmp eq i64 %t700, 4
  br i1 %t701, label %L697, label %L698
L697:
  %t702 = getelementptr i64, ptr %t696, i64 1
  %t703 = load i64, ptr %t702
  %t704 = inttoptr i64 %t703 to ptr
  %t705 = call ptr @m._pystachy_complex$complex.__format__(ptr %t704, ptr @s.50)
  br label %L699
L698:
  %t706 = ptrtoint ptr %t696 to i64
  %t707 = call ptr @pys_format(i64 %t706, ptr @s.49, ptr @s.50)
  br label %L699
L699:
  %t708 = phi ptr [%t705, %L697], [%t707, %L698]
  %t709 = load ptr, ptr %v.2
  %t711 = load i64, ptr %t709
  %t714 = icmp eq i64 %t711, 4
  br i1 %t714, label %L713, label %L712
L713:
  %t715 = getelementptr i64, ptr %t709, i64 1
  %t716 = load i64, ptr %t715
  %t717 = inttoptr i64 %t716 to ptr
  %t721 = icmp eq ptr %t717, null
  br i1 %t721, label %L718, label %L719
L718:
  br label %L720
L719:
  %t722 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t717)
  br label %L720
L720:
  %t723 = phi ptr [@s.4, %L718], [%t722, %L719]
  br label %L710
L712:
  %t726 = icmp eq i64 %t711, 3
  br i1 %t726, label %L725, label %L724
L725:
  %t727 = getelementptr i64, ptr %t709, i64 1
  %t728 = load i64, ptr %t727
  %t729 = bitcast i64 %t728 to double
  %t730 = call ptr @pys_str_float(double %t729)
  br label %L710
L724:
  %t731 = getelementptr i64, ptr %t709, i64 1
  %t732 = load i64, ptr %t731
  %t733 = call ptr @pys_str_int(i64 %t732)
  br label %L710
L710:
  %t734 = phi ptr [%t723, %L720], [%t730, %L725], [%t733, %L724]
  %t735 = load ptr, ptr %v.2
  %t736 = ptrtoint ptr %t735 to i64
  %t737 = call ptr @pys_repr(i64 %t736, ptr @s.49)
  %t738 = call ptr @pys_str_cat(i64 5, ptr %t708, ptr @s.51, ptr %t734, ptr @s.51, ptr %t737, ptr null, ptr null, ptr null)
  %t739 = load ptr, ptr %v.2
  %t741 = load i64, ptr %t739
  %t744 = icmp eq i64 %t741, 4
  br i1 %t744, label %L743, label %L742
L743:
  %t745 = getelementptr i64, ptr %t739, i64 1
  %t746 = load i64, ptr %t745
  %t747 = inttoptr i64 %t746 to ptr
  %t751 = icmp eq ptr %t747, null
  br i1 %t751, label %L748, label %L749
L748:
  br label %L750
L749:
  %t752 = call ptr @m._pystachy_complex$complex.__repr__(ptr %t747)
  br label %L750
L750:
  %t753 = phi ptr [@s.4, %L748], [%t752, %L749]
  br label %L740
L742:
  %t756 = icmp eq i64 %t741, 3
  br i1 %t756, label %L755, label %L754
L755:
  %t757 = getelementptr i64, ptr %t739, i64 1
  %t758 = load i64, ptr %t757
  %t759 = bitcast i64 %t758 to double
  %t760 = call ptr @pys_str_float(double %t759)
  br label %L740
L754:
  %t761 = getelementptr i64, ptr %t739, i64 1
  %t762 = load i64, ptr %t761
  %t763 = call ptr @pys_str_int(i64 %t762)
  br label %L740
L740:
  %t764 = phi ptr [%t753, %L750], [%t760, %L755], [%t763, %L754]
  %t765 = load ptr, ptr %v.2
  %t767 = load i64, ptr %t765
  %t770 = icmp eq i64 %t767, 4
  br i1 %t770, label %L769, label %L768
L769:
  %t771 = getelementptr i64, ptr %t765, i64 1
  %t772 = load i64, ptr %t771
  %t773 = inttoptr i64 %t772 to ptr
  %t774 = icmp ne ptr %t773, null
  br i1 %t774, label %L775, label %L776
L775:
  %t777 = call i1 @m._pystachy_complex$complex.__bool__(ptr %t773)
  br label %L776
L776:
  %t778 = phi i1 [false, %L769], [%t777, %L775]
  br label %L766
L768:
  %t781 = icmp eq i64 %t767, 3
  br i1 %t781, label %L780, label %L779
L780:
  %t782 = getelementptr i64, ptr %t765, i64 1
  %t783 = load i64, ptr %t782
  %t784 = bitcast i64 %t783 to double
  %t785 = fcmp une double %t784, 0.0
  br label %L766
L779:
  %t786 = getelementptr i64, ptr %t765, i64 1
  %t787 = load i64, ptr %t786
  %t788 = icmp ne i64 %t787, 0
  br label %L766
L766:
  %t789 = phi i1 [%t778, %L776], [%t785, %L780], [%t788, %L779]
  call void @pys_write(ptr %t695, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  call void @pys_write(ptr %t738, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  call void @pys_write(ptr %t764, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  %t790 = select i1 %t789, ptr @s.5, ptr @s.6
  call void @pys_write(ptr %t790, i64 1)
  call void @pys_write(ptr @s.2, i64 1)
  store i64 %t791, ptr @pys_recursion_state, !tbaa !6
  ret void
  br label %L324
L324:
  call void @pys_raise(ptr @s.29, ptr @s.52)
  unreachable
L341:
  call void @pys_raise(ptr @s.26, ptr @s.25)
  unreachable
L359:
  call void @pys_raise(ptr @s.29, ptr @s.53)
  unreachable
L399:
  call void @pys_raise(ptr @s.29, ptr @s.54)
  unreachable
L436:
  call void @pys_raise(ptr @s.29, ptr @s.55)
  unreachable
L475:
  call void @pys_raise(ptr @s.29, ptr @s.56)
  unreachable
L518:
  call void @pys_raise(ptr @s.29, ptr @s.57)
  unreachable
}

define i32 @main(i32 %argc, ptr %argv) {
  %sb = call ptr @llvm.frameaddress.p0(i32 0)
  call void @pys_init(i32 %argc, ptr %argv, ptr %sb, ptr @pys.roots, i64 7)
  call void @main.init()
  call void @pys_finish()
  ret i32 0
}
