define internal void @main.init() {
entry:
  call void @init.enum()
  call void @init.enum()
  store i1 true, ptr @g.IntEnum.imp
  store i1 true, ptr @g.IntFlag.imp
  call void @init.enum()
  call void @init.enum()
  store i1 true, ptr @g._pys_EnumType.imp
  store i1 true, ptr @g._pys_FlagType.imp
  %t2 = call ptr @pys_alloc(i64 ptrtoint (ptr getelementptr (%C.E, ptr null, i32 1) to i64))
  store i64 9, ptr %t2
  %t3 = getelementptr %C.E, ptr %t2, i32 0, i32 1
  store ptr @s.12, ptr %t3, !tbaa !27
  %t4 = getelementptr %C.E, ptr %t2, i32 0, i32 2
  store i1 true, ptr %t4, !tbaa !28
  %t5 = getelementptr %C.E, ptr %t2, i32 0, i32 4
  store i64 1, ptr %t5, !tbaa !29
  %t6 = getelementptr %C.E, ptr %t2, i32 0, i32 5
  store i1 true, ptr %t6, !tbaa !30
  %t7 = getelementptr %C.E, ptr %t2, i32 0, i32 3
  store i64 1, ptr %t7, !tbaa !31
  store ptr %t2, ptr @d.c.E.ONE
  %t8 = load i1, ptr @g._pys_EnumType.imp
  %t9 = xor i1 %t8, true
  br i1 %t9, label %L10, label %L11
L11:
  %t12 = load ptr, ptr @d.c.E.ONE
  %t13 = call ptr @pys_list_new(i64 1)
  %t14 = ptrtoint ptr %t12 to i64
  call void @pys_list_append(ptr %t13, i64 %t14)
  %t15 = load ptr, ptr @d.c.E.ONE
  %t16 = call ptr @pys_dict_new(i64 1, i64 1)
  %t17 = ptrtoint ptr @s.12 to i64
  %t18 = ptrtoint ptr %t15 to i64
  call void @pys_dict_set(ptr %t16, i64 %t17, i64 %t18)
  %t19 = call ptr @pys_alloc(i64 ptrtoint (ptr getelementptr (%C.enum$EnumType-1, ptr null, i32 1) to i64))
  call void @m.enum$EnumType-1.__init__.1(ptr %t19, ptr @s.13, ptr %t13, ptr %t16)
  store ptr %t19, ptr @g._pys_enum_E
  %t20 = call ptr @pys_alloc(i64 ptrtoint (ptr getelementptr (%C.F, ptr null, i32 1) to i64))
  store i64 10, ptr %t20
  %t21 = getelementptr %C.F, ptr %t20, i32 0, i32 1
  store ptr @s.17, ptr %t21, !tbaa !27
  %t22 = getelementptr %C.F, ptr %t20, i32 0, i32 2
  store i1 true, ptr %t22, !tbaa !28
  %t23 = getelementptr %C.F, ptr %t20, i32 0, i32 3
  store i64 1, ptr %t23, !tbaa !32
  %t24 = getelementptr %C.F, ptr %t20, i32 0, i32 4
  store i1 true, ptr %t24, !tbaa !33
  %t25 = getelementptr %C.F, ptr %t20, i32 0, i32 5
  store i64 1, ptr %t25, !tbaa !34
  store ptr %t20, ptr @d.c.F.A
  %t26 = call ptr @pys_alloc(i64 ptrtoint (ptr getelementptr (%C.F, ptr null, i32 1) to i64))
  store i64 10, ptr %t26
  %t27 = getelementptr %C.F, ptr %t26, i32 0, i32 1
  store ptr @s.18, ptr %t27, !tbaa !27
  %t28 = getelementptr %C.F, ptr %t26, i32 0, i32 2
  store i1 true, ptr %t28, !tbaa !28
  %t29 = getelementptr %C.F, ptr %t26, i32 0, i32 3
  store i64 2, ptr %t29, !tbaa !32
  %t30 = getelementptr %C.F, ptr %t26, i32 0, i32 4
  store i1 true, ptr %t30, !tbaa !33
  %t31 = getelementptr %C.F, ptr %t26, i32 0, i32 5
  store i64 2, ptr %t31, !tbaa !34
  store ptr %t26, ptr @d.c.F.B
  store i1 true, ptr @g.F.def
  %t32 = load i1, ptr @g._pys_FlagType.imp
  %t33 = xor i1 %t32, true
  br i1 %t33, label %L34, label %L35
L35:
  %t36 = load ptr, ptr @d.c.F.A
  %t37 = load ptr, ptr @d.c.F.B
  %t38 = call ptr @pys_list_new(i64 2)
  %t39 = ptrtoint ptr %t36 to i64
  call void @pys_list_append(ptr %t38, i64 %t39)
  %t40 = ptrtoint ptr %t37 to i64
  call void @pys_list_append(ptr %t38, i64 %t40)
  %t41 = load ptr, ptr @d.c.F.A
  %t42 = load ptr, ptr @d.c.F.B
  %t43 = call ptr @pys_dict_new(i64 1, i64 2)
  %t44 = ptrtoint ptr @s.17 to i64
  %t45 = ptrtoint ptr %t41 to i64
  call void @pys_dict_set(ptr %t43, i64 %t44, i64 %t45)
  %t46 = ptrtoint ptr @s.18 to i64
  %t47 = ptrtoint ptr %t42 to i64
  call void @pys_dict_set(ptr %t43, i64 %t46, i64 %t47)
  %t48 = load ptr, ptr @d.c.F.A
  %t49 = load ptr, ptr @d.c.F.B
  %t50 = call ptr @pys_dict_new(i64 0, i64 2)
  %t51 = ptrtoint ptr %t48 to i64
  call void @pys_dict_set(ptr %t50, i64 1, i64 %t51)
  %t52 = ptrtoint ptr %t49 to i64
  call void @pys_dict_set(ptr %t50, i64 2, i64 %t52)
  %t53 = call ptr @pys_alloc(i64 ptrtoint (ptr getelementptr (%C.enum$_FlagType-1, ptr null, i32 1) to i64))
  call void @m.enum$_FlagType-1.__init__.1(ptr %t53, ptr @s.19, ptr %t38, ptr %t43, ptr %t50, i64 3, i64 3, i64 3, i1 true)
  store ptr %t53, ptr @g._pys_enum_F
  store i1 true, ptr @g._pys_enum_F.def
  %t54 = call ptr @pys_ubox(i64 1, i64 1)
  call void @f.numbers(ptr %t54)
  %t55 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t55, double 0.0, double 0.0)
  %t56 = sitofp i64 1 to double
  %t57 = getelementptr %C._pystachy_complex$complex, ptr %t55, i32 0, i32 0
  %t58 = load double, ptr %t57
  %t59 = getelementptr %C._pystachy_complex$complex, ptr %t55, i32 0, i32 1
  %t60 = load double, ptr %t59
  %t61 = call ptr @f._pystachy_complex$_sum(double %t56, double 0.0, double %t58, double %t60)
  %t62 = ptrtoint ptr %t61 to i64
  %t63 = call ptr @pys_ubox(i64 2, i64 %t62)
  call void @f.numbers(ptr %t63)
  %t64 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t64, double 0.0, double 2.0)
  %t65 = ptrtoint ptr %t64 to i64
  %t66 = call ptr @pys_ubox(i64 2, i64 %t65)
  call void @f.numbers(ptr %t66)
  call void @f.maybe(ptr null)
  %t67 = bitcast double 1.0 to i64
  %t68 = call ptr @pys_ubox(i64 3, i64 %t67)
  call void @f.maybe(ptr %t68)
  %t69 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t69, double 0.0, double 0.0)
  %t70 = sitofp i64 1 to double
  %t71 = getelementptr %C._pystachy_complex$complex, ptr %t69, i32 0, i32 0
  %t72 = load double, ptr %t71
  %t73 = getelementptr %C._pystachy_complex$complex, ptr %t69, i32 0, i32 1
  %t74 = load double, ptr %t73
  %t75 = call ptr @f._pystachy_complex$_sum(double %t70, double 0.0, double %t72, double %t74)
  %t76 = ptrtoint ptr %t75 to i64
  %t77 = call ptr @pys_ubox(i64 2, i64 %t76)
  call void @f.maybe(ptr %t77)
  %t78 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t78, double 0.0, double 1.0)
  %t79 = ptrtoint ptr %t78 to i64
  %t80 = call ptr @pys_ubox(i64 2, i64 %t79)
  call void @f.maybe(ptr %t80)
  ret void
  br label %L10
L10:
  call void @pys_raise(ptr @s.22, ptr @s.21)
  unreachable
L34:
  call void @pys_raise(ptr @s.22, ptr @s.23)
  unreachable
}

define internal void @f.numbers(ptr %a0) {
entry:
  %v.2 = alloca ptr
  store ptr zeroinitializer, ptr %v.2
  %h.416 = alloca i64
  store i64 zeroinitializer, ptr %h.416
  store ptr %a0, ptr %v.2
  %t3 = load ptr, ptr %v.2
  %t4 = load ptr, ptr @d.c.E.ONE
  %t8 = load i64, ptr %t3
  %t9 = icmp eq i64 %t8, 2
  br i1 %t9, label %L6, label %L7
L6:
  %t10 = getelementptr i64, ptr %t3, i64 1
  %t11 = load i64, ptr %t10
  %t12 = inttoptr i64 %t11 to ptr
  %t16 = icmp eq ptr %t4, null
  br i1 %t16, label %L13, label %L14
L13:
  %t17 = icmp eq ptr %t12, null
  br label %L15
L14:
  %t18 = getelementptr %C.E, ptr %t4, i32 0, i32 3
  %t19 = load i64, ptr %t18, !tbaa !31
  %t20 = icmp eq ptr %t12, null
  br i1 %t20, label %L21, label %L22
L21:
  br label %L23
L22:
  %t24 = getelementptr %C._pystachy_complex$complex, ptr %t12, i32 0, i32 0
  %t25 = load double, ptr %t24
  %t26 = getelementptr %C._pystachy_complex$complex, ptr %t12, i32 0, i32 1
  %t27 = load double, ptr %t26
  %t28 = fcmp oeq double %t27, 0.0
  %t29 = call i64 @pys_cmp_if(i64 %t19, double %t25)
  %t30 = icmp eq i64 %t29, 2
  %t31 = sub i64 0, %t29
  %t32 = select i1 %t30, i64 2, i64 %t31
  %t33 = icmp eq i64 %t32, 0
  %t34 = and i1 %t28, %t33
  br label %L23
L23:
  %t35 = phi i1 [false, %L21], [%t34, %L22]
  br label %L15
L15:
  %t36 = phi i1 [%t17, %L13], [%t35, %L23]
  br label %L5
L7:
  br label %L37
L37:
  %t38 = getelementptr i64, ptr %t3, i64 1
  %t39 = load i64, ptr %t38
  %t43 = icmp eq ptr %t4, null
  br i1 %t43, label %L40, label %L41
L40:
  br label %L42
L41:
  %t44 = getelementptr %C.E, ptr %t4, i32 0, i32 3
  %t45 = load i64, ptr %t44, !tbaa !31
  %t46 = icmp eq i64 %t39, %t45
  br label %L42
L42:
  %t47 = phi i1 [false, %L40], [%t46, %L41]
  br label %L5
L5:
  %t48 = phi i1 [%t36, %L15], [%t47, %L42]
  %t49 = load ptr, ptr @d.c.E.ONE
  %t50 = load ptr, ptr %v.2
  %t54 = load i64, ptr %t50
  %t55 = icmp eq i64 %t54, 2
  br i1 %t55, label %L52, label %L53
L52:
  %t56 = getelementptr i64, ptr %t50, i64 1
  %t57 = load i64, ptr %t56
  %t58 = inttoptr i64 %t57 to ptr
  %t62 = icmp eq ptr %t49, null
  br i1 %t62, label %L59, label %L60
L59:
  %t63 = icmp eq ptr %t58, null
  br label %L61
L60:
  %t64 = getelementptr %C.E, ptr %t49, i32 0, i32 3
  %t65 = load i64, ptr %t64, !tbaa !31
  %t66 = icmp eq ptr %t58, null
  br i1 %t66, label %L67, label %L68
L67:
  br label %L69
L68:
  %t70 = getelementptr %C._pystachy_complex$complex, ptr %t58, i32 0, i32 0
  %t71 = load double, ptr %t70
  %t72 = getelementptr %C._pystachy_complex$complex, ptr %t58, i32 0, i32 1
  %t73 = load double, ptr %t72
  %t74 = fcmp oeq double %t73, 0.0
  %t75 = call i64 @pys_cmp_if(i64 %t65, double %t71)
  %t76 = icmp eq i64 %t75, 2
  %t77 = sub i64 0, %t75
  %t78 = select i1 %t76, i64 2, i64 %t77
  %t79 = icmp eq i64 %t78, 0
  %t80 = and i1 %t74, %t79
  br label %L69
L69:
  %t81 = phi i1 [false, %L67], [%t80, %L68]
  br label %L61
L61:
  %t82 = phi i1 [%t63, %L59], [%t81, %L69]
  br label %L51
L53:
  br label %L83
L83:
  %t84 = getelementptr i64, ptr %t50, i64 1
  %t85 = load i64, ptr %t84
  %t89 = icmp eq ptr %t49, null
  br i1 %t89, label %L86, label %L87
L86:
  br label %L88
L87:
  %t90 = getelementptr %C.E, ptr %t49, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !31
  %t92 = icmp eq i64 %t91, %t85
  br label %L88
L88:
  %t93 = phi i1 [false, %L86], [%t92, %L87]
  br label %L51
L51:
  %t94 = phi i1 [%t82, %L61], [%t93, %L88]
  %t95 = load ptr, ptr %v.2
  %t96 = load ptr, ptr @d.c.E.ONE
  %t100 = load i64, ptr %t95
  %t101 = icmp eq i64 %t100, 2
  br i1 %t101, label %L98, label %L99
L98:
  %t102 = getelementptr i64, ptr %t95, i64 1
  %t103 = load i64, ptr %t102
  %t104 = inttoptr i64 %t103 to ptr
  %t108 = icmp eq ptr %t96, null
  br i1 %t108, label %L105, label %L106
L105:
  %t109 = icmp ne ptr %t104, null
  br label %L107
L106:
  %t110 = getelementptr %C.E, ptr %t96, i32 0, i32 3
  %t111 = load i64, ptr %t110, !tbaa !31
  %t112 = icmp eq ptr %t104, null
  br i1 %t112, label %L113, label %L114
L113:
  %t116 = xor i1 false, true
  br label %L115
L114:
  %t117 = getelementptr %C._pystachy_complex$complex, ptr %t104, i32 0, i32 0
  %t118 = load double, ptr %t117
  %t119 = getelementptr %C._pystachy_complex$complex, ptr %t104, i32 0, i32 1
  %t120 = load double, ptr %t119
  %t121 = fcmp oeq double %t120, 0.0
  %t122 = call i64 @pys_cmp_if(i64 %t111, double %t118)
  %t123 = icmp eq i64 %t122, 2
  %t124 = sub i64 0, %t122
  %t125 = select i1 %t123, i64 2, i64 %t124
  %t126 = icmp eq i64 %t125, 0
  %t127 = and i1 %t121, %t126
  %t128 = xor i1 %t127, true
  br label %L115
L115:
  %t129 = phi i1 [%t116, %L113], [%t128, %L114]
  br label %L107
L107:
  %t130 = phi i1 [%t109, %L105], [%t129, %L115]
  br label %L97
L99:
  br label %L131
L131:
  %t132 = getelementptr i64, ptr %t95, i64 1
  %t133 = load i64, ptr %t132
  %t137 = icmp eq ptr %t96, null
  br i1 %t137, label %L134, label %L135
L134:
  br label %L136
L135:
  %t138 = getelementptr %C.E, ptr %t96, i32 0, i32 3
  %t139 = load i64, ptr %t138, !tbaa !31
  %t140 = icmp ne i64 %t133, %t139
  br label %L136
L136:
  %t141 = phi i1 [true, %L134], [%t140, %L135]
  br label %L97
L97:
  %t142 = phi i1 [%t130, %L107], [%t141, %L136]
  %t143 = load ptr, ptr @d.c.E.ONE
  %t144 = load ptr, ptr %v.2
  %t148 = load i64, ptr %t144
  %t149 = icmp eq i64 %t148, 2
  br i1 %t149, label %L146, label %L147
L146:
  %t150 = getelementptr i64, ptr %t144, i64 1
  %t151 = load i64, ptr %t150
  %t152 = inttoptr i64 %t151 to ptr
  %t156 = icmp eq ptr %t143, null
  br i1 %t156, label %L153, label %L154
L153:
  %t157 = icmp ne ptr %t152, null
  br label %L155
L154:
  %t158 = getelementptr %C.E, ptr %t143, i32 0, i32 3
  %t159 = load i64, ptr %t158, !tbaa !31
  %t160 = icmp eq ptr %t152, null
  br i1 %t160, label %L161, label %L162
L161:
  %t164 = xor i1 false, true
  br label %L163
L162:
  %t165 = getelementptr %C._pystachy_complex$complex, ptr %t152, i32 0, i32 0
  %t166 = load double, ptr %t165
  %t167 = getelementptr %C._pystachy_complex$complex, ptr %t152, i32 0, i32 1
  %t168 = load double, ptr %t167
  %t169 = fcmp oeq double %t168, 0.0
  %t170 = call i64 @pys_cmp_if(i64 %t159, double %t166)
  %t171 = icmp eq i64 %t170, 2
  %t172 = sub i64 0, %t170
  %t173 = select i1 %t171, i64 2, i64 %t172
  %t174 = icmp eq i64 %t173, 0
  %t175 = and i1 %t169, %t174
  %t176 = xor i1 %t175, true
  br label %L163
L163:
  %t177 = phi i1 [%t164, %L161], [%t176, %L162]
  br label %L155
L155:
  %t178 = phi i1 [%t157, %L153], [%t177, %L163]
  br label %L145
L147:
  br label %L179
L179:
  %t180 = getelementptr i64, ptr %t144, i64 1
  %t181 = load i64, ptr %t180
  %t185 = icmp eq ptr %t143, null
  br i1 %t185, label %L182, label %L183
L182:
  br label %L184
L183:
  %t186 = getelementptr %C.E, ptr %t143, i32 0, i32 3
  %t187 = load i64, ptr %t186, !tbaa !31
  %t188 = icmp ne i64 %t187, %t181
  br label %L184
L184:
  %t189 = phi i1 [true, %L182], [%t188, %L183]
  br label %L145
L145:
  %t190 = phi i1 [%t178, %L155], [%t189, %L184]
  %t191 = load ptr, ptr %v.2
  %t192 = load i1, ptr @g.F.def
  %t193 = xor i1 %t192, true
  br i1 %t193, label %L194, label %L195
L195:
  %t196 = load ptr, ptr @d.c.F.B
  %t200 = load i64, ptr %t191
  %t201 = icmp eq i64 %t200, 2
  br i1 %t201, label %L198, label %L199
L198:
  %t202 = getelementptr i64, ptr %t191, i64 1
  %t203 = load i64, ptr %t202
  %t204 = inttoptr i64 %t203 to ptr
  %t208 = icmp eq ptr %t196, null
  br i1 %t208, label %L205, label %L206
L205:
  %t209 = icmp eq ptr %t204, null
  br label %L207
L206:
  %t210 = getelementptr %C.F, ptr %t196, i32 0, i32 5
  %t211 = load i64, ptr %t210, !tbaa !34
  %t212 = icmp eq ptr %t204, null
  br i1 %t212, label %L213, label %L214
L213:
  br label %L215
L214:
  %t216 = getelementptr %C._pystachy_complex$complex, ptr %t204, i32 0, i32 0
  %t217 = load double, ptr %t216
  %t218 = getelementptr %C._pystachy_complex$complex, ptr %t204, i32 0, i32 1
  %t219 = load double, ptr %t218
  %t220 = fcmp oeq double %t219, 0.0
  %t221 = call i64 @pys_cmp_if(i64 %t211, double %t217)
  %t222 = icmp eq i64 %t221, 2
  %t223 = sub i64 0, %t221
  %t224 = select i1 %t222, i64 2, i64 %t223
  %t225 = icmp eq i64 %t224, 0
  %t226 = and i1 %t220, %t225
  br label %L215
L215:
  %t227 = phi i1 [false, %L213], [%t226, %L214]
  br label %L207
L207:
  %t228 = phi i1 [%t209, %L205], [%t227, %L215]
  br label %L197
L199:
  br label %L229
L229:
  %t230 = getelementptr i64, ptr %t191, i64 1
  %t231 = load i64, ptr %t230
  %t235 = icmp eq ptr %t196, null
  br i1 %t235, label %L232, label %L233
L232:
  br label %L234
L233:
  %t236 = getelementptr %C.F, ptr %t196, i32 0, i32 5
  %t237 = load i64, ptr %t236, !tbaa !34
  %t238 = icmp eq i64 %t231, %t237
  br label %L234
L234:
  %t239 = phi i1 [false, %L232], [%t238, %L233]
  br label %L197
L197:
  %t240 = phi i1 [%t228, %L207], [%t239, %L234]
  %t241 = load i1, ptr @g.F.def
  %t242 = xor i1 %t241, true
  br i1 %t242, label %L194, label %L243
L243:
  %t244 = load ptr, ptr @d.c.F.A
  %t245 = load ptr, ptr %v.2
  %t249 = load i64, ptr %t245
  %t250 = icmp eq i64 %t249, 2
  br i1 %t250, label %L247, label %L248
L247:
  %t251 = getelementptr i64, ptr %t245, i64 1
  %t252 = load i64, ptr %t251
  %t253 = inttoptr i64 %t252 to ptr
  %t257 = icmp eq ptr %t244, null
  br i1 %t257, label %L254, label %L255
L254:
  %t258 = icmp ne ptr %t253, null
  br label %L256
L255:
  %t259 = getelementptr %C.F, ptr %t244, i32 0, i32 5
  %t260 = load i64, ptr %t259, !tbaa !34
  %t261 = icmp eq ptr %t253, null
  br i1 %t261, label %L262, label %L263
L262:
  %t265 = xor i1 false, true
  br label %L264
L263:
  %t266 = getelementptr %C._pystachy_complex$complex, ptr %t253, i32 0, i32 0
  %t267 = load double, ptr %t266
  %t268 = getelementptr %C._pystachy_complex$complex, ptr %t253, i32 0, i32 1
  %t269 = load double, ptr %t268
  %t270 = fcmp oeq double %t269, 0.0
  %t271 = call i64 @pys_cmp_if(i64 %t260, double %t267)
  %t272 = icmp eq i64 %t271, 2
  %t273 = sub i64 0, %t271
  %t274 = select i1 %t272, i64 2, i64 %t273
  %t275 = icmp eq i64 %t274, 0
  %t276 = and i1 %t270, %t275
  %t277 = xor i1 %t276, true
  br label %L264
L264:
  %t278 = phi i1 [%t265, %L262], [%t277, %L263]
  br label %L256
L256:
  %t279 = phi i1 [%t258, %L254], [%t278, %L264]
  br label %L246
L248:
  br label %L280
L280:
  %t281 = getelementptr i64, ptr %t245, i64 1
  %t282 = load i64, ptr %t281
  %t286 = icmp eq ptr %t244, null
  br i1 %t286, label %L283, label %L284
L283:
  br label %L285
L284:
  %t287 = getelementptr %C.F, ptr %t244, i32 0, i32 5
  %t288 = load i64, ptr %t287, !tbaa !34
  %t289 = icmp ne i64 %t288, %t282
  br label %L285
L285:
  %t290 = phi i1 [true, %L283], [%t289, %L284]
  br label %L246
L246:
  %t291 = phi i1 [%t279, %L256], [%t290, %L285]
  %t292 = select i1 %t48, ptr @s.26, ptr @s.27
  call void @pys_write(ptr %t292, i64 1)
  call void @pys_write(ptr @s.24, i64 1)
  %t293 = select i1 %t94, ptr @s.26, ptr @s.27
  call void @pys_write(ptr %t293, i64 1)
  call void @pys_write(ptr @s.24, i64 1)
  %t294 = select i1 %t142, ptr @s.26, ptr @s.27
  call void @pys_write(ptr %t294, i64 1)
  call void @pys_write(ptr @s.24, i64 1)
  %t295 = select i1 %t190, ptr @s.26, ptr @s.27
  call void @pys_write(ptr %t295, i64 1)
  call void @pys_write(ptr @s.24, i64 1)
  %t296 = select i1 %t240, ptr @s.26, ptr @s.27
  call void @pys_write(ptr %t296, i64 1)
  call void @pys_write(ptr @s.24, i64 1)
  %t297 = select i1 %t291, ptr @s.26, ptr @s.27
  call void @pys_write(ptr %t297, i64 1)
  call void @pys_write(ptr @s.25, i64 1)
  %t298 = load ptr, ptr @d.c.E.ONE
  %t299 = load ptr, ptr %v.2
  %t300 = call ptr @pys_alloc(i64 8)
  %t301 = ptrtoint ptr %t299 to i64
  %t302 = getelementptr i64, ptr %t300, i64 0
  store i64 %t301, ptr %t302
  %t304 = getelementptr i64, ptr %t300, i64 0
  %t305 = load i64, ptr %t304
  %t306 = inttoptr i64 %t305 to ptr
  %t310 = load i64, ptr %t306
  %t311 = icmp eq i64 %t310, 2
  br i1 %t311, label %L308, label %L309
L308:
  %t312 = getelementptr i64, ptr %t306, i64 1
  %t313 = load i64, ptr %t312
  %t314 = inttoptr i64 %t313 to ptr
  %t318 = icmp eq ptr %t298, null
  br i1 %t318, label %L315, label %L316
L315:
  %t319 = icmp eq ptr %t314, null
  br label %L317
L316:
  %t320 = getelementptr %C.E, ptr %t298, i32 0, i32 3
  %t321 = load i64, ptr %t320, !tbaa !31
  %t322 = icmp eq ptr %t314, null
  br i1 %t322, label %L323, label %L324
L323:
  br label %L325
L324:
  %t326 = getelementptr %C._pystachy_complex$complex, ptr %t314, i32 0, i32 0
  %t327 = load double, ptr %t326
  %t328 = getelementptr %C._pystachy_complex$complex, ptr %t314, i32 0, i32 1
  %t329 = load double, ptr %t328
  %t330 = fcmp oeq double %t329, 0.0
  %t331 = call i64 @pys_cmp_if(i64 %t321, double %t327)
  %t332 = icmp eq i64 %t331, 2
  %t333 = sub i64 0, %t331
  %t334 = select i1 %t332, i64 2, i64 %t333
  %t335 = icmp eq i64 %t334, 0
  %t336 = and i1 %t330, %t335
  br label %L325
L325:
  %t337 = phi i1 [false, %L323], [%t336, %L324]
  br label %L317
L317:
  %t338 = phi i1 [%t319, %L315], [%t337, %L325]
  br label %L307
L309:
  br label %L339
L339:
  %t340 = getelementptr i64, ptr %t306, i64 1
  %t341 = load i64, ptr %t340
  %t345 = icmp eq ptr %t298, null
  br i1 %t345, label %L342, label %L343
L342:
  br label %L344
L343:
  %t346 = getelementptr %C.E, ptr %t298, i32 0, i32 3
  %t347 = load i64, ptr %t346, !tbaa !31
  %t348 = icmp eq i64 %t341, %t347
  br label %L344
L344:
  %t349 = phi i1 [false, %L342], [%t348, %L343]
  br label %L307
L307:
  %t350 = phi i1 [%t338, %L317], [%t349, %L344]
  br i1 %t350, label %L303, label %L351
L351:
  br label %L303
L303:
  %t352 = phi i1 [true, %L307], [false, %L351]
  %t353 = load ptr, ptr %v.2
  %t354 = load ptr, ptr @d.c.E.ONE
  %t355 = call ptr @pys_alloc(i64 8)
  %t356 = ptrtoint ptr %t354 to i64
  %t357 = getelementptr i64, ptr %t355, i64 0
  store i64 %t356, ptr %t357
  %t359 = getelementptr i64, ptr %t355, i64 0
  %t360 = load i64, ptr %t359
  %t361 = inttoptr i64 %t360 to ptr
  %t365 = load i64, ptr %t353
  %t366 = icmp eq i64 %t365, 2
  br i1 %t366, label %L363, label %L364
L363:
  %t367 = getelementptr i64, ptr %t353, i64 1
  %t368 = load i64, ptr %t367
  %t369 = inttoptr i64 %t368 to ptr
  %t373 = icmp eq ptr %t361, null
  br i1 %t373, label %L370, label %L371
L370:
  %t374 = icmp eq ptr %t369, null
  br label %L372
L371:
  %t375 = getelementptr %C.E, ptr %t361, i32 0, i32 3
  %t376 = load i64, ptr %t375, !tbaa !31
  %t377 = icmp eq ptr %t369, null
  br i1 %t377, label %L378, label %L379
L378:
  br label %L380
L379:
  %t381 = getelementptr %C._pystachy_complex$complex, ptr %t369, i32 0, i32 0
  %t382 = load double, ptr %t381
  %t383 = getelementptr %C._pystachy_complex$complex, ptr %t369, i32 0, i32 1
  %t384 = load double, ptr %t383
  %t385 = fcmp oeq double %t384, 0.0
  %t386 = call i64 @pys_cmp_if(i64 %t376, double %t382)
  %t387 = icmp eq i64 %t386, 2
  %t388 = sub i64 0, %t386
  %t389 = select i1 %t387, i64 2, i64 %t388
  %t390 = icmp eq i64 %t389, 0
  %t391 = and i1 %t385, %t390
  br label %L380
L380:
  %t392 = phi i1 [false, %L378], [%t391, %L379]
  br label %L372
L372:
  %t393 = phi i1 [%t374, %L370], [%t392, %L380]
  br label %L362
L364:
  br label %L394
L394:
  %t395 = getelementptr i64, ptr %t353, i64 1
  %t396 = load i64, ptr %t395
  %t400 = icmp eq ptr %t361, null
  br i1 %t400, label %L397, label %L398
L397:
  br label %L399
L398:
  %t401 = getelementptr %C.E, ptr %t361, i32 0, i32 3
  %t402 = load i64, ptr %t401, !tbaa !31
  %t403 = icmp eq i64 %t402, %t396
  br label %L399
L399:
  %t404 = phi i1 [false, %L397], [%t403, %L398]
  br label %L362
L362:
  %t405 = phi i1 [%t393, %L372], [%t404, %L399]
  br i1 %t405, label %L358, label %L406
L406:
  br label %L358
L358:
  %t407 = phi i1 [true, %L362], [false, %L406]
  %t408 = load ptr, ptr %v.2
  %t409 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t409, double 0.0, double 2.0)
  %t410 = call ptr @pys_alloc(i64 16)
  %t411 = ptrtoint ptr %t408 to i64
  %t412 = getelementptr i64, ptr %t410, i64 0
  store i64 %t411, ptr %t412
  %t413 = ptrtoint ptr %t409 to i64
  %t414 = getelementptr i64, ptr %t410, i64 1
  store i64 %t413, ptr %t414
  %t415 = load ptr, ptr @d.c.E.ONE
  store i64 0, ptr %h.416
  %t418 = getelementptr i64, ptr %t410, i64 0
  %t419 = load i64, ptr %t418
  %t420 = inttoptr i64 %t419 to ptr
  %t424 = load i64, ptr %t420
  %t425 = icmp eq i64 %t424, 2
  br i1 %t425, label %L422, label %L423
L422:
  %t426 = getelementptr i64, ptr %t420, i64 1
  %t427 = load i64, ptr %t426
  %t428 = inttoptr i64 %t427 to ptr
  %t432 = icmp eq ptr %t415, null
  br i1 %t432, label %L429, label %L430
L429:
  %t433 = icmp eq ptr %t428, null
  br label %L431
L430:
  %t434 = getelementptr %C.E, ptr %t415, i32 0, i32 3
  %t435 = load i64, ptr %t434, !tbaa !31
  %t436 = icmp eq ptr %t428, null
  br i1 %t436, label %L437, label %L438
L437:
  br label %L439
L438:
  %t440 = getelementptr %C._pystachy_complex$complex, ptr %t428, i32 0, i32 0
  %t441 = load double, ptr %t440
  %t442 = getelementptr %C._pystachy_complex$complex, ptr %t428, i32 0, i32 1
  %t443 = load double, ptr %t442
  %t444 = fcmp oeq double %t443, 0.0
  %t445 = call i64 @pys_cmp_if(i64 %t435, double %t441)
  %t446 = icmp eq i64 %t445, 2
  %t447 = sub i64 0, %t445
  %t448 = select i1 %t446, i64 2, i64 %t447
  %t449 = icmp eq i64 %t448, 0
  %t450 = and i1 %t444, %t449
  br label %L439
L439:
  %t451 = phi i1 [false, %L437], [%t450, %L438]
  br label %L431
L431:
  %t452 = phi i1 [%t433, %L429], [%t451, %L439]
  br label %L421
L423:
  br label %L453
L453:
  %t454 = getelementptr i64, ptr %t420, i64 1
  %t455 = load i64, ptr %t454
  %t459 = icmp eq ptr %t415, null
  br i1 %t459, label %L456, label %L457
L456:
  br label %L458
L457:
  %t460 = getelementptr %C.E, ptr %t415, i32 0, i32 3
  %t461 = load i64, ptr %t460, !tbaa !31
  %t462 = icmp eq i64 %t455, %t461
  br label %L458
L458:
  %t463 = phi i1 [false, %L456], [%t462, %L457]
  br label %L421
L421:
  %t464 = phi i1 [%t452, %L431], [%t463, %L458]
  br i1 %t464, label %L417, label %L465
L465:
  br label %L466
L417:
  %t467 = load i64, ptr %h.416
  %t468 = add i64 %t467, 1
  store i64 %t468, ptr %h.416
  br label %L466
L466:
  %t470 = getelementptr i64, ptr %t410, i64 1
  %t471 = load i64, ptr %t470
  %t472 = inttoptr i64 %t471 to ptr
  %t474 = icmp eq ptr %t472, %t415
  br i1 %t474, label %L469, label %L473
L473:
  %t478 = icmp eq ptr %t415, null
  br i1 %t478, label %L475, label %L476
L475:
  %t479 = icmp eq ptr %t472, null
  br label %L477
L476:
  %t480 = getelementptr %C.E, ptr %t415, i32 0, i32 3
  %t481 = load i64, ptr %t480, !tbaa !31
  %t482 = icmp eq ptr %t472, null
  br i1 %t482, label %L483, label %L484
L483:
  br label %L485
L484:
  %t486 = getelementptr %C._pystachy_complex$complex, ptr %t472, i32 0, i32 0
  %t487 = load double, ptr %t486
  %t488 = getelementptr %C._pystachy_complex$complex, ptr %t472, i32 0, i32 1
  %t489 = load double, ptr %t488
  %t490 = fcmp oeq double %t489, 0.0
  %t491 = call i64 @pys_cmp_if(i64 %t481, double %t487)
  %t492 = icmp eq i64 %t491, 2
  %t493 = sub i64 0, %t491
  %t494 = select i1 %t492, i64 2, i64 %t493
  %t495 = icmp eq i64 %t494, 0
  %t496 = and i1 %t490, %t495
  br label %L485
L485:
  %t497 = phi i1 [false, %L483], [%t496, %L484]
  br label %L477
L477:
  %t498 = phi i1 [%t479, %L475], [%t497, %L485]
  br i1 %t498, label %L469, label %L499
L499:
  br label %L500
L469:
  %t501 = load i64, ptr %h.416
  %t502 = add i64 %t501, 1
  store i64 %t502, ptr %h.416
  br label %L500
L500:
  %t503 = load i64, ptr %h.416
  %t504 = load ptr, ptr %v.2
  %t505 = load i1, ptr @g.F.def
  %t506 = xor i1 %t505, true
  br i1 %t506, label %L194, label %L507
L507:
  %t508 = load ptr, ptr @d.c.F.A
  %t512 = load i64, ptr %t504
  %t513 = icmp eq i64 %t512, 2
  br i1 %t513, label %L510, label %L511
L510:
  %t514 = getelementptr i64, ptr %t504, i64 1
  %t515 = load i64, ptr %t514
  %t516 = inttoptr i64 %t515 to ptr
  %t520 = icmp eq ptr %t508, null
  br i1 %t520, label %L517, label %L518
L517:
  %t521 = icmp eq ptr %t516, null
  br label %L519
L518:
  %t522 = getelementptr %C.F, ptr %t508, i32 0, i32 5
  %t523 = load i64, ptr %t522, !tbaa !34
  %t524 = icmp eq ptr %t516, null
  br i1 %t524, label %L525, label %L526
L525:
  br label %L527
L526:
  %t528 = getelementptr %C._pystachy_complex$complex, ptr %t516, i32 0, i32 0
  %t529 = load double, ptr %t528
  %t530 = getelementptr %C._pystachy_complex$complex, ptr %t516, i32 0, i32 1
  %t531 = load double, ptr %t530
  %t532 = fcmp oeq double %t531, 0.0
  %t533 = call i64 @pys_cmp_if(i64 %t523, double %t529)
  %t534 = icmp eq i64 %t533, 2
  %t535 = sub i64 0, %t533
  %t536 = select i1 %t534, i64 2, i64 %t535
  %t537 = icmp eq i64 %t536, 0
  %t538 = and i1 %t532, %t537
  br label %L527
L527:
  %t539 = phi i1 [false, %L525], [%t538, %L526]
  br label %L519
L519:
  %t540 = phi i1 [%t521, %L517], [%t539, %L527]
  br label %L509
L511:
  br label %L541
L541:
  %t542 = getelementptr i64, ptr %t504, i64 1
  %t543 = load i64, ptr %t542
  %t547 = icmp eq ptr %t508, null
  br i1 %t547, label %L544, label %L545
L544:
  br label %L546
L545:
  %t548 = getelementptr %C.F, ptr %t508, i32 0, i32 5
  %t549 = load i64, ptr %t548, !tbaa !34
  %t550 = icmp eq i64 %t543, %t549
  br label %L546
L546:
  %t551 = phi i1 [false, %L544], [%t550, %L545]
  br label %L509
L509:
  %t552 = phi i1 [%t540, %L519], [%t551, %L546]
  br i1 %t552, label %L553, label %L554
L553:
  %t556 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t556, double 0.0, double 2.0)
  %t557 = load ptr, ptr %v.2
  %t558 = call ptr @pys_alloc(i64 16)
  %t559 = ptrtoint ptr %t556 to i64
  %t560 = getelementptr i64, ptr %t558, i64 0
  store i64 %t559, ptr %t560
  %t561 = ptrtoint ptr %t557 to i64
  %t562 = getelementptr i64, ptr %t558, i64 1
  store i64 %t561, ptr %t562
  %t563 = load i1, ptr @g.F.def
  %t564 = xor i1 %t563, true
  br i1 %t564, label %L194, label %L565
L565:
  %t566 = load ptr, ptr @d.c.F.A
  %t568 = getelementptr i64, ptr %t558, i64 0
  %t569 = load i64, ptr %t568
  %t570 = inttoptr i64 %t569 to ptr
  %t572 = icmp eq ptr %t570, %t566
  br i1 %t572, label %L567, label %L571
L571:
  %t576 = icmp eq ptr %t566, null
  br i1 %t576, label %L573, label %L574
L573:
  %t577 = icmp eq ptr %t570, null
  br label %L575
L574:
  %t578 = getelementptr %C.F, ptr %t566, i32 0, i32 5
  %t579 = load i64, ptr %t578, !tbaa !34
  %t580 = icmp eq ptr %t570, null
  br i1 %t580, label %L581, label %L582
L581:
  br label %L583
L582:
  %t584 = getelementptr %C._pystachy_complex$complex, ptr %t570, i32 0, i32 0
  %t585 = load double, ptr %t584
  %t586 = getelementptr %C._pystachy_complex$complex, ptr %t570, i32 0, i32 1
  %t587 = load double, ptr %t586
  %t588 = fcmp oeq double %t587, 0.0
  %t589 = call i64 @pys_cmp_if(i64 %t579, double %t585)
  %t590 = icmp eq i64 %t589, 2
  %t591 = sub i64 0, %t589
  %t592 = select i1 %t590, i64 2, i64 %t591
  %t593 = icmp eq i64 %t592, 0
  %t594 = and i1 %t588, %t593
  br label %L583
L583:
  %t595 = phi i1 [false, %L581], [%t594, %L582]
  br label %L575
L575:
  %t596 = phi i1 [%t577, %L573], [%t595, %L583]
  br i1 %t596, label %L567, label %L597
L597:
  %t598 = getelementptr i64, ptr %t558, i64 1
  %t599 = load i64, ptr %t598
  %t600 = inttoptr i64 %t599 to ptr
  %t604 = load i64, ptr %t600
  %t605 = icmp eq i64 %t604, 2
  br i1 %t605, label %L602, label %L603
L602:
  %t606 = getelementptr i64, ptr %t600, i64 1
  %t607 = load i64, ptr %t606
  %t608 = inttoptr i64 %t607 to ptr
  %t612 = icmp eq ptr %t566, null
  br i1 %t612, label %L609, label %L610
L609:
  %t613 = icmp eq ptr %t608, null
  br label %L611
L610:
  %t614 = getelementptr %C.F, ptr %t566, i32 0, i32 5
  %t615 = load i64, ptr %t614, !tbaa !34
  %t616 = icmp eq ptr %t608, null
  br i1 %t616, label %L617, label %L618
L617:
  br label %L619
L618:
  %t620 = getelementptr %C._pystachy_complex$complex, ptr %t608, i32 0, i32 0
  %t621 = load double, ptr %t620
  %t622 = getelementptr %C._pystachy_complex$complex, ptr %t608, i32 0, i32 1
  %t623 = load double, ptr %t622
  %t624 = fcmp oeq double %t623, 0.0
  %t625 = call i64 @pys_cmp_if(i64 %t615, double %t621)
  %t626 = icmp eq i64 %t625, 2
  %t627 = sub i64 0, %t625
  %t628 = select i1 %t626, i64 2, i64 %t627
  %t629 = icmp eq i64 %t628, 0
  %t630 = and i1 %t624, %t629
  br label %L619
L619:
  %t631 = phi i1 [false, %L617], [%t630, %L618]
  br label %L611
L611:
  %t632 = phi i1 [%t613, %L609], [%t631, %L619]
  br label %L601
L603:
  br label %L633
L633:
  %t634 = getelementptr i64, ptr %t600, i64 1
  %t635 = load i64, ptr %t634
  %t639 = icmp eq ptr %t566, null
  br i1 %t639, label %L636, label %L637
L636:
  br label %L638
L637:
  %t640 = getelementptr %C.F, ptr %t566, i32 0, i32 5
  %t641 = load i64, ptr %t640, !tbaa !34
  %t642 = icmp eq i64 %t635, %t641
  br label %L638
L638:
  %t643 = phi i1 [false, %L636], [%t642, %L637]
  br label %L601
L601:
  %t644 = phi i1 [%t632, %L611], [%t643, %L638]
  br i1 %t644, label %L567, label %L645
L645:
  call void @pys_raise(ptr @s.29, ptr @s.28)
  unreachable
L567:
  %t646 = phi i64 [0, %L565], [0, %L575], [1, %L601]
  br label %L555
L554:
  br label %L555
L555:
  %t647 = phi i64 [%t646, %L567], [-1, %L554]
  %t648 = select i1 %t352, ptr @s.26, ptr @s.27
  call void @pys_write(ptr %t648, i64 1)
  call void @pys_write(ptr @s.24, i64 1)
  %t649 = select i1 %t407, ptr @s.26, ptr @s.27
  call void @pys_write(ptr %t649, i64 1)
  call void @pys_write(ptr @s.24, i64 1)
  %t650 = call ptr @pys_str_int(i64 %t503)
  call void @pys_write(ptr %t650, i64 1)
  call void @pys_write(ptr @s.24, i64 1)
  %t651 = call ptr @pys_str_int(i64 %t647)
  call void @pys_write(ptr %t651, i64 1)
  call void @pys_write(ptr @s.25, i64 1)
  ret void
  br label %L194
L194:
  call void @pys_raise(ptr @s.22, ptr @s.30)
  unreachable
}

define i32 @main(i32 %argc, ptr %argv) {
  %sb = call ptr @llvm.frameaddress.p0(i32 0)
  call void @pys_init(i32 %argc, ptr %argv, ptr %sb, ptr @pys.roots, i64 6)
  call void @pys_eh_on()
  call void @main.init()
  call void @pys_finish()
  ret i32 0
}
