define internal void @main.init() {
entry:
  %t2 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t2, double 0.0, double 1.0)
  call void @f.optional(ptr %t2)
  call void @f.optional(ptr null)
  %t3 = call ptr @pys_ubox(i64 1, i64 1)
  call void @f.numbers(ptr %t3)
  %t4 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C._pystachy_complex$complex, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m._pystachy_complex$complex.__init__(ptr %t4, double 0.0, double 0.0)
  %t5 = sitofp i64 2 to double
  %t6 = getelementptr %C._pystachy_complex$complex, ptr %t4, i32 0, i32 0
  %t7 = load double, ptr %t6
  %t8 = getelementptr %C._pystachy_complex$complex, ptr %t4, i32 0, i32 1
  %t9 = load double, ptr %t8
  %t10 = call ptr @f._pystachy_complex$_sum(double %t5, double 0.0, double %t7, double %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t12 = call ptr @pys_ubox(i64 2, i64 %t11)
  call void @f.numbers(ptr %t12)
  ret void
}

define internal void @f.numbers(ptr %a0) {
entry:
  %v.2 = alloca ptr
  store ptr zeroinitializer, ptr %v.2
  %e.4 = alloca ptr
  store ptr zeroinitializer, ptr %e.4
  store ptr %a0, ptr %v.2
  %t3 = call noalias nonnull ptr @pys_new(i64 ptrtoint (ptr getelementptr (%C.Equal, ptr null, i32 1) to i64)) allockind("alloc,zeroed") allocsize(0) "alloc-family"="pys"
  call void @m.Equal.__init__(ptr %t3)
  store ptr %t3, ptr %e.4
  %t5 = load ptr, ptr %e.4
  %t6 = load ptr, ptr %v.2
  %t10 = load i64, ptr %t6
  %t11 = icmp eq i64 %t10, 2
  br i1 %t11, label %L8, label %L9
L8:
  %t12 = getelementptr i64, ptr %t6, i64 1
  %t13 = load i64, ptr %t12
  %t14 = inttoptr i64 %t13 to ptr
  %t18 = icmp eq ptr %t5, null
  br i1 %t18, label %L15, label %L16
L15:
  %t19 = icmp eq ptr %t14, null
  br label %L17
L16:
  %t20 = call i1 @m.Equal.__eq__.1(ptr %t5, ptr %t14)
  br label %L17
L17:
  %t21 = phi i1 [%t19, %L15], [%t20, %L16]
  br label %L7
L9:
  br label %L22
L22:
  %t23 = getelementptr i64, ptr %t6, i64 1
  %t24 = load i64, ptr %t23
  %t28 = icmp eq ptr %t5, null
  br i1 %t28, label %L25, label %L26
L25:
  br label %L27
L26:
  %t29 = call i1 @m.Equal.__eq__.2(ptr %t5, i64 %t24)
  br label %L27
L27:
  %t30 = phi i1 [false, %L25], [%t29, %L26]
  br label %L7
L7:
  %t31 = phi i1 [%t21, %L17], [%t30, %L27]
  %t32 = load ptr, ptr %e.4
  %t33 = load ptr, ptr %v.2
  %t37 = load i64, ptr %t33
  %t38 = icmp eq i64 %t37, 2
  br i1 %t38, label %L35, label %L36
L35:
  %t39 = getelementptr i64, ptr %t33, i64 1
  %t40 = load i64, ptr %t39
  %t41 = inttoptr i64 %t40 to ptr
  %t45 = icmp eq ptr %t32, null
  br i1 %t45, label %L42, label %L43
L42:
  %t46 = icmp eq ptr %t41, null
  br label %L44
L43:
  %t47 = call i1 @m.Equal.__eq__.1(ptr %t32, ptr %t41)
  br label %L44
L44:
  %t48 = phi i1 [%t46, %L42], [%t47, %L43]
  %t49 = xor i1 %t48, true
  br label %L34
L36:
  br label %L50
L50:
  %t51 = getelementptr i64, ptr %t33, i64 1
  %t52 = load i64, ptr %t51
  %t56 = icmp eq ptr %t32, null
  br i1 %t56, label %L53, label %L54
L53:
  br label %L55
L54:
  %t57 = call i1 @m.Equal.__eq__.2(ptr %t32, i64 %t52)
  br label %L55
L55:
  %t58 = phi i1 [false, %L53], [%t57, %L54]
  %t59 = xor i1 %t58, true
  br label %L34
L34:
  %t60 = phi i1 [%t49, %L44], [%t59, %L55]
  %t61 = select i1 %t31, ptr @s.3, ptr @s.4
  call void @pys_write(ptr %t61, i64 1)
  call void @pys_write(ptr @s.0, i64 1)
  %t62 = select i1 %t60, ptr @s.3, ptr @s.4
  call void @pys_write(ptr %t62, i64 1)
  call void @pys_write(ptr @s.1, i64 1)
  ret void
}

define i32 @main(i32 %argc, ptr %argv) {
  %sb = call ptr @llvm.frameaddress.p0(i32 0)
  call void @pys_init(i32 %argc, ptr %argv, ptr %sb, ptr @pys.roots, i64 0)
  call void @main.init()
  call void @pys_finish()
  ret i32 0
}
