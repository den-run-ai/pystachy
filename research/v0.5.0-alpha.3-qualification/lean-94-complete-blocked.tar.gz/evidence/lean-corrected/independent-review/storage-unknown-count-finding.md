# Strict storage remains incomplete

The selected new fixture `python_int_optional_tuple_keys.py` has eight counted storage obligations, all proved, and three additional unsupported function results with unknown obligation counts: `@main.init`, `@f.exercise`, and `@f.fixed_optional_tuple_keys$read_nested`. Their reason is `tuple boundary changes a non-integer representation`. The existing strict-storage audit requires an empty unproved list, so the counted 8/8 does not satisfy it.

The exact row is preserved from the immutable 2,562-record prefix, with its snapshot hash and prefix identity in the JSON. The possible source mechanism is the nested tuple comparison branch in `check_lean_storage.py`; it only recognizes direct tuple child representations, while the fixture contains nested optional tuples crossing fixed/promoting integer boundaries. Exact failing typed operations must establish that diagnosis before any repair or acceptance.

This finding does not change source or acceptance policy and does not infer a runtime failure. No compiler, runtime, or checker was run for this review.
