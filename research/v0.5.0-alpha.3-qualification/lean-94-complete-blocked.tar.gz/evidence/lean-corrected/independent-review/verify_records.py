"""Independent read-only arithmetic/coverage audit of the completed Lean evidence.

This imports no compiler or checker, executes no proof, and changes only its own
derived review artifact. Semantic dispositions remain a separate manual review.
"""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
BASE = Path('/workspace/scratch/7dd0519bc14a/lean-reports/alpha2-storage-lean-records.jsonl')
BASE_SHA = '98d2cd703064e39dbb14e41f3d13bb1b5df7bbcf4d30903966db4b427ecd09a6'
COMMON = {'payload', 'access', 'null', 'union', 'union_payload', 'fields', 'gc'}
CONDITIONAL = {'int', 'int_inline', 'storage'}

def read(path):
    return json.loads(path.read_text())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def inventory(names):
    return {'count': len(names), 'sha256': sha256(json.dumps(sorted(names, key=str.encode)).encode()).hexdigest()}

def load(path):
    raw = path.read_bytes()
    assert raw.endswith(b'\n'), 'Record stream is not complete at a line boundary'
    lines = [json.loads(line) for line in raw.splitlines()]
    assert set(lines[0]) == {'header'}
    header, rows = lines[0]['header'], lines[1:]
    names = [r['program'] for r in rows]
    assert len(names) == len(set(names))
    assert inventory(names) == header['inventory']
    assert len(header['promoting']) == len(set(header['promoting']))
    selected = set(header['promoting'])
    assert selected <= set(names)
    totals, unknown, numerical_gaps, residuals, storage_gaps = {}, [], [], [], []
    for row in rows:
        assert not row.get('error') and not row.get('failed'), row['program']
        assert re.fullmatch('[0-9a-f]{64}', row['snapshot_sha256'])
        assert set(row['checks']) == COMMON | (CONDITIONAL if row['program'] in selected else set())
        for key, value in row['checks'].items():
            for field in ('functions', 'obligations', 'proved'):
                assert type(value[field]) is int and value[field] >= 0
            assert value['proved'] <= value['obligations']
            total = totals.setdefault(key, dict(programs=0, functions=0, obligations=0, proved=0))
            total['programs'] += value['obligations'] > 0
            for field in ('functions', 'obligations', 'proved'):
                total[field] += value[field]
            for item in value['unproved']:
                assert item['status'] in ('rejected', 'unsupported')
                count = item['obligations']
                assert count is None or (type(count) is int and count >= 0)
                entry = dict(program=row['program'], check=key, **item)
                residuals.append(entry)
                if count is None:
                    unknown.append(entry)
            known_residual_count = sum(i['obligations'] or 0 for i in value['unproved'])
            counted_gap = value['obligations'] - value['proved']
            if counted_gap != known_residual_count:
                numerical_gaps.append({'program': row['program'], 'check': key,
                                       'counted_gap': counted_gap,
                                       'known_residual_count': known_residual_count,
                                       'residuals': value['unproved']})
            if row['program'] in selected and key == 'storage':
                if value['obligations'] != value['proved'] or value['unproved']:
                    storage_gaps.append({'program': row['program'], 'storage': value})
    return header, dict(zip(names, rows)), totals, unknown, numerical_gaps, residuals, storage_gaps

assert digest(BASE) == BASE_SHA
prepared, acceptance, delta = [read(ROOT / name) for name in ('prepared.json', 'acceptance.json', 'delta-alpha2.json')]
failed_acceptance_checks = [k for k, v in acceptance['checks'].items() if not v]
assert failed_acceptance_checks in ([], ['strict_storage_all_accepted'])
assert acceptance['programs'] == 2699 and acceptance['storage_programs'] == 196
assert acceptance['records_sha256'] == digest(ROOT / 'records.jsonl')
assert acceptance['report_sha256'] == digest(ROOT / 'report.md')
old_h, old, old_t, old_unknown, old_gaps, old_res, old_storage_gaps = load(BASE)
new_h, new, new_t, new_unknown, new_gaps, new_res, new_storage_gaps = load(ROOT / 'records.jsonl')
assert not old_storage_gaps
assert new_storage_gaps == acceptance['storage_gaps']
assert acceptance['checks']['strict_storage_all_accepted'] == (not new_storage_gaps)
assert len(old) == 2550 and len(old_h['promoting']) == 175
assert len(new) == 2699 and len(new_h['promoting']) == 196
assert set(old) <= set(new) and set(old_h['promoting']) <= set(new_h['promoting'])
assert set(new) == set(prepared['programs'])
assert set(new_h['promoting']) == set(prepared['promoting'])
assert new_h['inputs'] == prepared['inputs']
assert new_h['checker_executables'] == prepared['checker_executables']
assert new_h['commit'] == prepared['commit'][:12]
assert acceptance['commit'] == prepared['commit'] and acceptance['tree'] == prepared['tree']
assert not acceptance['incomplete_records'] and not acceptance['invalid_records']
for totals, reference in [(old_t, acceptance['baseline_proof_totals']), (new_t, acceptance['full_proof_totals'])]:
    for key, counts in totals.items():
        assert counts == {field: reference[key][field] for field in counts}

changes, decreases, losses, gap_increases, raw_residual_changes = [], [], [], [], []
for program in sorted(old):
    before, after = old[program]['checks'], new[program]['checks']
    for key in sorted(set(before) | set(after)):
        a, b = before.get(key, {}), after.get(key, {})
        if a != b:
            changes.append(dict(program=program, check=key, before=a, after=b))
        if b.get('obligations', 0) < a.get('obligations', 0):
            decreases.append(dict(program=program, check=key, before=a.get('obligations', 0), after=b.get('obligations', 0)))
        if b.get('proved', 0) < a.get('proved', 0):
            losses.append(dict(program=program, check=key, before=a.get('proved', 0), after=b.get('proved', 0)))
        gap_a, gap_b = (a.get('obligations', 0) - a.get('proved', 0), b.get('obligations', 0) - b.get('proved', 0))
        ua, ub = (sum(i['obligations'] is None for i in v.get('unproved', [])) for v in (a, b))
        if gap_b > gap_a or ub > ua:
            gap_increases.append(dict(program=program, check=key, counted_gap_before=gap_a,
                                      counted_gap_after=gap_b, unknown_count_functions_before=ua,
                                      unknown_count_functions_after=ub,
                                      before_unproved=a.get('unproved', []), after_unproved=b.get('unproved', [])))
        if a.get('unproved', []) != b.get('unproved', []):
            raw_residual_changes.append(dict(program=program, check=key,
                                             before=a.get('unproved', []), after=b.get('unproved', [])))
added = sorted(set(new) - set(old))
added_unproved = [dict(program=p, check=k, **i) for p in added
                  for k, value in new[p]['checks'].items() for i in value['unproved']]
assert added == delta['added_programs']
assert changes == delta['shared_changes']
assert decreases == delta['obligation_decreases']
assert losses == delta['proved_count_decreases']
assert gap_increases == delta['shared_unproved_count_increases']
assert added_unproved == delta['added_program_unproved']
assert delta['missing_programs'] == []
markers = [line for line in (ROOT / 'report.md').read_text().splitlines()
           if line.startswith('<!-- lean-report-completion ')]
assert len(markers) == 1 and markers[0].endswith(' -->')
completion = json.loads(markers[0][len('<!-- lean-report-completion '):-len(' -->')])
assert completion == {'version': 1, 'expected': inventory(list(new)), 'evaluated': inventory(list(new)),
                      'promoting': inventory(new_h['promoting']), 'failed': 0}
run_receipts = sorted(ROOT.glob('run-*.json'))
assert len(run_receipts) == 2, 'Review any additional attempt explicitly before acceptance'
runs = [read(path) for path in run_receipts]
first, final = runs
assert first['resume'] is False and final['resume'] is True
assert first['report_exit'] == -9 and first['status_exit'] == first['audit_exit'] == 1
assert final['report_exit'] == final['status_exit'] == 0
assert final['audit_exit'] == (1 if failed_acceptance_checks else 0)
assert final['command'] == first['command'] + ['--resume']
assert first['started_utc'] < final['started_utc']
for run in runs:
    assert run['jobs'] == 1 and run['cwd'] == prepared['repo']
    assert run['source_before'] == run['source_after'] == ''
    assert run['commit'] == run['commit_after'] == prepared['commit']
    assert run['tree'] == run['tree_after'] == prepared['tree']

frozen_dir = ROOT / 'pre-resume-2562'
preflight_path = frozen_dir / 'failure-and-resume-preflight.json'
preflight = read(preflight_path)
assert preflight['status'] == 'incomplete_report_process_killed'
assert preflight['completed_programs'] == 2562 and preflight['remaining_programs'] == 137
assert preflight['expected_programs'] == 2699
assert preflight['commit'] == prepared['commit'] and preflight['tree'] == prepared['tree']
assert preflight['no_error_records'] and preflight['no_nested_adapter_errors']
assert preflight['no_census_acceptance']
for name, identity in preflight['files'].items():
    path = Path(identity['path'])
    assert path == frozen_dir / name
    assert path.stat().st_size == identity['bytes'] and digest(path) == identity['sha256']
assert (frozen_dir / run_receipts[0].name).read_bytes() == run_receipts[0].read_bytes()
assert (frozen_dir / Path(first['log']).name).read_bytes() == Path(first['log']).read_bytes()
assert all(read(frozen_dir / 'source-revalidation.json').values())
prefix = (frozen_dir / 'records.jsonl').read_bytes()
assert len(prefix) == 2231387
assert sha256(prefix).hexdigest() == 'bfb655c74867954575567037ff544abdb61329b404947859a4259b26c06d31fb'
assert prefix.endswith(b'\n')
assert (ROOT / 'records.jsonl').read_bytes().startswith(prefix)
frozen_lines = [json.loads(line) for line in prefix.splitlines()]
assert frozen_lines[0] == {'header': new_h}
prefix_rows = frozen_lines[1:]
prefix_names = [row['program'] for row in prefix_rows]
assert len(prefix_names) == len(set(prefix_names)) == 2562
assert all(new[row['program']] == row for row in prefix_rows)
appended = (ROOT / 'records.jsonl').read_bytes()[len(prefix):]
appended_rows = [json.loads(line) for line in appended.splitlines()]
appended_names = [row['program'] for row in appended_rows]
assert len(appended_names) == len(set(appended_names)) == 137
assert not set(prefix_names) & set(appended_names)
assert appended_names == preflight['remaining_inventory']
assert prefix_names[-1] == preflight['last_recorded_program']
assert appended_names[0] == preflight['first_unrecorded_program']
execution = dict(mode='same-source validated resume after interrupted first attempt',
                 first_attempt_exit=-9, kill_cause='unproven',
                 preserved_prefix_records=2562, appended_records=137,
                 preserved_prefix_bytes=len(prefix), preserved_prefix_sha256=sha256(prefix).hexdigest(),
                 preflight_sha256=digest(preflight_path),
                 attempts=[dict(receipt=str(path), receipt_sha256=digest(path),
                                log_sha256=digest(Path(run['log'])), **run)
                           for path, run in zip(run_receipts, runs)],
                 prefix_byte_for_byte_preserved=True,
                 prior_b0_records_reused=False)
identities = read(ROOT / 'qualification-script-identities.json')
for name, identity in identities['files'].items():
    assert digest(ROOT / name) == identity['sha256'], name
for row in prepared['source_correspondence']:
    assert digest(Path(prepared['repo']) / row['path']) == row['sha256']
for row in prepared['copied_executables'].values():
    assert digest(Path(row['destination'])) == row['sha256']

result = dict(status=('complete_census_verified_but_strict_storage_gate_blocked' if new_storage_gaps
                      else 'structural_census_verified_semantic_review_separate'),
              failed_acceptance_checks=failed_acceptance_checks,
              storage_gaps=new_storage_gaps,
              commit=prepared['commit'], tree=prepared['tree'],
              baseline_sha256=BASE_SHA, records_sha256=acceptance['records_sha256'],
              report_sha256=acceptance['report_sha256'],
              baseline_programs=len(old), candidate_programs=len(new),
              baseline_storage_programs=len(old_h['promoting']), candidate_storage_programs=len(new_h['promoting']),
              old_totals=old_t, new_totals=new_t,
              obligation_decreases=decreases, proved_count_decreases=losses,
              shared_gap_or_unknown_count_increases=gap_increases,
              exact_raw_shared_residual_changes=raw_residual_changes,
              added_program_unproved=added_unproved,
              baseline_unknown_count_residuals=old_unknown, candidate_unknown_count_residuals=new_unknown,
              numerical_gap_inventory={'baseline': old_gaps, 'candidate': new_gaps},
              baseline_unproved_rows=len(old_res), candidate_unproved_rows=len(new_res),
              completion=completion,
              execution=execution,
              method='Pure JSON arithmetic, exact record dictionaries, hashes and completion marker; no compiler/checker import or execution. No normalization of residuals.',
              limits=['Structural acceptance does not establish that every obligation is proved.',
                      'Every raw residual change, count decrease and added residual still needs the separate semantic disposition.'])
(OUT / 'structural-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('status', 'baseline_programs', 'candidate_programs', 'candidate_storage_programs')}, indent=2))
print(json.dumps({'decreases': len(decreases), 'proved_count_decreases': len(losses),
                  'raw_residual_changes': len(raw_residual_changes), 'gap_increases': len(gap_increases),
                  'added_unproved': len(added_unproved), 'unknown_count_residuals': len(new_unknown)}, indent=2))
