# Independent review of added complex residuals

I found no actionable source/IR contradiction in the reviewed first-failure dispositions. The nine added fixtures retain 542 rejected union reads and 409 unproved associated payload obligations across 21 functions. Every original residual dictionary and snapshot identity agrees with the frozen census. No obligation is waived.

For the seven numeric fixtures I independently inspected source, the first failing loads, caller bodies, fresh union-box definitions, tuple transport, pick/fpick return arms, and the six-element boxed list/current-value global used by complex_unions. Optional helpers are distinct from the rejected nonoptional specializations. The retained conservative domain adds null for the internal complex spelling; runtime nonnull facts require the stated caller/callee and pointer-preservation reasoning, rather than a nonexistent local guard.

The per-function description was corrected for the prior complex-null main and dynamic-identity check functions; the reviewed input hash and exact correction are retained in JSON. Both prior detailed reviews remain linked by the primary report. The report explicitly labels reconstructed complete domains when the raw diagnostic was truncated.

This review explains each first reported failure and does not prove later obligations. The overall release remains blocked by the separate three unknown-count strict-storage functions pending repair and fresh qualification. No compiler, runtime or Lean checker was executed.
