"""Independently check full coverage/provenance, strict storage, and alpha.2 delta."""
import collections
import hashlib
import json
from pathlib import Path
import platform
import re
import subprocess
import sys

OUT = Path(__file__).resolve().parent
prepared = json.loads((OUT / "prepared.json").read_text())
REPO = Path(prepared["repo"])
BASE = Path("/workspace/scratch/7dd0519bc14a/lean-reports/alpha2-storage-lean-records.jsonl")
BASE_HASH = "98d2cd703064e39dbb14e41f3d13bb1b5df7bbcf4d30903966db4b427ecd09a6"
sys.path.insert(0, str(REPO / "tools"))
import lean_report as r

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args], text=True).strip()

def load(path):
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    assert set(rows[0]) == {"header"}
    names = [row["program"] for row in rows[1:]]
    assert len(names) == len(set(names)), "duplicate records"
    return rows[0]["header"], {row["program"]: row for row in rows[1:]}

assert digest(BASE) == BASE_HASH
old_header, old = load(BASE)
header, records = load(OUT / "records.jsonl")
programs = r.corpus.corpus()
promoting = set(r.storage_corpus.select(programs))
current_inputs = r.inputs()
checks = {
    "exact_corpus_census": set(records) == set(programs) == set(prepared["programs"]),
    "exact_program_count": len(records) == len(programs) == prepared["expected_programs"],
    "exact_storage_census": set(header["promoting"]) == promoting == set(prepared["promoting"]),
    "exact_storage_count": len(header["promoting"]) == len(promoting) == prepared["expected_promoting"],
    "baseline_program_names_retained": set(old) <= set(records),
    "baseline_storage_program_names_retained": set(old_header["promoting"]) <= promoting,
    "header_inventory_matches": header["inventory"] == r.inventory(programs),
    "full_not_selected_inputs": header["inputs"]["corpus"]["programs"] == [],
    "source_commit_matches": git("rev-parse", "HEAD") == prepared["commit"] and header["commit"] == git("rev-parse", "--short=12", "HEAD"),
    "source_tree_matches": git("rev-parse", "HEAD^{tree}") == prepared["tree"],
    "source_clean": git("status", "--porcelain") == "",
    "clean_inputs": r.clean_inputs(header["inputs"]) and r.clean_inputs(current_inputs),
    "input_identities_match": header["inputs"] == current_inputs == r.recorded(OUT / "report.md") == prepared["inputs"],
    "checker_identities_match": header["checker_executables"] == r.checker_executables(r.boundary.DEFAULT_CHECKER, r.access.DEFAULT_CHECKER) == prepared["checker_executables"],
    "all_copied_checker_hashes_match": all(digest(row["destination"]) == row["sha256"] for row in prepared["copied_executables"].values()),
    "all_checker_sources_match": all(digest(REPO / row["path"]) == row["sha256"] for row in prepared["source_correspondence"]),
    "python_matches": header["python"] == prepared["python"] == platform.python_version(),
    "platform_matches": header["platform"] == prepared["platform"] == sys.platform,
}
conditional = {"int", "int_inline", "storage"}
required = {key for key, *_ in r.CHECKS} - conditional
incomplete = []
invalid = []
storage_gaps = []
for program, row in records.items():
    wanted = required | (conditional if program in promoting else set())
    if row.get("error") or row.get("failed") or set(row.get("checks", {})) != wanted:
        incomplete.append(row)
    for name, check in row.get("checks", {}).items():
        if not (all(type(check[key]) is int and check[key] >= 0 for key in ("functions", "obligations", "proved"))
                and check["proved"] <= check["obligations"]
                and isinstance(check["unproved"], list)
                and all(item["status"] in ("rejected", "unsupported") for item in check["unproved"])):
            invalid.append({"program": program, "check": name, "record": check})
    if program in promoting:
        item = row.get("checks", {}).get("storage", {})
        if (not item or type(item.get("obligations")) is not int
                or type(item.get("proved")) is not int
                or item.get("proved") != item.get("obligations") or item.get("unproved")):
            storage_gaps.append({"program": program, "storage": item})
completion = r.recorded_completion(OUT / "report.md")
checks["completion_matches_records"] = completion == r.meta(header, list(records.values()))["completion"]
checks["completion_valid"] = not r.completion_problem(completion, r.inventory(programs), r.inventory(promoting))
checks["no_incomplete_or_failed_records"] = not incomplete
checks["valid_numeric_check_records"] = not invalid
checks["strict_storage_all_accepted"] = not storage_gaps

def identity(item):
    reason = re.sub(r"%t\d+", "%tN", item["reason"])
    reason = re.sub(r"\bL\d+\b", "LN", reason)
    return re.sub(r"\.\d+$", "", item["function"] or ""), item["status"], reason

changes, new_unproved, decreases, proof_losses, gap_increases = [], [], [], [], []
for program in sorted(old.keys() & records.keys()):
    before_row, after_row = old[program], records[program]
    if any(row.get("error") or row.get("failed") for row in (before_row, after_row)):
        continue
    for check in sorted(set(before_row["checks"]) | set(after_row["checks"])):
        before = before_row["checks"].get(check, {})
        after = after_row["checks"].get(check, {})
        if before != after:
            changes.append({"program": program, "check": check, "before": before, "after": after})
        existing = collections.Counter(identity(item) for item in before.get("unproved", []))
        for item in after.get("unproved", []):
            key = identity(item)
            if existing[key]:
                existing[key] -= 1
            else:
                new_unproved.append({"program": program, "check": check, **item})
        if after.get("obligations", 0) < before.get("obligations", 0):
            decreases.append({"program": program, "check": check, "before": before.get("obligations", 0), "after": after.get("obligations", 0)})
        if after.get("proved", 0) < before.get("proved", 0):
            proof_losses.append({"program": program, "check": check, "before": before.get("proved", 0), "after": after.get("proved", 0)})
        before_gap = before.get("obligations", 0) - before.get("proved", 0)
        after_gap = after.get("obligations", 0) - after.get("proved", 0)
        before_unknown = sum(item.get("obligations") is None for item in before.get("unproved", []))
        after_unknown = sum(item.get("obligations") is None for item in after.get("unproved", []))
        if after_gap > before_gap or after_unknown > before_unknown:
            gap_increases.append({"program": program, "check": check,
                                  "counted_gap_before": before_gap, "counted_gap_after": after_gap,
                                  "unknown_count_functions_before": before_unknown,
                                  "unknown_count_functions_after": after_unknown,
                                  "before_unproved": before.get("unproved", []),
                                  "after_unproved": after.get("unproved", [])})
added = sorted(records.keys() - old.keys())
added_unproved = [{"program": program, "check": check, **item} for program in added
                  for check, data in records[program].get("checks", {}).items() for item in data["unproved"]]
delta = {
    "baseline_records": str(BASE), "baseline_sha256": BASE_HASH,
    "baseline_commit": old_header["commit"], "candidate_commit": header["commit"],
    "baseline_programs": len(old), "candidate_programs": len(records),
    "shared_programs": len(old.keys() & records.keys()), "added_programs": added,
    "missing_programs": sorted(old.keys() - records.keys()),
    "storage_selection_delta": {
        "baseline": len(old_header["promoting"]), "candidate": len(promoting),
        "retained": len(set(old_header["promoting"]) & promoting),
        "added": sorted(promoting - set(old_header["promoting"])),
        "removed": sorted(set(old_header["promoting"]) - promoting),
    },
    "new_unproved_shared_programs": new_unproved, "added_program_unproved": added_unproved,
    "obligation_decreases": decreases, "proved_count_decreases": proof_losses,
    "shared_unproved_count_increases": gap_increases,
    "shared_changes": changes,
    "normalization": "Only temporary %tN, block LN, and trailing numeric specialization suffixes are normalized for residual matching; exact before/after dictionaries are retained.",
}
(OUT / "delta-alpha2.json").write_text(json.dumps(delta, indent=2) + "\n")
summary = r.summarize(list(records.values()))
old_summary = r.summarize(list(old.values()))
acceptance = {
    "commit": prepared["commit"], "tree": prepared["tree"], "checks": checks,
    "programs": len(records), "storage_programs": len(promoting),
    "full_proof_totals": summary["checks"], "failed_records": summary["failed"],
    "baseline_proof_totals": old_summary["checks"],
    "incomplete_records": incomplete, "invalid_records": invalid, "storage_gaps": storage_gaps,
    "report_sha256": digest(OUT / "report.md"), "records_sha256": digest(OUT / "records.jsonl"),
    "delta_summary": {"added_programs": len(added), "missing_programs": len(delta["missing_programs"]),
                      "new_unproved_shared": len(new_unproved), "added_program_unproved": len(added_unproved),
                      "obligation_decreases": len(decreases), "proved_count_decreases": len(proof_losses),
                      "shared_unproved_count_increases": len(gap_increases)},
    "limitation": "Complete census acceptance is separate from semantic proof-delta review; changed or newly unproved obligations require explicit review before release.",
}
(OUT / "acceptance.json").write_text(json.dumps(acceptance, indent=2) + "\n")
print(json.dumps({"programs": len(records), "storage_programs": len(promoting),
                  "checks": checks, "delta_summary": acceptance["delta_summary"]}, indent=2))
raise SystemExit(0 if all(checks.values()) else 1)
