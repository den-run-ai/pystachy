define internal ptr @f._pystachy_copy$_memo_get.1(ptr %a0, ptr %a1) {
entry:
  %memo.2 = alloca ptr
  store ptr zeroinitializer, ptr %memo.2
  %x.3 = alloca ptr
  store ptr zeroinitializer, ptr %x.3
  %i.15 = alloca i64
  store i64 zeroinitializer, ptr %i.15
  store ptr %a0, ptr %memo.2
  store ptr %a1, ptr %x.3
  %t4 = load ptr, ptr %memo.2
  %t5 = icmp eq ptr %t4, null
  br i1 %t5, label %L6, label %L7
L7:
  %t8 = getelementptr %C._pystachy_copy$_Memo, ptr %t4, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !17
  %t12 = load ptr, ptr %x.3
  %t13 = ptrtoint ptr %t12 to i64
  %t14 = call i64 @pys_dict_get(ptr %t9, i64 %t13, i64 -1)
  store i64 %t14, ptr %i.15
  %t16 = load i64, ptr %i.15
  %t17 = icmp slt i64 %t16, 0
  br i1 %t17, label %L18, label %L19
L18:
  ret ptr null
L19:
  br label %L20
L20:
  %t21 = load ptr, ptr %memo.2
  %t25 = getelementptr %C._pystachy_copy$_Memo, ptr %t21, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !18
  %t27 = load i64, ptr %i.15
  %t28 = call i64 @pys_list_get(ptr %t26, i64 %t27)
  %t29 = inttoptr i64 %t28 to ptr
  %t30 = load ptr, ptr %x.3
  ret ptr %t29
L6:
  call void @pys_raise(ptr @s.10, ptr @s.19)
  unreachable
}
