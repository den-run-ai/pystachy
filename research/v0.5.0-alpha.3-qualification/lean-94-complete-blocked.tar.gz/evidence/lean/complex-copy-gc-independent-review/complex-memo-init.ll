define internal void @m._pystachy_copy$_Memo.__init__(ptr nonnull %a0) {
entry:
  %self.2 = alloca ptr
  store ptr zeroinitializer, ptr %self.2
  store ptr %a0, ptr %self.2
  %t3 = call ptr @pys_dict_new_atomic(i64 0, i64 0)
  %t4 = load ptr, ptr %self.2
  %t5 = getelementptr %C._pystachy_copy$_Memo, ptr %t4, i32 0, i32 0
  store ptr %t3, ptr %t5, !tbaa !17
  %t6 = call ptr @pys_list_new(i64 0)
  %t7 = load ptr, ptr %self.2
  %t8 = getelementptr %C._pystachy_copy$_Memo, ptr %t7, i32 0, i32 1
  store ptr %t6, ptr %t8, !tbaa !18
  ret void
}
