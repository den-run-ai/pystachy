"""Read-only retained-IR explanation of the newly encountered memo-get GC gap."""
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parent
WORK = OUT.parents[2]
REPO = WORK / 'alpha3-lean-corrected'
BASE = '80490143498d149d407343ba1cb7aedb1db2d2c5'
HEAD = '94f472d6de5350fc9481ecf3b9ec019d2ecdb4f2'
RECORDS = WORK / 'evidence/lean-corrected/records.jsonl'
BASE_RECORDS = Path('/workspace/scratch/7dd0519bc14a/lean-reports/alpha2-storage-lean-records.jsonl')
CASE = 'tests/programs/numbers/complex_values.py'

def digest(data):
    return sha256(data).hexdigest()

def identity(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path.read_bytes())}

def git(commit, path):
    return subprocess.check_output(['git', '-C', str(REPO), 'show', commit + ':' + path])

def rows(path):
    return {row['program']: row for row in map(json.loads, path.read_text().splitlines()[1:])}

def function(text, symbol):
    found = re.search(r'^define[^\n]* @' + re.escape(symbol) + r'\([^\n]*\) \{\n.*?^\}\n', text, re.M | re.S)
    assert found, symbol
    return found.group()

assert digest(RECORDS.read_bytes()) == '396f4b02ede94afda93ecc796f1da3aa1d3cb022a78939c51c4fc34a22101bbe'
assert digest(BASE_RECORDS.read_bytes()) == '98d2cd703064e39dbb14e41f3d13bb1b5df7bbcf4d30903966db4b427ecd09a6'
old_record = rows(BASE_RECORDS)['tests/programs/library/lib_enum.py']
new_record = rows(RECORDS)[CASE]
new_residual = new_record['checks']['gc']['unproved']
assert len(new_residual) == 1 and new_residual[0]['obligations'] == 3
old_residual = next(row for row in old_record['checks']['gc']['unproved']
                    if row['function'] == '@f._pystachy_copy$_memo_get.1')
assert old_residual == new_residual[0]
old_path, new_path = (WORK / 'ir-audit/cases/1608/old.ll', WORK / 'ir-audit/cases/1835/new.ll')
old_text, new_text = old_path.read_text(), new_path.read_text()
old_fn, new_fn = [function(text, 'f._pystachy_copy$_memo_get.1') for text in (old_text, new_text)]
definitions = [{m.group(1): m.group(2) for m in re.finditer(r'^(![0-9]+|@s\.[0-9]+) = (.*)$', text, re.M)}
               for text in (old_text, new_text)]

def expanded(defs, name):
    return re.sub(r'![0-9]+', lambda m: '(' + expanded(defs, m.group()) + ')', defs[name])

bindings = {'!28': '!17', '!29': '!18', '@s.30': '@s.10', '@s.72': '@s.19'}
binding_evidence = []
for a, b in bindings.items():
    aa, bb = expanded(definitions[0], a), expanded(definitions[1], b)
    assert aa == bb
    binding_evidence.append({'old_reference': a, 'new_reference': b,
                             'old_definition': definitions[0][a], 'new_definition': definitions[1][b],
                             'expanded_definition': aa, 'exact_semantic_definition_equal': True})
mapped = re.sub(r'![0-9]+|@s\.[0-9]+', lambda m: bindings.get(m.group(), m.group()), old_fn)
assert mapped == new_fn
for name, value in [('alpha2-enum-memo-get.ll', old_fn), ('complex-memo-get.ll', new_fn),
                    ('complex-memo-put.ll', function(new_text, 'f._pystachy_copy$_memo_put.1')),
                    ('complex-memo-init.ll', function(new_text, 'm._pystachy_copy$_Memo.__init__')),
                    ('complex-deepcopy-list.ll', function(new_text, 'f.copy$_deepcopy_list.1'))]:
    (OUT / name).write_text(value)
copy_path = 'lib/_pystachy_copy.py'
assert git(BASE, copy_path) == git(HEAD, copy_path) == (REPO / copy_path).read_bytes()
reflection_path = 'src/pystachy_compiler/reflection.py'
start = '    memo_prims = ["__pys_copy_addr", "__pys_copy_ref", "__pys_copy_unref"]'
end = '    if name == "__pys_deepcopy_list":'
segments = []
for commit in (BASE, HEAD):
    text = git(commit, reflection_path).decode()
    segments.append(text[text.index(start):text.index(end, text.index(start))])
assert segments[0] == segments[1]
(OUT / 'private-copy-primitives.py.txt').write_text(segments[1])
native = WORK / 'evidence/ci/b0-native-coverage/all-residual-coverage.json'
native_case = next(row for row in json.loads(native.read_text())['fixtures'] if row['program'] == CASE)
report = {'status': 'reviewed_existing_model_limitation_encountered_by_added_fixture',
          'candidate_commit': HEAD, 'candidate_tree': '51f6c150748b2d17945e4d1c6779d8080b6edd6a',
          'program': CASE, 'census': identity(RECORDS), 'snapshot_sha256': new_record['snapshot_sha256'],
          'gc_counts': new_record['checks']['gc'], 'residual': new_residual[0],
          'baseline_reference': {'program': old_record['program'], 'census': identity(BASE_RECORDS),
                                 'snapshot_sha256': old_record['snapshot_sha256'], 'residual': old_residual,
                                 'residual_dictionary_exactly_equal': True},
          'retained_ir': {'old': identity(old_path), 'new': identity(new_path)},
          'exact_case_specific_reference_map': binding_evidence,
          'full_memo_get_body_equal_after_only_verified_references': True,
          'source': {'memo_protocol': identity(REPO / copy_path),
                     'memo_protocol_bytes_equal_alpha2_and_candidate': True,
                     'private_primitives_source': identity(REPO / reflection_path),
                     'private_primitives_region_bytes_equal': True,
                     'private_primitives_region': identity(OUT / 'private-copy-primitives.py.txt'),
                     'collector_adapter': identity(REPO / 'tools/check_lean_gc.py')},
          'mechanism': [
              'The memo maps an original object address to an index into _keep. _keep is constructed with pys_list_new and stores original/copy pointers as scanned words.',
              'The hit path uses pys_list_get, casts the returned word to a pointer, and returns it as the original container type. The private compiler primitives check that the stored copy matches its original type and restrict access to the library module.',
              'The GC finite-tag model does not recover the returned container array kind from that private heterogeneous memo protocol. At the retained return, %t29 has no inferred scanned/none fact.',
              'This exact residual already occurs in alpha2 lib_enum. The new complex fixture newly reaches it; the three obligations remain rejected.'
          ],
          'native_coverage': {'report': identity(native), 'fixture': native_case},
          'limits': ['No proof obligation is accepted or removed by this review.',
                     'The reported first failure and existing protocol explain the rejection; they do not separately prove every obligation in the rejected function.',
                     'The collector model checks container array scanning, not general pointer lifetime or GC-root completeness.',
                     'No compiler, runtime, checker or network operation was performed.']}
(OUT / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
(OUT / 'review.md').write_text('''# Complex copy: retained GC model gap

The added `complex_values.py` fixture retains **three rejected GC obligations** in `@f._pystachy_copy$_memo_get.1`. At the hit-path return, `%t29` comes from a `pys_list_get` word cast to a pointer. The model requires the returned container array to be scanned or absent and has no inferred fact for this private memo encoding.

The memo protocol stores originals and copies in `_keep`, created by `pys_list_new`, and maps original addresses to positions. The compiler restricts its private primitives to the library and checks the stored copy against the original type. That protocol is outside the finite-tag inference used for this return. The full memo module and the exact private-primitives source region are byte-identical to alpha2.

This is an additional fixture encountering an existing limitation. Alpha2 `lib_enum.py` records the **exact same residual dictionary**. Its complete memo-get LLVM function and this fixture's function are identical after only four explicitly verified references: two TBAA references whose entire definition trees agree and two equal exception-string constants. No general name, block, or instruction normalization was applied. Both bodies and the verification map are retained.

The fixture passed retained native JIT and AOT against its recorded CPython oracle; the companion JSON binds those concrete execution rows and source hashes. Runtime observations do not discharge the rejected function, and this review grants no theorem. The first reported failure explains the observed rejection; the remaining obligations are not separately proved by that explanation. No new compiler, runtime, checker, or network operation was performed.
''')
print(json.dumps({'status': report['status'], 'unproved_gc_obligations': 3, 'exact_alpha2_residual_match': True}))
