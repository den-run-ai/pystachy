# Complex copy: retained GC model gap

The added `complex_values.py` fixture retains **three rejected GC obligations** in `@f._pystachy_copy$_memo_get.1`. At the hit-path return, `%t29` comes from a `pys_list_get` word cast to a pointer. The model requires the returned container array to be scanned or absent and has no inferred fact for this private memo encoding.

The memo protocol stores originals and copies in `_keep`, created by `pys_list_new`, and maps original addresses to positions. The compiler restricts its private primitives to the library and checks the stored copy against the original type. That protocol is outside the finite-tag inference used for this return. The full memo module and the exact private-primitives source region are byte-identical to alpha2.

This is an additional fixture encountering an existing limitation. Alpha2 `lib_enum.py` records the **exact same residual dictionary**. Its complete memo-get LLVM function and this fixture's function are identical after only four explicitly verified references: two TBAA references whose entire definition trees agree and two equal exception-string constants. No general name, block, or instruction normalization was applied. Both bodies and the verification map are retained.

The fixture passed retained native JIT and AOT against its recorded CPython oracle; the companion JSON binds those concrete execution rows and source hashes. Runtime observations do not discharge the rejected function, and this review grants no theorem. The first reported failure explains the observed rejection; the remaining obligations are not separately proved by that explanation. No new compiler, runtime, checker, or network operation was performed.
