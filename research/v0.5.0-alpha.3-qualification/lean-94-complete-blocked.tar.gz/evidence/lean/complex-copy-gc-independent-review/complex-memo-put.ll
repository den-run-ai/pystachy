define internal void @f._pystachy_copy$_memo_put.1(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %memo.2 = alloca ptr
  store ptr zeroinitializer, ptr %memo.2
  %x.3 = alloca ptr
  store ptr zeroinitializer, ptr %x.3
  %y.4 = alloca ptr
  store ptr zeroinitializer, ptr %y.4
  store ptr %a0, ptr %memo.2
  store ptr %a1, ptr %x.3
  store ptr %a2, ptr %y.4
  %t5 = load ptr, ptr %memo.2
  %t6 = icmp eq ptr %t5, null
  br i1 %t6, label %L7, label %L8
L8:
  %t9 = getelementptr %C._pystachy_copy$_Memo, ptr %t5, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !18
  %t11 = load ptr, ptr %x.3
  %t12 = ptrtoint ptr %t11 to i64
  call void @pys_list_append(ptr %t10, i64 %t12)
  %t13 = load ptr, ptr %memo.2
  %t16 = getelementptr %C._pystachy_copy$_Memo, ptr %t13, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !18
  %t18 = load i64, ptr %t17
  %t19 = load ptr, ptr %memo.2
  %t23 = getelementptr %C._pystachy_copy$_Memo, ptr %t19, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !17
  %t25 = load ptr, ptr %x.3
  %t26 = ptrtoint ptr %t25 to i64
  call void @pys_dict_set(ptr %t24, i64 %t26, i64 %t18)
  %t27 = load ptr, ptr %memo.2
  %t30 = getelementptr %C._pystachy_copy$_Memo, ptr %t27, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !18
  %t32 = load ptr, ptr %y.4
  %t33 = load ptr, ptr %x.3
  %t34 = ptrtoint ptr %t32 to i64
  call void @pys_list_append(ptr %t31, i64 %t34)
  ret void
  br label %L7
L7:
  call void @pys_raise(ptr @s.10, ptr @s.20)
  unreachable
}
