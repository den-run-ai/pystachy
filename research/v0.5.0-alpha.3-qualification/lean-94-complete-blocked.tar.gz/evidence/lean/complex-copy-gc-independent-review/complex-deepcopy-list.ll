define internal ptr @f.copy$_deepcopy_list.1(ptr %a0, ptr %a1) {
entry:
  %x.2 = alloca ptr
  store ptr zeroinitializer, ptr %x.2
  %memo.3 = alloca ptr
  store ptr zeroinitializer, ptr %memo.3
  %hit.11 = alloca ptr
  store ptr zeroinitializer, ptr %hit.11
  %y.20 = alloca ptr
  store ptr zeroinitializer, ptr %y.20
  %h.30 = alloca i64
  store i64 zeroinitializer, ptr %h.30
  %a.41 = alloca ptr
  store ptr zeroinitializer, ptr %a.41
  store ptr %a0, ptr %x.2
  store ptr %a1, ptr %memo.3
  %t4 = load i1, ptr @g.copy$_memo_get.imp
  %t5 = xor i1 %t4, true
  br i1 %t5, label %L6, label %L7
L7:
  %t8 = load ptr, ptr %memo.3
  %t9 = load ptr, ptr %x.2
  %t10 = call ptr @f._pystachy_copy$_memo_get.1(ptr %t8, ptr %t9)
  store ptr %t10, ptr %hit.11
  %t12 = load ptr, ptr %hit.11
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %L14, label %L15
L14:
  %t17 = load ptr, ptr %hit.11
  ret ptr %t17
L15:
  br label %L16
L16:
  %t18 = load ptr, ptr %x.2
  %t19 = call ptr @pys_list_copy(ptr %t18)
  store ptr %t19, ptr %y.20
  %t21 = load ptr, ptr %y.20
  call void @pys_list_clear(ptr %t21)
  %t22 = load i1, ptr @g.copy$_memo_put.imp
  %t23 = xor i1 %t22, true
  br i1 %t23, label %L24, label %L25
L25:
  %t26 = load ptr, ptr %memo.3
  %t27 = load ptr, ptr %x.2
  %t28 = load ptr, ptr %y.20
  call void @f._pystachy_copy$_memo_put.1(ptr %t26, ptr %t27, ptr %t28)
  %t29 = load ptr, ptr %x.2
  store i64 0, ptr %h.30
  %t31 = load i64, ptr %t29
  br label %L32
L32:
  %t35 = load i64, ptr %h.30
  %t36 = load i64, ptr %t29
  %t37 = icmp slt i64 %t35, %t36
  br i1 %t37, label %L38, label %L34
L38:
  %t49 = getelementptr inbounds {i64, i64, ptr}, ptr %t29, i64 0, i32 2
  %t50 = load ptr, ptr %t49, !tbaa !19
  %t51 = getelementptr inbounds i64, ptr %t50, i64 %t35
  %t39 = load i64, ptr %t51, !tbaa !20
  %t40 = inttoptr i64 %t39 to ptr
  store ptr %t40, ptr %a.41
  %t42 = load ptr, ptr %y.20
  %t43 = load ptr, ptr %a.41
  %t44 = load ptr, ptr %memo.3
  %t45 = call ptr @f.copy$_deepcopy.2(ptr %t43, ptr %t44)
  %t46 = ptrtoint ptr %t45 to i64
  call void @pys_list_append(ptr %t42, i64 %t46)
  br label %L33
L33:
  %t47 = add i64 %t35, 1
  store i64 %t47, ptr %h.30
  br label %L32
L34:
  %t48 = load ptr, ptr %y.20
  ret ptr %t48
L6:
  call void @pys_raise(ptr @s.22, ptr @s.21)
  unreachable
L24:
  call void @pys_raise(ptr @s.22, ptr @s.23)
  unreachable
}
