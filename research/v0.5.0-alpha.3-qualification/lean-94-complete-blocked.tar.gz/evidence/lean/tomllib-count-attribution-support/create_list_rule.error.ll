L107:
  call void @pys_raise(ptr @s.101, ptr @s.567)
  unreachable

@s.101 = private unnamed_addr global {i64, i64, i64, [15 x i8]} {i64 14, i64 0, i64 15, [15 x i8] c"AttributeError\00"}, align 8
@s.567 = private unnamed_addr global {i64, i64, i64, [47 x i8]} {i64 46, i64 0, i64 47, [47 x i8] c"'NoneType' object has no attribute 'unset_all'\00"}, align 8
