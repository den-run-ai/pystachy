define internal {i64, i64} @v.f.tomllib$_parser$create_dict_rule(ptr %a0, i64 %a1, ptr %a2, ptr %aid1) personality ptr @pys_personality {
entry:
  %src.2 = alloca ptr
  store ptr zeroinitializer, ptr %src.2
  %pos.3 = alloca i64
  store i64 zeroinitializer, ptr %pos.3
  %pos.box.3 = alloca ptr
  store ptr zeroinitializer, ptr %pos.box.3
  %pos.boxgen.3 = alloca i64
  store i64 zeroinitializer, ptr %pos.boxgen.3
  %out.4 = alloca ptr
  store ptr zeroinitializer, ptr %out.4
  %h.28 = alloca ptr
  store ptr zeroinitializer, ptr %h.28
  %h.31 = alloca i64
  store i64 zeroinitializer, ptr %h.31
  %key.60 = alloca ptr
  store ptr zeroinitializer, ptr %key.60
  %h.136 = alloca ptr
  store ptr zeroinitializer, ptr %h.136
  %t1 = call i64 @pys.recursion.enter()
  %t206 = sub i64 %t1, 1
  store ptr %a0, ptr %src.2
  store i64 %a1, ptr %pos.3
  store ptr %aid1, ptr %pos.box.3
  store ptr %a2, ptr %out.4
  %t5 = load i64, ptr %pos.3
  %t6 = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %t5, i64 1)
  %t7 = extractvalue {i64, i1} %t6, 0
  %t8 = extractvalue {i64, i1} %t6, 1
  br i1 %t8, label %L9, label %L10
L10:
  store i64 %t7, ptr %pos.3
  store ptr null, ptr %pos.box.3
  %t11 = load i64, ptr %pos.boxgen.3
  %t12 = add i64 %t11, 1
  store i64 %t12, ptr %pos.boxgen.3
  %t13 = load i1, ptr @g.tomllib$_parser$skip_chars.def
  %t14 = xor i1 %t13, true
  br i1 %t14, label %L15, label %L16
L16:
  %t17 = load ptr, ptr %src.2
  %t18 = load i64, ptr %pos.3
  %t19 = load ptr, ptr %pos.box.3
  %t20 = load i64, ptr %pos.boxgen.3
  %t21 = load ptr, ptr %pos.box.3
  %t22 = call ptr @pys_dyn_int_box(i64 %t18, ptr %t21)
  store ptr %t22, ptr %pos.box.3
  %t23 = load i1, ptr @g.tomllib$_parser$TOML_WS.def
  %t24 = xor i1 %t23, true
  br i1 %t24, label %L25, label %L26
L26:
  %t27 = load ptr, ptr @g.tomllib$_parser$TOML_WS
  store ptr null, ptr %h.28
  %t29 = call i64 @f.tomllib$_parser$skip_chars.1(ptr %t17, i64 %t18, ptr %t27, ptr %t22, ptr %h.28)
  %t30 = load ptr, ptr %h.28
  store i64 %t29, ptr %pos.3
  %t32 = load ptr, ptr %h.28
  %t33 = icmp ne ptr %t30, null
  %t34 = select i1 %t33, ptr %t30, ptr %t32
  %t35 = load ptr, ptr %pos.box.3
  %t36 = icmp eq ptr %t35, %t34
  %t37 = icmp ne ptr %t35, null
  %t38 = and i1 %t36, %t37
  %t39 = select i1 %t38, i64 0, i64 1
  store ptr %t34, ptr %pos.box.3
  %t40 = load i64, ptr %pos.boxgen.3
  %t41 = add i64 %t40, %t39
  store i64 %t41, ptr %pos.boxgen.3
  %t42 = load i1, ptr @g.tomllib$_parser$parse_key.def
  %t43 = xor i1 %t42, true
  br i1 %t43, label %L44, label %L45
L45:
  %t46 = load ptr, ptr %src.2
  %t47 = load i64, ptr %pos.3
  %t48 = load ptr, ptr %pos.box.3
  %t49 = load i64, ptr %pos.boxgen.3
  %t50 = load ptr, ptr %pos.box.3
  %t51 = call ptr @pys_dyn_int_box(i64 %t47, ptr %t50)
  store ptr %t51, ptr %pos.box.3
  %t52 = call {i64, i64} @v.f.tomllib$_parser$parse_key(ptr %t46, i64 %t47, ptr %t51)
  %t54 = extractvalue {i64, i64} %t52, 0
  store i64 %t54, ptr %pos.3
  store ptr null, ptr %pos.box.3
  %t55 = load i64, ptr %pos.boxgen.3
  %t56 = add i64 %t55, 1
  store i64 %t56, ptr %pos.boxgen.3
  %t58 = extractvalue {i64, i64} %t52, 1
  %t59 = inttoptr i64 %t58 to ptr
  store ptr %t59, ptr %key.60
  %t61 = load ptr, ptr %out.4
  %t62 = icmp eq ptr %t61, null
  br i1 %t62, label %L63, label %L64
L64:
  %t65 = getelementptr %C.tomllib$_parser$Output, ptr %t61, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !92
  %t67 = icmp eq ptr %t66, null
  br i1 %t67, label %L68, label %L69
L69:
  %t70 = load ptr, ptr %key.60
  %t71 = load i1, ptr @g.tomllib$_parser$Flags.def
  %t72 = xor i1 %t71, true
  br i1 %t72, label %L73, label %L74
L74:
  %t75 = load i64, ptr @d.c.tomllib$_parser$Flags.EXPLICIT_NEST
  %t76 = load ptr, ptr @d.c.tomllib$_parser$Flags.EXPLICIT_NEST.box
  %t77 = call ptr @pys_dyn_int_box(i64 %t75, ptr %t76)
  store ptr %t77, ptr @d.c.tomllib$_parser$Flags.EXPLICIT_NEST.box
  %t78 = call i1 @m.tomllib$_parser$Flags.is_(ptr %t66, ptr %t70, i64 %t75, ptr %t77)
  br i1 %t78, label %L80, label %L79
L79:
  %t81 = load ptr, ptr %out.4
  %t84 = getelementptr %C.tomllib$_parser$Output, ptr %t81, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !92
  %t86 = icmp eq ptr %t85, null
  br i1 %t86, label %L68, label %L87
L87:
  %t88 = load ptr, ptr %key.60
  %t89 = load i1, ptr @g.tomllib$_parser$Flags.def
  %t90 = xor i1 %t89, true
  br i1 %t90, label %L73, label %L91
L91:
  %t92 = load i64, ptr @d.c.tomllib$_parser$Flags.FROZEN
  %t93 = load ptr, ptr @d.c.tomllib$_parser$Flags.FROZEN.box
  %t94 = call ptr @pys_dyn_int_box(i64 %t92, ptr %t93)
  store ptr %t94, ptr @d.c.tomllib$_parser$Flags.FROZEN.box
  %t95 = call i1 @m.tomllib$_parser$Flags.is_(ptr %t85, ptr %t88, i64 %t92, ptr %t94)
  br label %L80
L80:
  %t96 = phi i1 [%t78, %L74], [%t95, %L91]
  br i1 %t96, label %L97, label %L98
L97:
  %t100 = load i1, ptr @g.tomllib$_parser$suffixed_err.def
  %t101 = xor i1 %t100, true
  br i1 %t101, label %L102, label %L103
L103:
  %t104 = load ptr, ptr %src.2
  %t105 = load i64, ptr %pos.3
  %t106 = load ptr, ptr %pos.box.3
  %t107 = load i64, ptr %pos.boxgen.3
  %t108 = load ptr, ptr %pos.box.3
  %t109 = call ptr @pys_dyn_int_box(i64 %t105, ptr %t108)
  store ptr %t109, ptr %pos.box.3
  %t110 = load ptr, ptr %key.60
  %t111 = ptrtoint ptr %t110 to i64
  %t112 = call ptr @pys_repr(i64 %t111, ptr @s.554)
  %t113 = call ptr @pys_str_cat(i64 3, ptr @s.553, ptr %t112, ptr @s.555, ptr null, ptr null, ptr null, ptr null, ptr null)
  %t114 = call ptr @f.tomllib$_parser$suffixed_err(ptr %t104, i64 %t105, ptr %t113, ptr %t109)
  %t115 = icmp eq ptr %t114, null
  br i1 %t115, label %L116, label %L117
L117:
  %t118 = call ptr @pys_exc_user(ptr %t114)
  call void @pys_throw(ptr %t118)
  unreachable
L98:
  br label %L99
L99:
  %t119 = load ptr, ptr %out.4
  %t122 = getelementptr %C.tomllib$_parser$Output, ptr %t119, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !92
  %t124 = icmp eq ptr %t123, null
  br i1 %t124, label %L125, label %L126
L126:
  %t127 = load ptr, ptr %key.60
  %t128 = load i1, ptr @g.tomllib$_parser$Flags.def
  %t129 = xor i1 %t128, true
  br i1 %t129, label %L73, label %L130
L130:
  %t131 = load i64, ptr @d.c.tomllib$_parser$Flags.EXPLICIT_NEST
  %t132 = load ptr, ptr @d.c.tomllib$_parser$Flags.EXPLICIT_NEST.box
  %t133 = call ptr @pys_dyn_int_box(i64 %t131, ptr %t132)
  store ptr %t133, ptr @d.c.tomllib$_parser$Flags.EXPLICIT_NEST.box
  call void @m.tomllib$_parser$Flags.set(ptr %t123, ptr %t127, i64 %t131, i1 false, ptr %t133)
  %t134 = call i64 @pys_try_mark()
  %t135 = call ptr @pys_exc_handled()
  br label %L139
L139:
  %t140 = load ptr, ptr %out.4
  %t144 = getelementptr %C.tomllib$_parser$Output, ptr %t140, i32 0, i32 0
  %t145 = load ptr, ptr %t144, !tbaa !93
  %t146 = icmp eq ptr %t145, null
  br i1 %t146, label %L147, label %L148
L148:
  %t149 = load ptr, ptr %key.60
  %t150 = invoke ptr @m.tomllib$_parser$NestedDict.get_or_create_nest(ptr %t145, ptr %t149, i1 true) to label %L207 unwind label %L137
L207:
  br label %L138
L137:
  %t152 = landingpad { ptr, i32 } catch ptr null
  %t153 = extractvalue { ptr, i32 } %t152, 0
  store ptr %t153, ptr %h.136
  br label %L151
L151:
  %t154 = load ptr, ptr %h.136
  store i64 %t1, ptr @pys_recursion_state, !tbaa !6
  %t155 = call ptr @pys_exc_begin(ptr %t154, i64 %t134)
  %t158 = call i64 @pys_exc_in(ptr %t155, ptr @s.556)
  %t159 = icmp ne i64 %t158, 0
  br i1 %t159, label %L156, label %L157
L156:
  %t160 = load i1, ptr @g.tomllib$_parser$suffixed_err.def
  %t161 = xor i1 %t160, true
  br i1 %t161, label %L102, label %L162
L162:
  %t163 = load ptr, ptr %src.2
  %t164 = load i64, ptr %pos.3
  %t165 = load ptr, ptr %pos.box.3
  %t166 = load i64, ptr %pos.boxgen.3
  %t167 = load ptr, ptr %pos.box.3
  %t168 = call ptr @pys_dyn_int_box(i64 %t164, ptr %t167)
  store ptr %t168, ptr %pos.box.3
  %t169 = call ptr @f.tomllib$_parser$suffixed_err(ptr %t163, i64 %t164, ptr @s.557, ptr %t168)
  %t170 = icmp eq ptr %t169, null
  br i1 %t170, label %L116, label %L171
L171:
  %t172 = call ptr @pys_exc_user(ptr %t169)
  call void @pys_throw(ptr %t172)
  unreachable
L157:
  call void @pys_throw(ptr %t155)
  unreachable
L138:
  %t173 = load ptr, ptr %src.2
  %t174 = load i64, ptr %pos.3
  %t175 = load ptr, ptr %pos.box.3
  %t176 = load i64, ptr %pos.boxgen.3
  %t177 = call i64 @pys_text_startswith(ptr %t173, ptr @s.558, i64 %t174, i64 9223372036854775807)
  %t178 = icmp ne i64 %t177, 0
  %t179 = xor i1 %t178, true
  br i1 %t179, label %L180, label %L181
L180:
  %t183 = load i1, ptr @g.tomllib$_parser$suffixed_err.def
  %t184 = xor i1 %t183, true
  br i1 %t184, label %L102, label %L185
L185:
  %t186 = load ptr, ptr %src.2
  %t187 = load i64, ptr %pos.3
  %t188 = load ptr, ptr %pos.box.3
  %t189 = load i64, ptr %pos.boxgen.3
  %t190 = load ptr, ptr %pos.box.3
  %t191 = call ptr @pys_dyn_int_box(i64 %t187, ptr %t190)
  store ptr %t191, ptr %pos.box.3
  %t192 = call ptr @f.tomllib$_parser$suffixed_err(ptr %t186, i64 %t187, ptr @s.559, ptr %t191)
  %t193 = icmp eq ptr %t192, null
  br i1 %t193, label %L116, label %L194
L194:
  %t195 = call ptr @pys_exc_user(ptr %t192)
  call void @pys_throw(ptr %t195)
  unreachable
L181:
  br label %L182
L182:
  %t196 = load i64, ptr %pos.3
  %t197 = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %t196, i64 1)
  %t198 = extractvalue {i64, i1} %t197, 0
  %t199 = extractvalue {i64, i1} %t197, 1
  br i1 %t199, label %L9, label %L200
L200:
  %t201 = load ptr, ptr %key.60
  %t204 = ptrtoint ptr %t201 to i64
  store i64 %t206, ptr @pys_recursion_state, !tbaa !6
  %t202.v0 = insertvalue {i64, i64} zeroinitializer, i64 %t198, 0
  %t202.v1 = insertvalue {i64, i64} %t202.v0, i64 %t204, 1
  ret {i64, i64} %t202.v1
L9:
  call void @pys_raise(ptr @s.112, ptr @s.111)
  unreachable
L15:
  call void @pys_raise(ptr @s.99, ptr @s.541)
  unreachable
L25:
  call void @pys_raise(ptr @s.99, ptr @s.542)
  unreachable
L44:
  call void @pys_raise(ptr @s.99, ptr @s.560)
  unreachable
L63:
  call void @pys_raise(ptr @s.101, ptr @s.222)
  unreachable
L68:
  call void @pys_raise(ptr @s.101, ptr @s.561)
  unreachable
L73:
  call void @pys_raise(ptr @s.99, ptr @s.539)
  unreachable
L102:
  call void @pys_raise(ptr @s.99, ptr @s.548)
  unreachable
L116:
  call void @pys_raise(ptr @s.178, ptr @s.517)
  unreachable
L125:
  call void @pys_raise(ptr @s.101, ptr @s.562)
  unreachable
L147:
  %t208 = call ptr @pys_exc_new(ptr @s.101, ptr @s.563, ptr null)
  store ptr %t208, ptr %h.136
  br label %L151
}
