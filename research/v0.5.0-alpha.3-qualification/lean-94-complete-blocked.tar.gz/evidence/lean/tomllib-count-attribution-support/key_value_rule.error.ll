L118:
  call void @pys_raise(ptr @s.101, ptr @s.573)
  unreachable

@s.101 = private unnamed_addr global {i64, i64, i64, [15 x i8]} {i64 14, i64 0, i64 15, [15 x i8] c"AttributeError\00"}, align 8
@s.573 = private unnamed_addr global {i64, i64, i64, [49 x i8]} {i64 48, i64 0, i64 49, [49 x i8] c"'NoneType' object has no attribute 'add_pending'\00"}, align 8
