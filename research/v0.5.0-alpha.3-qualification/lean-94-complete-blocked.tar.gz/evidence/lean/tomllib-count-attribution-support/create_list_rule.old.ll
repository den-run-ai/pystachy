define internal {i64, i64} @v.f.tomllib$_parser$create_list_rule(ptr %a0, i64 %a1, ptr %a2, ptr %aid1) personality ptr @pys_personality {
entry:
  %src.2 = alloca ptr
  store ptr zeroinitializer, ptr %src.2
  %pos.3 = alloca i64
  store i64 zeroinitializer, ptr %pos.3
  %pos.box.3 = alloca ptr
  store ptr zeroinitializer, ptr %pos.box.3
  %pos.boxgen.3 = alloca i64
  store i64 zeroinitializer, ptr %pos.boxgen.3
  %out.4 = alloca ptr
  store ptr zeroinitializer, ptr %out.4
  %h.28 = alloca ptr
  store ptr zeroinitializer, ptr %h.28
  %h.31 = alloca i64
  store i64 zeroinitializer, ptr %h.31
  %key.60 = alloca ptr
  store ptr zeroinitializer, ptr %key.60
  %h.127 = alloca ptr
  store ptr zeroinitializer, ptr %h.127
  %t1 = call i64 @pys.recursion.enter()
  %t196 = sub i64 %t1, 1
  store ptr %a0, ptr %src.2
  store i64 %a1, ptr %pos.3
  store ptr %aid1, ptr %pos.box.3
  store ptr %a2, ptr %out.4
  %t5 = load i64, ptr %pos.3
  %t6 = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %t5, i64 2)
  %t7 = extractvalue {i64, i1} %t6, 0
  %t8 = extractvalue {i64, i1} %t6, 1
  br i1 %t8, label %L9, label %L10
L10:
  store i64 %t7, ptr %pos.3
  store ptr null, ptr %pos.box.3
  %t11 = load i64, ptr %pos.boxgen.3
  %t12 = add i64 %t11, 1
  store i64 %t12, ptr %pos.boxgen.3
  %t13 = load i1, ptr @g.tomllib$_parser$skip_chars.def
  %t14 = xor i1 %t13, true
  br i1 %t14, label %L15, label %L16
L16:
  %t17 = load ptr, ptr %src.2
  %t18 = load i64, ptr %pos.3
  %t19 = load ptr, ptr %pos.box.3
  %t20 = load i64, ptr %pos.boxgen.3
  %t21 = load ptr, ptr %pos.box.3
  %t22 = call ptr @pys_dyn_int_box(i64 %t18, ptr %t21)
  store ptr %t22, ptr %pos.box.3
  %t23 = load i1, ptr @g.tomllib$_parser$TOML_WS.def
  %t24 = xor i1 %t23, true
  br i1 %t24, label %L25, label %L26
L26:
  %t27 = load ptr, ptr @g.tomllib$_parser$TOML_WS
  store ptr null, ptr %h.28
  %t29 = call i64 @f.tomllib$_parser$skip_chars.1(ptr %t17, i64 %t18, ptr %t27, ptr %t22, ptr %h.28)
  %t30 = load ptr, ptr %h.28
  store i64 %t29, ptr %pos.3
  %t32 = load ptr, ptr %h.28
  %t33 = icmp ne ptr %t30, null
  %t34 = select i1 %t33, ptr %t30, ptr %t32
  %t35 = load ptr, ptr %pos.box.3
  %t36 = icmp eq ptr %t35, %t34
  %t37 = icmp ne ptr %t35, null
  %t38 = and i1 %t36, %t37
  %t39 = select i1 %t38, i64 0, i64 1
  store ptr %t34, ptr %pos.box.3
  %t40 = load i64, ptr %pos.boxgen.3
  %t41 = add i64 %t40, %t39
  store i64 %t41, ptr %pos.boxgen.3
  %t42 = load i1, ptr @g.tomllib$_parser$parse_key.def
  %t43 = xor i1 %t42, true
  br i1 %t43, label %L44, label %L45
L45:
  %t46 = load ptr, ptr %src.2
  %t47 = load i64, ptr %pos.3
  %t48 = load ptr, ptr %pos.box.3
  %t49 = load i64, ptr %pos.boxgen.3
  %t50 = load ptr, ptr %pos.box.3
  %t51 = call ptr @pys_dyn_int_box(i64 %t47, ptr %t50)
  store ptr %t51, ptr %pos.box.3
  %t52 = call {i64, i64} @v.f.tomllib$_parser$parse_key(ptr %t46, i64 %t47, ptr %t51)
  %t54 = extractvalue {i64, i64} %t52, 0
  store i64 %t54, ptr %pos.3
  store ptr null, ptr %pos.box.3
  %t55 = load i64, ptr %pos.boxgen.3
  %t56 = add i64 %t55, 1
  store i64 %t56, ptr %pos.boxgen.3
  %t58 = extractvalue {i64, i64} %t52, 1
  %t59 = inttoptr i64 %t58 to ptr
  store ptr %t59, ptr %key.60
  %t61 = load ptr, ptr %out.4
  %t62 = icmp eq ptr %t61, null
  br i1 %t62, label %L63, label %L64
L64:
  %t65 = getelementptr %C.tomllib$_parser$Output, ptr %t61, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !92
  %t67 = icmp eq ptr %t66, null
  br i1 %t67, label %L68, label %L69
L69:
  %t70 = load ptr, ptr %key.60
  %t71 = load i1, ptr @g.tomllib$_parser$Flags.def
  %t72 = xor i1 %t71, true
  br i1 %t72, label %L73, label %L74
L74:
  %t75 = load i64, ptr @d.c.tomllib$_parser$Flags.FROZEN
  %t76 = load ptr, ptr @d.c.tomllib$_parser$Flags.FROZEN.box
  %t77 = call ptr @pys_dyn_int_box(i64 %t75, ptr %t76)
  store ptr %t77, ptr @d.c.tomllib$_parser$Flags.FROZEN.box
  %t78 = call i1 @m.tomllib$_parser$Flags.is_(ptr %t66, ptr %t70, i64 %t75, ptr %t77)
  br i1 %t78, label %L79, label %L80
L79:
  %t82 = load i1, ptr @g.tomllib$_parser$suffixed_err.def
  %t83 = xor i1 %t82, true
  br i1 %t83, label %L84, label %L85
L85:
  %t86 = load ptr, ptr %src.2
  %t87 = load i64, ptr %pos.3
  %t88 = load ptr, ptr %pos.box.3
  %t89 = load i64, ptr %pos.boxgen.3
  %t90 = load ptr, ptr %pos.box.3
  %t91 = call ptr @pys_dyn_int_box(i64 %t87, ptr %t90)
  store ptr %t91, ptr %pos.box.3
  %t92 = load ptr, ptr %key.60
  %t93 = ptrtoint ptr %t92 to i64
  %t94 = call ptr @pys_repr(i64 %t93, ptr @s.554)
  %t95 = call ptr @pys_str_add(ptr @s.564, ptr %t94)
  %t96 = call ptr @f.tomllib$_parser$suffixed_err(ptr %t86, i64 %t87, ptr %t95, ptr %t91)
  %t97 = icmp eq ptr %t96, null
  br i1 %t97, label %L98, label %L99
L99:
  %t100 = call ptr @pys_exc_user(ptr %t96)
  call void @pys_throw(ptr %t100)
  unreachable
L80:
  br label %L81
L81:
  %t101 = load ptr, ptr %out.4
  %t104 = getelementptr %C.tomllib$_parser$Output, ptr %t101, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !92
  %t109 = load ptr, ptr %key.60
  call void @m.tomllib$_parser$Flags.unset_all(ptr %t105, ptr %t109)
  %t110 = load ptr, ptr %out.4
  %t113 = getelementptr %C.tomllib$_parser$Output, ptr %t110, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !92
  %t115 = icmp eq ptr %t114, null
  br i1 %t115, label %L116, label %L117
L117:
  %t118 = load ptr, ptr %key.60
  %t119 = load i1, ptr @g.tomllib$_parser$Flags.def
  %t120 = xor i1 %t119, true
  br i1 %t120, label %L73, label %L121
L121:
  %t122 = load i64, ptr @d.c.tomllib$_parser$Flags.EXPLICIT_NEST
  %t123 = load ptr, ptr @d.c.tomllib$_parser$Flags.EXPLICIT_NEST.box
  %t124 = call ptr @pys_dyn_int_box(i64 %t122, ptr %t123)
  store ptr %t124, ptr @d.c.tomllib$_parser$Flags.EXPLICIT_NEST.box
  call void @m.tomllib$_parser$Flags.set(ptr %t114, ptr %t118, i64 %t122, i1 false, ptr %t124)
  %t125 = call i64 @pys_try_mark()
  %t126 = call ptr @pys_exc_handled()
  br label %L130
L130:
  %t131 = load ptr, ptr %out.4
  %t135 = getelementptr %C.tomllib$_parser$Output, ptr %t131, i32 0, i32 0
  %t136 = load ptr, ptr %t135, !tbaa !93
  %t137 = icmp eq ptr %t136, null
  br i1 %t137, label %L138, label %L139
L139:
  %t140 = load ptr, ptr %key.60
  invoke void @m.tomllib$_parser$NestedDict.append_nest_to_list(ptr %t136, ptr %t140) to label %L197 unwind label %L128
L197:
  br label %L129
L128:
  %t142 = landingpad { ptr, i32 } catch ptr null
  %t143 = extractvalue { ptr, i32 } %t142, 0
  store ptr %t143, ptr %h.127
  br label %L141
L141:
  %t144 = load ptr, ptr %h.127
  store i64 %t1, ptr @pys_recursion_state, !tbaa !6
  %t145 = call ptr @pys_exc_begin(ptr %t144, i64 %t125)
  %t148 = call i64 @pys_exc_in(ptr %t145, ptr @s.556)
  %t149 = icmp ne i64 %t148, 0
  br i1 %t149, label %L146, label %L147
L146:
  %t150 = load i1, ptr @g.tomllib$_parser$suffixed_err.def
  %t151 = xor i1 %t150, true
  br i1 %t151, label %L84, label %L152
L152:
  %t153 = load ptr, ptr %src.2
  %t154 = load i64, ptr %pos.3
  %t155 = load ptr, ptr %pos.box.3
  %t156 = load i64, ptr %pos.boxgen.3
  %t157 = load ptr, ptr %pos.box.3
  %t158 = call ptr @pys_dyn_int_box(i64 %t154, ptr %t157)
  store ptr %t158, ptr %pos.box.3
  %t159 = call ptr @f.tomllib$_parser$suffixed_err(ptr %t153, i64 %t154, ptr @s.557, ptr %t158)
  %t160 = icmp eq ptr %t159, null
  br i1 %t160, label %L98, label %L161
L161:
  %t162 = call ptr @pys_exc_user(ptr %t159)
  call void @pys_throw(ptr %t162)
  unreachable
L147:
  call void @pys_throw(ptr %t145)
  unreachable
L129:
  %t163 = load ptr, ptr %src.2
  %t164 = load i64, ptr %pos.3
  %t165 = load ptr, ptr %pos.box.3
  %t166 = load i64, ptr %pos.boxgen.3
  %t167 = call i64 @pys_text_startswith(ptr %t163, ptr @s.565, i64 %t164, i64 9223372036854775807)
  %t168 = icmp ne i64 %t167, 0
  %t169 = xor i1 %t168, true
  br i1 %t169, label %L170, label %L171
L170:
  %t173 = load i1, ptr @g.tomllib$_parser$suffixed_err.def
  %t174 = xor i1 %t173, true
  br i1 %t174, label %L84, label %L175
L175:
  %t176 = load ptr, ptr %src.2
  %t177 = load i64, ptr %pos.3
  %t178 = load ptr, ptr %pos.box.3
  %t179 = load i64, ptr %pos.boxgen.3
  %t180 = load ptr, ptr %pos.box.3
  %t181 = call ptr @pys_dyn_int_box(i64 %t177, ptr %t180)
  store ptr %t181, ptr %pos.box.3
  %t182 = call ptr @f.tomllib$_parser$suffixed_err(ptr %t176, i64 %t177, ptr @s.566, ptr %t181)
  %t183 = icmp eq ptr %t182, null
  br i1 %t183, label %L98, label %L184
L184:
  %t185 = call ptr @pys_exc_user(ptr %t182)
  call void @pys_throw(ptr %t185)
  unreachable
L171:
  br label %L172
L172:
  %t186 = load i64, ptr %pos.3
  %t187 = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %t186, i64 2)
  %t188 = extractvalue {i64, i1} %t187, 0
  %t189 = extractvalue {i64, i1} %t187, 1
  br i1 %t189, label %L9, label %L190
L190:
  %t191 = load ptr, ptr %key.60
  %t194 = ptrtoint ptr %t191 to i64
  store i64 %t196, ptr @pys_recursion_state, !tbaa !6
  %t192.v0 = insertvalue {i64, i64} zeroinitializer, i64 %t188, 0
  %t192.v1 = insertvalue {i64, i64} %t192.v0, i64 %t194, 1
  ret {i64, i64} %t192.v1
L9:
  call void @pys_raise(ptr @s.112, ptr @s.111)
  unreachable
L15:
  call void @pys_raise(ptr @s.99, ptr @s.541)
  unreachable
L25:
  call void @pys_raise(ptr @s.99, ptr @s.542)
  unreachable
L44:
  call void @pys_raise(ptr @s.99, ptr @s.560)
  unreachable
L63:
  call void @pys_raise(ptr @s.101, ptr @s.222)
  unreachable
L68:
  call void @pys_raise(ptr @s.101, ptr @s.561)
  unreachable
L73:
  call void @pys_raise(ptr @s.99, ptr @s.539)
  unreachable
L84:
  call void @pys_raise(ptr @s.99, ptr @s.548)
  unreachable
L98:
  call void @pys_raise(ptr @s.178, ptr @s.517)
  unreachable
L116:
  call void @pys_raise(ptr @s.101, ptr @s.562)
  unreachable
L138:
  %t198 = call ptr @pys_exc_new(ptr @s.101, ptr @s.568, ptr null)
  store ptr %t198, ptr %h.127
  br label %L141
}
