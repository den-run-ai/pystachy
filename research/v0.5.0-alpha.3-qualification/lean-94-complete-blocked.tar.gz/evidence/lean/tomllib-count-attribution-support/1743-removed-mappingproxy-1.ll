define internal ptr @m._pystachy_mappingproxy$mappingproxy-3.__ror__(ptr nonnull %a0, ptr %a1) {
entry:
  %self.2 = alloca ptr
  store ptr zeroinitializer, ptr %self.2
  %other.3 = alloca ptr
  store ptr zeroinitializer, ptr %other.3
  store ptr %a0, ptr %self.2
  store ptr %a1, ptr %other.3
  %t4 = load ptr, ptr %other.3
  %t5 = load ptr, ptr %self.2
  %t6 = getelementptr %C._pystachy_mappingproxy$mappingproxy-3, ptr %t5, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !16
  %t8 = call ptr @pys_dict_copy(ptr %t4)
  call void @pys_dict_update(ptr %t8, ptr %t7)
  ret ptr %t8
}
