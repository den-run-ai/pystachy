L68:
  call void @pys_raise(ptr @s.101, ptr @s.561)
  unreachable

@s.101 = private unnamed_addr global {i64, i64, i64, [15 x i8]} {i64 14, i64 0, i64 15, [15 x i8] c"AttributeError\00"}, align 8
@s.561 = private unnamed_addr global {i64, i64, i64, [41 x i8]} {i64 40, i64 0, i64 41, [41 x i8] c"'NoneType' object has no attribute 'is_'\00"}, align 8
