define internal i64 @f.tomllib$_parser$key_value_rule(ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4, ptr %aid1, ptr %idret) personality ptr @pys_personality {
entry:
  %src.2 = alloca ptr
  store ptr zeroinitializer, ptr %src.2
  %pos.3 = alloca i64
  store i64 zeroinitializer, ptr %pos.3
  %pos.box.3 = alloca ptr
  store ptr zeroinitializer, ptr %pos.box.3
  %pos.boxgen.3 = alloca i64
  store i64 zeroinitializer, ptr %pos.boxgen.3
  %out.4 = alloca ptr
  store ptr zeroinitializer, ptr %out.4
  %header.5 = alloca ptr
  store ptr zeroinitializer, ptr %header.5
  %parse_float.6 = alloca ptr
  store ptr zeroinitializer, ptr %parse_float.6
  %key.26 = alloca ptr
  store ptr zeroinitializer, ptr %key.26
  %value.30 = alloca ptr
  store ptr zeroinitializer, ptr %value.30
  %key_parent.36 = alloca ptr
  store ptr zeroinitializer, ptr %key_parent.36
  %key_stem.37 = alloca ptr
  store ptr zeroinitializer, ptr %key_stem.37
  %abs_key_parent.41 = alloca ptr
  store ptr zeroinitializer, ptr %abs_key_parent.41
  %relative_path_cont_keys.48 = alloca ptr
  store ptr zeroinitializer, ptr %relative_path_cont_keys.48
  %h.50 = alloca i64
  store i64 zeroinitializer, ptr %h.50
  %cont_key.71 = alloca ptr
  store ptr zeroinitializer, ptr %cont_key.71
  %h.165 = alloca ptr
  store ptr zeroinitializer, ptr %h.165
  %nest.180 = alloca ptr
  store ptr zeroinitializer, ptr %nest.180
  %t1 = call i64 @pys.recursion.enter()
  %t264 = sub i64 %t1, 1
  store ptr %a0, ptr %src.2
  store i64 %a1, ptr %pos.3
  store ptr %aid1, ptr %pos.box.3
  store ptr %a2, ptr %out.4
  store ptr %a3, ptr %header.5
  store ptr %a4, ptr %parse_float.6
  %t7 = load i1, ptr @g.tomllib$_parser$parse_key_value_pair.def
  %t8 = xor i1 %t7, true
  br i1 %t8, label %L9, label %L10
L10:
  %t11 = load ptr, ptr %src.2
  %t12 = load i64, ptr %pos.3
  %t13 = load ptr, ptr %pos.box.3
  %t14 = load i64, ptr %pos.boxgen.3
  %t15 = load ptr, ptr %pos.box.3
  %t16 = call ptr @pys_dyn_int_box(i64 %t12, ptr %t15)
  store ptr %t16, ptr %pos.box.3
  %t17 = load ptr, ptr %parse_float.6
  %t18 = call {i64, i64, i64} @v.f.tomllib$_parser$parse_key_value_pair(ptr %t11, i64 %t12, ptr %t17, ptr %t16)
  %t20 = extractvalue {i64, i64, i64} %t18, 0
  store i64 %t20, ptr %pos.3
  store ptr null, ptr %pos.box.3
  %t21 = load i64, ptr %pos.boxgen.3
  %t22 = add i64 %t21, 1
  store i64 %t22, ptr %pos.boxgen.3
  %t24 = extractvalue {i64, i64, i64} %t18, 1
  %t25 = inttoptr i64 %t24 to ptr
  store ptr %t25, ptr %key.26
  %t28 = extractvalue {i64, i64, i64} %t18, 2
  %t29 = inttoptr i64 %t28 to ptr
  store ptr %t29, ptr %value.30
  %t31 = load ptr, ptr %key.26
  %t32 = call ptr @pys_vtuple_slice(ptr %t31, i64 -9223372036854775808, i64 -1, i64 1)
  %t33 = load ptr, ptr %key.26
  %t34 = call i64 @pys_vtuple_get(ptr %t33, i64 -1)
  %t35 = inttoptr i64 %t34 to ptr
  store ptr %t32, ptr %key_parent.36
  store ptr %t35, ptr %key_stem.37
  %t38 = load ptr, ptr %header.5
  %t39 = load ptr, ptr %key_parent.36
  %t40 = call ptr @pys_vtuple_concat(ptr %t38, ptr %t39)
  store ptr %t40, ptr %abs_key_parent.41
  %t42 = load ptr, ptr %key.26
  %t43 = load i64, ptr %t42
  %t44 = call ptr @pys_dyn_int(i64 1)
  %t45 = load ptr, ptr %header.5
  %t46 = load ptr, ptr %key.26
  %t47 = call ptr @f.genexpr.1.1(i64 1, i64 %t43, ptr %t45, ptr %t46, ptr %t44, ptr null)
  store ptr %t47, ptr %relative_path_cont_keys.48
  %t49 = load ptr, ptr %relative_path_cont_keys.48
  store i64 0, ptr %h.50
  br label %L51
L51:
  %t54 = load i64, ptr %h.50
  %t55 = call ptr @llvm.coro.promise(ptr %t49, i32 8, i1 false)
  %t56 = getelementptr i64, ptr %t55, i64 2
  %t57 = load i64, ptr %t56
  %t59 = icmp eq i64 %t57, 2
  br i1 %t59, label %L53, label %L58
L58:
  %t60 = icmp eq i64 %t57, 3
  br i1 %t60, label %L61, label %L62
L62:
  %t63 = call i64 @pys.recursion.resume(ptr %t56)
  %t64 = sub i64 %t63, 1
  store i64 3, ptr %t56
  call void @llvm.coro.resume(ptr %t49)
  store i64 %t64, ptr @pys_recursion_state, !tbaa !6
  %t65 = load i64, ptr %t56
  %t67 = icmp eq i64 %t65, 2
  br i1 %t67, label %L53, label %L66
L66:
  br i1 true, label %L68, label %L53
L68:
  %t69 = load i64, ptr %t55
  %t70 = inttoptr i64 %t69 to ptr
  store ptr %t70, ptr %cont_key.71
  %t72 = load ptr, ptr %out.4
  %t73 = icmp eq ptr %t72, null
  br i1 %t73, label %L74, label %L75
L75:
  %t76 = getelementptr %C.tomllib$_parser$Output, ptr %t72, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !92
  %t78 = icmp eq ptr %t77, null
  br i1 %t78, label %L79, label %L80
L80:
  %t81 = load ptr, ptr %cont_key.71
  %t82 = load i1, ptr @g.tomllib$_parser$Flags.def
  %t83 = xor i1 %t82, true
  br i1 %t83, label %L84, label %L85
L85:
  %t86 = load i64, ptr @d.c.tomllib$_parser$Flags.EXPLICIT_NEST
  %t87 = load ptr, ptr @d.c.tomllib$_parser$Flags.EXPLICIT_NEST.box
  %t88 = call ptr @pys_dyn_int_box(i64 %t86, ptr %t87)
  store ptr %t88, ptr @d.c.tomllib$_parser$Flags.EXPLICIT_NEST.box
  %t89 = call i1 @m.tomllib$_parser$Flags.is_(ptr %t77, ptr %t81, i64 %t86, ptr %t88)
  br i1 %t89, label %L90, label %L91
L90:
  %t93 = load i1, ptr @g.tomllib$_parser$suffixed_err.def
  %t94 = xor i1 %t93, true
  br i1 %t94, label %L95, label %L96
L96:
  %t97 = load ptr, ptr %src.2
  %t98 = load i64, ptr %pos.3
  %t99 = load ptr, ptr %pos.box.3
  %t100 = load i64, ptr %pos.boxgen.3
  %t101 = load ptr, ptr %pos.box.3
  %t102 = call ptr @pys_dyn_int_box(i64 %t98, ptr %t101)
  store ptr %t102, ptr %pos.box.3
  %t103 = load ptr, ptr %cont_key.71
  %t104 = ptrtoint ptr %t103 to i64
  %t105 = call ptr @pys_repr(i64 %t104, ptr @s.554)
  %t106 = call ptr @pys_str_add(ptr @s.570, ptr %t105)
  %t107 = call ptr @f.tomllib$_parser$suffixed_err(ptr %t97, i64 %t98, ptr %t106, ptr %t102)
  %t108 = icmp eq ptr %t107, null
  br i1 %t108, label %L109, label %L110
L110:
  %t111 = call ptr @pys_exc_user(ptr %t107)
  call void @pys_throw(ptr %t111)
  unreachable
L91:
  br label %L92
L92:
  %t112 = load ptr, ptr %out.4
  %t115 = getelementptr %C.tomllib$_parser$Output, ptr %t112, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !92
  %t117 = icmp eq ptr %t116, null
  br i1 %t117, label %L118, label %L119
L119:
  %t120 = load ptr, ptr %cont_key.71
  %t121 = load i1, ptr @g.tomllib$_parser$Flags.def
  %t122 = xor i1 %t121, true
  br i1 %t122, label %L84, label %L123
L123:
  %t124 = load i64, ptr @d.c.tomllib$_parser$Flags.EXPLICIT_NEST
  %t125 = load ptr, ptr @d.c.tomllib$_parser$Flags.EXPLICIT_NEST.box
  %t126 = call ptr @pys_dyn_int_box(i64 %t124, ptr %t125)
  store ptr %t126, ptr @d.c.tomllib$_parser$Flags.EXPLICIT_NEST.box
  call void @m.tomllib$_parser$Flags.add_pending(ptr %t116, ptr %t120, i64 %t124, ptr %t126)
  br label %L52
L52:
  %t127 = add i64 %t54, 1
  store i64 %t127, ptr %h.50
  br label %L51
L53:
  %t128 = load ptr, ptr %out.4
  %t129 = icmp eq ptr %t128, null
  br i1 %t129, label %L74, label %L130
L130:
  %t131 = getelementptr %C.tomllib$_parser$Output, ptr %t128, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !92
  %t133 = icmp eq ptr %t132, null
  br i1 %t133, label %L79, label %L134
L134:
  %t135 = load ptr, ptr %abs_key_parent.41
  %t136 = load i1, ptr @g.tomllib$_parser$Flags.def
  %t137 = xor i1 %t136, true
  br i1 %t137, label %L84, label %L138
L138:
  %t139 = load i64, ptr @d.c.tomllib$_parser$Flags.FROZEN
  %t140 = load ptr, ptr @d.c.tomllib$_parser$Flags.FROZEN.box
  %t141 = call ptr @pys_dyn_int_box(i64 %t139, ptr %t140)
  store ptr %t141, ptr @d.c.tomllib$_parser$Flags.FROZEN.box
  %t142 = call i1 @m.tomllib$_parser$Flags.is_(ptr %t132, ptr %t135, i64 %t139, ptr %t141)
  br i1 %t142, label %L143, label %L144
L143:
  %t146 = load i1, ptr @g.tomllib$_parser$suffixed_err.def
  %t147 = xor i1 %t146, true
  br i1 %t147, label %L95, label %L148
L148:
  %t149 = load ptr, ptr %src.2
  %t150 = load i64, ptr %pos.3
  %t151 = load ptr, ptr %pos.box.3
  %t152 = load i64, ptr %pos.boxgen.3
  %t153 = load ptr, ptr %pos.box.3
  %t154 = call ptr @pys_dyn_int_box(i64 %t150, ptr %t153)
  store ptr %t154, ptr %pos.box.3
  %t155 = load ptr, ptr %abs_key_parent.41
  %t156 = ptrtoint ptr %t155 to i64
  %t157 = call ptr @pys_repr(i64 %t156, ptr @s.554)
  %t158 = call ptr @pys_str_add(ptr @s.564, ptr %t157)
  %t159 = call ptr @f.tomllib$_parser$suffixed_err(ptr %t149, i64 %t150, ptr %t158, ptr %t154)
  %t160 = icmp eq ptr %t159, null
  br i1 %t160, label %L109, label %L161
L161:
  %t162 = call ptr @pys_exc_user(ptr %t159)
  call void @pys_throw(ptr %t162)
  unreachable
L144:
  br label %L145
L145:
  %t163 = call i64 @pys_try_mark()
  %t164 = call ptr @pys_exc_handled()
  br label %L168
L168:
  %t169 = load ptr, ptr %out.4
  %t173 = getelementptr %C.tomllib$_parser$Output, ptr %t169, i32 0, i32 0
  %t174 = load ptr, ptr %t173, !tbaa !93
  %t175 = icmp eq ptr %t174, null
  br i1 %t175, label %L176, label %L177
L177:
  %t178 = load ptr, ptr %abs_key_parent.41
  %t179 = invoke ptr @m.tomllib$_parser$NestedDict.get_or_create_nest(ptr %t174, ptr %t178, i1 true) to label %L265 unwind label %L166
L265:
  store ptr %t179, ptr %nest.180
  br label %L167
L166:
  %t182 = landingpad { ptr, i32 } catch ptr null
  %t183 = extractvalue { ptr, i32 } %t182, 0
  store ptr %t183, ptr %h.165
  br label %L181
L181:
  %t184 = load ptr, ptr %h.165
  store i64 %t1, ptr @pys_recursion_state, !tbaa !6
  %t185 = call ptr @pys_exc_begin(ptr %t184, i64 %t163)
  %t188 = call i64 @pys_exc_in(ptr %t185, ptr @s.556)
  %t189 = icmp ne i64 %t188, 0
  br i1 %t189, label %L186, label %L187
L186:
  %t190 = load i1, ptr @g.tomllib$_parser$suffixed_err.def
  %t191 = xor i1 %t190, true
  br i1 %t191, label %L95, label %L192
L192:
  %t193 = load ptr, ptr %src.2
  %t194 = load i64, ptr %pos.3
  %t195 = load ptr, ptr %pos.box.3
  %t196 = load i64, ptr %pos.boxgen.3
  %t197 = load ptr, ptr %pos.box.3
  %t198 = call ptr @pys_dyn_int_box(i64 %t194, ptr %t197)
  store ptr %t198, ptr %pos.box.3
  %t199 = call ptr @f.tomllib$_parser$suffixed_err(ptr %t193, i64 %t194, ptr @s.557, ptr %t198)
  %t200 = icmp eq ptr %t199, null
  br i1 %t200, label %L109, label %L201
L201:
  %t202 = call ptr @pys_exc_user(ptr %t199)
  call void @pys_throw(ptr %t202)
  unreachable
L187:
  call void @pys_throw(ptr %t185)
  unreachable
L167:
  %t203 = load ptr, ptr %key_stem.37
  %t204 = load ptr, ptr %nest.180
  %t205 = call ptr @pys_dyn_ref(ptr @pys_dyntype_str, ptr %t203)
  %t206 = ptrtoint ptr %t205 to i64
  %t207 = call i64 @pys_dict_has(ptr %t204, i64 %t206)
  %t208 = icmp ne i64 %t207, 0
  br i1 %t208, label %L209, label %L210
L209:
  %t212 = load i1, ptr @g.tomllib$_parser$suffixed_err.def
  %t213 = xor i1 %t212, true
  br i1 %t213, label %L95, label %L214
L214:
  %t215 = load ptr, ptr %src.2
  %t216 = load i64, ptr %pos.3
  %t217 = load ptr, ptr %pos.box.3
  %t218 = load i64, ptr %pos.boxgen.3
  %t219 = load ptr, ptr %pos.box.3
  %t220 = call ptr @pys_dyn_int_box(i64 %t216, ptr %t219)
  store ptr %t220, ptr %pos.box.3
  %t221 = call ptr @f.tomllib$_parser$suffixed_err(ptr %t215, i64 %t216, ptr @s.557, ptr %t220)
  %t222 = icmp eq ptr %t221, null
  br i1 %t222, label %L109, label %L223
L223:
  %t224 = call ptr @pys_exc_user(ptr %t221)
  call void @pys_throw(ptr %t224)
  unreachable
L210:
  br label %L211
L211:
  %t225 = load ptr, ptr %value.30
  %t226 = load ptr, ptr %t225
  %t227 = icmp eq ptr %t226, @pys_dyntype_dict
  %t228 = icmp eq ptr %t226, @pys_dyntype_list
  %t229 = or i1 %t227, %t228
  %t230 = icmp eq ptr %t226, @pys_dyntype_intlist
  %t231 = or i1 %t229, %t230
  br i1 %t231, label %L232, label %L233
L232:
  %t235 = load ptr, ptr %out.4
  %t238 = getelementptr %C.tomllib$_parser$Output, ptr %t235, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !92
  %t240 = icmp eq ptr %t239, null
  br i1 %t240, label %L241, label %L242
L242:
  %t243 = load ptr, ptr %header.5
  %t244 = load ptr, ptr %key.26
  %t245 = call ptr @pys_vtuple_concat(ptr %t243, ptr %t244)
  %t246 = load i1, ptr @g.tomllib$_parser$Flags.def
  %t247 = xor i1 %t246, true
  br i1 %t247, label %L84, label %L248
L248:
  %t249 = load i64, ptr @d.c.tomllib$_parser$Flags.FROZEN
  %t250 = load ptr, ptr @d.c.tomllib$_parser$Flags.FROZEN.box
  %t251 = call ptr @pys_dyn_int_box(i64 %t249, ptr %t250)
  store ptr %t251, ptr @d.c.tomllib$_parser$Flags.FROZEN.box
  call void @m.tomllib$_parser$Flags.set(ptr %t239, ptr %t245, i64 %t249, i1 true, ptr %t251)
  br label %L234
L233:
  br label %L234
L234:
  %t252 = load ptr, ptr %value.30
  %t253 = load ptr, ptr %nest.180
  %t254 = load ptr, ptr %key_stem.37
  %t255 = call ptr @pys_dyn_ref(ptr @pys_dyntype_str, ptr %t254)
  %t256 = ptrtoint ptr %t255 to i64
  %t257 = ptrtoint ptr %t252 to i64
  call void @pys_dict_set(ptr %t253, i64 %t256, i64 %t257)
  %t258 = load i64, ptr %pos.3
  %t259 = load ptr, ptr %pos.box.3
  %t260 = load i64, ptr %pos.boxgen.3
  %t261 = load ptr, ptr %pos.box.3
  %t262 = icmp ne ptr %t259, null
  %t263 = select i1 %t262, ptr %t259, ptr %t261
  store ptr %t263, ptr %idret
  store i64 %t264, ptr @pys_recursion_state, !tbaa !6
  ret i64 %t258
L9:
  call void @pys_raise(ptr @s.99, ptr @s.571)
  unreachable
L61:
  call void @pys_raise(ptr @s.162, ptr @s.572)
  unreachable
L74:
  call void @pys_raise(ptr @s.101, ptr @s.222)
  unreachable
L79:
  call void @pys_raise(ptr @s.101, ptr @s.561)
  unreachable
L84:
  call void @pys_raise(ptr @s.99, ptr @s.539)
  unreachable
L95:
  call void @pys_raise(ptr @s.99, ptr @s.548)
  unreachable
L109:
  call void @pys_raise(ptr @s.178, ptr @s.517)
  unreachable
L118:
  call void @pys_raise(ptr @s.101, ptr @s.573)
  unreachable
L176:
  %t266 = call ptr @pys_exc_new(ptr @s.101, ptr @s.563, ptr null)
  store ptr %t266, ptr %h.165
  br label %L181
L241:
  call void @pys_raise(ptr @s.101, ptr @s.562)
  unreachable
}
