# Tomllib proof-denominator support

This read-only source/retained-IR review supports the five Tomllib fixtures with three fewer removed-null-check obligations: cases 1736, 1737, 1738, 1739 and 1741. Exact attribution remains provisional until the before-pass nullcheck records are compared.

## Retained receiver checks

One additional null comparison survives in each of three functions, in every one of those fixtures. They check `Output.flags` (class field index 1):

| Function | Receiver in case 1736 | Following method | Null target |
|---|---|---|---|
| key_value_rule | %t116 | Flags.add_pending | L118 |
| create_dict_rule | %t85 | second Flags.is_ | L68 |
| create_list_rule | %t105 | Flags.unset_all | L107 |

Every null edge raises `AttributeError` with the method-specific NoneType message and terminates at `unreachable`. These are class-receiver guards; tuple-header allocation and offset changes are separate. The earlier IR-review wording calling them tuple-pointer/TypeError checks was inaccurate; its owner independently confirmed the correction. Cases 2557 and 2558 share the same corrected attribution.

The compiler source explains the conservative change: `Flags.is_` calls `vtuple.slice`, whose effect changes from `R A` to `R A rO wO`. Function summaries propagate that write effect. `gen_reaching` stops reusing a heap-load value across `RAWW` (including `wO`), so `gen_nullcheck` cannot remove the following receiver check using the earlier load's fact. No null-check optimization code changed. This mechanism and the three surviving guards support the denominator explanation, but do not substitute for the old before-pass removal records.

## Mappingproxy GC inventory

The retained LLVM confirms an old, unreferenced `mappingproxy.__ror__` helper disappears in all six Tomllib fixtures, including typed_callback (1740), and in the mappingproxy consumers 1743, 1744 and 2674. Each removed symbol occurs exactly once in the old IR (its definition) and zero times in the new IR. Bodies use dictionary copy/update and are preserved alongside this report. The exact lost GC-obligation counts require typed GC attribution; no count is inferred from LLVM allocation totals.

## Evidence and limits

The JSON contains exact old/new IR hashes, per-function null-comparison counts, same-side canonical body hashes across the fixtures, original/current source hashes, removed-helper bodies, error blocks/global strings and a snapshot of the current reported null/GC rows. Complete old/new reference functions are retained. Source files and the running census were not changed. No compilation or checker execution was performed; no rejected proof obligation is waived.
