tests/errors/containers/dict_update_int.py:3: error: 'int' object is not iterable
