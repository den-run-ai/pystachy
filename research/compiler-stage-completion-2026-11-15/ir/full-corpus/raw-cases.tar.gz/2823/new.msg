tests/errors/classes/obj_len_missing.py:6: error: object of type 'C' has no len()
