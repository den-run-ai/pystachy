tests/errors/classes/class_slots_private.py:3: error: __slots__ entry '__x' is not supported
