tests/errors/classes/property_setter_undefined.py:4: error: @value.setter needs property value, a @property def value before it in the class body
