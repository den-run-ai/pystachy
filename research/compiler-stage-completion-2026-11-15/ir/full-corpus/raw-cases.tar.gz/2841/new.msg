tests/errors/classes/object_sentinel_alias.py:6: error: unsupported call object()
