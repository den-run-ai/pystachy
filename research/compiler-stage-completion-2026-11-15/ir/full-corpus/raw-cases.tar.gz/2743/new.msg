tests/errors/classes/dataclass_mutable_field_default.py:7: error: mutable default <class 'dict'> for field counts is not allowed: use default_factory
