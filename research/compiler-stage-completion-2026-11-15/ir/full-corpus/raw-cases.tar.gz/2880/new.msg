tests/errors/containers/comprehension_target_unbound.py:7: error: 'y' is read before the comprehension's for clause that binds it, where CPython raises UnboundLocalError (not supported)
