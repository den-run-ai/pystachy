tests/errors/classes/class_call_init.py:8: error: C.__init__() is a method of its objects: calling it through the class is not supported; call it on an object, o.__init__(...)
