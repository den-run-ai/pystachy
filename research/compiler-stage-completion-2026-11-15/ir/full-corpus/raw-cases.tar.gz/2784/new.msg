tests/errors/classes/inheritance_secondary_override.py:16: error: secondary base method 'read' needs a matching instance method signature
