tests/errors/classes/class_call_missing.py:8: error: type object 'C' has no attribute 'make'
