tests/errors/classes/class_slots_outside.py:7: error: field 'y' is outside __slots__ of 'Point'
