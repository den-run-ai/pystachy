tests/errors/classes/class_consts_lambda.py:5: error: class attribute 'ADD' of 'Op' used in a class-body default is not supported
