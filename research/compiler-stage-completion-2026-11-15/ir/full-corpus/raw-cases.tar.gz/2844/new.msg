tests/errors/classes/object_sentinel_dict_get.py:5: error: expected int, got object
