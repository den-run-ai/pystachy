tests/errors/classes/private_name_external.py:9: error: 'C' object has no attribute '__value'
