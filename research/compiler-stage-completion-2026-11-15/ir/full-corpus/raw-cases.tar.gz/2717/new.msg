tests/errors/classes/dataclass_dataclass_default.py:12: error: mutable default <class '__main__.Inner'> for field inner is not allowed: use default_factory
