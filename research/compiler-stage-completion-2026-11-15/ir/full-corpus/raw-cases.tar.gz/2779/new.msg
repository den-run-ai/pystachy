tests/errors/classes/inheritance_redefined.py:4: error: class emods.inheritance_redefined.Base is not supported: redefinition of class 'emods.inheritance_redefined.Base' is not supported
