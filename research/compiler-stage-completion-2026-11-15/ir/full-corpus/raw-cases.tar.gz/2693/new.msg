tests/errors/classes/class_slots_inherited_method.py:10: error: slot 'value' shadows an inherited method or property: not supported
