tests/errors/classes/class_template_rebind.py:9: error: expected Box[int], got Box[str]
