tests/errors/containers/dict_update_gen.py:4: error: dict.update() of a dict[str,int] takes a dict of its type, a list[tuple[str,int]] or keyword arguments, not Generator[tuple[str,int]]
