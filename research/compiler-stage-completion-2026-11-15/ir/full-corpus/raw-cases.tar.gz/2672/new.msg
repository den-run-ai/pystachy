tests/errors/classes/class_local_base_method.py:10: error: local variable 'E' is read before its first assignment; declare it first (E: T)
