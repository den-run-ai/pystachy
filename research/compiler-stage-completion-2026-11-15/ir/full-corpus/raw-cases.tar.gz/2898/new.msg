tests/errors/containers/dict_union_types.py:5: error: unsupported operand types for |: dict[str,int] and dict[str,float] (a dict holds keys and values of one type each)
