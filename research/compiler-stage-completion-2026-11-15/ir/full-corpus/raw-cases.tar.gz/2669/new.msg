tests/errors/classes/class_consts_value.py:4: error: class attribute 'xs' of 'C' used in a class-body default is not supported
