tests/errors/classes/dataclass_kw_only_option_twice.py:10: error: '__' is KW_ONLY, but KW_ONLY has already been specified
