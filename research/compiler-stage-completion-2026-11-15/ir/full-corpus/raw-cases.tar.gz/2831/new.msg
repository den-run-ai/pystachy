tests/errors/classes/obj_not_subscriptable.py:7: error: 'Plain' object is not subscriptable
