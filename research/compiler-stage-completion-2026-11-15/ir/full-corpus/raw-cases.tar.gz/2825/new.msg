tests/errors/classes/obj_neg_missing.py:6: error: bad operand type for unary -: 'C'
