tests/errors/classes/inheritance_secondary_methods.py:12: error: both bases declare method 'read'
