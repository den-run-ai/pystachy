tests/errors/classes/obj_slice_del_missing.py:7: error: 'C' object does not support item deletion
