tests/errors/classes/object_sentinel_import_alias.py:7: error: unsupported call object()
