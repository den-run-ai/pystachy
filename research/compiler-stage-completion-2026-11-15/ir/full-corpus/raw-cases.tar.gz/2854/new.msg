tests/errors/classes/property_deleter_parameters.py:8: error: property deleter value must take only self
