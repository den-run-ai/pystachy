tests/errors/classes/dataclass_order_eq.py:6: error: eq must be true if order is true
