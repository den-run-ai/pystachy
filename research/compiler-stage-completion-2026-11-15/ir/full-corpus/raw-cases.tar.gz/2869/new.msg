tests/errors/classes/slash_first.py:2: error: at least one argument must precede /
