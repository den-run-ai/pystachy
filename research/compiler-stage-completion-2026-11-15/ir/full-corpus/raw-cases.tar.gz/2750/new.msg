tests/errors/classes/dataclass_replace_unknown.py:10: error: P.__init__() got an unexpected keyword argument 'y'
