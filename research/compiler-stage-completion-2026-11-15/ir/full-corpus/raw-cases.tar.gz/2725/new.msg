tests/errors/classes/dataclass_field_order.py:8: error: non-default argument 'b' follows default argument 'a'
