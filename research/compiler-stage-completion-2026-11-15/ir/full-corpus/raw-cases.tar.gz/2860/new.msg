tests/errors/classes/property_setter_base.py:16: error: @Other.value.setter is not supported here: Other must be the base class whose property value this class inherits
