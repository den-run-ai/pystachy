tests/errors/classes/class_body_try.py:3: error: a class body may only contain fields, methods, a docstring, pass and ..., not a try statement
