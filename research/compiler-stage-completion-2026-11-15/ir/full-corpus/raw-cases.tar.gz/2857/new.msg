tests/errors/classes/property_override_getter.py:8: error: overriding 'value' as a different kind of attribute (property or method) is not supported
