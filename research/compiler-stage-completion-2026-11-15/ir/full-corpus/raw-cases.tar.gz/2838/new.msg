tests/errors/classes/obj_unpack.py:7: error: cannot unpack non-iterable Plain object
