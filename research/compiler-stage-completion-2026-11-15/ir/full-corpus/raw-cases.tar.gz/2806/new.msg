tests/errors/classes/obj_add_missing.py:6: error: unsupported operand type(s) for +: 'C' and 'int'
