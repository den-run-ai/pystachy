tests/errors/classes/obj_slice_no_getitem.py:6: error: 'C' object is not subscriptable
