tests/errors/classes/inheritance_namedtuple.py:9: error: inheritance from a NamedTuple is not supported
