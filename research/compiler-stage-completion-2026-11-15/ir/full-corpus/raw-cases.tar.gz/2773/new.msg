tests/errors/classes/inheritance_narrow_global.py:22: error: 'Base' object has no attribute 'extra'
