tests/errors/containers/dict_fromkeys_untyped.py:2: error: dict.fromkeys(keys) needs the type of the dict it makes, whose values are None: annotate it (d: dict[K, V | None] = ...)
