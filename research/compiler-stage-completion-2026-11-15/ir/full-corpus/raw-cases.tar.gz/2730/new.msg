tests/errors/classes/dataclass_import_retyped.py:5: error: class emods.dataclass_retyped.Retyped is not supported: field 'x' of 'Point' declared again in 'Retyped' with another type (not supported)
