tests/errors/classes/inheritance_secondary_state.py:11: error: secondary base methods may not use super() or read or write the instance
