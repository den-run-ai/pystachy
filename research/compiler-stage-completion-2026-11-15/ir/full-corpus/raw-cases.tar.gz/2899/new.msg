tests/errors/containers/dict_unpack_call_unpack.py:3: error: ** of a dict[str,str] is not supported: of a function's **kwargs, or a dict display with str keys, it is
