tests/errors/classes/class_attr_new.py:6: error: type object 'C' has no attribute 'x': adding a class attribute by assigning it is not supported (declare it in the class body, x: T = ...)
