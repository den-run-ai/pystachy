tests/errors/classes/dataclass_frozen_error_raise.py:5: error: dataclasses.FrozenInstanceError is only supported in an except clause, which catches what assigning a field of a frozen dataclass raises
