tests/errors/classes/inheritance_narrow_negative.py:14: error: 'Base' object has no attribute 'extra'
