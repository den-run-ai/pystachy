tests/errors/containers/comprehension_clause_unbound.py:6: error: 'b' is read before the comprehension's for clause that binds it, where CPython raises UnboundLocalError (not supported)
