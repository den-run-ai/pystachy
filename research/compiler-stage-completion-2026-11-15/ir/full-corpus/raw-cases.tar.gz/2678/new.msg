tests/errors/classes/class_singleton_attr.py:6: error: 'Sentinel' object has no attribute 'missing'
