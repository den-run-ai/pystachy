tests/errors/classes/class_slots_annotation_value.py:3: error: expected int, got str
