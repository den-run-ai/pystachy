tests/errors/classes/bound_method_print.py:3: error: printing a function, or comparing containers of functions, is not supported: <built-in method append of list object>
