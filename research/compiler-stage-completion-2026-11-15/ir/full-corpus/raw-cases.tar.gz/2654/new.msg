tests/errors/classes/bound_method_is.py:10: error: 'is' between bound methods is not supported: CPython makes a new method object each time one is read (compare them with ==)
