tests/errors/classes/dataclass_inheritance_redeclared.py:13: error: non-default argument 'y' follows default argument 'x'
