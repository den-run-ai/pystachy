tests/errors/classes/classmethod_assigns_cls.py:4: error: class method make() assigns its parameter 'cls', which names the class: not supported
