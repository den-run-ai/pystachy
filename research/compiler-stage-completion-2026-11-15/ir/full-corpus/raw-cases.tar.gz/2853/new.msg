tests/errors/classes/property_class_shadowed.py:5: error: unsupported decorator @property: the name is shadowed in the class body
