tests/errors/classes/property_base_field.py:7: error: field 'value' of 'C' conflicts with property 'value'
