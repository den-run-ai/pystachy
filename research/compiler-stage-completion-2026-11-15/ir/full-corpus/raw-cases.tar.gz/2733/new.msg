tests/errors/classes/dataclass_inheritance_order.py:12: error: non-default argument 'y' follows default argument 'x'
