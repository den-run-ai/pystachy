tests/errors/classes/obj_abs_missing.py:6: error: bad operand type for abs(): 'C'
