tests/errors/containers/dict_fromkeys_args.py:2: error: fromkeys expected at least 1 argument, got 0
