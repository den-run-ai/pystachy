tests/errors/classes/class_doc_read.py:6: error: reading '__doc__' in a class body is not supported (a class's docstring cannot be read)
