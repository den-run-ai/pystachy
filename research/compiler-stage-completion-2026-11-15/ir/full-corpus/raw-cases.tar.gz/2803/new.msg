tests/errors/classes/method_without_self.py:3: error: method '__init__' of class 'A' must take self as its first parameter
