tests/errors/classes/final_class_value_uninferred.py:6: error: cannot infer the type of class attribute 'KEYS'; annotate it (KEYS: Final[T] = ...)
