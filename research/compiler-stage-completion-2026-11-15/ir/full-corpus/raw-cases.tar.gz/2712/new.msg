tests/errors/classes/classvar_dataclass.py:9: error: typing.ClassVar (a class attribute) is not supported
