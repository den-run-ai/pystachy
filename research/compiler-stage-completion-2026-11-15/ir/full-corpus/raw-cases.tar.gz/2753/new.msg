tests/errors/classes/dataclass_unhashable_default.py:15: error: mutable default <class '__main__.P'> for field p is not allowed: use default_factory
