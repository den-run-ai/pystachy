tests/errors/classes/class_slots_inherited_property.py:11: error: slot 'value' shadows an inherited method or property: not supported
