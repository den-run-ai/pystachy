tests/errors/classes/class_singleton_later.py:7: error: 'Mode' is bound both as a variable and as a function, class or import (not supported)
