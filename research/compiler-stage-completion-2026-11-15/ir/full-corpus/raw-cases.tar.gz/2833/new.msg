tests/errors/classes/obj_slice.py:7: error: slicing an object is not supported: C.__getitem__ would take a slice object, which Pystachy does not have
