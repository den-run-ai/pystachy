tests/errors/classes/special_return.py:6: error: __eq__ must return bool
