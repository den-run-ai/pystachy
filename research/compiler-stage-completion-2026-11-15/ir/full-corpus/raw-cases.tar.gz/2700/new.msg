tests/errors/classes/class_slots_redeclared.py:4: error: multiple __slots__ declarations are not supported; use one literal declaration
