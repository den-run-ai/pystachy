tests/errors/classes/obj_iter_getitem.py:7: error: iterating over Seq by its __getitem__ is not supported (CPython calls __getitem__(0), __getitem__(1), ... until IndexError): define __iter__
