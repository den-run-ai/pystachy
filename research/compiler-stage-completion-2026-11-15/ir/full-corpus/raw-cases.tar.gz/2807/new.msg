tests/errors/classes/obj_call_arity.py:11: error: Scale.__call__() missing 1 required positional argument: 'x'
