tests/errors/classes/inheritance_secondary_slots.py:14: error: __slots__ in a hierarchy with a secondary base is not supported
