tests/errors/classes/dataclass_inheritance_unfrozen.py:11: error: cannot inherit frozen dataclass from a non-frozen one
