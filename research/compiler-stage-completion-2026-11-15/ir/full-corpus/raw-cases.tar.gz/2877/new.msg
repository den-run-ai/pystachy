tests/errors/containers/comprehension_empty_tuple.py:6: error: cannot infer the element type of this comprehension
