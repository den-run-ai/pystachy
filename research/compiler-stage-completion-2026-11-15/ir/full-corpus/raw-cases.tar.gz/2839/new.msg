tests/errors/classes/object_rebound.py:5: error: class inheritance is not supported (the module may have rebound the name 'object' before this statement)
