tests/errors/classes/dataclass_field_keyword.py:7: error: field() got an unexpected keyword argument 'doc'
