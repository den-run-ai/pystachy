tests/errors/classes/object_sentinel_args.py:3: error: object() takes no arguments
