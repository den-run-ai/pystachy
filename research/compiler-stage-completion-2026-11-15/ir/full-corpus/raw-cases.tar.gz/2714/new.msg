tests/errors/classes/classvar_namedtuple.py:8: error: typing.ClassVar (a class attribute) is not supported
