tests/errors/classes/class_local_store.py:9: error: local variable 'A' is read before its first assignment; declare it first (A: T)
