tests/errors/classes/property_setter_parameters.py:8: error: property setter value must take only self and the value, by position
