tests/errors/classes/dataclass_field_unannotated.py:7: error: 'x' is a field but has no type annotation
