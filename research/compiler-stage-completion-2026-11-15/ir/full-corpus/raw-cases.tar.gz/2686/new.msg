tests/errors/classes/class_slots_augmented.py:7: error: field 'count' is outside __slots__ of 'Point'
