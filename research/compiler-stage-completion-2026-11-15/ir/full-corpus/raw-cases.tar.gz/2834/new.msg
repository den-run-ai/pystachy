tests/errors/classes/obj_slice_assign.py:7: error: slicing an object is not supported: C.__setitem__ would take a slice object, which Pystachy does not have
