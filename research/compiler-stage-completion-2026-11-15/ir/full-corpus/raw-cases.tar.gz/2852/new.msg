tests/errors/classes/property_class_read.py:7: error: C.value is a property: read it on an instance
