tests/errors/classes/object_sentinel_eq_class.py:9: error: cannot compare object == C
