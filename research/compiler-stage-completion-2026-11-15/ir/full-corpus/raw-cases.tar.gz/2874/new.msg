tests/errors/classes/union_attr_store_new.py:20: error: type A | B has no attribute 'y'
