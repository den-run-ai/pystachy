tests/errors/classes/class_singleton_init.py:7: error: 'Registry' is bound both as a variable and as a function, class or import (not supported)
