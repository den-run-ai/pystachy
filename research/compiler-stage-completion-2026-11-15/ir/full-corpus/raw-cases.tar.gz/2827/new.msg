tests/errors/classes/obj_no_setitem.py:8: error: 'Ro' object does not support item assignment
