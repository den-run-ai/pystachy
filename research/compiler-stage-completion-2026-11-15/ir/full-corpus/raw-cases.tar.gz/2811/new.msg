tests/errors/classes/obj_float_missing.py:6: error: float() argument must be a string or a real number, not 'C'
