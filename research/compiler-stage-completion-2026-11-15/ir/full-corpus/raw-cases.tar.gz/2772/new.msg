tests/errors/classes/inheritance_narrow_field.py:23: error: 'Base' object has no attribute 'extra'
