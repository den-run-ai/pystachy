tests/errors/classes/static_method_value.py:9: error: a static method as a value (Tools.make) is not supported: call it
