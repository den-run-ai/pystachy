tests/errors/classes/static_len_big_int.py:6: error: integer literal does not fit in 64 bits
