tests/errors/classes/class_local_call.py:13: error: local variable 'A' is read before its first assignment; declare it first (A: T)
