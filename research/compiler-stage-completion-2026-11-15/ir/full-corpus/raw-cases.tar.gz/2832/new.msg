tests/errors/classes/obj_reversed.py:13: error: 'Seq' object is not reversible
