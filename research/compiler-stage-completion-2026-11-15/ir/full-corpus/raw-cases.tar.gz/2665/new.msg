tests/errors/classes/class_const_untyped.py:6: error: cannot infer the type of class attribute 'y'; annotate it (y: T = ...)
