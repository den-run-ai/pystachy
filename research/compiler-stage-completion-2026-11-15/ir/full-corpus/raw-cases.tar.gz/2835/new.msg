tests/errors/classes/obj_slice_assign_missing.py:6: error: 'C' object does not support item assignment
