tests/errors/containers/comprehension_condition_unbound.py:4: error: 'y' is read before the comprehension's for clause that binds it, where CPython raises UnboundLocalError (not supported)
