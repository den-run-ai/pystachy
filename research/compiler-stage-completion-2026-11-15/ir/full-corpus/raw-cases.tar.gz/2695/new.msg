tests/errors/classes/class_slots_instance_metadata.py:10: error: field '__slots__' is outside __slots__ of 'Point'
