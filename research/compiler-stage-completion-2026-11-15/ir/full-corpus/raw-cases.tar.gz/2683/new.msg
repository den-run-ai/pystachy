tests/errors/classes/class_slots_ancestor_method.py:14: error: slot 'value' shadows an inherited method or property: not supported
