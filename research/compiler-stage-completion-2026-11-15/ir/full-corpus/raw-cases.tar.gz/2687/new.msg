tests/errors/classes/class_slots_conflict.py:3: error: 'x' in __slots__ conflicts with class variable or method
