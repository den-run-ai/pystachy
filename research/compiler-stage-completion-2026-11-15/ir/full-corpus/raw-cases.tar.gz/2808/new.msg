tests/errors/classes/obj_call_class_attr.py:3: error: 'int' object is not callable
