tests/errors/classes/inheritance_generic.py:7: error: inheritance with generic class templates is not supported: annotate __init__ parameters with concrete types (not Any or object)
