tests/errors/classes/inheritance_secondary_undeclared.py:12: error: secondary base methods may not use super() or read or write the instance
