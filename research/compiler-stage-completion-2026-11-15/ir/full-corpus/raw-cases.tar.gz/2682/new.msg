tests/errors/classes/class_slots_ancestor_default.py:11: error: slot 'value' shadows an inherited class variable: not supported
