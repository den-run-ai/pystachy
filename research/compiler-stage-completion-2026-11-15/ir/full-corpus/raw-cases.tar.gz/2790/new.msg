tests/errors/classes/inheritance_shadow_method.py:7: error: field 'value' of 'Child' conflicts with method 'Child.value': method and field shadowing in an inheritance hierarchy is not supported
