tests/errors/classes/class_local_raise.py:8: error: local variable 'E' is read before its first assignment; declare it first (E: T)
