tests/errors/classes/inheritance_secondary_argument.py:15: error: secondary base methods may not use super() or read or write the instance
