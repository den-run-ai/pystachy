tests/errors/classes/inheritance_template_param_field.py:11: error: cannot infer the type of field 'pending'; annotate it (self.pending: T = ...)
