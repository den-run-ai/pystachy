tests/errors/classes/property_parameters.py:4: error: property value must take only self
