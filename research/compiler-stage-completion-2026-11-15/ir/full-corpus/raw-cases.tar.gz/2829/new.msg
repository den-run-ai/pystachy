tests/errors/classes/obj_not_callable_local.py:4: error: 'list' object is not callable
