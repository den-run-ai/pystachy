tests/errors/classes/dataclass_replace_init_false.py:11: error: field total is declared with init=False, it cannot be specified with replace()
