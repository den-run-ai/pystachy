tests/errors/classes/dataclass_kw_only_twice.py:10: error: 'b' is KW_ONLY, but KW_ONLY has already been specified
