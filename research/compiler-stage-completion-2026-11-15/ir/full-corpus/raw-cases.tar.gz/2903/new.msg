tests/errors/containers/dict_update_kwargs.py:3: error: dict.update() with keyword arguments adds str keys, which a dict[int,int] cannot hold
