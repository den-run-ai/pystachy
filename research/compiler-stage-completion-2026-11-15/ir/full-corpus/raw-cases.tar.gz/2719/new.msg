tests/errors/classes/dataclass_factory_call.py:11: error: default_factory= is only supported as a function, a class or a lambda without parameters
