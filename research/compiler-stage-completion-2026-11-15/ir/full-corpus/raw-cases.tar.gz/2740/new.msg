tests/errors/classes/dataclass_kw_only_positional.py:10: error: D.__init__() takes 1 positional argument but 2 were given
