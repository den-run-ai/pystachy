tests/errors/classes/class_slots_annotated.py:7: error: field 'x' is outside __slots__ of 'Empty'
