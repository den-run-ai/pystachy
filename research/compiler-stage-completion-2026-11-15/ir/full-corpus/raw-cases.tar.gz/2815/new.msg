tests/errors/classes/obj_iter_called.py:13: error: calling Seq.__iter__() is not supported (its iterator is the list it steps through here): iterate over the object
