tests/errors/classes/obj_call_field.py:7: error: 'int' object is not callable
