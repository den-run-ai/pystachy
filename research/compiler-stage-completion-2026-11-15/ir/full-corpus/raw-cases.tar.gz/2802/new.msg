tests/emods/tmeth.py:17: error: 'int' has no method 'no_such_thing' (compiling emods.tmeth.Acc.broken(int) for the call at tests/errors/classes/method_template_imported.py:4)
