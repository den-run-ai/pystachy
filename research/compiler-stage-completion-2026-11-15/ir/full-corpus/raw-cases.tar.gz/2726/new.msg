tests/errors/classes/dataclass_field_outside.py:6: error: dataclasses.field() is only supported in the body of a @dataclass class
