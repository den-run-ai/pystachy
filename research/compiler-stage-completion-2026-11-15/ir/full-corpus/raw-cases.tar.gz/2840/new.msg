tests/errors/classes/object_reversed_list.py:11: error: Seq.__reversed__ returning list[int] is not supported: return iter(xs) of a list xs of the items (-> Iterator[T])
