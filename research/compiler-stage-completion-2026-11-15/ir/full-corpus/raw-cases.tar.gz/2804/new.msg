tests/errors/classes/new_method.py:9: error: the special method __new__ is not supported (CPython calls it to make each object of the class)
