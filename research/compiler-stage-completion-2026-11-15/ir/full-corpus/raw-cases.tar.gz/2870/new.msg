tests/errors/classes/slash_twice.py:2: error: / may appear only once
