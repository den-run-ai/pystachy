tests/errors/classes/obj_iter_dict.py:10: error: iter() of dict[str,int] in __iter__ is not supported: return iter(xs) of a list xs of the items
