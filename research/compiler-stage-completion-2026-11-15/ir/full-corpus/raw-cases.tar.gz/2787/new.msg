tests/errors/classes/inheritance_secondary_super.py:17: error: a primary hierarchy with another secondary base or super() is not supported
