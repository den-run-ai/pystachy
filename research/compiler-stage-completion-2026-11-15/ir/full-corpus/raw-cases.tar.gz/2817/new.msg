tests/errors/classes/obj_iter_dict_keys.py:10: error: iter() of a dict's keys() in __iter__ is not supported: its iterator raises if the dict changes size; return iter(list(...)) of a copy
