tests/errors/classes/obj_in_not_iterable.py:7: error: argument of type 'Plain' is not iterable
