tests/errors/classes/method_template_eq.py:10: error: __eq__ must return bool, and V.__eq__() returns int (compiling V.__eq__(V) for the call at tests/errors/classes/method_template_eq.py:10)
