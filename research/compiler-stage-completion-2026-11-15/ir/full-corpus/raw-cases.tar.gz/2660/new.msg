tests/errors/classes/class_attr_missing.py:5: error: type object 'C' has no attribute 'nope'
