tests/errors/classes/dataclass_mutable_default.py:7: error: mutable default <class 'list'> for field xs is not allowed: use default_factory
