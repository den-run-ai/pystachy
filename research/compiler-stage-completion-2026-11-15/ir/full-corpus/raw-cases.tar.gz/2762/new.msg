tests/errors/classes/generic_base_arity.py:12: error: Visitor[...] takes 1 type (T), not 2
