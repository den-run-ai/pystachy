tests/errors/classes/dataclass_factory_and_default.py:7: error: cannot specify both default and default_factory
