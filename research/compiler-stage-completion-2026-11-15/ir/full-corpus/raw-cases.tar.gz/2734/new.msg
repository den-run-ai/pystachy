tests/errors/classes/dataclass_inheritance_plain_base.py:11: error: a @dataclass class whose base is not a dataclass is not supported
