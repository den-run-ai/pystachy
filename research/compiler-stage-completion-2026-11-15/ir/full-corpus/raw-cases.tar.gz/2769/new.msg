tests/errors/classes/inheritance_dataclass.py:10: error: inheritance from a dataclass is only supported by a @dataclass class
