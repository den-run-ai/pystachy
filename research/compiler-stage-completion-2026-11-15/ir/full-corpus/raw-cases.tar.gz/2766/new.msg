tests/errors/classes/inheritance.py:10: error: multiple inheritance requires an ordinary primary base and an independent method-only secondary base
