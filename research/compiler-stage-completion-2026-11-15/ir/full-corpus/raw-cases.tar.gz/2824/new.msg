tests/errors/classes/obj_len_missing_template.py:7: error: object of type 'C' has no len() (compiling n(C) for the call at tests/errors/classes/obj_len_missing_template.py:10)
