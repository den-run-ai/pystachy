tests/errors/classes/property_shadowed.py:7: error: unsupported decorator @property
