tests/errors/classes/class_as_value.py:7: error: class 'C' cannot be used as a value (classes are not values: call it, or read an attribute, C.x)
