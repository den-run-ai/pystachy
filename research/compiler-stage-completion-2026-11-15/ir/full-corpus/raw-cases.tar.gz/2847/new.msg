tests/errors/classes/object_sentinel_qualified.py:7: error: unsupported call object()
