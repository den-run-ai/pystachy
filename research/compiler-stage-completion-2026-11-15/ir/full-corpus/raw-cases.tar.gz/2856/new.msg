tests/errors/classes/property_getter_decorator.py:8: error: unsupported decorator @value.getter: define the property's getter once, with @property
