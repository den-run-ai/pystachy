tests/errors/classes/property_unannotated.py:8: error: property value needs a return annotation
