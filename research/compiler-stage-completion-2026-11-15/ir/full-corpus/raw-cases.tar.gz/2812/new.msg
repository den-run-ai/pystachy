tests/errors/classes/obj_getitem_arity.py:7: error: __getitem__ must take 1 argument besides self
