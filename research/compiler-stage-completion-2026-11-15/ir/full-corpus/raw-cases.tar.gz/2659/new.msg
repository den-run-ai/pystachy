tests/errors/classes/class_attr_instance_field.py:7: error: type object 'C' has no attribute 'v' (its objects have the field 'v')
