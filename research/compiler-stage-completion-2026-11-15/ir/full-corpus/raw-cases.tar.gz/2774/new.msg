tests/errors/classes/inheritance_narrow_join.py:14: error: 'Base' object has no attribute 'extra'
