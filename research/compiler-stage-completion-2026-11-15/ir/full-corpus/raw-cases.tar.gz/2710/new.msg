tests/errors/classes/classmethod_no_cls.py:4: error: method 'make' of class 'C' must take cls as its first parameter
