tests/errors/classes/dataclass_inheritance_type.py:12: error: field 'x' of 'Base' declared again in 'Derived' with another type (not supported)
