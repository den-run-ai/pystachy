tests/errors/classes/dataclass_unannotated.py:8: error: a class attribute without an annotation (y = ...), which is no field of a dataclass, is not supported: annotate it
