tests/errors/classes/property_function.py:12: error: property() called as a function is not supported: decorate the getter with @property and the setter with @x.setter
