tests/errors/classes/inheritance_narrow_nonlocal.py:18: error: 'Base' object has no attribute 'extra'
