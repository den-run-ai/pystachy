tests/errors/classes/method_kwargs.py:2: error: keyword arguments to str.split() are not supported; pass them by position
