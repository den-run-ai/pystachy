tests/errors/classes/class_slots_shadow_inherited.py:7: error: shadowing inherited slot 'x' with a class variable or method is not supported
