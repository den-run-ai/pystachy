tests/errors/classes/classmethod_module_function.py:3: error: unsupported decorator @classmethod
