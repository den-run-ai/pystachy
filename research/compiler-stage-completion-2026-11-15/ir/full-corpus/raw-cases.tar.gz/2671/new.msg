tests/errors/classes/class_local_attr.py:8: error: local variable 'A' is read before its first assignment; declare it first (A: T)
