tests/errors/containers/dict_key.py:2: error: dict keys must be int or str, objects, or tuples of int, bool, str, str | None and objects, not float
