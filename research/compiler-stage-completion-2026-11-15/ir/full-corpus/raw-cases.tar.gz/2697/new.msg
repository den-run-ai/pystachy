tests/errors/classes/class_slots_metadata_rebind.py:11: error: field 'extra' is outside __slots__ of 'Point'
