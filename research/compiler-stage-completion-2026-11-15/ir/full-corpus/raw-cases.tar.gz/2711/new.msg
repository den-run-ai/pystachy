tests/errors/classes/classmethod_special.py:4: error: @classmethod on the special method __len__ is not supported
