tests/errors/classes/dataclass_replace_class.py:10: error: replace() should be called on dataclass instances, not Q
