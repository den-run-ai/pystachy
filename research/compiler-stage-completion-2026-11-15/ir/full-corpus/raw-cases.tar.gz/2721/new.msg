tests/errors/classes/dataclass_factory_order.py:9: error: non-default argument 'b' follows default argument 'a'
