tests/errors/classes/dataclass_arguments.py:6: error: @dataclass(slots=...) is not supported: its supported arguments are init=, repr=, eq=, order=, unsafe_hash=, frozen=, match_args=, kw_only=
