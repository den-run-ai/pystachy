tests/errors/classes/obj_iter_dict_values.py:12: error: iter() of a dict's values() in __iter__ is not supported: its iterator raises if the dict changes size; return iter(list(...)) of a copy
