tests/errors/containers/dict_fromkeys_int.py:2: error: 'int' object is not iterable
