tests/errors/classes/inheritance_override_kind.py:13: error: overriding 'make' of 'Base' with another kind of method (instance, static or class method) in 'Derived' is not supported
