tests/errors/classes/class_method_value.py:7: error: method 'C.m' cannot be used as a value (call it)
