tests/errors/classes/object_sentinel_attr.py:4: error: field 'note' is outside __slots__ of 'object'
