tests/errors/classes/dataclass_order_overwrite.py:9: error: Cannot overwrite attribute __lt__ in class P Consider using functools.total_ordering
