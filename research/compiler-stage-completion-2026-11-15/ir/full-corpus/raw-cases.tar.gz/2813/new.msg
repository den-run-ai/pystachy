tests/errors/classes/obj_iadd_missing.py:7: error: unsupported operand type(s) for +=: 'C' and 'int'
