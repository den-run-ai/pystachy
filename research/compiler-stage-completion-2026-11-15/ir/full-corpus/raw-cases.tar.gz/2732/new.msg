tests/errors/classes/dataclass_inheritance_frozen.py:11: error: cannot inherit non-frozen dataclass from a frozen one
