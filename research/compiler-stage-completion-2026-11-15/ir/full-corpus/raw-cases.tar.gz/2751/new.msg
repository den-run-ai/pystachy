tests/errors/classes/dataclass_set_default.py:7: error: mutable default <class 'set'> for field seen is not allowed: use default_factory
