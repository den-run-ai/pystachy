tests/errors/classes/inheritance_narrow_reassigned.py:14: error: 'Base' object has no attribute 'extra'
