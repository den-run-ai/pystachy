tests/errors/classes/class_consts_rebound.py:5: error: class attribute 'x' of 'C' used in a class-body default is not supported
