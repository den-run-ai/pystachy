tests/errors/classes/final_class_value_namedtuple.py:7: error: a field annotated Final without a type needs a constant value (int, float, str or bool): annotate it Final[T]
