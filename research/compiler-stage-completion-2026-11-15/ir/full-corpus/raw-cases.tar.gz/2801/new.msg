tests/errors/classes/method_template_eq_star.py:6: error: __eq__ must take 1 argument besides self
