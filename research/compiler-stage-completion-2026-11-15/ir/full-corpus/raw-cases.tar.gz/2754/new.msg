tests/errors/classes/dataclass_unsafe_hash_overwrite.py:9: error: Cannot overwrite attribute __hash__ in class P
