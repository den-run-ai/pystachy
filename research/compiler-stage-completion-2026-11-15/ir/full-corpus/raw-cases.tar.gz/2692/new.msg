tests/errors/classes/class_slots_inherited_default.py:8: error: slot 'value' shadows an inherited class variable: not supported
