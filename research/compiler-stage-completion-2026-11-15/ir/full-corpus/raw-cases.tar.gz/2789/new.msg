tests/errors/classes/inheritance_shadow.py:7: error: field 'value' of 'Child' conflicts with method 'Base.value': method and field shadowing in an inheritance hierarchy is not supported
