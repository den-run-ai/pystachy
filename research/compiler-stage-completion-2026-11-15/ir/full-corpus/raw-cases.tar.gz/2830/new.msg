tests/errors/classes/obj_not_iterable.py:7: error: 'Plain' object is not iterable
