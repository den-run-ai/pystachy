tests/errors/containers/dict_pairs_items.py:3: error: dict() of a list[int] is not supported: it takes a dict, or (key, value) tuples
