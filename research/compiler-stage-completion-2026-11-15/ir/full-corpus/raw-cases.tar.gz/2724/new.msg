tests/errors/classes/dataclass_field_option.py:9: error: field(repr=...) needs True or False
