tests/errors/classes/property_setter_method.py:7: error: @value.deleter needs property value, a @property def value before it in the class body
