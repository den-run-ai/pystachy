tests/errors/classes/class_slots_template.py:7: error: field 'extra' is outside __slots__ of 'Box' (compiling Box.__init__(int) for the call at tests/errors/classes/class_slots_template.py:10)
