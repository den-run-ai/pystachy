tests/errors/classes/class_slots_heterogeneous_read.py:11: error: reading __slots__ through Base is not supported when subclasses use different declaration types; read it through the concrete class
