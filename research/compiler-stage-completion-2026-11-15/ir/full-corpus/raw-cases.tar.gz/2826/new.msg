tests/errors/classes/obj_no_delitem.py:7: error: 'Plain' object doesn't support item deletion
