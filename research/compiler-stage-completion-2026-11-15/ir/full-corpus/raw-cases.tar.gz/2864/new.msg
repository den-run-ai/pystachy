tests/errors/classes/property_setter_redefinition.py:12: error: redefinition of method 'C.value' is not supported
