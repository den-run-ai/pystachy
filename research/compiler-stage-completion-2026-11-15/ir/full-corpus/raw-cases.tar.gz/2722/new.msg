tests/errors/classes/dataclass_field.py:7: error: field(metadata=...) is not supported
