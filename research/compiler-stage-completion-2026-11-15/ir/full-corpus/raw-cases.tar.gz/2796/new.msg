tests/errors/classes/init_subclass_classattr.py:8: error: a base that defines __init_subclass__ is not supported (CPython calls Failed.__init_subclass__() when it creates class Retry)
