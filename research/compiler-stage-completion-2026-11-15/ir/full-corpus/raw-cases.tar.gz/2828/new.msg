tests/errors/classes/obj_not_callable.py:7: error: 'C' object is not callable
