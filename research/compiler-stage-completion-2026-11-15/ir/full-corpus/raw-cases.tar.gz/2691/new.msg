tests/errors/classes/class_slots_inherited.py:14: error: field 'y' is outside __slots__ of 'Child' (compiling Child.__init__() for the call at tests/errors/classes/class_slots_inherited.py:17)
