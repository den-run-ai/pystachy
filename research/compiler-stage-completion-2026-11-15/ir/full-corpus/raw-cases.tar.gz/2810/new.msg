tests/errors/classes/obj_call_result.py:7: error: 'P' object is not callable
