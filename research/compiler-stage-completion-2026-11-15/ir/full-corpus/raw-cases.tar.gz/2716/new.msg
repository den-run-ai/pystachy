tests/errors/classes/dataclass_class_store.py:10: error: assigning to a class attribute of dataclass D (D.x = ...) is not supported
