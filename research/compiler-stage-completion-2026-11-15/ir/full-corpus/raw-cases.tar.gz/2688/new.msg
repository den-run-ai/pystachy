tests/errors/classes/class_slots_dynamic.py:6: error: __slots__ needs a literal string, tuple or list of strings
