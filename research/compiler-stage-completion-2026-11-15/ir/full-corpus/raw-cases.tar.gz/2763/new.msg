tests/errors/classes/generic_base_init.py:14: error: a subclass of Box[...] is not supported: the __init__ of Box binds its type variables, as its calls' arguments do
