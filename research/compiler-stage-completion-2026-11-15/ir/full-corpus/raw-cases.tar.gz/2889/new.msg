tests/errors/containers/dict_get_no_args.py:4: error: get expected at least 1 argument, got 0
