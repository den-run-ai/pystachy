tests/errors/classes/classmethod_cls_value.py:5: error: class 'C' cannot be used as a value (classes are not values: call it, or read an attribute, C.x)
