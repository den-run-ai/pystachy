tests/errors/classes/dataclass_not_imported.py:3: error: unsupported decorator @dataclass (import dataclass from dataclasses)
