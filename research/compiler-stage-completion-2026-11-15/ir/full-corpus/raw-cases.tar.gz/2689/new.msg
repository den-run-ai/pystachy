tests/errors/classes/class_slots_exception_override.py:15: error: reading __slots__ through exception base Base is not supported when a subclass overrides it; read it through the concrete class
