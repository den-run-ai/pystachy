tests/errors/classes/property_subclass_field.py:8: error: field 'value' of 'D' conflicts with property 'value'
