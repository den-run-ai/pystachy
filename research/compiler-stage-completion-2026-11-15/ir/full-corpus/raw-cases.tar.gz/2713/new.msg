tests/errors/classes/classvar_declared.py:6: error: typing.ClassVar (a class attribute) is not supported
