tests/final_attr_support/fattrs_typeddict.py:5: error: a field annotated Final without a type needs a constant value (int, float, str or bool): annotate it Final[T]
