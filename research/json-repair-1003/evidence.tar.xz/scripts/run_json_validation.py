import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/workspace/scratch/89d2b70f0d89')
candidate = root / 'pystachy'
baseline = root / 'pystachy-base'
compiler = baseline / 'pystachy'
python = root / 'toolchains/dev/bin/python'
env0 = {k: v for k, v in os.environ.items() if not k.startswith('PYSTACHY_') and k != 'PYTHONPATH'}
records = []


def run(name, command, home, *, stress=False, check=True):
    env = dict(env0, PYSTACHY_HOME=str(home), PYSTACHY_PATH=str(home / 'ports'))
    if stress:
        env['PYSTACHY_GC_STRESS_PROGRAM'] = '1'
        if str(command[0]) != str(compiler):
            env['PYSTACHY_GC_STRESS'] = '1'
    start = time.perf_counter()
    with (root / (name + '.out')).open('w') as out, (root / (name + '.err')).open('w') as err:
        result = subprocess.run([str(x) for x in command], cwd=candidate, env=env, stdout=out, stderr=err, timeout=240)
    row = {'name': name, 'command': [str(x) for x in command], 'home': str(home),
           'stress': stress, 'exit': result.returncode, 'seconds': time.perf_counter() - start,
           'stdout_sha256': hashlib.sha256((root / (name + '.out')).read_bytes()).hexdigest()}
    records.append(row)
    (root / 'json-validation.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, round(row['seconds'], 3), flush=True)
    if check and result.returncode:
        raise RuntimeError((root / (name + '.err')).read_text())
    return root / (name + '.out')


replay = candidate / 'tests/upstream/json_repair/replay.py'
inputs = root / 'json-repair-inputs.jsonl'
binary = root / 'candidate-replay'
run('replay-build', [compiler, 'build', replay, '-o', binary], candidate)
for mode in ('jit', 'aot'):
    for stress in (False, True):
        name = 'replay-' + mode + ('-gc' if stress else '')
        command = [compiler, 'run', replay, inputs] if mode == 'jit' else [binary, inputs]
        output = run(name, command, candidate, stress=stress)
        run(name + '-check', [python, candidate / 'tools/json_repair_parity.py', output,
                             '--report', root / (name + '-report.json')], candidate)
        print((root / (name + '-check.out')).read_text().strip(), flush=True)

probe = root / 'json_negative_controls.py'
for label, home in [('base', baseline), ('candidate', candidate)]:
    output = run('negative-' + label + '-jit', [compiler, 'run', probe], home)
    binary = root / ('negative-' + label)
    run('negative-' + label + '-build', [compiler, 'build', probe, '-o', binary], home)
    run('negative-' + label + '-aot', [binary], home)
    assert output.read_bytes() == (root / ('negative-' + label + '-aot.out')).read_bytes()
    print(output.read_text(), flush=True)
