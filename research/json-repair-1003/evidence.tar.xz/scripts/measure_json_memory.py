import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/workspace/scratch/89d2b70f0d89')
prep = root / 'benchmark-prep'
repo = root / 'pystachy'
config = json.loads((prep / 'config-aot.json').read_text())
clean = {k: v for k, v in os.environ.items() if not k.startswith('PYSTACHY_') and k != 'PYTHONPATH'}
os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
rows = []
witnesses = {}
for case in config['cases']:
    for variant in config['variants']:
        values = []
        for sample in range(3):
            command = [str(prep / 'rss-run')] + variant['commands'][case['probe']] + case['args'] + ['1', '3']
            result = subprocess.run(command, env=dict(clean, **variant.get('env', {})), capture_output=True, text=True, timeout=90)
            if result.returncode:
                raise RuntimeError(result.stderr)
            witness = '\n'.join(x for x in result.stdout.splitlines() if not x.startswith(('seconds ', 'warmup_seconds ')))
            if case['name'] in witnesses and witness != witnesses[case['name']]:
                raise RuntimeError('memory witness mismatch')
            witnesses[case['name']] = witness
            peak = int(next(x.split()[1] for x in result.stderr.splitlines() if x.startswith('child_peak_rss_kib ')))
            values.append(peak)
        rows.append({'case': case['name'], 'variant': variant['name'], 'peak_rss_kib': values,
                     'command': command, 'witness': witness})
        print(case['name'], variant['name'], values, flush=True)
        (prep / 'memory-results.json').write_text(json.dumps({'scope': 'whole child process maximum RSS from a fresh small C parent; includes startup, fixture, validation, three warmups and one measured batch; not retained heap',
             'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
             'launcher_sha256': hashlib.sha256((prep / 'rss_run.c').read_bytes()).hexdigest(),
             'samples': rows}, indent=2) + '\n')
