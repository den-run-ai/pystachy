import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/workspace/scratch/89d2b70f0d89')
prep = root / 'benchmark-prep'
candidate = root / 'pystachy'
base = root / 'pystachy-base'
compiler = base / 'pystachy'
probes = {'json': candidate / 'bench/json_repair/codec.py',
          'repair': candidate / 'bench/json_repair/facade.py'}
clean = {k: v for k, v in os.environ.items() if not k.startswith('PYSTACHY_') and k != 'PYTHONPATH'}
records = json.loads((prep / 'builds.json').read_text()) if (prep / 'builds.json').exists() else []
for label, home in [('base', base), ('candidate', candidate)]:
    env = dict(clean, PYSTACHY_HOME=str(home), PYSTACHY_PATH=str(home / 'ports'),
               PYSTACHY_CACHE=str(prep / ('cache-' + label)), PYSTACHY_LLVM='/usr/lib/llvm-18/bin')
    for name, source in probes.items():
        if any(row['role'] == label and row['probe'] == name and
               row['source_sha256'] == hashlib.sha256(source.read_bytes()).hexdigest() for row in records):
            continue
        binary = prep / (label + '-' + name)
        command = [str(compiler), 'build', str(source), '-o', str(binary)]
        start = time.perf_counter()
        result = subprocess.run(command, env=env, cwd=candidate, capture_output=True, text=True, timeout=180)
        row = {'role': label, 'probe': name, 'command': command, 'env': {k: v for k, v in env.items() if k.startswith('PYSTACHY_')},
               'seconds': time.perf_counter() - start, 'returncode': result.returncode, 'stderr': result.stderr}
        if result.returncode:
            raise RuntimeError(row)
        row.update(binary_bytes=binary.stat().st_size, binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                   source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
        args = ['loads', '32', '0', '1', '0'] if name == 'json' else ['malformed', '0', '1', '0']
        for mode, command in [('aot', [str(binary)]), ('jit', [str(compiler), 'run', str(source)])]:
            result = subprocess.run(command + args, env=env, cwd=candidate, capture_output=True, text=True, timeout=180)
            if result.returncode:
                raise RuntimeError(result.stderr)
            (prep / (label + '-' + name + '-' + mode + '-smoke.out')).write_text(result.stdout)
        records.append(row)
        (prep / 'builds.json').write_text(json.dumps(records, indent=2) + '\n')
        print(label, name, round(row['seconds'], 3), row['binary_bytes'], flush=True)

for engine in ('aot', 'jit'):
    for startup in (False, True):
        path = prep / ('config-' + engine + ('-startup' if startup else '') + '.json')
        config = json.loads(path.read_text())
        for variant in config['variants']:
            role = variant['name'].split('-')[0]
            variant['identity']['probe_sha256'] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in probes.values()}
            if role == 'cpython':
                variant['name'] = 'cpython'
                variant['commands'] = {k: [str(root / 'toolchains/dev/bin/python'), str(v)] for k, v in probes.items()}
            elif engine == 'jit':
                variant['commands'] = {k: [str(compiler), 'run', str(v)] for k, v in probes.items()}
        if startup:
            config['cases'] = [x for x in config['cases'] if x['name'] in ('json-small', 'repair-malformed')]
        path.write_text(json.dumps(config, indent=2) + '\n')
