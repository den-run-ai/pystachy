import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import subprocess
import time


root = Path('/workspace/scratch/89d2b70f0d89')
prep = root / 'benchmark-prep'
repo = root / 'pystachy'
config = json.loads((prep / 'config-jit.json').read_text())
spec = importlib.util.spec_from_file_location('bench', repo / 'tools/json_repair_bench.py')
bench = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)
os.sched_setaffinity(0, {0})
clean_env = {k: v for k, v in os.environ.items()
             if not k.startswith('PYSTACHY_') and k not in ('PYTHONPATH', 'PYTHONHOME')}
llvm = Path('/usr/lib/llvm-18/bin')
bindir = prep / 'profile-jit-bin'
bindir.mkdir(exist_ok=True)
for name in ('clang', 'opt', 'llvm-link', 'llvm-as'):
    path = bindir / name
    if not path.exists():
        path.symlink_to(llvm / name)
wrapper = bindir / 'lli'
wrapper.write_text('#!/bin/sh\n'
                   + shlex.quote(str(llvm / 'opt'))
                   + ' -S -passes=verify /dev/fd/9 -o "$JSONBENCH_IR" || exit $?\n'
                   + 'exec /usr/bin/valgrind --tool=callgrind '
                   + '--callgrind-out-file="$JSONBENCH_PROFILE" '
                   + shlex.quote(str(llvm / 'lli')) + ' "$@"\n')
wrapper.chmod(0o755)
variants = [v for v in config['variants'] if v['name'] in ('base-jit', 'candidate-jit')]
identities = {v['name']: bench.source_identity(v['source']) for v in variants}
report = {'scope': 'Actual default ORC lli invocation, after the driver optimizer; '
                  'subtract zero-loop instructions from measured-loop instructions. '
                  'LLVM code generation is present in each process and cancels approximately; '
                  'no runtime phase marker is used.',
          'cpu': 0, 'identities': identities, 'samples': [], 'summary': {}}
for case in [c for c in config['cases'] if c['name'] in
             ('repair-malformed', 'repair-serialize-malformed')]:
    witnesses = {}
    counts = {}
    for variant in variants:
        role = variant['name']
        counts[role] = {}
        for rounds in (0, 200):
            name = 'jit-' + case['name'] + '-' + role + '-' + str(rounds)
            profile = prep / (name + '.callgrind')
            ir = prep / (name + '.ll')
            command = variant['commands']['repair'] + case['args'][:-1] + [str(rounds), '1', '0']
            env = dict(clean_env, **variant['env'])
            env.update(PYSTACHY_LLVM=str(bindir), JSONBENCH_PROFILE=str(profile), JSONBENCH_IR=str(ir))
            started = time.perf_counter()
            result = subprocess.run(command, env=env, capture_output=True, text=True, timeout=240)
            if result.returncode:
                raise RuntimeError(f'{command}: {result.returncode}\n{result.stderr}')
            parsed = bench.parse_output(result.stdout, 1, 0)
            if rounds in witnesses and witnesses[rounds] != parsed['witness']:
                raise RuntimeError('JIT profile semantic witness mismatch')
            witnesses[rounds] = parsed['witness']
            instructions = int(next(line.split(':', 1)[1] for line in profile.read_text().splitlines()
                                    if line.startswith('summary:')))
            counts[role][rounds] = instructions
            report['samples'].append({'case': case['name'], 'role': role, 'rounds': rounds,
                                      'instructions': instructions, 'command': command,
                                      'env': {k: env[k] for k in sorted(variant['env'])},
                                      'wrapper': wrapper.read_text(), 'stdout': result.stdout,
                                      'stderr': result.stderr, 'ir_lines': len(ir.read_text().splitlines()),
                                      'ir_sha256': hashlib.sha256(ir.read_bytes()).hexdigest(),
                                      'profile_sha256': hashlib.sha256(profile.read_bytes()).hexdigest(),
                                      'instrumented_seconds': time.perf_counter() - started})
            (prep / 'jit-instruction-results.json').write_text(json.dumps(report, indent=2) + '\n')
            print(name, instructions, flush=True)
    baseline = counts['base-jit'][200] - counts['base-jit'][0]
    candidate = counts['candidate-jit'][200] - counts['candidate-jit'][0]
    report['summary'][case['name']] = {'rounds': 200,
                                     'base_incremental_instructions': baseline,
                                     'candidate_incremental_instructions': candidate,
                                     'change_percent': (candidate / baseline - 1) * 100,
                                     'whole_process': counts}
    (prep / 'jit-instruction-results.json').write_text(json.dumps(report, indent=2) + '\n')
    print(case['name'], baseline, candidate, report['summary'][case['name']]['change_percent'], flush=True)
for variant in variants:
    if identities[variant['name']] != bench.source_identity(variant['source']):
        raise RuntimeError('Source changed during JIT profiling')
