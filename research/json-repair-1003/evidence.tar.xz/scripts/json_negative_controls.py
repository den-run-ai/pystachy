# pystachy: dynamic-any
from typing import Any
from json_repair import loads, repair_json


for source in ['12345678901234567890', '-12345678901234567890',
               '{"n":12345678901234567890,"s":"\\uD83D\\uDE00"}',
               '"n":12345678901234567890}',
               '{"a": /* c */ {"b":1}}', '[/* c */12]', '[/* c */[1,2]]']:
    try:
        result: Any = repair_json(source)
        print(repr(result))
    except OverflowError:
        print("OverflowError")
for source in ['{"":12345678901234567890}', '{"n":1,"n":12345678901234567890}']:
    try:
        print(repair_json(source, strict=True))
    except ValueError:
        print("strict ValueError")
value: Any = loads('{"n":12345678901234567890,"s":"\\uD83D\\uDE00"}')
emoji: str = value["s"]
print("unicode", len(emoji), ord(emoji[0]))
try:
    value = loads("9" * 4301)
    print("digit limit", type(value).__name__, value == "")
except ValueError:
    print("digit limit ValueError")
try:
    value = loads("[" * 512 + "0" + "]" * 512, skip_json_loads=True)
    print("deep repair accepted")
except ValueError:
    print("deep repair ValueError")
