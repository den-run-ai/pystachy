import hashlib
import io
import json
from pathlib import Path
import statistics
import tarfile

root = Path('/workspace/scratch/89d2b70f0d89')
prep = root / 'benchmark-prep'
out = root / 'json-1003-evidence'
out.mkdir(exist_ok=True)
source = 'dceda23e8b71311c43e5c843698ed4443292004b'
base = '07b26e02425d023288ed95a9d2a5077be5aeb45e'
instructions = json.loads((prep / 'instruction-results.json').read_text())
aot = json.loads((prep / 'aot-results.json').read_text())
jit = json.loads((prep / 'jit-results.json').read_text())
jit_confirm = json.loads((prep / 'jit-confirm-results.json').read_text())
jit_instructions = json.loads((prep / 'jit-instruction-results.json').read_text())
memory = json.loads((prep / 'memory-results.json').read_text())
assert set(jit_instructions['summary']) == {'repair-malformed', 'repair-serialize-malformed'}
assert len(jit_instructions['samples']) == 8
ir_identity = {}
for role in ('base-jit', 'candidate-jit'):
    rows = {}
    for path in sorted(prep.glob('jit-*-' + role + '-*.ll')):
        normalized = '\n'.join(line for line in path.read_text().splitlines()
                               if not line.startswith('source_filename = '))
        rows[path.name] = hashlib.sha256(normalized.encode()).hexdigest()
    assert len(rows) == 4 and len(set(rows.values())) == 1
    ir_identity[role] = rows
(prep / 'jit-ir-identity-results.json').write_text(json.dumps({
    'normalization': 'Exclude only the LLVM source_filename line naming the driver temporary file.',
    'normalized_sha256': ir_identity,
}, indent=2) + '\n')
files = {}
for pattern in ['*-results.json', 'config-*.json', '*.callgrind', 'jit-*.ll', '*-smoke.out', '*-progress.log', 'builds.json']:
    for path in prep.glob(pattern):
        files['benchmark/' + path.name] = path
for pattern in ['replay-*.out', 'replay-*.err', 'replay-*-report.json', 'negative-*.out', 'negative-*.err']:
    for path in root.glob(pattern):
        files['validation/' + path.name] = path
for name in ['json-validation.json', 'validation-progress.log', 'focused-new.log', 'focused-rerun.log',
             'focused-existing.log', 'focused-gc.log', 'lint-recordings.log', 'base-build.log',
             'benchmark-build.log', 'benchmark-build-rerun.log', 'candidate-cpython-replay.out']:
    files['validation/' + name] = root / name
for name in ['run_json_validation.py', 'json_negative_controls.py', 'build_json_benchmarks.py',
             'profile_json_benchmarks.py', 'profile_json_jit.py', 'measure_json_memory.py',
             'prepare_json_evidence.py']:
    files['scripts/' + name] = root / name
files['scripts/rss_run.c'] = prep / 'rss_run.c'
manifest = {'candidate_source': source, 'base_source': base,
            'files': {name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                      for name, path in sorted(files.items())}}
archive = out / 'evidence.tar.xz'
with tarfile.open(archive, mode='w:xz', preset=6) as z:
    for name, path in sorted(files.items()):
        z.add(path, arcname=name, recursive=False)
    data = (json.dumps(manifest, indent=2) + '\n').encode()
    entry = tarfile.TarInfo('manifest.json')
    entry.size = len(data)
    z.addfile(entry, io.BytesIO(data))
with tarfile.open(archive) as z:
    names = z.getnames()
    assert len(names) == len(set(names)) == len(files) + 1
    for name, details in manifest['files'].items():
        data = z.extractfile(name).read()
        assert len(data) == details['bytes']
        assert hashlib.sha256(data).hexdigest() == details['sha256']
archive_sha = hashlib.sha256(archive.read_bytes()).hexdigest()

lines = [
    '# JSON-repair correctness and performance evidence for PR #1003', '',
    f'Candidate: [`{source[:8]}`](https://github.com/den-run-ai/pystachy/commit/{source}); '
    f'baseline: [`{base[:8]}`](https://github.com/den-run-ai/pystachy/commit/{base}).', '',
    'The implementation and six regression programs are byte-identical to implementation commit '
    '`94894897`. Later commits refresh documentation and correct one benchmark witness expression. '
    'This research branch preserves evidence; it is not proposed for merging.', '',
    '## Result', '',
    'The dynamic native decoder promotes an overflowing integer token directly instead of sending '
    'the entire valid document through heuristic repair. This preserves root integers, surrogate '
    'pairs, strict empty/duplicate-key behavior, nonfinite values and missing-opening-brace recovery. '
    'Integer conversion-limit errors remain visible. Object/array comments retain the following value '
    'and container nesting. Active array/object/string repair parses are bounded to 256; alternating '
    'top-level comments and prose are processed iteratively.', '',
    'The controls add essentially no AOT instructions for valid JSON and 1.65–1.78% for malformed '
    'repair, with similar whole-process memory to baseline. Longer JIT confirmation gives +4.11% '
    'for malformed object-return repair and -0.70% including serialization, with overlapping ranges. '
    'Elapsed measurements do not establish a latency improvement or zero overhead. This is fix-branch '
    'evidence, not validation of a future final alpha.4 release commit.', '',
    '## Correctness', '',
    '- The original 645-case corpus matches in adapted CPython, native JIT, native AOT, JIT with '
    'collection at every allocation and AOT with collection at every allocation. The upstream oracle was not changed.',
    '- Six new regression programs pass in both native modes with collection at every allocation: '
    '12 successful executions. They cover integer boundaries, raw-decode offsets, code points, '
    '31 digit-limit assertions, comment semantics and depth/unwinding behavior.',
    '- Existing JSON/repair selection: 24 programs, 48 JIT/AOT passes. Corrected ordinary-mode new '
    'fixtures also pass. Initial test-only compilation errors from unsupported `ord(Any)` and a typed '
    'JSONValue-to-Any conversion are retained in `focused-new.log`; later recordings use supported '
    'narrowing and preserve the same expected values.',
    '- Independent baseline/candidate probes agree between JIT and AOT in each role, and reproduce '
    'the original defects before the fix. The source and complete outputs are included.',
    '- Fresh baseline bootstrap: compiler and runtime three-stage fixed points, 775,228 and 18,805 IR lines. '
    'Local runs use that source-identical compiler with explicit baseline/candidate resource homes; '
    'the compiler and runtime source files themselves are unchanged.',
    '- Local Ruff, shellcheck, C warning/root lint, 29 JSON tool unit tests and 11 repository-hygiene '
    'unit tests pass. The full recording check checked 1,934 recordings, 110 deviations and 11 library '
    'copies, but retains one failure: unchanged `exc_except_attr` sees sandbox OSError(30) instead of '
    'FileNotFoundError(2). The fixture was not rewritten. Exact-head GitHub Lint separately passes.', '',
    '## AOT instruction controls', '',
    'LLVM/Clang 18.1.3, CPython 3.13.16, Valgrind 3.22.0, Intel Xeon Platinum 8573C, CPU 0. '
    'Each value subtracts a zero-loop process from the corresponding measured-loop process, using '
    'one batch and no warmups. Counts include the loop, checksums and its allocation/GC work; '
    'they are not wall-clock throughput or JIT instruction counts. Tiny differences can include '
    'timing-number formatting. Full Callgrind profiles and output checks are preserved.', '',
    '| Control | Rounds | Baseline instructions | Candidate instructions | Change |',
    '|---|---:|---:|---:|---:|',
]
for name, row in instructions['summary'].items():
    lines.append(f"| {name} | {row['rounds']} | {row['base_incremental_instructions']:,} | "
                 f"{row['candidate_incremental_instructions']:,} | {row['change_percent']:+.3f}% |")
lines += ['', 'The direct JSON control has 32 rows per document. Repair controls contain four inputs '
          'per round. The direct control deliberately does not import json_repair, which already '
          'opts into promoting integers and would mask an import-related effect.', '',
          '## Elapsed controls: advisory', '',
          'Processes are interleaved in rotating order and pinned to CPU 0. AOT uses five process '
          'rounds, five measured batches and six warmups; JIT uses three rounds, three batches and '
          'three warmups. Complete output is checked before and after every batch. The same adapted '
          'parser runs under CPython. These are common inputs on which baseline and candidate are '
          'both correct; the newly fixed failures are not timed as if their old wrong outputs were valid.', '',
          'Medians of process medians, milliseconds per batch:', '',
          '| Control | Baseline AOT | Candidate AOT | CPython (AOT campaign) | Baseline JIT loop | Candidate JIT loop |',
          '|---|---:|---:|---:|---:|---:|']
for name, variants in aot['summary'].items():
    v = jit['summary'][name]
    values = [variants['base-aot']['median_seconds'], variants['candidate-aot']['median_seconds'],
              variants['cpython']['median_seconds'], v['base-jit']['median_seconds'], v['candidate-jit']['median_seconds']]
    lines.append('| ' + name + ' | ' + ' | '.join(f'{x * 1000:.3f}' for x in values) + ' |')
lines += ['', 'Elapsed apparent regressions are retained, not relabelled as wins. For example, AOT '
          'malformed repair has process medians of 11.715–19.119 ms on baseline and 10.433–43.465 ms '
          'on candidate; valid repair has 2.018–4.360 ms versus 1.852–9.232 ms. This variation and the '
          'separate +1.777% instruction result do not establish a causal elapsed magnitude. '
          'The short JIT malformed samples initially suggested a larger regression: +26.4% for '
          'object returns and +14.6% including serialization. Their raw samples are preserved. '
          'They prompted the separate longer confirmation below rather than being dismissed '
          'using the AOT instruction result.', '',
          '## JIT confirmation', '',
          'The same exact source and probe were rerun sequentially, pinned to CPU 0, with two '
          'native variants in alternating order, five process pairs, five measured batches and '
          'three warmups. Each batch contains 5,000 rounds (20,000 repairs), compared with 200 '
          'rounds in the earlier campaign. No other local native benchmark ran concurrently.', '',
          '| JIT control | Baseline median ms | Candidate median ms | Change | Baseline process range ms | Candidate process range ms |',
          '|---|---:|---:|---:|---:|---:|']
for name, variants in jit_confirm['summary'].items():
    b = variants['base-jit']
    c = variants['candidate-jit']
    b_range = b['process_medians_seconds']
    c_range = c['process_medians_seconds']
    lines.append(f"| {name} | {b['median_seconds'] * 1000:.3f} | {c['median_seconds'] * 1000:.3f} | "
                 f"{(c['median_seconds'] / b['median_seconds'] - 1) * 100:+.2f}% | "
                 f"{min(b_range) * 1000:.3f}–{max(b_range) * 1000:.3f} | "
                 f"{min(c_range) * 1000:.3f}–{max(c_range) * 1000:.3f} |")
lines += ['', 'The longer controls do not reproduce the earlier 26% difference. They still show '
          'a possible modest malformed-repair cost; overlapping ranges do not prove equivalence.', '',
          'A transparent lli wrapper also captured the actual optimized JIT program and ran lli '
          'under Callgrind. The table subtracts each role’s zero-loop process from its 200-round '
          'process. This includes approximately cancelling ORC code generation as well as timed '
          'loop work; it is not an isolated hardware count or a throughput measurement. The IR '
          'is identical between the zero-loop and measured-loop process in each role after '
          'excluding only source_filename, which names the driver’s temporary file. Raw IR and '
          'normalized hashes are retained.', '',
          '| JIT control | Baseline incremental instructions | Candidate incremental instructions | Change |',
          '|---|---:|---:|---:|']
for name, row in jit_instructions['summary'].items():
    lines.append(f"| {name} | {row['base_incremental_instructions']:,} | "
                 f"{row['candidate_incremental_instructions']:,} | {row['change_percent']:+.3f}% |")
lines += ['', 'The captured baseline program has 22,491 LLVM IR lines and the candidate 22,845. '
          'Both retain the array/object/string forwarding calls; there is no evidence of a newly '
          'crossed inlining threshold. The new depth guards add fixed-width field checks and exception '
          'unwind bookkeeping; their successful hot path allocates no integer objects.', '',
          'A controlled final-release benchmark is still needed. PyPy, GraalPy and pristine-upstream '
          'comparisons were not rerun.', '', '## Startup and memory', '',
          'Zero-loop process observations include imports, fixture construction and validation. '
          'Runtime caches were prepared before JIT measurements; cold runtime-cache construction '
          'is not measured. Candidate JIT process medians were 367 ms for direct JSON and 1,486 ms '
          'for malformed repair, versus 389 and 1,430 ms on baseline (three samples). AOT process '
          'observations sit at the runner’s roughly 10 ms polling floor and do not resolve actual '
          'AOT startup latency.', '',
          'The generic Python runner initially reports an inherited launch-memory floor for short '
          'children (about 49–52 MiB); those raw results are retained but are not used below. A small '
          'fresh C parent uses wait4 to measure the child’s peak RSS without that Python-parent floor. '
          'Three runs per cell use three warmups and one measured batch. This is whole-process peak '
          'memory, including fixtures and validation, not retained heap or a long-running service test.', '',
          '| Control | Baseline AOT MiB | Candidate AOT MiB | Adapted CPython MiB |',
          '|---|---:|---:|---:|']
for name in aot['summary']:
    values = {r['variant']: statistics.median(r['peak_rss_kib']) / 1024 for r in memory['samples'] if r['case'] == name}
    lines.append(f"| {name} | {values['base-aot']:.3f} | {values['candidate-aot']:.3f} | {values['cpython']:.3f} |")
lines += ['', 'Native peak RSS stays close to baseline on these controls and exceeds CPython’s. '
          'This does not establish general memory efficiency.', '', '## Limits and release status', '',
          '- The public typed JSONValue/JSONDecoder path still checks signed 64-bit bounds. '
          'Dynamic loads/raw_decode promotes tokens and retains the 4,300-digit decimal limit.',
          '- Forced repair can discard primitive roots, including primitives surrounded by comments '
          'or prose, following upstream heuristics. Use default decoding for valid scalar documents.',
          '- The 256-active-parse policy intentionally rejects some deeper native repairs that '
          'previously completed. CPython may exhaust its interpreter stack earlier. General compiler '
          'recursion semantics and PR #996 remain separate.',
          '- The JSON-repair announcement remains held. No release was published or PR merged here.', '',
          '## Reproduction and retained files', '',
          'Use the pinned candidate and baseline commits and the maintained `bench/json_repair/codec.py`, '
          '`facade.py` and `tools/json_repair_bench.py`. The archive keeps exact command arrays, '
          'environment overrides, source/binary hashes, process samples, all Callgrind profiles, '
          'native replay output, failure logs and the small RSS launcher. Local absolute paths in '
          'the raw scripts/configurations describe this execution and should be replaced for another checkout.', '',
          'The two roles deliberately use the same freshly bootstrapped native compiler binary '
          'because compiler/runtime sources are unchanged; each role has its own PYSTACHY_HOME '
          'and runtime cache. Do not accidentally give the baseline the candidate’s library path.', '',
          f'[Download the complete evidence archive](evidence.tar.xz): {archive.stat().st_size:,} bytes, '
          f'{len(files) + 1} entries. Archive integrity, entry uniqueness and every archived file’s '
          'size/hash were checked. Each retained '
          'file has a byte size and SHA-256 in manifest.json.', '',
          f'Archive SHA-256: `{archive_sha}`.', '',
          'Exact-source GitHub CI completed with 40 successful checks and one expected fork-only '
          'DCO skip. The CI, Installation, Packages, Lint and Performance smoke workflows all '
          'succeeded. See `ci.json` for the complete check/run ledger and URLs. Maintainer review '
          'is still required before merge.', '']
(out / 'README.md').write_text('\n'.join(lines))
print(json.dumps({'archive_bytes': archive.stat().st_size, 'sha256': archive_sha, 'entries': len(files) + 1,
                  'readme_bytes': (out / 'README.md').stat().st_size}))
