import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/workspace/scratch/89d2b70f0d89')
prep = root / 'benchmark-prep'
config = json.loads((prep / 'config-aot.json').read_text())
os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
env = {k: v for k, v in os.environ.items() if not k.startswith('PYSTACHY_') and k != 'PYTHONPATH'}
rows = []
summary = {}
for case in config['cases']:
    witnesses = {}
    counts = {}
    for role in ['base', 'candidate']:
        counts[role] = {}
        for rounds in [0, int(case['args'][-1])]:
            binary = prep / (role + '-' + case['probe'])
            args = case['args'][:-1] + [str(rounds), '1', '0']
            name = case['name'] + '-' + role + '-' + str(rounds)
            profile = prep / (name + '.callgrind')
            command = ['valgrind', '--tool=callgrind', '--callgrind-out-file=' + str(profile), str(binary)] + args
            start = time.perf_counter()
            result = subprocess.run(command, env=env, capture_output=True, text=True, timeout=180)
            if result.returncode:
                raise RuntimeError(result.stderr)
            witness = '\n'.join(line for line in result.stdout.splitlines() if not line.startswith('seconds '))
            if rounds in witnesses and witnesses[rounds] != witness:
                raise RuntimeError('profile output mismatch')
            witnesses[rounds] = witness
            instructions = int(next(line.split(':', 1)[1] for line in profile.read_text().splitlines() if line.startswith('summary:')))
            counts[role][rounds] = instructions
            rows.append({'case': case['name'], 'role': role, 'rounds': rounds, 'instructions': instructions,
                         'command': command, 'stdout': result.stdout, 'stderr': result.stderr,
                         'profile_sha256': hashlib.sha256(profile.read_bytes()).hexdigest(),
                         'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
                         'instrumented_seconds': time.perf_counter() - start})
            (prep / 'instruction-results.json').write_text(json.dumps({'samples': rows, 'summary': summary}, indent=2) + '\n')
    count = int(case['args'][-1])
    base = counts['base'][count] - counts['base'][0]
    candidate = counts['candidate'][count] - counts['candidate'][0]
    summary[case['name']] = {'rounds': count, 'base_incremental_instructions': base,
                            'candidate_incremental_instructions': candidate,
                            'change_percent': (candidate / base - 1) * 100, 'whole_process': counts}
    (prep / 'instruction-results.json').write_text(json.dumps({'samples': rows, 'summary': summary}, indent=2) + '\n')
    print(case['name'], base, candidate, round(summary[case['name']]['change_percent'], 3), flush=True)
